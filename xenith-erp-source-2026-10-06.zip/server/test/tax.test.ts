// The tax a paper files is the tax its goods carry. Both halves of the shop used to take the
// figure a form typed: a bill of 5,000 of taxed ghee could file no tax at all, and the counter
// blended one percentage over dishes that carry a rate and drinks that carry none. The rate is
// now read off the product card, on the paper and at the till alike.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DAY = '';

const TAXED_SKU = 'TEST-TAX-18';
const FREE_SKU = 'TEST-TAX-NONE';
const DISH_SKU = 'TEST-TAX-DISH';
const WATER_SKU = 'TEST-TAX-WATER';

let taxed: any = {};
let untaxed: any = {};
let dish: any = {};
let water: any = {};
let counterId = 0;

// The card carries a sale rate and a purchase rate, and they are deliberately different
// figures: a vendor's bill measured off the selling rate would pass a test that proved nothing.
const taxesOf = (rates: number[]) => rates.map(r => ({ name: 'Sales Tax', rate: r }));
const product = (name: string, sku: string, price: number, saleRates: number[], buyRates: number[]) =>
  A.call('POST', '/products', {
    name, sku, unit: 'PCS', isSold: true, isPurchased: !!buyRates.length, salePrice: price,
    purchasePrice: Math.round(price * 0.6), trackInventory: false,
    saleTaxes: taxesOf(saleRates), purchaseTaxes: taxesOf(buyRates)
  });

const line = (name: string, sku: string, qty: number, price: number) =>
  ({ productName: name, sku, unit: 'PCS', quantity: qty, price, discountType: 'Percent', discountValue: 0 });

const posLine = (p: any, qty: number, discountPercent = 0) =>
  ({ productId: p.id, productName: p.name, quantity: qty, price: p.salePrice, discountPercent });

// The trial balance read on the side an account grows, so a head and its opposite can be told
// apart without caring which column the statement happened to print it in.
const signed = (name: string, list: any[]) => {
  const row = list.find(x => x.account === name);
  if (!row) return 0;
  return /Income|Liability/.test(row.type)
    ? Number(row.credit) - Number(row.debit) : Number(row.debit) - Number(row.credit);
};
const onAccount = async (name: string) =>
  signed(name, ((await A.call('GET', '/reports/trial-balance')).json?.rows) || []);

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
  taxed = (await product('Test Ghee 5kg', TAXED_SKU, 1000, [18], [5])).json;
  untaxed = (await product('Test Loose Salt', FREE_SKU, 50, [], [])).json;
  dish = (await product('Test Karahi', DISH_SKU, 1000, [18], [5])).json;
  water = (await product('Test Water', WATER_SKU, 500, [], [])).json;
  expect((await A.call('POST', '/customers', { name: 'Test Grocers' })).status).toBe(201);
  expect((await A.call('POST', '/vendors', { name: 'Test Suppliers' })).status).toBe(201);
  // A fresh book has no till set up, so the counter is opened here rather than assumed.
  const made = await A.call('POST', '/pos/counters', {
    name: 'Test Counter', warehouseId: 1, warehouseName: 'Central Warehouse (Karachi)',
    autoPrint: false, allowDiscount: true, maxDiscountPercent: 100, isActive: true
  });
  counterId = made.json?.id;
  expect(counterId).toBeTruthy();
});

describe('the tax on a paper', () => {
  const bill = (extra: object) => ({
    date: DAY, partyName: 'Test Grocers', lines: [line('Test Ghee 5kg', TAXED_SKU, 5, 1000)], ...extra
  });

  // 5 × 1,000 of goods carrying 18% is 900 of tax.
  it('cannot be filed as no tax at all', async () => {
    const r = await A.call('POST', '/saleInvoices', bill({ tax: 0 }));
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/carry 900\.00/);
    expect(r.json.error).toMatch(/files 0\.00/);
  });

  it('cannot be filed at a figure the goods do not carry', async () => {
    expect((await A.call('POST', '/saleInvoices', bill({ tax: 850 }))).status).toBe(400);
  });

  it('is accepted when it files what the goods carry', async () => {
    expect((await A.call('POST', '/saleInvoices', bill({ tax: 900 }))).status).toBe(201);
  });

  // A discount on the whole bill comes off each line in proportion, so the tax follows what the
  // customer is actually charged: 5,000 less 1,000 at 18% is 720.
  it('follows the discounted value, not the shelf price', async () => {
    expect((await A.call('POST', '/saleInvoices', bill({ discount: 1000, tax: 720 }))).status).toBe(201);
    expect((await A.call('POST', '/saleInvoices', bill({ discount: 1000, tax: 900 }))).status).toBe(400);
  });

  // A service or an unlisted line has no card to read a rate off, so the figure on the header is
  // the only reading there is and the save must be left alone.
  it('is left to its own figure when the goods carry no card', async () => {
    const r = await A.call('POST', '/saleInvoices', {
      date: DAY, partyName: 'Test Grocers', tax: 150,
      lines: [line('Test Counter Service', 'NOT-A-CARD', 2, 500)]
    });
    expect(r.status).toBe(201);
  });

  it('is measured on the purchase side too', async () => {
    const gr = await A.call('POST', '/goodReceivings', {
      date: DAY, partyName: 'Test Suppliers', lines: [line('Test Ghee 5kg', TAXED_SKU, 5, 600)]
    });
    expect(gr.status).toBe(201);
    expect((await A.call('PATCH', `/goodReceivings/${gr.json.id}/status`, { status: 'Approved' })).status).toBe(200);
    const source = (gr.json.lines || [])[0] || {};
    const billBody = (tax: number) => ({
      date: DAY, dueDate: DAY, partyName: 'Test Suppliers', tax,
      lines: [{ ...line('Test Ghee 5kg', TAXED_SKU, 5, 600), sourceNumber: gr.json.number, sourceLineId: source.id }]
    });
    // 5% of what was bought: not nothing, and not the 18% the goods will sell at.
    expect((await A.call('POST', '/purchaseBills', billBody(0))).status).toBe(400);
    expect((await A.call('POST', '/purchaseBills', billBody(540))).status).toBe(400);
    expect((await A.call('POST', '/purchaseBills', billBody(150))).status).toBe(201);
  });
});

describe('a paper raised under an older rate', () => {
  // A rule that starts today cannot make an old paper unsaveable over the figure it was raised
  // with, so a re-saved paper whose tax has not moved is left alone even when the card has.
  it('keeps its own tax while the tax on it is untouched', async () => {
    const saved = await A.call('POST', '/saleInvoices', {
      date: DAY, partyName: 'Test Grocers', tax: 900, lines: [line('Test Ghee 5kg', TAXED_SKU, 5, 1000)]
    });
    expect(saved.status).toBe(201);
    const raised = await A.call('PUT', `/products/${taxed.id}`,
      { ...taxed, saleTaxes: [{ name: 'Sales Tax', rate: 20 }] });
    expect(raised.status).toBe(200);
    const kept = await A.call('PUT', `/saleInvoices/${saved.json.id}`, {
      date: DAY, partyName: 'Test Grocers', tax: 900, status: saved.json.status,
      lines: [line('Test Ghee 5kg', TAXED_SKU, 5, 1000)]
    });
    expect(kept.status).toBe(200);
    // The moment the figure on it is changed, the card it stands on now is asked for.
    const moved = await A.call('PUT', `/saleInvoices/${saved.json.id}`, {
      date: DAY, partyName: 'Test Grocers', tax: 950, status: saved.json.status,
      lines: [line('Test Ghee 5kg', TAXED_SKU, 5, 1000)]
    });
    expect(moved.status).toBe(400);
    expect(moved.json.error).toMatch(/carry 1000\.00/);
  });
});

describe('the tax at the counter', () => {
  const sale = (extra: object) => ({
    counterId, customerName: 'Test Dine In', type: 'Sale',
    lines: [posLine(dish, 2, 50), posLine(water, 2)], ...extra
  });

  // The dish is half off, so it is charged at 1,000 and carries 180 of tax; the salt carries
  // none. The blend the screen used to send — 12% over everything — would have charged 240.
  it('is measured line by line off each card', async () => {
    const r = await A.call('POST', '/pos/bills', sale({ taxPercent: 12 }));
    expect(r.status, JSON.stringify(r.json)).toBeLessThan(300);
    expect(Number(r.json.tax)).toBe(180);
    expect(Number(r.json.grandTotal)).toBe(2180);
  });

  it('is charged even when the tender claims none', async () => {
    const r = await A.call('POST', '/pos/bills', sale({ taxPercent: 0 }));
    expect(Number(r.json.tax)).toBe(180);
  });

  it('reads the same on a plain bill of one dish', async () => {
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Take Away', type: 'Sale', taxPercent: 18,
      lines: [posLine(dish, 1)]
    });
    expect(Number(r.json.tax)).toBe(180);
    expect(Number(r.json.grandTotal)).toBe(1180);
  });

  it('lands on Tax Payable at the figure the goods carry', async () => {
    const was = await onAccount('Tax Payable');
    await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Settle', type: 'Sale',
      lines: [posLine(dish, 1)], payments: [{ mode: 'Cash', amount: 1180 }]
    });
    expect(await onAccount('Tax Payable')).toBeCloseTo(was + 180, 2);
  });
});
