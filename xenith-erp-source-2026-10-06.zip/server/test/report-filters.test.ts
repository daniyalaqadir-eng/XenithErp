// A register is cut by its main asks, not column by column: the engine gives a filter box to the
// columns that name a thing — a list to search and tick, a word to type where the column carries a
// name on every row, one pair of days beyond the window the report already strikes. Its figures
// are the answer the reader came for, so no money or quantity column is narrowed by hand. Each
// ask bites at the server, so the tiles above the table, the footer under it and the printed paper
// all read the same rows the reader is looking at.
//
// These tests hold both halves of that promise: a column's ask narrows what comes back, the asks
// the form no longer shows move nothing, and nothing else about the answer moves.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;

// A register holding no rows answers every filter question by agreeing with nothing: an empty
// loop proves nothing about the cut. The seeded book opens without paper, so the bills these asks
// bite on are raised here — over three months, at six different figures, to three customers. This
// file's server runs on its own temporary book, swept when the suite exits; nothing here can
// reach a company the reader keeps.
const SKU = 'TEST-FILTER-RICE';
const PRICE = 1000;
const PARTIES = ['Filter Alpha Traders', 'Filter Beta Traders', 'Filter Gamma Traders'];
const shiftDay = (iso: string, n: number) =>
  new Date(new Date(`${iso}T00:00:00Z`).getTime() + n * 86400000).toISOString().slice(0, 10);

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  const day = await A.today();
  expect((await A.call('POST', '/products', {
    name: 'Filter Rice 25kg', unit: 'PCS', sku: SKU, isSold: true, isPurchased: true,
    trackInventory: true, salePrice: PRICE, purchasePrice: 200,
    saleTaxes: [{ name: 'Sales Tax', rate: 18 }]
  })).status).toBe(201);
  expect((await A.call('POST', '/inventory/items', {
    name: 'Filter Rice 25kg', sku: SKU, unit: 'PCS', stockQty: 500, purchasePrice: 200, isActive: true
  })).status).toBe(201);
  for (const name of PARTIES) {
    expect((await A.call('POST', '/customers', { name })).status).toBe(201);
  }
  const bills = [
    { date: shiftDay(day, -70), qty: 1 }, { date: shiftDay(day, -60), qty: 2 },
    { date: shiftDay(day, -35), qty: 3 }, { date: shiftDay(day, -20), qty: 4 },
    { date: shiftDay(day, -10), qty: 5 }, { date: day, qty: 6 }
  ];
  for (const [i, b] of bills.entries()) {
    const raised = await A.call('POST', '/saleInvoices', {
      date: b.date, partyName: PARTIES[i % PARTIES.length],
      lines: [{
        productName: 'Filter Rice 25kg', sku: SKU, unit: 'PCS',
        quantity: b.qty, price: PRICE, discountType: 'Percent', discountValue: 0
      }],
      tax: b.qty * PRICE * 0.18
    });
    expect(raised.status, JSON.stringify(raised.json)).toBe(201);
    const filed = await A.call('PATCH', `/saleInvoices/${raised.json.id}/status`, { status: 'Approved' });
    expect(filed.status, JSON.stringify(filed.json)).toBe(200);
  }
});

const get = async (name: string, filt: Record<string, string> = {}, param: Record<string, string> = {}) => {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(param)) if (v) q.set(`param[${k}]`, v);
  for (const [k, v] of Object.entries(filt)) if (v) q.set(`filt[${k}]`, v);
  const query = q.toString();
  const res = await A.call('GET', `/reports/${name}${query ? `?${query}` : ''}`);
  expect(res.status, JSON.stringify(res.json)).toBe(200);
  return res.json;
};

const sum = (rows: any[], key: string) => rows.reduce((s, r) => s + (Number(r[key]) || 0), 0);

describe('the universal filter layer', () => {
  it('holds the papers every ask below is cut on', async () => {
    // Said outright rather than left to the register of each later test: a filter over an empty
    // book passes without ever biting, which is the one thing none of these may do.
    const all = await get('sale-invoice-report');
    expect(all.rows.length).toBeGreaterThanOrEqual(6);
    expect((all.facets ?? []).length, 'the sales register offers a box for its main columns').toBeGreaterThan(0);
  });

  it('offers a box for the columns that name a thing, and only the main asks', async () => {
    const found = await findAsk('list');
    const all = await get(found.name);
    const facets = all.facets ?? [];
    const held = new Set((all.params ?? []).map((p: any) => p.col).filter(Boolean));
    const keys = (all.columns ?? []).map((c: any) => c.key);
    const figures = (all.columns ?? [])
      .filter((c: any) => ['money', 'int', 'qty', 'pct'].includes(c.type)).map((c: any) => c.key);
    for (const f of facets) {
      // Every box belongs to a column the register actually prints, and never to one the report
      // already asks for as a parameter — the same question must not stand twice on the screen.
      expect(keys, `${f.key} is a column of ${found.name}`).toContain(f.key);
      expect(held.has(f.key), `${f.key} is already a parameter of ${found.name}`).toBe(false);
      // A figure is the answer the reader came for, not a range to type at it.
      expect(figures, `${found.name}.${f.key} is a figure column`).not.toContain(f.key);
      expect(['list', 'text', 'date']).toContain(f.kind);
      if (f.kind === 'list') {
        // The tick list is the shape of the ask whatever the book's size today — one warehouse is
        // still marked off a list. Only a column with no value at all, or one name on every row,
        // is searched by word instead.
        expect(f.options.length).toBeGreaterThanOrEqual(1);
        expect(f.options.length).toBeLessThanOrEqual(1000);
      } else {
        expect(f.options, `${f.key} carries no list to tick`).toBeUndefined();
      }
    }
    // The register's own date column is cut by its window, and one further date — a due date —
    // is as many pairs of days as the form offers. A sheet of dated boxes is not a filter, it is
    // a calendar.
    expect(facets.filter((f: any) => f.kind === 'date').length, 'one date beyond the window').toBeLessThanOrEqual(1);
  });

  it('cuts the register to the values asked for, and totals what is left standing', async () => {
    const found = await findAsk('list');
    const all = await get(found.name);
    const pickedValue = found.values[0];
    const cut = await get(found.name, { [found.facet]: pickedValue });
    expect(cut.rows.length).toBeGreaterThan(0);
    // One value of several cannot answer with the whole register.
    expect(cut.rows.length).toBeLessThan(all.rows.length);
    for (const r of cut.rows) expect(String(r[found.facet]).trim()).toBe(pickedValue);
    // The count the screen quotes is the register's own width, not the answer's.
    expect(cut.rowCount).toBe(all.rows.length);
    // A column the report sums closes over the rows kept, not over the book.
    const money = (all.columns ?? []).find((c: any) => c.type === 'money' && !(all.closingTotals ?? []).includes(c.key));
    if (money) expect(cut.totals[money.key]).toBeCloseTo(sum(cut.rows, money.key), 2);
  });

  it('keeps a ticked list to the records marked, and leaves the columns alone', async () => {
    const found = await findAsk('list');
    const two = found.values.slice(0, 2);
    expect(two.length).toBe(2);
    const cut = await get(found.name, { [found.facet]: two.join('|') });
    expect(cut.rows.length).toBeGreaterThan(0);
    for (const r of cut.rows) expect(two).toContain(String(r[found.facet]).trim());
    expect(cut.columns.map((c: any) => c.key)).toEqual((await get(found.name)).columns.map((c: any) => c.key));
  });

  it('reads a search across every column it shows', async () => {
    const found = await findAsk('list');
    const all = await get(found.name);
    const term = String(all.rows[0][found.facet] ?? '').trim();
    expect(term, 'the register answers with something to search for').toBeTruthy();
    const cut = await get(found.name, { __q: term });
    expect(cut.rows.length).toBeGreaterThan(0);
    const keys = all.columns.map((c: any) => c.key);
    for (const r of cut.rows) {
      expect(keys.some((k: string) => String(r[k] ?? '').toLowerCase().includes(term.toLowerCase()))).toBe(true);
    }
  });

  it('cuts a period on the register\'s own date column', async () => {
    const all = await get('sale-invoice-report');
    const dateKey = (all.columns ?? []).find((c: any) => c.type === 'date')?.key;
    expect(dateKey, 'the sales register shows a date column').toBeTruthy();
    const days = all.rows.map((r: any) => String(r[dateKey] ?? '')).filter((d: string) => d.length === 10).sort();
    // Six papers over three months: a window across half of them has to shut the rest out, or
    // the ask is only ever proven against an empty register.
    expect(days.length, 'the seeded papers carry dates to window').toBeGreaterThanOrEqual(2);
    const lo = days[0];
    const mid = days[Math.floor(days.length / 2)];
    const cut = await get('sale-invoice-report', { __from: lo, __to: mid });
    expect(cut.rows.length).toBeGreaterThan(0);
    expect(cut.rows.length).toBeLessThan(all.rows.length);
    for (const r of cut.rows) {
      const d = String(r[dateKey] ?? '');
      if (d.length === 10) expect(d >= lo && d <= mid, `${d} between ${lo} and ${mid}`).toBe(true);
    }
    expect(cut.rowCount).toBe(all.rows.length);
  });

  it('searches one column and only that column', async () => {
    const found = await findAsk('text');
    const all = await get(found.name);
    const term = String(all.rows[0][found.facet] ?? '').trim().slice(0, 3);
    expect(term, 'the register answers with something to search for').toBeTruthy();
    const cut = await get(found.name, { [`__cq.${found.facet}`]: term });
    expect(cut.rows.length).toBeGreaterThan(0);
    for (const r of cut.rows) {
      expect(String(r[found.facet]).toLowerCase()).toContain(term.toLowerCase());
    }
    // A second word the column does not hold answers nothing, rather than the whole book.
    const none = await get(found.name, { [`__cq.${found.facet}`]: `${term}zzz-nothing` });
    expect(none.rows.length).toBe(0);
  });

  it('leaves its figures alone, because a money column is the answer and not the ask', async () => {
    const all = await get('sale-invoice-report');
    const figures = (all.columns ?? [])
      .filter((c: any) => ['money', 'int', 'qty', 'pct'].includes(c.type)).map((c: any) => c.key);
    expect(figures.length, 'the sales register prints figures').toBeGreaterThan(0);
    // No box is offered for a figure, and one asked anyway — the shape a preset saved before this
    // trim still carries — moves neither the rows standing nor the footer closing over them.
    for (const k of figures) {
      expect((all.facets ?? []).some((f: any) => f.key === k), `${k} offers no box`).toBe(false);
    }
    const figKey = figures.find((k: string) => all.totals?.[k] !== undefined) ?? figures[0];
    const asked = await get('sale-invoice-report', { [`__rq.${figKey}`]: '1|2', [figKey]: '1|2' });
    expect(asked.rows.length).toBe(all.rows.length);
    expect(Number(asked.totals[figKey]) || 0).toBeCloseTo(Number(all.totals[figKey]) || 0, 2);
  });

  it('windows one date column between two days', async () => {
    const found = await findAsk('date');
    const all = await get(found.name);
    const days = all.rows.map((r: any) => String(r[found.facet] ?? '')).filter((d: string) => d.length === 10).sort();
    // A column nobody has dated cannot be windowed, so the ask would pass without biting.
    expect(days.length, `${found.name}.${found.facet} carries dated rows`).toBeGreaterThanOrEqual(2);
    const mid = days[Math.floor(days.length / 2)];
    const cut = await get(found.name, { [`__dq.${found.facet}`]: `${days[0]}|${mid}` });
    expect(cut.rows.length).toBeGreaterThan(0);
    expect(cut.rows.length).toBeLessThan(all.rows.length);
    for (const r of cut.rows) {
      const d = String(r[found.facet] ?? '');
      if (d.length === 10) expect(d >= days[0] && d <= mid, `${d} between ${days[0]} and ${mid}`).toBe(true);
    }
  });

  it('ignores a scoped ask naming a column the register does not show', async () => {
    const all = await get('sale-invoice-report');
    const cut = await get('sale-invoice-report', {
      '__cq.nosuchcolumn': 'abc', '__rq.nosuchcolumn': '1|2', '__dq.nosuchcolumn': '2020-01-01|2020-12-31'
    });
    expect(cut.rows.length).toBe(all.rows.length);
  });

  it('puts the rows carrying no figure away when asked', async () => {
    const all = await get('sale-invoice-report', {}, { zero: '1' });
    const cut = await get('sale-invoice-report', { __nz: '1' });
    expect(cut.rows.length).toBeLessThanOrEqual(all.rows.length);
    const moneyKeys = (all.columns ?? []).filter((c: any) => ['money', 'int', 'qty'].includes(c.type)).map((c: any) => c.key);
    for (const r of cut.rows) {
      expect(moneyKeys.some((k: string) => Math.abs(Number(r[k]) || 0) > 0), JSON.stringify(r)).toBe(true);
    }
  });

  it('leaves a statement alone, because it writes its own totals before anything narrows it', async () => {
    const all = await get('trial-balance');
    expect(all.statement).toBe(true);
    expect(all.facets, 'a statement offers no column filters').toBeFalsy();
    const asked = await get('trial-balance', { account: 'Anything', __q: 'zzz-nothing-matches', __nz: '1' });
    expect(asked.statement).toBe(true);
    // The paper keeps the same lines it always had: narrowing a statement would leave its own
    // subtotals answering for figures no longer on the page.
    expect(asked.rows.length).toBe(all.rows.length);
  });

  it('ignores a filter map that is not a map', async () => {
    const res = await A.call('GET', '/reports/sale-invoice-report?filt=nonsense');
    expect(res.status).toBe(200);
    const all = await get('sale-invoice-report');
    expect(res.json.rows.length).toBe(all.rows.length);
  });
});

// One register the seeded book can carry each of these questions on, read off the catalog rather
// than hardcoded so the test follows the book instead of failing when a demo name changes. The
// shape a column asks for has to be matched by rows that actually hold something to cut: a box
// over an empty column answers nothing, and a test on it would pass by never testing.
type Ask = { name: string; facet: string; values: string[] };
const byKind = new Map<string, Ask>();
async function findAsk(kind: 'list' | 'text' | 'date'): Promise<Ask> {
  if (byKind.has(kind)) return byKind.get(kind)!;
  const cat = await A.call('GET', '/reports');
  const names: string[] = cat.json.groups.flatMap((g: any) => g.reports.map((r: any) => r.key));
  for (const name of names) {
    const payload = await get(name);
    if (payload.statement) continue;
    const facet = (payload.facets ?? []).find((f: any) => f.kind === kind);
    const rows = payload.rows ?? [];
    if (!facet || rows.length < 2) continue;
    const cell = (r: any) => String(r[facet.key] ?? '').trim();
    // A list ask needs two values to choose between and a date ask two different days to draw a
    // window between; a search needs at least one row carrying the word in the first place.
    const ok = kind === 'list' ? facet.options.length >= 2
      : kind === 'text' ? rows.some(cell)
        : new Set(rows.map(cell).filter((d: string) => d.length === 10)).size >= 2;
    if (!ok) continue;
    const ask = { name, facet: facet.key, values: facet.options ?? [] };
    byKind.set(kind, ask);
    return ask;
  }
  throw new Error(`No seeded register offers a ${kind} column the book can be cut on`);
}
