// Every dropdown a report offers is searched and marked off, the same shape a clerk uses on the
// POS and in the registers: "these three customers", "a salesman and an order booker". The server
// says which of a register's asks may be marked, and it says it for all of them bar two — the two
// that change what the paper means rather than which records stand on it, and which are named here
// so the rule cannot quietly widen again.
//
// These tests hold that contract across the whole catalog, and then bite: a ticked list of types
// and a ticked list of statuses cut the register to exactly the rows marked, which is the shape the
// screen sends now that every record dropdown is a tick list.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;

// One account's running balance is one account's paper — the bulk register is the report that reads
// several — and the discount register's columns change meaning with its ask, so neither is marked.
const SINGLE = { 'customer-ledger': 'customer', 'discount-summary-report': 'level' };

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  const day = await A.today();
  for (const [name, type] of [['Tick Salesman', 'isSalesman'], ['Tick Bookman', 'isOrderBooker']] as [string, string][]) {
    const made = await A.call('POST', '/salesPersons', { name, [type]: true });
    expect(made.status, JSON.stringify(made.json)).toBe(201);
  }
  for (const party of ['Tick Alpha Traders', 'Tick Beta Traders']) {
    expect((await A.call('POST', '/customers', { name: party })).status).toBe(201);
  }
  expect((await A.call('POST', '/products', {
    name: 'Tick Rice 25kg', sku: 'TEST-TICK-RICE', unit: 'PCS',
    isSold: true, isPurchased: true, trackInventory: false, salePrice: 500, purchasePrice: 300
  })).status).toBe(201);
  // Three papers: one per salesman, and Beta carries a posted bill besides its draft so the
  // single-account ledger below is not proven against a book with nothing posted on it.
  for (const [party, agent, status, qty, discount] of [
    ['Tick Alpha Traders', 'Tick Salesman', 'Approved', 4, 5],
    ['Tick Beta Traders', 'Tick Bookman', 'Draft', 4, 10],
    ['Tick Beta Traders', 'Tick Bookman', 'Approved', 2, 20]
  ] as [string, string, string, number, number][]) {
    const raised = await A.call('POST', '/saleInvoices', {
      date: day, partyName: party, salesPersonName: agent,
      lines: [{
        productName: 'Tick Rice 25kg', sku: 'TEST-TICK-RICE', unit: 'PCS',
        quantity: qty, price: 500, discountType: 'Percent', discountValue: discount
      }]
    });
    expect(raised.status, JSON.stringify(raised.json)).toBe(201);
    if (status === 'Approved') {
      expect((await A.call('PATCH', `/saleInvoices/${raised.json.id}/status`, { status })).status).toBe(200);
    }
  }
});

const ask = async (name: string, param: Record<string, string> = {}) => {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(param)) if (v) q.set(`param[${k}]`, v);
  const tail = q.toString();
  const res = await A.call('GET', `/reports/${name}${tail ? `?${tail}` : ''}`);
  expect(res.status, JSON.stringify(res.json)).toBe(200);
  return res.json;
};
const cutBy = async (name: string, filt: Record<string, string>) => {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(filt)) if (v) q.set(`filt[${k}]`, v);
  const tail = q.toString();
  const res = await A.call('GET', `/reports/${name}${tail ? `?${tail}` : ''}`);
  expect(res.status, JSON.stringify(res.json)).toBe(200);
  return res.json;
};
const names = (rows: any[], col: string) =>
  [...new Set(rows.map((r: any) => String(r[col] ?? '').trim()))].sort();

describe('every report dropdown searches and ticks', () => {
  it('offers a tick list for every ask that carries choices', async () => {
    const cat = await A.call('GET', '/reports');
    expect(cat.status).toBe(200);
    const keys: string[] = cat.json.groups.flatMap((g: any) => g.reports.map((r: any) => r.key));
    expect(keys.length, 'the catalog is worth walking').toBeGreaterThan(40);
    const plain: string[] = [];
    for (const key of keys) {
      const data = await ask(key);
      for (const p of data.params ?? []) {
        if (p.kind !== 'pick' || !p.options?.length) continue;
        if (SINGLE[key] === p.key) {
          // One account's paper and one mode of the same paper: neither may be marked, because
          // two answers on one sheet is a different report rather than a narrower one. A record
          // list among them still searches, since a long book cannot be scrolled — a mode of two
          // written-out choices has no list to search.
          expect(p.multi, `${key}.${p.key} stays a single choice`).toBeFalsy();
          if (p.options.length > 2) expect(p.search, `${key}.${p.key} searches`).toBe(true);
          continue;
        }
        if (!p.multi) plain.push(`${key}.${p.key}`);
      }
    }
    expect(plain, 'dropdowns left without ticks: ' + plain.join(', ')).toEqual([]);
  });

  it('keeps the shape of an ask whose register holds no paper today', async () => {
    // Not one challan was approved on this book, so the delivery register answers with nothing —
    // and its columns still name the records the shop keeps. The reader gets the same searchable
    // tick list here as on a full sheet, rather than six empty boxes that change shape with the
    // weather, and a bill number stays a typed ask because no book closes the list of numbers it
    // will mint tomorrow.
    const empty = await ask('sales-delivery-detail-report');
    expect(empty.rows.length).toBe(0);
    const facet = (key: string) => (empty.facets ?? []).find((f: any) => f.key === key);
    expect(facet('partyName')?.kind, 'the customer column is still a list').toBe('list');
    expect(facet('partyName')?.options).toEqual(expect.arrayContaining(['Tick Alpha Traders', 'Tick Beta Traders']));
    expect(facet('productName')?.options.length).toBeGreaterThan(0);
    expect(facet('unit')?.options.length).toBeGreaterThan(0);
    expect(facet('number')?.kind, 'a bill number is typed').toBe('text');
    // Ticking a name the sheet does not carry answers empty — the honest answer to the question,
    // and not a reason to take the question away.
    const cut = await cutBy('sales-delivery-detail-report', { partyName: 'Tick Alpha Traders' });
    expect(cut.rows.length).toBe(0);

    // The same rule reads a register's own declared dropdown: a pick over a column the empty
    // sheet carries no value for is still the book's list of customers, marked several at a time.
    // Nothing has ever come back from these two traders, so the return register answers with
    // nothing — and its Customer ask still names both of them.
    const returns = await ask('sale-return-report');
    expect(returns.rows.length).toBe(0);
    const customerPick = (returns.params ?? []).find((p: any) => p.key === 'customer');
    expect(customerPick?.options, 'the declared customer pick still lists the book')
      .toEqual(expect.arrayContaining([{ value: 'Tick Alpha Traders', label: 'Tick Alpha Traders' }]));
    expect(customerPick?.multi).toBe(true);
  });

  it('reads a ticked Sales Person Type as the types marked', async () => {
    const none = await ask('sale-performance-by-sales-person-report');
    expect(names(none.rows, 'agent')).toEqual(['Tick Bookman', 'Tick Salesman']);
    const one = await ask('sale-performance-by-sales-person-report', { salesmanType: 'Salesman' });
    expect(names(one.rows, 'agent')).toEqual(['Tick Salesman']);
    // Both ticks are the same two people the register answers with when nothing is marked, and a
    // type nobody holds answers nothing rather than everything.
    const two = await ask('sale-performance-by-sales-person-report', { salesmanType: 'Salesman|Order Booker' });
    expect(names(two.rows, 'agent')).toEqual(['Tick Bookman', 'Tick Salesman']);
    const noneKept = await ask('sale-performance-by-sales-person-report', { salesmanType: 'Delivery Person' });
    expect(noneKept.rows.length).toBe(0);
  });

  it('cuts a declared dropdown to the records ticked on it', async () => {
    const all = await ask('sale-invoice-report');
    expect(names(all.rows, 'status')).toEqual(['Approved', 'Draft']);
    const one = await ask('sale-invoice-report', { status: 'Draft' });
    expect(names(one.rows, 'status')).toEqual(['Draft']);
    const both = await ask('sale-invoice-report', { status: 'Draft|Approved' });
    expect(names(both.rows, 'status')).toEqual(['Approved', 'Draft']);
    // The register's own width is quoted beside the answer, so a tick never hides how far the
    // cut reached.
    expect(both.rowCount).toBe(all.rowCount);
  });

  it('keeps the two asks that are a mode, not a record list, a single choice', async () => {
    const alpha = await ask('customer-ledger', { customer: 'Tick Alpha Traders' });
    const beta = await ask('customer-ledger', { customer: 'Tick Beta Traders' });
    expect(alpha.rows.length).toBeGreaterThan(0);
    expect(beta.rows.length).toBeGreaterThan(0);
    // Each sheet is one account's running balance, so the two papers answer apart. The tick shape
    // this ask never offers — both names at once — names no account rather than quietly merging
    // two books into a single balance line.
    expect(alpha.rows.at(-1).balance).not.toBe(beta.rows.at(-1).balance);
    const merged = await ask('customer-ledger', { customer: 'Tick Alpha Traders|Tick Beta Traders' });
    expect(merged.rows.length).toBe(0);

    // The discount register's ask renames its own first column instead of narrowing rows, so one
    // sheet never carries two meanings at once — and whichever way it reads, the discounts the
    // seeded papers carry stand on it rather than an empty table agreeing with anything.
    const discount = await ask('discount-summary-report', { level: 'product' });
    expect(discount.columns.map((c: any) => c.label)[0]).toBe('Product');
    expect(discount.rows.length).toBeGreaterThan(0);
    const byCustomer = await ask('discount-summary-report', { level: 'invoice' });
    expect(byCustomer.columns.map((c: any) => c.label)[0]).toBe('Customer');
    expect(byCustomer.rows.length).toBeGreaterThan(0);
  });
});
