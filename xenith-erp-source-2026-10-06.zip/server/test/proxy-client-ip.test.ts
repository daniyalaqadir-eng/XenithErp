// The address a request came from is a fact the server has to get right twice: the login budget
// is spent per connection, and every audit line names one. On a deployed machine nginx answers
// the socket and the customer's own address travels only in X-Forwarded-For, so a server that
// ignores that header judges forty thousand people by one counter — and believes any caller who
// writes his own address in it. This file runs with XENITH_TRUST_PROXY=1, which is what the
// deploy writes for the one nginx in front.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, SLUG, type Api } from './support/api';

process.env.XENITH_TRUST_PROXY = '1';

let A: Api;
let jar = '';

const hit = async (method: string, path: string, body?: unknown, xff?: string) => {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (jar) headers.Cookie = jar;
  if (xff) headers['X-Forwarded-For'] = xff;
  const res = await fetch(A.origin + path, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body)
  });
  const sent = res.headers.get('set-cookie');
  if (sent) jar = sent.split(';')[0];
  let json: any = null;
  try { json = await res.json(); } catch { json = null; }
  return { status: res.status, json };
};

const book = (p: string) => `/api/${SLUG}/${BRANCH}${p}`;

beforeAll(async () => {
  A = await api();
  expect((await hit('POST', '/api/auth/login', { email: 'demo@xenitherp.com', password: 'demo123' })).status).toBe(200);
});

describe('the address the audit names', () => {
  it('is the customer behind the proxy, not the proxy itself', async () => {
    const made = await hit('POST', book('/bank-accounts'),
      { accountTitle: 'Test Proxied Bank', bankName: 'Test Bank' }, '203.0.113.77');
    expect(made.status, JSON.stringify(made.json)).toBe(201);
    const log = await hit('GET', book('/settings/activity-log'));
    const line = (log.json?.data || []).find((x: any) => String(x.record).startsWith('Test Proxied Bank'));
    expect(line?.ipAddress).toBe('203.0.113.77');
  });

  it('and the machine itself when no proxy spoke for it', async () => {
    const made = await hit('POST', book('/bank-accounts'),
      { accountTitle: 'Test Direct Bank', bankName: 'Test Bank' });
    expect(made.status, JSON.stringify(made.json)).toBe(201);
    const log = await hit('GET', book('/settings/activity-log'));
    const line = (log.json?.data || []).find((x: any) => String(x.record).startsWith('Test Direct Bank'));
    expect(line?.ipAddress).toMatch(/::ffff:127\.0\.0\.1$/);
  });
});

describe('the login budget', () => {
  it('is spent by one customer, not by the whole installation', async () => {
    let blocked = 0;
    for (let i = 0; i < 50; i++) {
      const r = await hit('POST', '/api/auth/login',
        { email: `no-such-person-${i}@demo.invalid`, password: 'wrong' }, '203.0.113.7');
      if (r.status === 429) { blocked = i + 1; break; }
    }
    expect(blocked).toBeGreaterThan(30);
    // The next customer at the same door is a different connection, and gets his own forty.
    const other = await hit('POST', '/api/auth/login',
      { email: 'no-such-person-999@demo.invalid', password: 'wrong' }, '198.51.100.9');
    expect(other.status).not.toBe(429);
    // A caller who forges a list of addresses cannot land himself on a fresh one by appending a
    // second entry: with one proxy trusted, the address nginx appended is the one that counts.
    const forged = await hit('POST', '/api/auth/login',
      { email: 'no-such-person-998@demo.invalid', password: 'wrong' }, '192.0.2.5, 203.0.113.7');
    expect(forged.status).toBe(429);
  });
});
