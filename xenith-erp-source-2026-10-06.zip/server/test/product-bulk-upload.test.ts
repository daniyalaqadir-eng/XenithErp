// A client's price list is a spreadsheet, so the products screen takes one as an upload. The
// promises that make that safe are all here: the file is read by what it holds rather than by its
// name, nothing is written during the check, every row that lands goes through the same minting
// door as the ADD PRODUCT form, and a row the sheet cannot vouch for is left out with its reason
// said out loud instead of being guessed at.
import { beforeAll, describe, expect, it } from 'vitest';
import { excelBytes } from '../../client/src/utils/exportExcel';
import { api, BRANCH, type Api } from './support/api';

let A: Api;
let DAY = '';

const products = async () => (((await A.call('GET', '/products')).json?.data) || []) as any[];
const b64 = (bytes: Uint8Array) => Buffer.from(bytes).toString('base64');
const check = (file: string, name: string, apply = false) =>
  A.call('POST', '/products/bulk', { file, name, apply });

// The same header the sample file carries, written out by whichever hand the file came from.
const HEAD = 'Product Name,Unit,SKU,Sale Price,Purchase Price,Sales Tax %,Category,Track Inventory';

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
}, 120000);

describe('the sample file the screen offers', () => {
  it('names the columns and the values this company actually holds', async () => {
    const meta = (await A.call('GET', '/products/bulk-template')).json;
    expect(meta.columns.find((c: any) => c.label === 'Product Name').required).toBe(true);
    expect(meta.columns.find((c: any) => c.label === 'Unit').required).toBe(true);
    expect(meta.columns.filter((c: any) => c.required).length).toBe(2);
    expect(meta.units.length).toBeGreaterThan(3);
    expect(meta.units.every((u: any) => u.code && u.name)).toBe(true);
    expect(meta.examples.length).toBe(2);
    expect(String(meta.examples[0]['Product Name']).length).toBeGreaterThan(3);
    // Opening stock is deliberately not a column: the ledger, not the master, holds what is on
    // the shelf, and a figure here would be overwritten the first time the stock ledger is read.
    expect(meta.columns.some((c: any) => /opening stock/i.test(c.label))).toBe(false);
    expect(meta.tips.join(' ')).toMatch(/Stock Adjustment/i);
  });
});

describe('a CSV of products', () => {
  const csv = [
    HEAD,
    'Sella Basmati 5 kg,BAG,SEL-5KG,1050,780,18,,Yes',
    'Widget Loose,PCS,,250,,,,No',
    'Sack of Salt,JERRY-BIN,SLT-25,900,600,,,Yes',
    ',BAG,,100,,,,Yes',
    'Old Code Item,BAG,,100,,,,'
  ].join('\n');

  it('is checked without writing a single product', async () => {
    const before = await products();
    const r = await check(b64(Buffer.from(csv, 'utf8')), 'list.csv');
    expect(r.status).toBe(200);
    expect(r.json.applied).toBe(false);
    expect(r.json.read).toBe(5);
    expect(r.json.ready).toBe(3);
    expect(r.json.bad).toBe(2);
    const bad = r.json.rows.filter((x: any) => x.problems.length);
    expect(bad.find((x: any) => x.values['Product Name'] === 'Sack of Salt').problems.join(' ')).toMatch(/Units of Measurement/);
    expect(bad.find((x: any) => x.line === 5).problems.join(' ')).toMatch(/Product Name is empty/);
    expect(await products()).toHaveLength(before.length);
  });

  it('imports only the rows it vouched for', async () => {
    const before = await products();
    const r = await check(b64(Buffer.from(csv, 'utf8')), 'list.csv', true);
    expect(r.status).toBe(200);
    expect(r.json.applied).toBe(true);
    expect(r.json.created).toHaveLength(3);
    expect(r.json.skipped).toHaveLength(2);
    expect(r.json.skipped[0].reason).toMatch(/Units of Measurement/);
    const rows = await products();
    expect(rows).toHaveLength(before.length + 3);
    const rice = rows.find(p => p.name === 'Sella Basmati 5 kg');
    expect(rice.sku).toBe('SEL-5KG');
    // Through the same door as the form: the unit is stored as the board names it, and the tax
    // column becomes the product card's own tax line.
    expect(rice.unit).toBe('Bag/Sack');
    expect(rice.salePrice).toBe(1050);
    expect(rice.saleTaxes).toEqual([{ id: rice.saleTaxes[0].id, name: 'Sales Tax', rate: 18 }]);
    expect(rows.find(p => p.name === 'Widget Loose').trackInventory).toBe(false);
    expect(rows.find(p => p.name === 'Old Code Item').code).toMatch(/^P-\d{6}$/);
  });

  it('refuses the same file a second time rather than filing it twice', async () => {
    const before = await products();
    const r = await check(b64(Buffer.from(csv, 'utf8')), 'list.csv', true);
    expect(r.json.created).toHaveLength(0);
    expect(r.json.skipped.filter((s: any) => /SKU SEL-5KG already belongs/.test(s.reason)).length).toBe(1);
    expect(await products()).toHaveLength(before.length);
  });

  it('reads a heading under a title block, and lets the money be typed the way clerks type it', async () => {
    const money = [
      'ABC Company price list',
      'drawn up ' + DAY,
      'item name,uom,price,weight',
      'Sugar 1 kg,KG,"PKR 1,450.50",1',
      'Tea Packet,PCS,"Rs. 320/-",0.25'
    ].join('\n');
    const r = await check(b64(Buffer.from(money, 'utf8')), 'prices.csv');
    expect(r.json.read).toBe(2);
    expect(r.json.ready).toBe(2);
    expect(r.json.ignored).toEqual([]);
    // The preview follows the sheet, not this app's own column table.
    expect(r.json.columns).toEqual(['Product Name', 'Unit', 'Sale Price', 'Weight (kg)']);
    const applied = await check(b64(Buffer.from(money, 'utf8')), 'prices.csv', true);
    const sugar = (await products()).find(p => p.name === 'Sugar 1 kg');
    expect(sugar.salePrice).toBe(1450.5);
    expect(sugar.weight).toBe(1);
    // “Rs. 320/-” is one figure with a currency word and a closing dash, not 0.32 and not 320-;
    // a stray period in front of the amount was once filed as a paisa figure.
    const tea = (await products()).find(p => p.name === 'Tea Packet');
    expect(tea.salePrice).toBe(320);
    expect(applied.json.created).toHaveLength(2);
  });

  it('refuses a cell holding two figures rather than joining them', async () => {
    const two = ['Product Name,Unit,Sale Price,Reorder Level', 'Lassi 1 L,PTR,10-20,1.2.3'].join('\n');
    const r = await check(b64(Buffer.from(two, 'utf8')), 'two-figures.csv');
    const p = r.json.rows[0].problems.join(' ');
    expect(p).toMatch(/“10-20” in Sale Price is not a number/);
    expect(p).toMatch(/“1.2.3” in Reorder Level is not a number/);
  });

  it('says what a column it does not know was left out', async () => {
    const extra = ['Product Name,Unit,Shelf Colour,name', 'Lassi 1 L,PTR,yellow,' ].join('\n');
    const r = await check(b64(Buffer.from(extra, 'utf8')), 'with-extra.csv');
    expect(r.json.ignored).toEqual(['Shelf Colour']);
    // A row with nothing recognised in it is not a product, and the file says so rather than
    // inventing one from the leftovers.
    expect(r.json.read).toBe(1);
  });
});

describe('an .xlsx workbook', () => {
  const sheet = (rows: Record<string, any>[]) => b64(excelBytes({
    title: 'Products to upload',
    style: 'plain',
    columns: HEAD.split(',').map(label => ({ label, value: (r: any) => String(r[label] ?? '') })),
    rows
  }));

  it('is opened by its own parts, and the sample rows it carries are read back', async () => {
    const meta = (await A.call('GET', '/products/bulk-template')).json;
    const workbook = b64(excelBytes({
      title: 'Sample',
      style: 'plain',
      columns: meta.columns.map((c: any) => ({ label: c.label, value: (r: any) => String(r[c.label] ?? '') })),
      rows: meta.examples
    }));
    const r = await check(workbook, 'sample.xlsx');
    expect(r.status).toBe(200);
    expect(r.json.read).toBe(2);
    // The example the server wrote names a unit by its symbol; the reading resolves it to the
    // board's own name, so the sample file the client downloads really does import.
    expect(r.json.ready).toBe(2);
    expect(r.json.rows[0].values['Unit']).toBe('BAG');
    const applied = await check(workbook, 'sample.xlsx', true);
    expect(applied.json.created.map((c: any) => c.name))
      .toEqual([meta.examples[0]['Product Name'], meta.examples[1]['Product Name']]);
    // and the number it hands back is the one the products screen shows.
    const made = (await products()).find(p => p.name === meta.examples[1]['Product Name']);
    expect(made.unit).toBe('Pieces');
    expect(made.type).toBe('Services');
  });

  it('is refused when it is not a workbook', async () => {
    const text = b64(Buffer.from('this is not a workbook at all', 'utf8'));
    expect((await check(text, 'list.xlsx')).status).toBe(400);
    expect((await check(b64(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 1, 2, 3])), 'old.xls')).json.error)
      .toMatch(/old \.xls form is not read/);
    expect((await check('', 'list.csv')).json.error).toMatch(/No file arrived/);
  });

  it('keeps a product out of the book when its brand is not on the list', async () => {
    const before = await products();
    const r = await sheet([
      { 'Product Name': 'Ghee Tin', Unit: 'PCS', SKU: 'GHT-1', 'Sale Price': 1900, Category: 'Dairy', Brand: 'Karachi Gold' },
      { 'Product Name': 'Ghee Tin Two', Unit: 'PCS', SKU: 'GHT-2', 'Sale Price': 900 }
    ]);
    const checked = await check(r, 'brands.xlsx');
    expect(checked.json.ready).toBe(1);
    expect(checked.json.rows.find((x: any) => x.problems.length).problems.join(' '))
      .toMatch(/not on the Product Categories list|not on the Brands list/);
    const applied = await check(r, 'brands.xlsx', true);
    expect(applied.json.created).toHaveLength(1);
    expect(await products()).toHaveLength(before.length + 1);
  });
});

describe('the same guards the product form answers to', () => {
  it('stops a session that may not add products', async () => {
    const roles = (await A.call('GET', '/roles')).json?.data || [];
    const made = await A.call('POST', '/roles', { name: 'Bulk Clerk', permissions: ['products:view'] });
    expect(made.status).toBe(201);
    const user = await A.call('POST', '/users', {
      name: 'Bulk Clerk One', email: 'bulk.clerk@xenith.test', password: 'clerk123',
      roleId: made.json?.data?.id, branchIds: [BRANCH]
    });
    expect(user.status).toBe(201);
    const clerk = A.client();
    expect((await clerk.as('bulk.clerk@xenith.test', 'clerk123')).status).toBe(200);
    const file = b64(Buffer.from(`${HEAD}\nX Bag Of Salt,BAG,XB-1,100,,,Yes`, 'utf8'));
    expect((await clerk.call('POST', '/products/bulk', { file, name: 'x.csv' })).status).toBe(403);
    // The door is the same one the single form stands behind, so a role that cannot add one
    // product cannot add four hundred.
    expect((await clerk.call('POST', '/products', { name: 'X Bag Of Salt', unit: 'BAG' })).status).toBe(403);
    // Taken back out: no clerk of the suite is left on a book anybody else reads.
    expect((await A.call('DELETE', `/users/${user.json?.data?.id}`)).status).toBe(200);
    expect((await A.call('DELETE', `/roles/${made.json?.data?.id}`)).status).toBe(200);
  });
});
