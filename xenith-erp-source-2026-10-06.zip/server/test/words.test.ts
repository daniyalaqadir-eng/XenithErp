// The amount written out in words is the figure a cashier signs under, so it has to carry the
// paisa, the sign, and the names the local numbering uses. Before this was fixed the printed
// words dropped the paisa, hid the minus on a credit note, and wrote the word "overflow" for a
// figure the reader could still count.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';
import { amountInWords } from '../../client/src/utils/amountInWords';

let A: Api;

const words = async (n: number) =>
  (await A.call('GET', `/api/utils/number-to-words?amount=${n}`)).json?.words;

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
});

describe('the server\u2019s spelling', () => {
  it('writes a whole figure out', async () => {
    expect(await words(2360)).toBe('two thousand three hundred and sixty rupees only');
  });

  it('keeps the paisa', async () => {
    const w = await words(1234.5);
    expect(w).toContain('fifty paisa');
    expect(w).toContain('one thousand two hundred');
  });

  it('says so when the figure is a credit', async () => {
    expect(await words(-2000)).toMatch(/^minus/);
  });

  it('names a large figure rather than refusing it', async () => {
    const w = await words(1234567890);
    expect(w).not.toMatch(/overflow/i);
    expect(w).toContain('crore');
  });

  it('writes nothing as a figure', async () => {
    expect(await words(0)).toBe('zero rupees only');
  });

  it('and gives a figure under a rupee its rupees line', async () => {
    expect(await words(0.5)).toBe('zero rupees and fifty paisa only');
  });
});

// The screens spell the same reading out for the printed paper, and the two copies are held to
// the same words — a figure checked on screen and the figure signed on paper must agree.
describe('the printed spelling', () => {
  const cases: [number, string][] = [
    [2360, 'Two Thousand Three Hundred and Sixty Rupees Only'],
    [1234.5, 'One Thousand Two Hundred and Thirty Four Rupees and Fifty Paisa Only'],
    [-2000, 'Minus Two Thousand Rupees Only'],
    [0, 'Zero Rupees Only'],
    [0.5, 'Zero Rupees and Fifty Paisa Only']
  ];

  it.each(cases)('writes %s as the words beside it', (n, want) => {
    expect(amountInWords(n)).toBe(want);
  });

  it('carries the names the local numbering uses', () => {
    expect(amountInWords(1234567890)).toBe(
      'One Arab Twenty Three Crore Forty Five Lakh Sixty Seven Thousand Eight Hundred and Ninety Rupees Only');
  });

  it('is the same reading the server gives, in its own case', async () => {
    for (const [n] of cases) {
      expect(await words(n)).toBe(amountInWords(n).toLowerCase());
    }
  });
});
