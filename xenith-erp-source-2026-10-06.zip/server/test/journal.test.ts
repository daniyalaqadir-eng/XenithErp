// A journal posts to two accounts at once, so the two sides have to be one figure to the paisa
// before anything reaches the ledger — and the trial balance is where that promise is checked.
// Before this rule was enforced the server approved an entry whose sides missed by nine tenths
// of a paisa, and the chart had no statement at all that proved the book tied.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DR = '';
let CR = '';
let DAY = '';
let postableCount = 0;
let startTotal: any = { debit: 0, credit: 0 };

const entry = (status: string, lines: object[]) =>
  ({ date: DAY, memo: 'Journal suite', status, lines });
const pair = (debit: number, credit: number) => [
  { account: DR, debit, credit: 0, description: 'in' },
  { account: CR, debit: 0, credit, description: 'out' }
];
const trialBalance = async () => {
  const r = await A.call('GET', '/reports/trial-balance');
  const list = (r.json?.rows) || [];
  return { status: r.status, list, total: list.find((x: any) => x.account === 'Total') };
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  // The day the server believes it is: a paper dated by this machine's clock can land on the
  // day before the book's, and then the statement is read a day short.
  DAY = await A.today();
  const chart = (await A.call('GET', '/chart-of-accounts')).json;
  const postable = ((chart as any).data || chart || [])
    .filter((a: any) => a && !a.isGroup && a.isActive !== false && a.name);
  postableCount = postable.length;
  DR = (postable.find((a: any) => /cash|bank/i.test(a.name)) || postable[0]).name;
  CR = (postable.find((a: any) => a.name !== DR && !/cash|bank/i.test(a.name)) || postable[1]).name;
  startTotal = (await trialBalance()).total;
});

describe('a journal that does not balance', () => {
  it('is refused a paisa apart', async () => {
    const r = await A.call('POST', '/journal-entries', entry('Approved', pair(1000, 999.99)));
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/must agree/);
    // The refusal has to say what it measured, or whoever keyed the entry cannot find the slip.
    expect(r.json.error).toMatch(/1000\.00/);
    expect(r.json.error).toMatch(/999\.99/);
  });

  it('is refused by less than a paisa', async () => {
    expect((await A.call('POST', '/journal-entries', entry('Approved', pair(1000, 1000.005)))).status).toBe(400);
  });

  it('cannot be re-saved out of balance once approved', async () => {
    const saved = await A.call('POST', '/journal-entries', entry('Approved', pair(2500, 2500)));
    expect(saved.status).toBe(201);
    const off = await A.call('PUT', `/journal-entries/${saved.json.id}`, entry('Approved', pair(2500, 2499.98)));
    expect(off.status).toBe(400);
  });

  it('may still be saved one-sided as a draft, but not approved', async () => {
    const draft = await A.call('POST', '/journal-entries',
      entry('Draft', [{ account: DR, debit: 700, credit: 0 }]));
    expect(draft.status).toBe(201);
    const approve = await A.call('PATCH', `/journal-entries/${draft.json.id}/status`, { status: 'Approved' });
    expect(approve.status).toBe(400);
  });
});

describe('a journal whose paisa are keyed below the smallest coin', () => {
  it('balances on the rounded figures and keeps them', async () => {
    const r = await A.call('POST', '/journal-entries', entry('Approved', pair(1000.005, 1000.005)));
    expect(r.status).toBe(201);
    expect(r.json.totalDebit).toBe(r.json.totalCredit);
    expect(r.json.lines.every((l: any) => Number(l.debit) === 1000.01 || Number(l.credit) === 1000.01)).toBe(true);
  });
});

describe('the trial balance', () => {
  it('prints the accounts the book touched, not the whole chart', async () => {
    const { status, list } = await trialBalance();
    expect(status).toBe(200);
    expect(list.length).toBeGreaterThanOrEqual(2);
    expect(list.filter((x: any) => x.account !== 'Total').length).toBeLessThan(postableCount);
  });

  it('lays every account on one side only', async () => {
    const { list } = await trialBalance();
    const both = list.filter((x: any) => x.account !== 'Total' && Number(x.debit) && Number(x.credit));
    expect(both).toEqual([]);
  });

  it('ties on the book as this suite found it', () => {
    expect(startTotal.debit).toBe(startTotal.credit);
  });

  it('grows both columns by the same figure', async () => {
    const was = (await trialBalance()).total;
    expect((await A.call('POST', '/journal-entries', entry('Approved', pair(4000, 4000)))).status).toBe(201);
    const now = (await trialBalance()).total;
    expect(Number(now.debit)).toBeCloseTo(Number(was.debit) + 4000, 2);
    expect(Number(now.credit)).toBeCloseTo(Number(was.credit) + 4000, 2);
    expect(now.type).toBe('In balance');
  });

  // The statement and the balance sheet are read off one posting map, so an account they both
  // carry cannot answer with two different figures.
  it('holds the same assets the balance sheet carries', async () => {
    const { list } = await trialBalance();
    const sheet = (await A.call('GET', '/reports/balance-sheet')).json;
    const held = ((sheet as any).rows || []).filter((r: any) => r.section === 'Assets' && r.kind === 'leaf' && Number(r.amount));
    expect(held.length).toBeGreaterThan(0);
    // An overdrawn account sits on the opposite column, so what is compared is the signed
    // figure the two statements agree on rather than the column it happens to print in.
    const off = held.filter((a: any) => {
      const t = list.find((x: any) => x.account === a.account);
      return !t || Math.abs(Number(t.debit) - Number(t.credit) - Number(a.amount)) >= 0.005;
    });
    expect(off).toEqual([]);
  });
});
