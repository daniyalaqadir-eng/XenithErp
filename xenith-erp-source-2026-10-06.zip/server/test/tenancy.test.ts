// Two customers on one installation used to share one Users table. `mockUsers`, `mockRoles` and
// the loyalty/valuation tables were filed under the account-level scope `*` rather than as
// workspace slots, so a firm's own list was every firm's list: buyer B read buyer A's people and
// their roles, and an owner who switched a colleague off switched him off everywhere. The ids
// repeated too, so `PUT /users/1` meant whichever row the process happened to be reading.
//
// These tests hold two books side by side in one process and ask the same question of each
// formerly-shared table: does what I write here appear there?
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, SLUG, type Api, type Client } from './support/api';

const VENDOR_NAME = 'xenith-vendor';
const VENDOR_KEY = 'vendor-desk-key-3';

// Read before the server module loads, because the vendor is taken from the environment once at
// boot; the second firm can only be opened by the hand that sells.
process.env.XENITH_VENDOR_USER = VENDOR_NAME;
process.env.XENITH_VENDOR_PASSWORD = VENDOR_KEY;
process.env.XENITH_VENDOR_NAME = 'Vendor';

let A: Api;              // the seeded company
let V: Client;           // the vendor
let B: Client;           // the second company's own owner
let slugB = '';
let branchB = 0;

const OWNER_B = {
  name: 'Second Owner', email: 'shared.name@firm-b.test', username: 'shared.name',
  password: 'both-books-key-9'
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  V = A.client();
  expect((await V.as(VENDOR_NAME, VENDOR_KEY)).status).toBe(200);

  const made = await V.call('POST', '/settings/companies', {
    name: 'Isolation Firm', typeOfOrganization: 'Retail',
    ownerName: OWNER_B.name, ownerEmail: OWNER_B.email,
    ownerUsername: OWNER_B.username, ownerPassword: OWNER_B.password
  });
  expect(made.status, JSON.stringify(made.json)).toBe(201);
  slugB = String(made.json?.slug);

  B = A.client();
  const inB = await B.as(OWNER_B.email, OWNER_B.password);
  expect(inB.status, JSON.stringify(inB.json)).toBe(200);
  expect(inB.json?.user?.companySlug).toBe(slugB);
  branchB = Number(inB.json?.user?.branchIds?.[0]);
  expect(branchB).toBeTruthy();
  // The books are named differently, and the branch id is not the seeded one.
  expect(slugB).not.toBe(SLUG);
  expect(branchB).not.toBe(BRANCH);
});

afterAll(() => {
  delete process.env.XENITH_VENDOR_USER;
  delete process.env.XENITH_VENDOR_PASSWORD;
  delete process.env.XENITH_VENDOR_NAME;
});

const rowsOf = (json: any) => (json?.data || []) as any[];

describe('two firms on one installation', () => {
  it('starts each book with its own people, and nobody else\u2019s', async () => {
    const inA = await A.call('GET', '/users');
    const inB = await B.call('GET', '/users');
    expect(inA.status).toBe(200);
    expect(inB.status).toBe(200);

    const emailsA = rowsOf(inA.json).map(u => String(u.email).toLowerCase());
    const emailsB = rowsOf(inB.json).map(u => String(u.email).toLowerCase());

    // The second firm was seeded from the first one's shape, so its own people are its own:
    // one row, the owner the vendor named.
    expect(emailsB).toEqual([OWNER_B.email]);
    expect(emailsA).toContain('demo@xenitherp.com');
    expect(emailsA).not.toContain(OWNER_B.email);
    expect(emailsB).not.toContain('demo@xenitherp.com');
  });

  it('keeps a user written in one book out of the other', async () => {
    const before = rowsOf((await B.call('GET', '/users')).json).length;
    const added = await A.call('POST', '/users', {
      name: 'Firm A Clerk', email: 'clerk@firm-a.test', password: 'clerk-key-9',
      roleId: 1, branchIds: [BRANCH]
    });
    expect(added.status, JSON.stringify(added.json)).toBe(201);

    expect(rowsOf((await A.call('GET', '/users')).json).map(u => u.email)).toContain('clerk@firm-a.test');
    const after = rowsOf((await B.call('GET', '/users')).json);
    expect(after.length).toBe(before);
    expect(after.map(u => String(u.email))).not.toContain('clerk@firm-a.test');
  });

  it('and the same for a role, which used to be one table for everyone', async () => {
    const made = await A.call('POST', '/roles', {
      name: 'Firm A Only', permissions: ['users:view']
    });
    expect(made.status, JSON.stringify(made.json)).toBe(201);

    const namesA = rowsOf((await A.call('GET', '/roles')).json).map(r => r.name);
    const namesB = rowsOf((await B.call('GET', '/roles')).json).map(r => r.name);
    expect(namesA).toContain('Firm A Only');
    expect(namesB).not.toContain('Firm A Only');
    // Both books still carry the built-in seat, so each firm can staff itself.
    expect(namesB.length).toBeGreaterThan(0);
  });

  it('and for the loyalty ledger, the adjustment types and the valuations', async () => {
    const type = await A.call('POST', '/adjustment-types', { name: 'Firm A Write-off', affects: 'Stock' });
    expect(type.status, JSON.stringify(type.json)).toBe(201);
    const inA = rowsOf((await A.call('GET', '/adjustment-types')).json).map(t => t.name);
    const inB = rowsOf((await B.call('GET', '/adjustment-types')).json).map(t => t.name);
    expect(inA).toContain('Firm A Write-off');
    expect(inB).not.toContain('Firm A Write-off');
  });

  it('treats a repeated id as two different people', async () => {
    // Both owners are id 1 in their own book: the number means nothing without the firm beside it.
    expect(rowsOf((await A.call('GET', '/users')).json).find(u => u.id === 1)?.email).toBe('demo@xenitherp.com');
    expect(rowsOf((await B.call('GET', '/users')).json).find(u => u.id === 1)?.email).toBe(OWNER_B.email);

    const renamed = await B.call('PUT', '/users/1', { name: 'Renamed In B' });
    expect(renamed.status, JSON.stringify(renamed.json)).toBe(200);
    expect(rowsOf((await B.call('GET', '/users')).json).find(u => u.id === 1)?.name).toBe('Renamed In B');
    expect(rowsOf((await A.call('GET', '/users')).json).find(u => u.id === 1)?.name)
      .not.toBe('Renamed In B');
  });

  it('refuses a session that asks for the other firm by address', async () => {
    // The wording says "not registered" on purpose: a different answer would tell a caller which
    // firm names exist on this installation.
    const aIntoB = await A.call('GET', `/api/${slugB}/${branchB}/users`);
    expect(aIntoB.status).toBe(404);
    const bIntoA = await B.call('GET', `/api/${SLUG}/${BRANCH}/users`);
    expect(bIntoA.status).toBe(404);
    // Neither answer carries a name from the book it refused.
    expect(JSON.stringify(aIntoB.json)).not.toMatch(/demo@xenith|Firm A Clerk/);
    expect(JSON.stringify(bIntoA.json)).not.toMatch(/demo@xenith|Firm A Clerk/);
    // While their own book stays open to each of them.
    expect((await A.call('GET', '/users')).status).toBe(200);
    expect((await B.call('GET', '/users')).status).toBe(200);
  });

  it('shows a firm only itself in the switch list', async () => {
    const mine = await B.call('GET', '/settings/companies');
    expect(mine.status).toBe(200);
    expect(rowsOf(mine.json).map(c => c.slug)).toEqual([slugB]);
    const theirs = await A.call('GET', '/settings/companies');
    expect(rowsOf(theirs.json).map(c => c.slug)).toEqual([SLUG]);
  });

  it('will not guess a firm for a name that signs in at two of them', async () => {
    // The same person, the same key, in both books. The seed's owner signs in as `muhammad`, so
    // this row takes that username in the first firm and the second one already holds it.
    const twin = await A.call('POST', '/users', {
      name: 'Twin At Firm A', email: 'shared.name@firm-a.test', username: 'shared.name',
      password: OWNER_B.password, roleId: 1, branchIds: [BRANCH]
    });
    expect(twin.status, JSON.stringify(twin.json)).toBe(201);

    const guessing = await A.client().as('shared.name', OWNER_B.password);
    expect(guessing.status).toBe(409);
    expect(String(guessing.json?.error)).toMatch(/company code/i);

    const inB = await A.client().as('shared.name', OWNER_B.password, slugB);
    expect(inB.status, JSON.stringify(inB.json)).toBe(200);
    expect(inB.json?.user?.companySlug).toBe(slugB);

    const inA = await A.client().as('shared.name', OWNER_B.password, SLUG);
    expect(inA.status, JSON.stringify(inA.json)).toBe(200);
    expect(inA.json?.user?.companySlug).toBe(SLUG);

    // A code that names no firm is turned away at the door, not searched for.
    expect((await A.client().as('shared.name', OWNER_B.password, 'no-such-firm')).status).toBe(401);
  });

  it('answers a session read with the roles of that person\u2019s own firm', async () => {
    // /api/auth/* sits outside the tenant gate, so the book has to come from the key itself.
    const jar = A.client();
    expect((await jar.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
    const asA = await jar.call('GET', '/api/auth/session');
    expect(asA.json?.user?.companySlug).toBe(SLUG);

    expect((await B.as(OWNER_B.email, OWNER_B.password)).status).toBe(200);
    const asB = await B.call('GET', '/api/auth/session');
    expect(asB.json?.user?.companySlug).toBe(slugB);
    // The role the session reports is the one in that book, so the menu the client builds is its
    // own firm's, whichever company the last request happened to open.
    expect(asB.json?.user?.permissions?.length).toBeGreaterThan(0);
    expect(asB.json?.user?.id).toBe(1);
    expect(asA.json?.user?.id).toBe(1);
  });
});
