// The person who sells this software cannot be a row inside the book he sells. While he is one,
// his name stands in the buyer's Users list, the buyer's own Administrator can edit or switch him
// off, and the password the seed carries is a master key that comes with every copy. So the vendor
// comes from the environment: he signs in against a name no database holds, no route lists, and no
// setting inside a company can change — and the sale of a company is his act, not the buyer's.
//
// The two environment keys are written before the API is imported, because the vendor is read once
// when the server module loads; they are taken back out afterwards so the files that run after this
// one boot under the desktop rule, exactly as they did before.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, type Api, type Client } from './support/api';

const VENDOR_NAME = 'xenith-vendor';
const VENDOR_KEY = 'vendor-desk-key-7';

process.env.XENITH_VENDOR_USER = VENDOR_NAME;
process.env.XENITH_VENDOR_PASSWORD = VENDOR_KEY;
process.env.XENITH_VENDOR_NAME = 'Vendor';

let A: Api;         // the company's own owner, the row that used to be the seller
let V: Client;      // the vendor, who is not in any book
let allModules: string[] = [];

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  const got = await A.call('GET', '/license');
  expect(got.status).toBe(200);
  allModules = (got.json?.data?.modules || []).map((m: any) => m.key);
  V = A.client();
  expect((await V.as(VENDOR_NAME, VENDOR_KEY)).status).toBe(200);
});

afterAll(() => {
  delete process.env.XENITH_VENDOR_USER;
  delete process.env.XENITH_VENDOR_PASSWORD;
  delete process.env.XENITH_VENDOR_NAME;
});

describe('the vendor signs in without being in anybody\u2019s book', () => {
  it('is answered by the environment, and says what it is', async () => {
    const fresh = A.client();
    const r = await fresh.as(VENDOR_NAME, VENDOR_KEY);
    expect(r.status).toBe(200);
    expect(r.json?.user?.isVendor).toBe(true);
    // The buyer sees a job title, not the person behind it.
    expect(r.json?.user?.name).toBe('Vendor');
  });

  it('turns a wrong key away at the same door', async () => {
    const r = await A.client().as(VENDOR_NAME, 'not-the-key');
    expect(r.status).toBe(401);
  });

  it('is never listed among the users of the company he is configuring', async () => {
    const users = await A.call('GET', '/users');
    expect(users.status).toBe(200);
    const rows = users.json?.data || [];
    expect(rows.some((u: any) => u.isVendor)).toBe(false);
    expect(rows.some((u: any) => String(u.username).toLowerCase() === VENDOR_NAME)).toBe(false);
    expect(rows.some((u: any) => u.id === 0)).toBe(false);
  });

  it('cannot be added, renamed into or edited from inside a book', async () => {
    // The name is refused where it is written, because a row holding it could never sign in.
    const imposter = await A.call('POST', '/users', {
      name: 'Vendor Copy', email: 'vendor.copy@xenith.test', username: VENDOR_NAME,
      password: 'copy123', roleId: 1, branchIds: [38039]
    });
    expect(imposter.status, JSON.stringify(imposter.json)).toBe(400);
    // And id 0 belongs to no row, so there is nothing for a buyer to switch off.
    expect((await A.call('PUT', '/users/0', { isActive: false })).status).toBe(404);
    expect((await A.call('DELETE', '/users/0')).status).toBe(404);
  });

  it('leaves the company\u2019s own list exactly as it found it', async () => {
    const users = await A.call('GET', '/users');
    expect(users.json?.total).toBe(users.json?.data?.length);
  });
});

describe('the sale of a company moved outside the company', () => {
  it('refuses the owner who holds every tick, because the wall is his to stand behind, not move', async () => {
    const r = await A.call('PUT', '/license', { modules: ['dashboard', 'setup'] });
    expect(r.status, JSON.stringify(r.json)).toBe(403);
    expect(String(r.json?.error)).toMatch(/vendor/i);
  });

  it('answers the vendor, who can hold a module back', async () => {
    const r = await V.call('PUT', '/license', { modules: allModules.filter(k => k !== 'pos') });
    expect(r.status, JSON.stringify(r.json)).toBe(200);
  });

  it('and the held module is a wall for the buyer and a door for him', async () => {
    expect((await A.call('GET', '/pos/counters')).status).toBe(403);
    expect((await V.call('GET', '/pos/counters')).status).toBeLessThan(300);
  });

  it('hands the whole sale back when the vendor says so', async () => {
    expect((await V.call('PUT', '/license', { modules: allModules })).status).toBe(200);
    expect((await A.call('GET', '/pos/counters')).status).toBeLessThan(300);
  });

  it('shows the buyer a plan he cannot edit, and only his own company', async () => {
    const mine = await A.call('GET', '/license');
    expect(mine.json?.data?.canSetSale).toBe(false);
    expect(mine.json?.data?.companies?.length).toBe(1);
    expect(mine.json?.data?.companies[0]?.slug).toBe('abc-company679');

    const asVendor = await V.call('GET', '/license');
    expect(asVendor.json?.data?.canSetSale).toBe(true);
  });

  it('says the same thing on the address the menu reads', async () => {
    expect((await A.call('GET', '/api/abc-company679/38039/tenant-info')).json?.canSetSubscription).toBe(false);
    expect((await V.call('GET', '/api/abc-company679/38039/tenant-info')).json?.canSetSubscription).toBe(true);
  });
});

describe('opening a company', () => {
  it('is the vendor\u2019s act as well', async () => {
    const byOwner = await A.call('POST', '/settings/companies', { name: 'Owner Own Firm', typeOfOrganization: 'Retail' });
    expect(byOwner.status, JSON.stringify(byOwner.json)).toBe(403);
    expect((await A.call('PUT', '/settings/companies/active', { slug: 'abc-company679' })).status).toBe(403);
  });

  // What a buyer would otherwise do to himself: register a firm of his own, which the licence
  // table has never heard of, and find the whole product switched on inside it.
  it('starts a new book at the two modules that keep it able to sign in, not at the whole product', async () => {
    const made = await V.call('POST', '/settings/companies', {
      name: 'Vendor Opened Firm', typeOfOrganization: 'Retail',
      ownerName: 'Second Buyer', ownerEmail: 'second@buyer.test', ownerPassword: 'second-buyer-key-9'
    });
    expect(made.status, JSON.stringify(made.json)).toBe(201);
    // The credentials are named back but the password is not: it went in through this request
    // and echoing it would leave it in the browser's network log.
    expect(made.json?.owner?.email).toBe('second@buyer.test');
    expect(made.json?.owner?.password).toBeUndefined();
    const lic = await V.call('GET', `/api/${made.json?.slug}/38039/license`);
    expect(lic.json?.data?.license?.modules).toEqual(['dashboard', 'setup']);
    expect((await V.call('GET', `/api/${made.json?.slug}/38039/pos/counters`)).status).toBeLessThan(300);
    // and the vendor can sell it the till on the spot
    expect((await V.call('PUT', '/license', { slug: made.json?.slug, modules: allModules })).status).toBe(200);
    expect((await V.call('GET', `/api/${made.json?.slug}/38039/pos/counters`)).status).toBeLessThan(300);
  });

  it('is a book of its own: its people, its sign-in and its sale', async () => {
    const made = await V.call('POST', '/settings/companies', {
      name: 'Second Firm', typeOfOrganization: 'Retail',
      ownerName: 'Other Owner', ownerEmail: 'other@firm.test', ownerPassword: 'other-firm-key-4'
    });
    expect(made.status, JSON.stringify(made.json)).toBe(201);
    const slug = String(made.json?.slug);
    const B = A.client();
    const signedIn = await B.as('other@firm.test', 'other-firm-key-4');
    expect(signedIn.status, 'the new owner signs in').toBe(200);
    // The session says whose firm it is, which is how the client stops guessing it from a
    // company name written into its own source.
    expect(signedIn.json?.user?.companySlug).toBe(slug);
    // He is an owner inside his own firm and nothing anywhere else.
    expect((await B.call('GET', '/users')).status).toBe(200);
    expect((await B.call('GET', '/users')).json?.data?.map((u: any) => u.email)).toEqual(['other@firm.test']);
    // The till was not sold to him, so the wall he meets is his own subscription.
    expect((await B.call('PUT', '/license', { modules: allModules })).status).toBe(403);
    // And the first firm\u2019s owner cannot reach into this one at all — answered the same way
    // as a name that was never installed, so a wrong slug teaches nobody what else is on the box.
    const cross = await A.call('GET', `/api/${slug}/38039/users`);
    expect(cross.status).toBe(404);
    expect(String(cross.json?.error)).not.toMatch(/Other Owner|other@firm/);
    // Reading his own list still works, so the 404 above is the wall and not a broken route.
    expect((await A.call('GET', '/users')).status).toBe(200);
  });

  it('refuses the seeded password on a company sold by a vendor', async () => {
    const r = await V.call('POST', '/settings/companies', { name: 'No Key Firm', typeOfOrganization: 'Retail' });
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(String(r.json?.error)).toMatch(/password/i);
  });

  it('is not a name the buyer\u2019s own switch list gets to read', async () => {
    const all = await V.call('GET', '/settings/companies');
    expect((all.json?.data || []).length).toBeGreaterThan(2);
    const byOwner = await A.call('GET', '/settings/companies');
    expect((byOwner.json?.data || []).map((c: any) => c.slug)).toEqual(['abc-company679']);
    const byOther = await A.client();
    expect((await byOther.as('other@firm.test', 'other-firm-key-4')).status).toBe(200);
    expect((await byOther.call('GET', '/settings/companies')).json?.data?.map((c: any) => c.slug))
      .toEqual(expect.arrayContaining([expect.stringMatching(/^second-firm/)]));
  });
});

describe('the vendor\u2019s own hand in the audit line', () => {
  it('is written as a job, not as the person behind the software', async () => {
    const audit = await A.call('GET', '/settings/activity-log');
    expect(audit.status).toBe(200);
    const rows = audit.json?.data || [];
    const sale = rows.find((r: any) => String(r.screen) === 'Subscription');
    expect(sale).toBeTruthy();
    expect(sale.user).toBe('Vendor');
    expect((audit.json?.users || []).filter((u: string) => /vendor/i.test(u))).toEqual(['Vendor']);
  });

  it('has no profile to edit and no password to change from the screen', async () => {
    expect((await V.call('POST', '/api/auth/change-password', { currentPassword: VENDOR_KEY, newPassword: 'another-key' })).status).toBe(400);
    expect((await V.call('PUT', '/api/auth/profile', { name: 'Renamed Vendor' })).status).toBe(400);
    // The key still opens the door afterwards, because nothing was written anywhere.
    expect((await A.client().as(VENDOR_NAME, VENDOR_KEY)).status).toBe(200);
  });
});
