// The sale is measured at the API. The licence used to trim only the menus a buyer was shown:
// every route of a module he never bought still answered any role whose tick sheet happened to
// name it — the owner's own chair included, which is the one seat the filter was written for.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, type Api, type Client } from './support/api';

let A: Api;
let allModules: string[] = [];
let allScreens: string[] = [];

const bankAccount = (title: string) => ({
  accountTitle: title, bankName: 'Test Bank', accountNumber: '', openingBalance: 0
});

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  const got = await A.call('GET', '/license');
  expect(got.status).toBe(200);
  allModules = (got.json?.data?.modules || []).map((m: any) => m.key);
  allScreens = [...got.json?.data?.licensedScreens].sort();
  expect(allModules.length).toBeGreaterThan(4);
});

describe('a module the company never bought', () => {
  const held = ['pos', 'hr', 'manufacturing', 'weekly-route'];

  beforeAll(async () => {
    const r = await A.call('PUT', '/license', { modules: allModules.filter(k => !held.includes(k)) });
    expect(r.status, JSON.stringify(r.json)).toBe(200);
  });
  afterAll(async () => {
    expect((await A.call('PUT', '/license', { modules: allModules })).status).toBe(200);
  });

  it.each([
    ['the till', '/pos/counters'], ['its goods', '/pos/products'], ['a sale at it', '/pos/bills'],
    ['the payroll desk', '/hr/employees'], ['the plant', '/manufacturing/items'],
    ['the delivery plan', '/weekly-routes']
  ])('answers 403 to %s', async (_what, path) => {
    const r = await A.call('GET', path);
    expect(r.status, JSON.stringify(r.json)).toBe(403);
    expect(String(r.json?.error)).toMatch(/subscription/);
  });

  it('and to the money a till would post', async () => {
    const r = await A.call('POST', '/pos/bills', { counterId: 1, lines: [], type: 'Sale' });
    expect(r.status).toBe(403);
  });

  it('holds even the owner, who is the one person the menu filter never hid anything from', async () => {
    expect((await A.call('GET', '/hr/salary-sheets')).status).toBe(403);
  });

  it('while the modules that were bought stay open', async () => {
    for (const p of ['/products', '/bank-accounts', '/chart-of-accounts', '/reports']) {
      const r = await A.call('GET', p);
      expect(r.status, `${p}: ${JSON.stringify(r.json)}`).toBeLessThan(300);
    }
  });

  it('is measured against the address asked, not the book that happens to be open', async () => {
    // One company survives on this installation (§23b prunes the seeded demo directories), and
    // the company directory itself lives inside each book, so a second address has no rows to
    // answer from — the gate reads the licence of the slug in the URL before any route runs.
    const ghost = await A.call('GET', `/api/not-a-company-at-all/${BRANCH}/pos/counters`);
    expect(ghost.status).toBe(404);
    expect(String(ghost.json?.error)).toMatch(/installation/);
  });
});

describe('a feature held back inside a module that was bought', () => {
  let bankClerk: Client;

  beforeAll(async () => {
    const role = await A.call('POST', '/roles', {
      name: 'Test Bank Clerk', permissions: ['bank-accounts:view', 'bank-accounts:add']
    });
    expect(role.status, JSON.stringify(role.json)).toBe(201);
    const user = await A.call('POST', '/users', {
      name: 'Test Bank Clerk One', email: 'test.bank.clerk@xenith.test', password: 'bank123',
      roleId: role.json?.data?.id, branchIds: [BRANCH]
    });
    expect(user.status, JSON.stringify(user.json)).toBe(201);
    bankClerk = A.client();
    expect((await bankClerk.as('test.bank.clerk@xenith.test', 'bank123')).status).toBe(200);
    // The tick is on the role, and the register is sold, so the door is open.
    expect((await bankClerk.call('POST', '/bank-accounts', bankAccount('Test Held Account'))).status).toBe(201);
  });

  it('shuts for the role that still holds the tick, and for the owner too', async () => {
    const heldBack = await A.call('PUT', '/license', { screens: allScreens.filter(k => k !== 'bank-accounts') });
    expect(heldBack.status, JSON.stringify(heldBack.json)).toBe(200);
    expect((await A.call('GET', '/permissions')).json?.data?.screens
      .some((s: any) => s.key === 'bank-accounts')).toBe(false);

    const byClerk = await bankClerk.call('POST', '/bank-accounts', bankAccount('Test Clerk Try'));
    expect(byClerk.status, JSON.stringify(byClerk.json)).toBe(403);
    // The owner answers 403 as well: a feature the buyer was not sold is not the seller's to use
    // either, and this is the case the menu alone could not cover.
    expect((await A.call('POST', '/bank-accounts', bankAccount('Test Owner Try'))).status).toBe(403);

    expect((await A.call('PUT', '/license', { screens: null })).status).toBe(200);
    expect((await bankClerk.call('POST', '/bank-accounts', bankAccount('Test Sold Again'))).status).toBe(201);
  });

  it('is not a wall a clerk can move himself', async () => {
    const r = await bankClerk.call('PUT', '/license', { modules: ['dashboard', 'setup'] });
    expect(r.status, JSON.stringify(r.json)).toBe(403);
    // Nothing changed on the way through the refusal.
    expect((await A.call('GET', '/pos/counters')).status).toBeLessThan(300);
    expect((await bankClerk.call('POST', '/bank-accounts', bankAccount('Test After Refusal'))).status).toBe(201);
  });
});
