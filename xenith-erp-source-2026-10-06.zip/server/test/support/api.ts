// One API and one book per test file. Vitest gives every file a fresh module registry, so this
// boots the server again for each one — the slow price of the server holding a company's whole
// ledger in module memory, and the reason a suite cannot share one book between two files and
// expect either of them to find its own rows. The book is a fresh seed in a temporary directory
// under the OS temp folder: nothing here can reach server/data, where the live customer sits.
import { mkdtempSync, readdirSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

// The seeded company and its one branch, the same pair the screens open on.
export const SLUG = 'abc-company679';
export const BRANCH = 38039;

// Every file registers its book on one shared list, and one exit handler sweeps the lot. A
// handler per file would be eleven of each of the process's listeners in a single fork, and node
// answers that with a memory-leak warning for a suite that is meant to do exactly that.
const sweep = (() => {
  const g = globalThis as any;
  if (!g.__xenithSuiteBooks) {
    g.__xenithSuiteBooks = [];
    process.on('exit', () => g.__xenithSuiteBooks.forEach((d: string) => rmSync(d, { recursive: true, force: true })));
    // The server answers a crash of the process with a handler of its own, so eleven servers in
    // one fork is eleven handlers and node calls that a leak. It is the shape of the suite, not
    // of the code under test.
    process.setMaxListeners(0);
  }
  return g.__xenithSuiteBooks as string[];
})();

// Vitest stops this fork with a signal rather than letting it finish, so the handler above
// usually never runs and every run leaves another book behind in the OS temp folder — close to
// a gigabyte after a few days of them. A run therefore opens by sweeping what the last ones
// abandoned; an hour is old enough that a second suite running alongside is untouched, and a
// book somebody is still holding simply refuses to delete.
const sweepAbandonedBooks = () => {
  const cut = Date.now() - 60 * 60 * 1000;
  let left: string[] = [];
  try { left = readdirSync(tmpdir()); } catch { return; }
  left.filter(n => /^xenith-(suite|store)-/.test(n)).forEach(n => {
    const dir = join(tmpdir(), n);
    try { if (statSync(dir).mtimeMs < cut) rmSync(dir, { recursive: true, force: true }); } catch { /* still held */ }
  });
};
sweepAbandonedBooks();

const bookDir = mkdtempSync(join(tmpdir(), 'xenith-suite-'));
sweep.push(bookDir);
process.env.XENITH_DB = join(bookDir, 'book.db');
process.env.XENITH_FRESH = '1';
// The suite measures the code, not the teaching set: a start-up that filled the book would put
// ninety days of sample trading into every test that counts rows.
process.env.XENITH_DEMO_DATA = '0';
delete process.env.XENITH_DB_OFF;

export interface Reply { status: number; json: any }

// A client is one session cookie. The permission tests need two jars side by side — the whole
// point is what a second, lesser session may not do — so the jar belongs to the client rather
// than to the server.
export interface Client {
  call: (method: string, path: string, body?: unknown) => Promise<Reply>;
  /** Sign this jar in, forgetting whoever it was holding before. A company code is only needed
   *  when the same name signs in at more than one firm on the installation. */
  as: (email: string, password: string, company?: string) => Promise<Reply>;
}

export interface Api extends Client {
  origin: string;
  api: string;
  /** The day the server itself believes it is — Karachi, not this machine's clock. */
  today: () => Promise<string>;
  client: () => Client;
}

let started: Promise<Api> | null = null;

const boot = async (): Promise<Api> => {
  const { listen } = await import('../../src/index');
  const { port } = await listen(0);
  const origin = `http://127.0.0.1:${port}`;
  const jar = (): Client => {
    let cookie = '';
    // Relative paths are sent to this company. It starts on the seeded book and moves to
    // whichever one a sign-in answers, which is what the real client does with the payload too.
    let slug = SLUG;
    const call = async (method: string, path: string, body?: unknown): Promise<Reply> => {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cookie) headers.Cookie = cookie;
      const res = await fetch(path.startsWith('/api') ? origin + path : `${origin}/api/${slug}/${BRANCH}${path}`, {
        method, headers, body: body === undefined ? undefined : JSON.stringify(body)
      });
      const sent = res.headers.get('set-cookie');
      if (sent) cookie = sent.split(';')[0];
      if (res.status === 401) cookie = '';
      let json: any = null;
      try { json = await res.json(); } catch { json = null; }
      return { status: res.status, json };
    };
    const as = async (email: string, password: string, company?: string): Promise<Reply> => {
      cookie = '';
      const r = await call('POST', '/api/auth/login', { email, password, company });
      // The server answers which book it opened, and the jar follows it, exactly as the real
      // client does: a session is a session in one company, not a name that works everywhere.
      if (r.status === 200 && r.json?.user?.companySlug) slug = String(r.json.user.companySlug);
      return r;
    };
    return { call, as };
  };
  const owner = jar();
  const api: Api = {
    origin,
    api: `${origin}/api/${SLUG}/${BRANCH}`,
    call: owner.call,
    as: owner.as,
    today: async () => String((await owner.call('GET', '/api/time')).json?.day),
    client: jar
  };
  return api;
};

export const api = (): Promise<Api> => (started ??= boot());
