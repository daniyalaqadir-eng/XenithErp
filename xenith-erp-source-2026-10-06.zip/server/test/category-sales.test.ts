// A category register reads a tree: goods leave on an invoice, some of it comes back on a
// return, and the answer has to fold to the leaf the goods sit in while still naming the two
// levels above it — because the printed sheet bands under the parent a reader thinks in. This
// file seeds one such tree, bills against it, and holds the register to its own arithmetic:
// sold less returned, a voided paper counted as the nothing it moved, and every ask — a window,
// a customer, a salesman, a gate, a product, a category — cutting the same papers the fold reads.
//
// The book is this file's own temporary seed, swept when the suite exits, so every figure below
// is one this file wrote and can therefore name exactly.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
const KEY = 'category-wise-sales-and-volume-report';

const shift = (iso: string, n: number) =>
  new Date(new Date(`${iso}T00:00:00Z`).getTime() + n * 86400000).toISOString().slice(0, 10);

const PARENT1 = 'CXR Grains', SUB1 = 'CXR Rice', LEAF1 = 'CXR Basmati';
const PARENT2 = 'CXR Oils', SUB2 = 'CXR Cooking Oil', LEAF2 = 'CXR Sunflower Oil';
const RICE5 = 'CXR Basmati 5kg', RICE25 = 'CXR Basmati 25kg', OIL5 = 'CXR Sunflower 5L';
const ONE = 'CXR Buyer One', TWO = 'CXR Buyer Two';
const GATE = 'CXR Return Gate', MAN = 'CXR Saleem';
const PRICE: Record<string, number> = { [RICE5]: 1000, [RICE25]: 4000, [OIL5]: 2000 };
const SKU: Record<string, string> = { [RICE5]: 'CXR-B5', [RICE25]: 'CXR-B25', [OIL5]: 'CXR-S5' };

let day = '';
let home = '';

// A seed that answers with the wrong paper says nothing about the register, so every step of it
// is asserted before the first ask is made.
const made = async (method: string, path: string, body: any, what: string) => {
  const res = await A.call(method, path, body);
  expect(res.status, `${what}: ${JSON.stringify(res.json)}`).toBeLessThan(300);
  return res.json;
};

const category = async (name: string, parentId: number | null) =>
  (await made('POST', '/categories', { name, type: 'product', parentId }, `category ${name}`)).id as number;

const product = async (name: string, categoryId: number) => {
  await made('POST', '/products', {
    name, unit: 'PCS', sku: SKU[name], isSold: true, isPurchased: true, trackInventory: true,
    salePrice: PRICE[name], purchasePrice: 100, categoryId
  }, `product ${name}`);
  await made('POST', '/inventory/items', {
    name, sku: SKU[name], unit: 'PCS', stockQty: 500, purchasePrice: 100, isActive: true
  }, `stock ${name}`);
};

const line = (productName: string, quantity: number, warehouseName?: string) => ({
  productName, sku: SKU[productName], unit: 'PCS', quantity, price: PRICE[productName],
  discountType: 'Percent', discountValue: 0, ...(warehouseName ? { warehouseName } : {})
});

const bill = async (resource: string, body: any) => {
  const raised = await made('POST', `/${resource}`, body, `bill on ${resource}`);
  const filed = await A.call('PATCH', `/${resource}/${raised.id}/status`, { status: 'Approved' });
  expect(filed.status, JSON.stringify(filed.json)).toBe(200);
  return raised.id as number;
};

const report = async (param: Record<string, string> = {}, filt: Record<string, string> = {}) => {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(param)) if (v) q.set(`param[${k}]`, v);
  for (const [k, v] of Object.entries(filt)) if (v) q.set(`filt[${k}]`, v);
  const query = q.toString();
  const res = await A.call('GET', `/reports/${KEY}${query ? `?${query}` : ''}`);
  expect(res.status, JSON.stringify(res.json)).toBe(200);
  return res.json;
};

const leaf = (payload: any, name: string) => (payload.rows as any[]).find(r => r.categoryName === name);
const figure = (rows: any[], key: string) =>
  rows.reduce((s, r) => s + (Number(r[key]) || 0), 0);

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  day = await A.today();

  const leaf1 = await category(LEAF1, await category(SUB1, await category(PARENT1, null)));
  const leaf2 = await category(LEAF2, await category(SUB2, await category(PARENT2, null)));
  await product(RICE5, leaf1);
  await product(RICE25, leaf1);
  await product(OIL5, leaf2);
  for (const name of [ONE, TWO]) await made('POST', '/customers', { name }, `customer ${name}`);

  // The gate the return posts back into, so the register has two places for goods to stand and
  // its warehouse ask has something to cut on.
  await made('POST', '/warehouses', { name: GATE, isActive: true }, `warehouse ${GATE}`);
  const gates = (await A.call('GET', '/warehouses')).json.data;
  home = String(gates.find((w: any) => w.isDefault)?.name || gates[0]?.name || '');
  expect(home, 'the seeded book has its own gate').toBeTruthy();

  // Two customers, two salesmen and three months apart, so a window, a party and a person each
  // have a paper to keep and a paper to put away.
  await bill('saleInvoices', {
    date: day, partyName: ONE, salesPersonName: MAN,
    lines: [line(RICE5, 10), line(OIL5, 4)], tax: 0
  });
  await bill('saleInvoices', { date: shift(day, -20), partyName: TWO, lines: [line(RICE25, 2)], tax: 0 });
  await bill('saleInvoices', { date: shift(day, -120), partyName: ONE, lines: [line(RICE5, 7)], tax: 0 });

  // A return written at the second gate: it moves goods back without moving the sold side at all.
  await bill('saleReturns', {
    date: shift(day, -10), partyName: ONE, lines: [line(RICE5, 2, GATE)], tax: 0
  });

  // A voided paper would bill a hundred units nobody shipped; it appears nowhere below.
  const voidId = await bill('saleInvoices', {
    date: shift(day, -5), partyName: TWO, lines: [line(OIL5, 100)], tax: 0
  });
  expect((await A.call('PATCH', `/saleInvoices/${voidId}/status`, { status: 'Void' })).json.status).toBe('Void');
});

describe('the category register', () => {
  it('declares the paper the sheet is printed on', async () => {
    const p = await report();
    expect(p.columns.map((c: any) => c.key)).toEqual([
      'parentCategoryName', 'subCategoryName', 'categoryName',
      'lines', 'qtySold', 'qtyReturned', 'netQty', 'soldValue', 'retValue', 'netRev'
    ]);
    // Bands are the parent a reader thinks in, and they close over both halves of the sum.
    expect(p.groupBy.key).toBe('parentCategoryName');
    expect(p.groupBy.head.map((h: any) => h.col)).toEqual(['parentCategoryName']);
    expect(p.groupBy.sums.map((s: any) => s.col)).toEqual(['soldValue', 'retValue', 'netRev', 'netQty']);
    // The foot closes over every figure on the row, and the register says so in its own words.
    expect(p.totalsLabel).toBe('Total');
    expect(Object.keys(p.totals).sort()).toEqual(
      ['lines', 'netQty', 'netRev', 'qtyReturned', 'qtySold', 'retValue', 'soldValue'].sort()
    );
    // What came back and what stayed are read against what was billed.
    expect(p.shareRow).toEqual({ of: 'soldValue', cols: ['retValue', 'netRev'] });
    expect(p.cards.map((c: any) => c.label)).toEqual([
      'Categories', 'Sold (PKR)', 'Returns (PKR)', 'Net Revenue (PKR)'
    ]);
    expect(p.params.map((x: any) => x.key)).toEqual([
      'customer', 'salesman', 'warehouse', 'product',
      'parentCategory', 'subCategory', 'productCategory', 'from', 'to'
    ]);
  });

  it('folds sold less returned to each leaf, and carries the trail above it', async () => {
    const p = await report();
    expect(p.rows.length).toBe(2);
    // The register runs on the biggest net first, which is the row a reader is looking for.
    expect(p.rows[0].categoryName).toBe(LEAF1);

    const rice = leaf(p, LEAF1);
    // Three invoice lines went out (10 + 2 + 7 units), two of them rice at one price and one at
    // another, and two units came back: 25,000 billed less 2,000 returned.
    expect(rice).toMatchObject({
      parentCategoryName: PARENT1, subCategoryName: SUB1, categoryName: LEAF1,
      lines: 3, qtySold: 19, qtyReturned: 2, netQty: 17,
      soldValue: 25000, retValue: 2000, netRev: 23000
    });
    const oil = leaf(p, LEAF2);
    expect(oil).toMatchObject({
      parentCategoryName: PARENT2, subCategoryName: SUB2, categoryName: LEAF2,
      lines: 1, qtySold: 4, qtyReturned: 0, netQty: 4,
      soldValue: 8000, retValue: 0, netRev: 8000
    });
    for (const r of p.rows) expect(r.netRev).toBeCloseTo(r.soldValue - r.retValue, 2);
    for (const r of p.rows) expect(r.netQty).toBe(r.qtySold - r.qtyReturned);
  });

  it('counts a voided paper as the nothing it moved', async () => {
    const p = await report();
    // The void bill alone would add a hundred units and 200,000 to the oil leaf.
    expect(figure(p.rows, 'qtySold')).toBe(23);
    expect(figure(p.rows, 'soldValue')).toBe(33000);
    expect(leaf(p, LEAF2).qtySold).toBe(4);
  });

  it('closes its footer and its headline boxes over the rows it answered with', async () => {
    const p = await report();
    for (const key of ['lines', 'qtySold', 'qtyReturned', 'netQty', 'soldValue', 'retValue', 'netRev']) {
      expect(p.totals[key], key).toBe(figure(p.rows, key));
    }
    const card = (label: string) => p.cards.find((c: any) => c.label === label)?.value;
    expect(card('Categories')).toBe(String(p.rows.length));
    const pkr = (n: number) => `PKR ${Math.round(n).toLocaleString()}`;
    expect(card('Sold (PKR)')).toBe(pkr(p.totals.soldValue));
    expect(card('Returns (PKR)')).toBe(pkr(p.totals.retValue));
    expect(card('Net Revenue (PKR)')).toBe(pkr(p.totals.netRev));
  });

  it('bands under the parent so each band sums to the rows standing in it', async () => {
    const p = await report();
    const parents = [...new Set(p.rows.map((r: any) => r.parentCategoryName))];
    expect(parents).toEqual([PARENT1, PARENT2]);
    // A printed band closes its own figures along its foot, so the bands together have to reach
    // the footer the same sheet quotes under them — or one paper would say two different sums.
    for (const key of ['soldValue', 'retValue', 'netRev', 'netQty']) {
      const byBand = parents.reduce(
        (s, m) => s + figure(p.rows.filter((r: any) => r.parentCategoryName === m), key), 0);
      expect(byBand, key).toBeCloseTo(p.totals[key], 2);
    }
    // Each band holds the leaves filed under it, and only those.
    expect(p.rows.filter((r: any) => r.parentCategoryName === PARENT2).map((r: any) => r.categoryName))
      .toEqual([LEAF2]);
  });

  it('cuts to the window the paper asks for', async () => {
    const all = await report();
    const p = await report({ from: shift(day, -30), to: day });
    // The 120-day-old bill is the only line the rice leaf loses.
    expect(leaf(p, LEAF1).lines).toBe(2);
    expect(leaf(p, LEAF1).qtySold).toBe(12);
    expect(leaf(p, LEAF1).soldValue).toBe(18000);
    // A return inside the window still counts against it.
    expect(leaf(p, LEAF1).retValue).toBe(2000);
    expect(leaf(p, LEAF2).netRev).toBe(leaf(all, LEAF2).netRev);
    expect(p.totals.soldValue).toBeLessThan(all.totals.soldValue);
    // Only half the window asked for: the older paper is the one left standing.
    const from = await report({ from: shift(day, -30) });
    expect(leaf(from, LEAF1).qtySold).toBe(12);
  });

  it('narrows to a customer, a salesman, a product or a category', async () => {
    const buyer = await report({ customer: TWO });
    // Buyer Two's only paper that moved anything is the 25kg bill — the void one says nothing.
    expect(buyer.rows.length).toBe(1);
    expect(leaf(buyer, LEAF1)).toMatchObject({ qtySold: 2, soldValue: 8000, retValue: 0, netRev: 8000 });

    const man = await report({ salesman: MAN });
    expect(man.rows.length).toBe(2);
    expect(leaf(man, LEAF1)).toMatchObject({ lines: 1, qtySold: 10, soldValue: 10000 });
    const unassigned = await report({ salesman: 'Unassigned' });
    expect(unassigned.rows.length).toBe(1);
    expect(leaf(unassigned, LEAF1).qtySold).toBe(9);

    const item = await report({ product: OIL5 });
    expect(item.rows.length).toBe(1);
    expect(leaf(item, LEAF2).netRev).toBe(8000);

    // A leaf, its sub and its parent each band the same paper at a different depth.
    expect((await report({ productCategory: LEAF1 })).rows.length).toBe(1);
    expect((await report({ subCategory: SUB2 })).rows.length).toBe(1);
    const parent = await report({ parentCategory: PARENT1 });
    expect(parent.rows.length).toBe(1);
    expect(parent.totals.netRev).toBe(leaf(await report(), LEAF1).netRev);
  });

  it('lets a gate holding only returns answer with a negative net', async () => {
    const back = await report({ warehouse: GATE });
    expect(back.rows.length).toBe(1);
    expect(leaf(back, LEAF1)).toMatchObject({ lines: 0, qtySold: 0, qtyReturned: 2, retValue: 2000, netRev: -2000 });
    // The sold side stands at the book's own gate, and the two halves are the whole register.
    const out = await report({ warehouse: home });
    expect(leaf(out, LEAF1).retValue).toBe(0);
    expect(out.totals.soldValue).toBe(33000);
    expect(leaf(out, LEAF1).netRev).toBe(25000);
  });

  it('takes a column ask like any other register', async () => {
    const all = await report();
    // Every column this register prints is either a category the form already names above the
    // table or a figure it works out for itself, so the engine offers no extra box here: the
    // declared asks are the whole filter.
    expect(all.facets ?? []).toEqual([]);
    const one = await report({ productCategory: LEAF1 });
    expect(one.rows.length).toBe(1);
    expect(one.totals.soldValue).toBe(leaf(all, LEAF1).soldValue);
    // A figure asked at the address moves neither the rows nor the footer — and a word still
    // reaches the trail as easily as the leaf.
    const bounded = await report({}, { '__rq.netRev': '10000|' });
    expect(bounded.rows.length).toBe(all.rows.length);
    expect(bounded.rowCount).toBe(all.rows.length);
    const search = await report({}, { __q: SUB2 });
    expect(search.rows.length).toBe(1);
    expect(search.rows[0].categoryName).toBe(LEAF2);
  });
});
