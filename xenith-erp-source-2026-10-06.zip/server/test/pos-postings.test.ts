// What the till and a paper leave in the ledger. A bill used to be a receipt with no posting
// behind it: the drawer, the tax and the shelf each went their own way, an underpayment was
// accepted as a settled sale, card tender counted as cash, and the change handed across the
// counter was booked as money the shop kept. Freight and the paisa a bill rounds to were
// counted as sales.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DAY = '';

const PRICE = 250;
const COST = 150;
const RATE = 18;

let product: any = {};
let salt: any = {};
let counterId = 0;

const lineOf = (p: any, qty: number, price = p.salePrice, discountPercent = 0) =>
  ({ productId: p.id, productName: p.name, quantity: qty, price, discountPercent });

// An account read on the side it grows, so an expense and an income can be told apart without
// caring which column the statement happened to print them in. The statement lists only the
// accounts a posting has touched, so a head missing from it carries no balance at all — which is
// exactly what a before-snapshot is. A wrong account name cannot pass quietly either, since every
// test here measures a change and a wrong name changes by nothing.
const books = async () => {
  const res = await A.call('GET', '/reports/trial-balance');
  const rows = res.json?.rows || [];
  if (!rows.length) throw new Error(`the trial balance answered nothing (${res.status} ${JSON.stringify(res.json).slice(0, 200)})`);
  const value = (name: string) => {
    const row = rows.find((x: any) => x.account === name);
    if (!row) return 0;
    return /Income|Liability/.test(row.type)
      ? Number(row.credit) - Number(row.debit) : Number(row.debit) - Number(row.credit);
  };
  return { value, rows };
};
const stockOf = async (id: number) => {
  const list = (await A.call('GET', '/pos/products?limit=500')).json?.data || [];
  const row = list.find((x: any) => x.id === id);
  if (!row) throw new Error('the product left the till list altogether');
  return Number(row.stockQty);
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
  const uoms = (await A.call('GET', '/uoms')).json?.data || [];
  const unit = (uoms.find((u: any) => u.isActive) || uoms[0] || {}).code || 'PCS';
  const made = await A.call('POST', '/products', {
    name: 'Test Cola 500ml', unit, sku: 'TEST-COLA', barcode: '8964000123456',
    isSold: true, isPurchased: true, trackInventory: true,
    salePrice: PRICE, purchasePrice: COST, reorderLevel: 0,
    saleTaxes: [{ name: 'Sales Tax', rate: RATE }]
  });
  expect(made.status).toBe(201);
  product = made.json;
  // The ledger owns a tracked product's balance, and an opening is placed by the item card that
  // carries the same SKU — not by a number typed on the product.
  expect((await A.call('POST', '/inventory/items', {
    name: 'Test Cola 500ml', sku: 'TEST-COLA', unit, stockQty: 100, purchasePrice: COST, isActive: true
  })).status).toBe(201);
  const saltMade = await A.call('POST', '/products', {
    name: 'Test Loose Salt', unit, sku: 'TEST-SALT', isSold: true, trackInventory: true,
    salePrice: 50, purchasePrice: 20, saleTaxes: []
  });
  expect(saltMade.status).toBe(201);
  salt = saltMade.json;
  expect((await A.call('POST', '/inventory/items', {
    name: 'Test Loose Salt', sku: 'TEST-SALT', unit, stockQty: 100, purchasePrice: 20, isActive: true
  })).status).toBe(201);
  const counter = await A.call('POST', '/pos/counters', {
    name: 'Test Till', warehouseId: 1, warehouseName: 'Central Warehouse (Karachi)',
    autoPrint: false, allowDiscount: true, maxDiscountPercent: 100, isActive: true
  });
  expect(counter.status).toBe(201);
  counterId = counter.json.id;
  // A paper is raised against a party the book knows, so the customer is laid down here rather
  // than left to whatever the seed happens to carry.
  expect((await A.call('POST', '/customers', { name: 'Test Counter Grocer' })).status).toBe(201);
});

describe('the shelf the till sells from', () => {
  it('takes its opening figure from the item card', async () => {
    expect(await stockOf(product.id)).toBe(100);
  });
});

describe('a cash sale', () => {
  let bill: any = {};
  let was: any = {};
  let total = 0;

  beforeAll(async () => {
    was = await books();
    const gross = 2 * PRICE;
    total = Math.round((gross * (1 + RATE / 100)) * 100) / 100;
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Walk-in', type: 'Sale', discount: 0, taxPercent: RATE,
      lines: [lineOf(product, 2)], payments: [{ mode: 'Cash', amount: total }]
    });
    expect(r.status).toBe(201);
    bill = r.json;
  });

  it('is refused when the tender does not cover it', async () => {
    const short = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Short', type: 'Sale', taxPercent: RATE,
      lines: [lineOf(product, 2)], payments: [{ mode: 'Cash', amount: 500 }]
    });
    expect(short.status).toBe(400);
  });

  it('charges the goods and the tax the goods carry', () => {
    expect(Number(bill.subtotal)).toBe(500);
    expect(Number(bill.tax)).toBe(90);
    expect(Number(bill.grandTotal)).toBe(total);
  });

  it('posts the sale net of its tax to Sales Revenue', async () => {
    expect((await books()).value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(500, 2);
  });

  it('posts the whole tender to the drawer', async () => {
    expect((await books()).value('Cash in Hand') - was.value('Cash in Hand')).toBeCloseTo(total, 2);
  });

  it('owes the tax it collected', async () => {
    expect((await books()).value('Tax Payable') - was.value('Tax Payable')).toBeCloseTo(90, 2);
  });

  it('costs the goods at the price they were bought in at', async () => {
    expect((await books()).value('Cost of Goods Sold') - was.value('Cost of Goods Sold')).toBeCloseTo(2 * COST, 2);
  });

  it('and takes the same figure off the shelf it holds', async () => {
    expect(was.value('Inventory') - (await books()).value('Inventory')).toBeCloseTo(2 * COST, 2);
  });

  it('leaves two bottles less on the rack', async () => {
    expect(await stockOf(product.id)).toBe(98);
  });

  it('voids the whole bill back, the goods included', async () => {
    const before = await stockOf(product.id);
    const voided = await A.call('PATCH', `/pos/bills/${bill.id}/status`, { status: 'Void' });
    expect(voided.status).toBe(200);
    const now = await books();
    expect(now.value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(0, 2);
    expect(now.value('Cash in Hand') - was.value('Cash in Hand')).toBeCloseTo(0, 2);
    expect(await stockOf(product.id)).toBe(before + 2);
  });

  it('and cannot be opened again once voided', async () => {
    expect((await A.call('PATCH', `/pos/bills/${bill.id}/status`, { status: 'Settled' })).status).toBe(400);
  });
});

describe('a card tender', () => {
  it('lands on Undeposited Funds and leaves the drawer alone', async () => {
    const was = await books();
    const cardTotal = Math.round(100 * 1.18 * 100) / 100;
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Card', type: 'Sale', taxPercent: RATE,
      lines: [lineOf(product, 1, 100)], payments: [{ mode: 'Card', amount: cardTotal }]
    });
    expect(r.status).toBe(201);
    const now = await books();
    expect(now.value('Undeposited Funds') - was.value('Undeposited Funds')).toBeCloseTo(cardTotal, 2);
    expect(now.value('Cash in Hand')).toBeCloseTo(was.value('Cash in Hand'), 2);
  });
});

describe('change handed across the counter', () => {
  // The card carries 18%, so the bill reads 118 even though this body claims no tax at all —
  // the goods decide, not the till. The change is then 500 less that 118.
  it('books the bill, not the note the customer handed over', async () => {
    const was = await books();
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Change', type: 'Sale', taxPercent: 0,
      lines: [lineOf(product, 1, 100)], payments: [{ mode: 'Cash', amount: 500 }]
    });
    expect(r.status).toBe(201);
    expect(Number(r.json.change)).toBe(382);
    const now = await books();
    expect(now.value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(100, 2);
    expect(now.value('Cash in Hand') - was.value('Cash in Hand')).toBeCloseTo(118, 2);
  });
});

describe('a return at the till', () => {
  it('gives back the tax as well as the price', async () => {
    const was = await books();
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Refund', type: 'Return', taxPercent: RATE,
      lines: [lineOf(product, 1, 500)], payments: [{ mode: 'Cash', amount: 590 }]
    });
    expect(r.status).toBe(201);
    const now = await books();
    expect(was.value('Sales Revenue') - now.value('Sales Revenue')).toBeCloseTo(500, 2);
    expect(was.value('Tax Payable') - now.value('Tax Payable')).toBeCloseTo(90, 2);
  });
});

describe('a paper carrying haulage and a rounding', () => {
  let invoice: any = {};
  let was: any = {};

  beforeAll(async () => {
    was = await books();
    const r = await A.call('POST', '/saleInvoices', {
      date: DAY, partyName: 'Test Counter Grocer', tax: 0, discount: 0,
      shippingCharges: 60, roundOff: -0.5,
      lines: [{ productName: 'Test Loose Salt', sku: 'TEST-SALT', unit: 'PCS', quantity: 4, price: 50,
        discountType: 'Percent', discountValue: 0 }]
    });
    expect(r.status, String(r.json?.error)).toBe(201);
    invoice = r.json;
    expect((await A.call('PATCH', `/saleInvoices/${invoice.id}/status`, { status: 'Approved' })).status).toBe(200);
  });

  it('charges the goods, the haulage and the rounding as three figures', () => {
    expect(Number(invoice.net)).toBeCloseTo(259.5, 2);
  });

  it('counts the goods alone as a sale', async () => {
    expect((await books()).value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(200, 2);
  });

  it('and the haulage less the rounding as a receipt, not a sale', async () => {
    expect((await books()).value('Other Income') - was.value('Other Income')).toBeCloseTo(59.5, 2);
  });

  it('takes both heads back when the paper is voided', async () => {
    expect((await A.call('PATCH', `/saleInvoices/${invoice.id}/status`, { status: 'Void' })).status).toBe(200);
    const now = await books();
    expect(now.value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(0, 2);
    expect(now.value('Other Income') - was.value('Other Income')).toBeCloseTo(0, 2);
  });
});

describe('a bill the till squares up', () => {
  // The paisa a counter rounds to is a receipt, and it sits on its own head: a sale of 50
  // squared to 50.50 must not read as 50.50 of goods.
  it('keeps the goods and the rounding apart', async () => {
    const was = await books();
    const r = await A.call('POST', '/pos/bills', {
      counterId, customerName: 'Test Round Off', type: 'Sale', roundOff: 0.5,
      lines: [lineOf(salt, 1)], payments: [{ mode: 'Cash', amount: 50.5 }]
    });
    expect(r.status).toBe(201);
    expect(Number(r.json.grandTotal)).toBe(50.5);
    const now = await books();
    expect(now.value('Sales Revenue') - was.value('Sales Revenue')).toBeCloseTo(50, 2);
    expect(now.value('Other Income') - was.value('Other Income')).toBeCloseTo(0.5, 2);
  });

  it('and the book still ties with the receipts on their own head', async () => {
    const total = (((await books()).rows) || []).slice(-1)[0];
    expect(total.account).toBe('Total');
    expect(total.type).toBe('In balance');
  });
});
