// A client who installs this software opens screens that are empty, and an empty screen teaches
// nothing. So the book fills itself once, and Settings can press the same fill or take it back
// out. What that history has to promise is that it is a real trading history: every paper raised
// through the normal saving routes, so the ledgers tie, no stock card goes under, and clearing the
// sample leaves exactly the book that was there before it. This file checks those four promises.
//
// The suite boots with XENITH_DEMO_DATA=0, so nothing here is measuring a book the start-up filled
// by itself — the press under test is the one this file makes.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
// Row counts per register before the sample, and the trial balance the book opened on: the clear
// has to bring both back to these, not merely to zero.
let openedBefore: Record<string, number> = {};
let tiedBefore = { debit: 0, credit: 0 };
let load: any = null;

// Every register the sample writes into, read through the same list route the menu uses.
const REGISTERS: [string, string][] = [
  ['categories', '/categories'],
  ['customers', '/customers'],
  ['vendors', '/vendors'],
  ['products', '/products'],
  ['sales persons', '/salesPersons'],
  ['employees', '/hr/employees'],
  ['POS counters', '/pos/counters'],
  ['chart of accounts', '/chart-of-accounts'],
  ['bank accounts', '/bank-accounts'],
  ['good receivings', '/goodReceivings'],
  ['purchase bills', '/purchaseBills'],
  ['sale invoices', '/saleInvoices'],
  ['delivery challans', '/saleDeliveries'],
  ['sale returns', '/saleReturns'],
  ['customer receipts', '/receivePayments'],
  ['vendor payments', '/vendorPayments'],
  ['POS bills', '/pos/bills'],
  ['cash vouchers', '/cashVouchers'],
  ['cash receipt vouchers', '/cashReceiptVouchers'],
  ['bank vouchers', '/bankVouchers'],
  ['stock adjustments', '/stockAdjustments'],
  ['journal entries', '/journal-entries'],
  ['petty cash', '/petty-cash']
];

const list = async (path: string) => {
  const r = await A.call('GET', path);
  const rows = r.json?.data ?? r.json;
  return Array.isArray(rows) ? rows : [];
};

const tally = async () => {
  const out: Record<string, number> = {};
  for (const [name, path] of REGISTERS) out[name] = (await list(path)).length;
  return out;
};

const trialBalance = async () => {
  const rows = ((await A.call('GET', '/reports/trial-balance')).json?.rows) || [];
  const total = rows.find((r: any) => r.account === 'Total') || { debit: 0, credit: 0 };
  return {
    debit: Math.round((Number(total.debit) || 0) * 100) / 100,
    credit: Math.round((Number(total.credit) || 0) * 100) / 100,
    accounts: rows.filter((r: any) => r.account !== 'Total')
  };
};

const state = async () => (await A.call('GET', '/settings/sample-book')).json;

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  openedBefore = await tally();
  tiedBefore = await trialBalance();
  load = (await A.call('POST', '/settings/sample-book')).json;
}, 180000);

describe('a book that has never held a record', () => {
  it('says so, and carries no sample of its own', async () => {
    // The two facts the start-up weighs before it dares fill a book.
    expect(openedBefore.customers).toBe(0);
    expect(openedBefore.products).toBe(0);
    expect(tiedBefore.debit).toBe(tiedBefore.credit);
  });
});

describe('the press that fills the book', () => {
  it('raised every paper the modules show', () => {
    expect(load).toBeTruthy();
    expect(load.failed).toEqual([]);
    // A module the subscription withholds is said out loud rather than left as a silent gap.
    expect(Array.isArray(load.skipped)).toBe(true);
    const counts: Record<string, number> = load.counts || {};
    expect(Object.keys(counts).length).toBeGreaterThan(15);
    expect(counts.mockCustomers || 0).toBeGreaterThanOrEqual(6);
    expect(counts.mockProducts || 0).toBeGreaterThanOrEqual(12);
    expect(counts['doc:saleInvoices'] || 0).toBeGreaterThanOrEqual(6);
    expect(counts['doc:purchaseBills'] || 0).toBeGreaterThanOrEqual(3);
    expect(counts.mockPosBills || 0).toBeGreaterThanOrEqual(5);
  });

  it('put rows where the menus read them', async () => {
    const after = await tally();
    expect(after.customers).toBeGreaterThan(openedBefore.customers);
    expect(after.products).toBeGreaterThan(openedBefore.products);
    expect(after['sale invoices']).toBeGreaterThan(0);
    // Goods that actually left the warehouse: an approved challan is the only paper the delivery
    // registers read, so a teaching book with none of them teaches that the shop never dispatches.
    expect(after['delivery challans']).toBeGreaterThan(0);
    expect(after['purchase bills']).toBeGreaterThan(0);
    expect(after['customer receipts']).toBeGreaterThan(0);
    expect(after['vendor payments']).toBeGreaterThan(0);
    expect(after['POS bills']).toBeGreaterThan(0);
    expect(after['journal entries']).toBeGreaterThan(0);
    expect(after['petty cash']).toBeGreaterThan(0);
    expect(after['good receivings']).toBeGreaterThan(0);
  });

  it('ties to the paisa on the trial balance', async () => {
    const tb = await trialBalance();
    expect(tb.debit).toBe(tb.credit);
    // Trading happened, so the book is not merely the openings it started on.
    expect(tb.debit).toBeGreaterThan(tiedBefore.debit);
  });

  it('never puts a stock card under zero', async () => {
    const cards = (await list('/products')).filter((p: any) => p.trackInventory);
    expect(cards.length).toBeGreaterThan(0);
    expect(cards.every((p: any) => (Number(p.stockQty) || 0) >= 0)).toBe(true);
    expect(cards.some((p: any) => (Number(p.stockQty) || 0) > 0)).toBe(true);
  });

  it('gives the reports something to answer with', async () => {
    for (const key of ['stock-in-hand-report', 'customer-due-list-report', 'product-wise-sales-report', 'balance-sheet',
      'sales-delivery-report', 'sales-delivery-detail-report']) {
      const rows = ((await A.call('GET', `/reports/${key}`)).json?.rows) || [];
      expect(rows.length, key).toBeGreaterThan(0);
    }
  });

  it('refuses to fill a book that is already filled', async () => {
    const again = await A.call('POST', '/settings/sample-book');
    expect(again.status).toBe(409);
    expect(String(again.json?.error)).toMatch(/Clear it first/);
  });

  it('is reported by the settings card that the screen reads', async () => {
    const s = await state();
    expect(s.total).toBeGreaterThan(100);
    expect(s.loadedAt).toBeTruthy();
    expect(s.fresh).toBe(false);
  });
});

describe('the press that takes the sample back out', () => {
  it('leaves exactly the book that was there before', async () => {
    const cleared = await A.call('DELETE', '/settings/sample-book');
    expect(cleared.status).toBe(200);
    expect(cleared.json.failed).toEqual([]);
    expect((await state()).total).toBe(0);
    expect(await tally()).toEqual(openedBefore);
    const tb = await trialBalance();
    expect(tb.debit).toBe(tiedBefore.debit);
    expect(tb.credit).toBe(tiedBefore.credit);
  }, 180000);

  it('can then be pressed again', async () => {
    const r = await A.call('POST', '/settings/sample-book');
    expect(r.status).toBe(200);
    expect(r.json.failed).toEqual([]);
    const again = (await state()).total;
    expect(again).toBeGreaterThan(100);
    // The book is left cleared: a suite that measured the sample would be measuring the sample,
    // and no later file should find somebody else's papers in it.
    const cleared = await A.call('DELETE', '/settings/sample-book');
    expect(cleared.json.failed).toEqual([]);
    expect(await tally()).toEqual(openedBefore);
  }, 180000);
});
