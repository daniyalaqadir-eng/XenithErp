// What the till may not post. The screen clamps a cashier's keys, but the money and the goods
// are kept on the server, and until this a request that skipped the screen sold goods the shop
// does not have, at a negative price, with a discount the counter was never allowed to give.
// Each of these was tried over HTTP against a throwaway book and answered 201.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
const SKU = 'TEST-GUARD-RICE';
const SERVICE_SKU = 'TEST-GUARD-SERVICE';

let rice: any = {};
let service: any = {};
let tillId = 0;      // cap of 10%
let nobreaksId = 0;  // discounts not allowed at all

const shelf = async () => Number(((await A.call('GET', '/pos/products?limit=500')).json?.data || [])
  .find((x: any) => x.sku === SKU)?.stockQty);

// One dish at 1,000, no tax on its card, so the bill is the price and the tender is the bill.
const lineOf = (p: any, qty: number, discountPercent = 0) =>
  ({ productId: p.id, productName: p.name, quantity: qty, price: 1000, discountPercent });
const sale = (lines: any[], extra: object = {}) => ({
  counterId: tillId, customerName: 'Test Walk-in', type: 'Sale', taxPercent: 0,
  lines, payments: [{ mode: 'Cash', amount: 1000 }], ...extra
});

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  rice = (await A.call('POST', '/products', {
    name: 'Test Guard Rice 25kg', unit: 'BAG', sku: SKU, isSold: true, isPurchased: true,
    trackInventory: true, salePrice: 1000, purchasePrice: 600, saleTaxes: []
  })).json;
  expect((await A.call('POST', '/inventory/items', {
    name: 'Test Guard Rice 25kg', sku: SKU, unit: 'BAG', stockQty: 10, purchasePrice: 600, isActive: true
  })).status).toBe(201);
  // A service is created with the stock switch off, and off is what it has to stay: nothing of
  // its own sits in a warehouse, so nothing of its own can go below zero.
  service = (await A.call('POST', '/products', {
    name: 'Test Guard Delivery', unit: 'PCS', sku: SERVICE_SKU, type: 'Services',
    isSold: true, trackInventory: false, salePrice: 1000, saleTaxes: []
  })).json;
  const till = await A.call('POST', '/pos/counters', {
    name: 'Test Capped Till', warehouseId: 1, warehouseName: 'Central Warehouse (Karachi)',
    autoPrint: false, allowDiscount: true, maxDiscountPercent: 10, isActive: true
  });
  tillId = till.json?.id;
  expect(tillId).toBeTruthy();
  const strict = await A.call('POST', '/pos/counters', {
    name: 'Test No-Discount Till', warehouseId: 1, warehouseName: 'Central Warehouse (Karachi)',
    autoPrint: false, allowDiscount: false, maxDiscountPercent: 0, isActive: true
  });
  nobreaksId = strict.json?.id;
  expect(nobreaksId).toBeTruthy();
});

describe('goods the shop does not hold', () => {
  it('cannot be sold off the till', async () => {
    const r = await A.call('POST', '/pos/bills', sale([lineOf(rice, 20)]));
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/holds only 10 BAG/);
    expect(r.json.error).toMatch(/below zero/);
  });

  it('and the shelf is exactly where it was', async () => {
    expect(await shelf()).toBe(10);
  });

  it('leaves a service alone, because it has no card to go under water', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(service, 50)], { payments: [{ mode: 'Cash', amount: 50000 }] }));
    expect(r.status, JSON.stringify(r.json)).toBe(201);
  });

  it('is measured over the whole bill, not line by line', async () => {
    // Six bags on one line and five on the next is eleven out of a ten-bag shelf: each line
    // alone looks sound, which is exactly how a bulk sale used to slip past.
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 6), lineOf(rice, 5)], { payments: [{ mode: 'Cash', amount: 11000 }] }));
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/holds only/);
  });

});

describe('the discount the counter was given', () => {
  it('is honoured on the money taken off the bill', async () => {
    const r = await A.call('POST', '/pos/bills', sale([lineOf(rice, 1)], { discount: 500 }));
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/may take 10% off a bill/);
    expect(r.json.error).toMatch(/gives away PKR 500/);
  });

  it('and on the percentage taken off a line', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1, 40)], { payments: [{ mode: 'Cash', amount: 600 }] }));
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/gives away PKR 400/);
  });

  it('lets the discount the cap allows through', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1)], { discount: 100, payments: [{ mode: 'Cash', amount: 900 }] }));
    expect(r.status, JSON.stringify(r.json)).toBe(201);
  });

  it('refuses every discount at a till that was given none', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1)], { counterId: nobreaksId, discount: 10, payments: [{ mode: 'Cash', amount: 990 }] }));
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/may take 0% off a bill/);
  });

  it('and a discount cannot be negative, which would add to the bill', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1)], { discount: -200, payments: [{ mode: 'Cash', amount: 1200 }] }));
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/negative bill discount/);
  });

  it('and a line discount has to be a percentage', async () => {
    const over = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1, 150)], { payments: [{ mode: 'Cash', amount: 0 }] }));
    expect(over.status).toBe(400);
    expect(over.json.error).toMatch(/between 0 and 100/);
    const under = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 1, -20)], { payments: [{ mode: 'Cash', amount: 1200 }] }));
    expect(under.status).toBe(400);
    expect(under.json.error).toMatch(/between 0 and 100/);
  });
});

describe('the money on a line', () => {
  it('cannot be negative', async () => {
    const r = await A.call('POST', '/pos/bills',
      { ...sale([lineOf(rice, 1)]), lines: [{ productId: rice.id, productName: rice.name, quantity: 1, price: -500, discountPercent: 0 }],
        payments: [{ mode: 'Cash', amount: 500 }] });
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/negative price/);
  });

  it('and a line cannot name a product that is not on the book', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([{ productId: 999999, productName: 'Ghost Bag', quantity: 1, price: 1000, discountPercent: 0 }]));
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/not on the book/);
  });

  it('while an unlisted line still sells, as the till is meant to allow', async () => {
    const r = await A.call('POST', '/pos/bills',
      sale([{ productName: 'Loose Item', quantity: 1, price: 1000, discountPercent: 0 }]));
    expect(r.status, JSON.stringify(r.json)).toBe(201);
  });

  it('and the bill cannot pick a counter the till does not have', async () => {
    const r = await A.call('POST', '/pos/bills', sale([lineOf(rice, 1)], { counterId: 999999 }));
    expect(r.status, JSON.stringify(r.json)).toBe(400);
    expect(r.json.error).toMatch(/nowhere to put its money/);
  });

  it('but a request that names no counter still goes to the shop\'s own till', async () => {
    const r = await A.call('POST', '/pos/bills', { ...sale([lineOf(rice, 1)]), counterId: undefined });
    expect(r.status, JSON.stringify(r.json)).toBe(201);
    expect(r.json.counterName).toBe('Test Capped Till');
  });
});

// Last, because it spends the shelf: the guard is one switch in Company Settings → Sales
// Settings, and the till has to read it the way the document register already does — on, a short
// sale goes through for a shop still entering its opening balances; off, it does not.
describe('the switch that lets a shop sell short', () => {
  it('opens the door when the owner asks for it', async () => {
    expect((await A.call('PUT', '/settings/company',
      { settings: { allowNegativeStockEntries: true } })).status).toBe(200);
    const r = await A.call('POST', '/pos/bills',
      sale([lineOf(rice, 50)], { payments: [{ mode: 'Cash', amount: 50000 }] }));
    expect(r.status, JSON.stringify(r.json)).toBe(201);
    expect(await shelf()).toBeLessThan(0);
  });

  it('and shuts it again the moment he turns it off', async () => {
    expect((await A.call('PUT', '/settings/company',
      { settings: { allowNegativeStockEntries: false } })).status).toBe(200);
    const after = await A.call('POST', '/pos/bills', sale([lineOf(rice, 1)]));
    expect(after.status).toBe(400);
    expect(after.json.error).toMatch(/below zero/);
  });
});
