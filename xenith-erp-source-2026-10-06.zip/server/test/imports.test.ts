// An importer's bill used to be raised out of nothing: it could add to the Inventory account
// while the shelf stayed empty, and it could bill fifty bags of goods ten were ever counted in.
// A bill now has to be raised out of a receiving note, and it cannot exceed what that note took.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DAY = '';
const SKU = 'TEST-IMP-RICE';
const COST = 200;

const goodsLine = (qty: number, source: { number?: string; lineId?: number } = {}) => ({
  productName: 'Test Import Rice 5kg', sku: SKU, unit: 'PCS', quantity: qty, price: COST,
  discountType: 'Percent', discountValue: 0,
  ...(source.number ? { sourceNumber: source.number, sourceLineId: source.lineId } : {})
});
const billBody = (line: object) => ({
  date: DAY, dueDate: DAY, partyName: 'Test Importers',
  lines: [line], customs: { currency: 'PKR', rate: 1, duties: [] },
  expenses: [], expenseMethod: 'Method 1', tax: 0
});
const shelfOf = async () => {
  const list = (await A.call('GET', '/pos/products?limit=500')).json?.data || [];
  const row = list.find((x: any) => x.sku === SKU);
  if (!row) throw new Error('the imported goods left the till list altogether');
  return Number(row.stockQty);
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
  expect((await A.call('POST', '/products', {
    name: 'Test Import Rice 5kg', unit: 'PCS', sku: SKU, isSold: true, isPurchased: true,
    trackInventory: true, salePrice: 1000, purchasePrice: COST, saleTaxes: []
  })).status).toBe(201);
  expect((await A.call('POST', '/vendors', { name: 'Test Importers' })).status).toBe(201);
});

describe('an importer\u2019s bill', () => {
  let received: { number: string; lineId: number } = { number: '', lineId: 0 };

  it('cannot be billed into the air', async () => {
    const r = await A.call('POST', '/importInvoices', billBody(goodsLine(10)));
    expect(r.status).toBe(400);
    expect(String(r.json?.error).toLowerCase()).toContain('good receiving');
  });

  it('is raised out of a receiving note that counted the goods in', async () => {
    const before = await shelfOf();
    const gr = await A.call('POST', '/goodReceivings', {
      date: DAY, partyName: 'Test Importers', lines: [goodsLine(10, {})]
    });
    expect(gr.status).toBe(201);
    expect((await A.call('PATCH', `/goodReceivings/${gr.json.id}/status`, { status: 'Approved' })).status).toBe(200);
    expect(await shelfOf()).toBe(before + 10);
    received = { number: gr.json.number, lineId: (gr.json.lines || [])[0]?.id };
  });

  it('and approves without moving those goods a second time', async () => {
    const shelf = await shelfOf();
    const imp = await A.call('POST', '/importInvoices', billBody(goodsLine(10, received)));
    expect(imp.status).toBe(201);
    expect((await A.call('PATCH', `/importInvoices/${imp.json.id}/status`, { status: 'Approved' })).status).toBe(200);
    expect(await shelfOf()).toBe(shelf);
  });

  it('cannot bill beyond what was received', async () => {
    const r = await A.call('POST', '/importInvoices', billBody(goodsLine(50, received)));
    expect(r.status).toBe(400);
    expect(String(r.json?.error).toLowerCase()).toContain('left to be billed');
  });
});
