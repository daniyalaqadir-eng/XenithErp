// Which of the hundred-odd registers a clerk may call for is now a tick of its own, so this
// suite asks the two questions that matter: is every report on the matrix and nowhere else, and
// does the door actually keep out the role that was not given one — including the role that
// simply types the address.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, SLUG, type Api, type Client } from './support/api';

let A: Api;
let owner: Client;
let clerk: Client;
let clerkId = 0;
let clerkRole = 0;

const paths = (p: string) => `/api/${SLUG}/${BRANCH}${p}`;

// The hub answers to the owner with the whole registry, which is the list the matrix has to
// match — read from the server rather than written out here so a report added by this build
// cannot slip past the test that is supposed to catch it.
let allReports: { key: string; title: string }[] = [];
let screens: any[] = [];

beforeAll(async () => {
  A = await api();
  owner = A;
  clerk = A.client();
  const login = await owner.as('muhammad', 'demo123');
  expect(login.status).toBe(200);
  const cat = await owner.call('GET', paths('/reports'));
  expect(cat.status).toBe(200);
  allReports = cat.json?.groups?.flatMap((g: any) => g.reports) ?? [];
  expect(allReports.length).toBeGreaterThan(100);
  const perm = await owner.call('GET', paths('/permissions'));
  screens = (perm.json?.data?.modules ?? []).flatMap((m: any) => m.screens as any[]);
});

describe('the matrix', () => {
  // A report nobody can tick is a door with no handle: the only fair shape is one row per
  // register, listed against the section of the books it reads.
  it('lists every registered report as its own screen', () => {
    allReports.forEach(r => {
      const s = screens.find(x => x.key === `rep-${r.key}`);
      expect(s, r.key).toBeTruthy();
      expect(s.label, r.key).toBe(r.title);
    });
  });

  it('offers them read-only, and never as a way to write', () => {
    allReports.forEach(r => {
      const s = screens.find(x => x.key === `rep-${r.key}`);
      expect(s?.actions, r.key).toEqual(['view']);
    });
  });

  // The client files the hundred rows under a heading per section; without the label the
  // matrix is a wall of names nobody can scan.
  it('says which section of the books each one belongs to', () => {
    const grouped = allReports
      .map(r => screens.find(x => x.key === `rep-${r.key}`)?.sub)
      .filter(Boolean);
    expect(new Set(grouped).size).toBeGreaterThan(4);
  });
});

describe('a role given no report at all', () => {
  beforeAll(async () => {
    const made = await owner.call('POST', paths('/roles'), {
      name: 'Register Clerk', permissions: ['reports:view', 'report-viewer:view']
    });
    expect(made.status).toBe(201);
    clerkRole = made.json?.data?.id;
    const user = await owner.call('POST', paths('/users'), {
      name: 'Clerk Two', email: 'clerk.two@xenith.test', password: 'clerk1234',
      roleId: clerkRole, branchIds: [BRANCH]
    });
    expect(user.status).toBe(201);
    clerkId = user.json?.data?.id;
    expect((await clerk.as('clerk.two@xenith.test', 'clerk1234')).status).toBe(200);
  });

  afterAll(async () => {
    expect((await owner.call('DELETE', paths(`/users/${clerkId}`))).status).toBe(200);
    expect((await owner.call('DELETE', paths(`/roles/${clerkRole}`))).status).toBe(200);
  });

  // Saving a role must store the list it was handed, not the list this build happens to ship:
  // a tick invented on the way in would undo the whole point of the screen.
  it('is saved with no report tick invented on the way in', async () => {
    const roles = (await owner.call('GET', paths('/roles'))).json?.data || [];
    const role = roles.find((r: any) => r.id === clerkRole);
    expect(role.permissions.filter((p: string) => p.startsWith('rep-'))).toEqual([]);
  });

  it('is shown an empty hub, with the count to match', async () => {
    const cat = await clerk.call('GET', paths('/reports'));
    expect(cat.status).toBe(200);
    expect(cat.json?.groups).toEqual([]);
    expect(cat.json?.total).toBe(0);
  });

  it('is refused a report by its address, and told which one', async () => {
    const r = await clerk.call('GET', paths('/reports/trial-balance'));
    expect(r.status).toBe(403);
    expect(String(r.json?.error)).toMatch(/Trial Balance/i);
  });

  // The Business Summary is not a table and has its own route, so it needs its own door.
  it('is refused the business summary too', async () => {
    expect((await clerk.call('GET', paths('/reports/business-summary'))).status).toBe(403);
  });

  // An alias is the same register by an older name, and the same answer.
  it('cannot reach a report through the older name for it', async () => {
    expect((await clerk.call('GET', paths('/reports/receivables'))).status).toBe(403);
  });

  it('still finds a report that does not exist a 404, not a refusal', async () => {
    expect((await clerk.call('GET', paths('/reports/no-such-register'))).status).toBe(404);
  });

  it('is answered every report by the owner', async () => {
    expect((await owner.call('GET', paths('/reports/trial-balance'))).status).toBe(200);
    expect((await owner.call('GET', paths('/reports/business-summary'))).status).toBe(200);
  });

  it('opens exactly the one report its role is given', async () => {
    const put = await owner.call('PUT', paths(`/roles/${clerkRole}`),
      { permissions: ['reports:view', 'report-viewer:view', 'rep-trial-balance:view'] });
    expect(put.status).toBe(200);
    const cat = await clerk.call('GET', paths('/reports'));
    expect(cat.json?.total).toBe(1);
    expect(cat.json?.groups?.flatMap((g: any) => g.reports).map((r: any) => r.key)).toEqual(['trial-balance']);
    expect((await clerk.call('GET', paths('/reports/trial-balance'))).status).toBe(200);
    expect((await clerk.call('GET', paths('/reports/amount-ledger'))).status).toBe(403);
  });

  // The Reports row on the matrix ticks the whole section at once, which is what a firm that
  // bought the module and wants all of it needs the administrator to be able to do.
  it('opens every report when the whole Reports section is ticked', async () => {
    const reportPerms = screens.filter(s => s.key.startsWith('rep-'))
      .flatMap(s => s.actions.map((a: string) => `${s.key}:${a}`));
    expect(reportPerms.length).toBe(allReports.length);
    const put = await owner.call('PUT', paths(`/roles/${clerkRole}`), {
      permissions: ['reports:view', 'report-viewer:view', ...reportPerms]
    });
    expect(put.status).toBe(200);
    const cat = await clerk.call('GET', paths('/reports'));
    expect(cat.json?.total).toBe(allReports.length);
    expect((await clerk.call('GET', paths('/reports/business-summary'))).status).toBe(200);
  });
});

describe('the roles this build ships', () => {
  // A book that already ran the Reports screen must not lose a single register the morning
  // the ticks appear, so every built-in role that opens reports holds all of them.
  it.each(['Accountant', 'Sales Executive', 'Store Keeper', 'Auditor (Read Only)'])(
    'gives %s every report it used to reach', async (name) => {
      const roles = (await owner.call('GET', paths('/roles'))).json?.data || [];
      const role = roles.find((r: any) => r.name === name);
      expect(role).toBeTruthy();
      const held = role.permissions.filter((p: string) => p.startsWith('rep-'));
      expect(held.length).toBe(allReports.length);
    });
});
