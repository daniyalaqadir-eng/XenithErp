// The life of a paper: the number it is given, the status it may reach, and what may not be
// deleted underneath it. A deleted invoice's number used to be handed to the next bill, a
// voided bill could be typed back to life, a payment could settle the same rupee twice or
// against a bill nobody raised, and a bill still owed money could be torn off the book.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DAY = '';

const SKU = 'TEST-P4-RICE';
const PRICE = 1000;
const COST = 150;

const billLine = () => ({
  productName: 'Test Rice 5kg', sku: SKU, unit: 'PCS', quantity: 5, price: PRICE,
  discountType: 'Percent', discountValue: 0
});
// 5,000 of goods at the 18% the card carries.
const billBody = (extra: object = {}) => ({
  date: DAY, partyName: 'Test Paper Traders', lines: [billLine()], tax: 900, ...extra
});
const listOf = async (resource: string) =>
  ((await A.call('GET', `/${resource}`)).json?.data) || [];
const findDoc = async (resource: string, number: string) =>
  (await listOf(resource)).find((d: any) => d.number === number) || null;
const error = (r: { json: any }, ...words: string[]) => {
  const message = String(r.json?.error || '');
  for (const w of words) expect(message.toLowerCase()).toContain(w.toLowerCase());
  return message;
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
  expect((await A.call('POST', '/products', {
    name: 'Test Rice 5kg', unit: 'PCS', sku: SKU, isSold: true, isPurchased: true,
    trackInventory: true, salePrice: PRICE, purchasePrice: COST,
    saleTaxes: [{ name: 'Sales Tax', rate: 18 }]
  })).status).toBe(201);
  expect((await A.call('POST', '/inventory/items', {
    name: 'Test Rice 5kg', sku: SKU, unit: 'PCS', stockQty: 100, purchasePrice: COST, isActive: true
  })).status).toBe(201);
  const cust = await A.call('POST', '/customers', { name: 'Test Paper Traders' });
  expect(cust.status).toBe(201);
  expect((await A.call('POST', '/vendors', { name: 'Test Paper Importers' })).status).toBe(201);
});

describe('a number that was let go', () => {
  it('is never handed to the next bill', async () => {
    const first = await A.call('POST', '/saleInvoices', billBody());
    expect(first.status).toBe(201);
    const num = first.json.number;
    expect((await A.call('DELETE', `/saleInvoices/${first.json.id}`)).status).toBe(200);
    const next = await A.call('POST', '/saleInvoices', billBody());
    expect(next.status).toBe(201);
    expect(next.json.number).not.toBe(num);
    // Counting on rather than back is the whole point: a re-used number would put two papers
    // of the same date under one label.
    const suffix = (n: string) => Number(String(n).split('-').pop());
    expect(suffix(next.json.number)).toBeGreaterThan(suffix(num));
    expect(await findDoc('saleInvoices', num)).toBeNull();
    await A.call('DELETE', `/saleInvoices/${next.json.id}`);
  });

  it('is retired on a deleted journal entry too', async () => {
    const body = {
      date: DAY, memo: 'Phase 4 numbers',
      lines: [{ account: 'Cash in Hand', debit: 100, credit: 0 }, { account: 'Owner Equity', debit: 0, credit: 100 }]
    };
    const first = await A.call('POST', '/journal-entries', body);
    expect(first.status).toBe(201);
    await A.call('DELETE', `/journal-entries/${first.json.id}`);
    const next = await A.call('POST', '/journal-entries', body);
    expect(next.json.entryNumber).not.toBe(first.json.entryNumber);
    await A.call('DELETE', `/journal-entries/${next.json.id}`);
  });
});

describe('the status a paper reaches', () => {
  let id = 0;
  let number = '';

  beforeAll(async () => {
    const raised = await A.call('POST', '/saleInvoices', billBody());
    id = raised.json.id;
    number = raised.json.number;
  });

  it('walks from Draft to Approved to Void', async () => {
    expect((await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Approved' })).json.status).toBe('Approved');
    expect((await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Void' })).json.status).toBe('Void');
  });

  it('cannot be approved back from void by the status button', async () => {
    const r = await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Approved' });
    expect(r.status).toBe(400);
    error(r, 'stays voided');
  });

  it('nor by saving the form over it', async () => {
    const r = await A.call('PUT', `/saleInvoices/${id}`, billBody({ status: 'Draft' }));
    expect(r.status).toBe(400);
    error(r, 'stays voided');
    expect((await findDoc('saleInvoices', number)).status).toBe('Void');
    await A.call('DELETE', `/saleInvoices/${id}`);
  });
});

describe('a bill whose goods have gone out', () => {
  let id = 0;

  beforeAll(async () => {
    const raised = await A.call('POST', '/saleInvoices', billBody());
    id = raised.json.id;
    const approved = await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Approved' });
    // Approving a bill files the challan its goods travel on.
    const filed = (approved.json?.filedDocs) || [];
    expect(filed.length).toBeGreaterThan(0);
    expect((await A.call('PATCH', `/saleDeliveries/${filed[0].id}/status`, { status: 'Approved' })).status).toBe(200);
  });

  it('cannot be voided', async () => {
    const r = await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Void' });
    expect(r.status).toBe(400);
    error(r, 'delivered against it');
  });

  it('cannot be deleted under them', async () => {
    const r = await A.call('DELETE', `/saleInvoices/${id}`);
    expect(r.status).toBe(400);
    error(r, 'delivered against it');
  });

  it('nor voided by saving the form instead of pressing Void', async () => {
    const r = await A.call('PUT', `/saleInvoices/${id}`, billBody({ status: 'Void' }));
    expect(r.status).toBe(400);
    error(r, 'delivered against it');
  });
});

describe('the payment box on a bill', () => {
  // A box on the bill claims money came in; it cannot claim more than the bill is worth, and
  // it cannot claim less than nothing.
  it('refuses a figure above the bill', async () => {
    const r = await A.call('POST', '/saleInvoices', billBody({ paymentAmount: 99999 }));
    expect(r.status).toBe(400);
    error(r, 'marked as received');
  });

  it('refuses a negative figure', async () => {
    const r = await A.call('POST', '/saleInvoices', billBody({ paymentAmount: -100 }));
    expect(r.status).toBe(400);
    error(r, 'less than nothing');
  });
});

describe('a payment settling a bill', () => {
  const cash = (amount: number) =>
    [{ paymentMode: 'Cash', accountId: null, accountName: 'Cash in Hand', amount }];
  const payment = (allocations: object[], lines?: object[]) => ({
    date: DAY, partyName: 'Test Paper Traders',
    paymentLines: lines || cash(1000), allocations
  });
  let sentBill = '';
  let strangerBill = '';

  beforeAll(async () => {
    const raised = await A.call('POST', '/saleInvoices', billBody());
    sentBill = raised.json.number;
    await A.call('PATCH', `/saleInvoices/${raised.json.id}/status`, { status: 'Approved' });
    const stranger = await A.call('POST', '/customers', { name: 'Test Paper Strangers' });
    const other = await A.call('POST', '/saleInvoices',
      billBody({ partyName: 'Test Paper Strangers' }));
    strangerBill = other.json.number;
    await A.call('PATCH', `/saleInvoices/${other.json.id}/status`, { status: 'Approved' });
    expect(stranger.status).toBe(201);
  });

  it('cannot be applied against a paper that does not exist', async () => {
    const r = await A.call('POST', '/receivePayments', payment([{ description: 'SI-999999', allocated: 500 }]));
    expect(r.status).toBe(400);
    error(r, 'not a document');
  });

  it('cannot take a negative sum out', async () => {
    const r = await A.call('POST', '/receivePayments', payment([{ description: sentBill, allocated: -500 }]));
    expect(r.status).toBe(400);
    error(r, 'not an amount to settle');
  });

  it('cannot settle one bill twice', async () => {
    const r = await A.call('POST', '/receivePayments',
      payment([{ description: sentBill, allocated: 500 }, { description: sentBill, allocated: 500 }]));
    expect(r.status).toBe(400);
    error(r, 'settled twice');
  });

  it('cannot apply money it was not given', async () => {
    const r = await A.call('POST', '/receivePayments',
      payment([{ description: sentBill, allocated: 5000 }], cash(1000)));
    expect(r.status).toBe(400);
    error(r, 'but the payment itself is');
  });

  // One customer's money settling another customer's bill would tie both accounts wrong and
  // leave neither figure traceable.
  it("cannot pay one customer's bill with another's money", async () => {
    const r = await A.call('POST', '/receivePayments', payment([{ description: strangerBill, allocated: 500 }]));
    expect(r.status).toBe(400);
    error(r, 'belongs to');
  });

  it('cannot settle more than the bill has left', async () => {
    const r = await A.call('POST', '/receivePayments',
      payment([{ description: sentBill, allocated: 9000 }], cash(9000)));
    expect(r.status).toBe(400);
    error(r, 'left to settle');
  });

  it('is accepted when it is sound money against a bill of the same customer', async () => {
    const r = await A.call('POST', '/receivePayments', payment([{ description: sentBill, allocated: 1000 }]));
    expect(r.status).toBe(201);
    expect((await A.call('PATCH', `/receivePayments/${r.json.id}/status`, { status: 'Approved' })).status).toBe(200);
  });
});

describe('what may be deleted while another paper leans on it', () => {
  let paidBillId = 0;
  let paymentNumber = '';

  beforeAll(async () => {
    const raised = await A.call('POST', '/saleInvoices', billBody({ partyName: 'Test Paper Strangers' }));
    paidBillId = raised.json.id;
    await A.call('PATCH', `/saleInvoices/${paidBillId}/status`, { status: 'Approved' });
    const pay = await A.call('POST', '/receivePayments', {
      date: DAY, partyName: 'Test Paper Strangers',
      paymentLines: [{ paymentMode: 'Cash', accountId: null, accountName: 'Cash in Hand', amount: 1000 }],
      allocations: [{ description: raised.json.number, allocated: 1000 }]
    });
    expect(pay.status).toBe(201);
    paymentNumber = pay.json.number;
    await A.call('PATCH', `/receivePayments/${pay.json.id}/status`, { status: 'Approved' });
  });

  it('leaves a bill with money settled on it on the book, naming the payment', async () => {
    const r = await A.call('DELETE', `/saleInvoices/${paidBillId}`);
    expect(r.status).toBe(400);
    error(r, 'settled against it');
    expect(String(r.json?.error)).toContain(paymentNumber);
  });

  it('and so does one whose goods are already on the road', async () => {
    const shipped = await A.call('POST', '/saleInvoices', billBody());
    const approved = await A.call('PATCH', `/saleInvoices/${shipped.json.id}/status`, { status: 'Approved' });
    const challan = (approved.json?.filedDocs || [])[0];
    await A.call('PATCH', `/saleDeliveries/${challan.id}/status`, { status: 'Approved' });
    const r = await A.call('DELETE', `/saleInvoices/${shipped.json.id}`);
    expect(r.status).toBe(400);
    error(r, 'delivered against it');
  });

  it('refuses to erase a customer the book owes papers to', async () => {
    const traders = (await listOf('customers')).find((c: any) => c.name === 'Test Paper Traders');
    const r = await A.call('DELETE', `/customers/${traders.id}`);
    expect(r.status).toBe(409);
    error(r, 'paper(s) on the book');
  });

  it('allows a customer who never traded', async () => {
    const free = await A.call('POST', '/customers', { name: 'Test Paper Nobody' });
    expect((await A.call('DELETE', `/customers/${free.json.id}`)).status).toBe(204);
  });

  it('and says so for an id nobody holds', async () => {
    expect((await A.call('DELETE', '/customers/999999')).status).toBe(404);
  });

  it('takes the payment itself back', async () => {
    const payments = (await listOf('receivePayments')).filter((p: any) => p.number === paymentNumber);
    expect((await A.call('DELETE', `/receivePayments/${payments[0].id}`)).status).toBe(200);
  });
});
