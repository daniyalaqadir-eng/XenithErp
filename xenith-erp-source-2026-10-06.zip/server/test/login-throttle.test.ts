// The door itself is throttled, not just the account behind it. A script rotating through
// usernames never trips a per-account lock, so the address gets forty attempts and the
// forty-first is refused. This file runs on its own because spending that budget locks out
// every later request from this machine — and vitest gives every file its own server, which is
// the only reason the rest of the suite never sees it.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;

beforeAll(async () => {
  A = await api();
});

describe('a script at the login door', () => {
  let firstBlocked = 0;

  it('is stopped after a run of wrong addresses', async () => {
    for (let i = 0; i < 60; i++) {
      const r = await A.call('POST', '/api/auth/login', { email: `no-such-person-${i}`, password: `wrong-${i}` });
      if (r.status === 429) { firstBlocked = i + 1; break; }
    }
    expect(firstBlocked).toBeGreaterThan(30);
    expect(firstBlocked).toBeLessThanOrEqual(45);
  });

  it('is turned away for the owner as well, because the counter is the address', async () => {
    expect((await A.client().as('muhammad', 'demo123')).status).toBe(429);
  });

  // The forgot-password link is how a locked-out office gets back in, so the login counter must
  // not spend that door's budget too.
  it('leaves the reset door open', async () => {
    const r = await A.call('POST', '/api/auth/request-password', { email: 'nobody-at-all@demo.invalid' });
    expect(r.status).not.toBe(429);
  });
});

describe('the reset door on its own', () => {
  it('says the same thing whether the address is in the book or not', async () => {
    const known = await A.call('POST', '/api/auth/request-password', { email: 'muhammad@demo.invalid' });
    const unknown = await A.call('POST', '/api/auth/request-password', { email: 'nobody-at-all@demo.invalid' });
    expect(unknown.status).toBe(known.status);
    expect(JSON.stringify(known.json)).not.toMatch(/has been sent to/);
  });

  it('refuses a wrong code', async () => {
    const r = await A.call('POST', '/api/auth/reset-password',
      { email: 'muhammad@demo.invalid', code: '000000', newPassword: 'abc123' });
    expect(r.status).toBe(400);
  });
});
