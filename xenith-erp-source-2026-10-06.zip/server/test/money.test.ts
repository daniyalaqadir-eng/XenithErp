// The one rule every figure in the book is measured by. It lives in server/src/money.ts, with
// a copy in client/src/utils/money.ts for the screens that add a total up before sending it,
// and these tests hold both copies to the same paisa.
import { describe, expect, it } from 'vitest';
import { rd, r2, roundMoney } from '../src/money';
import { roundMoney as browserRound } from '../../client/src/utils/money';

describe('the rounding rule', () => {
  it('carries a half paisa up rather than down', () => {
    expect(roundMoney(1.005)).toBe(1.01);
    expect(roundMoney(2.675)).toBe(2.68);
    expect(roundMoney(0.125)).toBe(0.13);
    expect(roundMoney(49.5 + 0.005)).toBe(49.51);
  });

  it('carries the half of a refund away from zero, so it reverses the sale', () => {
    expect(roundMoney(-1.005)).toBe(-1.01);
    expect(roundMoney(-0.125)).toBe(-0.13);
    expect(roundMoney(-1.005) + roundMoney(1.005)).toBe(0);
  });

  it('is not the naive rounding it replaced', () => {
    // Math.round sends 1.005 down because 1.005 * 100 is 100.49999999999999 in binary, and it
    // takes -1.005 towards zero, so a refund of the same figure lands a rupee short.
    expect(Math.round(1.005 * 100) / 100).toBe(1);
    expect(Math.round(-1.005 * 100) / 100).toBe(-1);
  });

  it('rounds nothing it was not given a figure for', () => {
    expect(roundMoney(Number.NaN)).toBe(0);
    expect(roundMoney(undefined as unknown as number)).toBe(0);
    expect(roundMoney('' as unknown as number)).toBe(0);
    expect(roundMoney(0)).toBe(0);
  });

  it('leaves a figure that is already in paisa alone', () => {
    expect(roundMoney(1234.56)).toBe(1234.56);
    expect(roundMoney(-1234.56)).toBe(-1234.56);
    expect(roundMoney(1e12)).toBe(1e12);
  });

  it('spells the same rule twice over — rd, r2 and the browser copy', () => {
    const cases = [1.005, 2.675, -1.005, 0.005, -0.005, 99.994, 99.995, 0.1 + 0.2, 1234.565, -0];
    for (const n of cases) {
      expect(rd(n)).toBe(roundMoney(n));
      expect(r2(n)).toBe(roundMoney(n));
      expect(browserRound(n)).toBe(roundMoney(n));
    }
  });
});

describe('a total of rounded lines', () => {
  // The books round each line and then add the lines up, because each line printed on the paper
  // is already in paisa — a total that disagreed with the lines a customer can read would be
  // the one nobody believes. Rounding the raw sum instead is a paisa short on the same bill.
  const lines = [10.005, 10.005];
  const shown = r2(lines.reduce((s, l) => s + r2(l), 0));
  const raw = r2(lines.reduce((s, l) => s + l, 0));

  it('adds the figures the paper carries', () => {
    expect(r2(10.005)).toBe(10.01);
    expect(shown).toBe(20.02);
  });

  it('and is a paisa above the total of the unrounded lines', () => {
    expect(raw).toBe(20.01);
    expect(shown).not.toBe(raw);
  });

  it('the same way on a bill of three, where the gap widens', () => {
    const parts = [1.005, 1.005, 1.005];
    expect(r2(parts.reduce((s, l) => s + r2(l), 0))).toBe(3.03);
    expect(r2(parts.reduce((s, l) => s + l, 0))).toBe(3.01);
  });
});
