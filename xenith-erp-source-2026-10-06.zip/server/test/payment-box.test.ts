// The "Payment" box on a bill used to move the bill's own balance with no paper behind it, so
// the drawer said one figure and the ledger another. It now files a receive payment of its own,
// is redrawn rather than doubled when the box changes, and goes back in the drawer when the box
// is cleared or the bill deleted.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let DAY = '';
const SKU = 'TEST-BOX-RICE';
// 5,000 of goods at the 18% the card carries, so the bill is worth 5,900.
const BILL = 5900;

const billBody = (extra: object = {}) => ({
  date: DAY, partyName: 'Test Box Traders',
  lines: [{ productName: 'Test Box Rice 5kg', sku: SKU, unit: 'PCS', quantity: 5, price: 1000,
    discountType: 'Percent', discountValue: 0 }],
  tax: 900, ...extra
});

// The statement lists only the accounts a posting has touched; a head missing from it carries no
// balance at all, which is what a before-snapshot of a fresh book is.
const books = async () => {
  const rows = ((await A.call('GET', '/reports/trial-balance')).json?.rows) || [];
  const value = (name: string) => {
    const row = rows.find((x: any) => x.account === name);
    if (!row) return 0;
    return /Income|Liability/.test(row.type)
      ? Number(row.credit) - Number(row.debit) : Number(row.debit) - Number(row.credit);
  };
  return { value, rows };
};
const shelfOf = async () => Number(((await A.call('GET', '/pos/products?limit=500')).json?.data || [])
  .find((x: any) => x.sku === SKU)?.stockQty);
const notesFor = async (number: string) =>
  (((await A.call('GET', '/receivePayments')).json?.data) || [])
    .filter((p: any) => (p.allocations || []).some((a: any) => a.description === number));
const findDoc = async (number: string) =>
  (((await A.call('GET', '/saleInvoices')).json?.data) || []).find((d: any) => d.number === number) || null;

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  DAY = await A.today();
  expect((await A.call('POST', '/products', {
    name: 'Test Box Rice 5kg', unit: 'PCS', sku: SKU, isSold: true, isPurchased: true,
    trackInventory: true, salePrice: 1000, purchasePrice: 150, saleTaxes: [{ name: 'Sales Tax', rate: 18 }]
  })).status).toBe(201);
  expect((await A.call('POST', '/inventory/items', {
    name: 'Test Box Rice 5kg', sku: SKU, unit: 'PCS', stockQty: 100, purchasePrice: 150, isActive: true
  })).status).toBe(201);
  expect((await A.call('POST', '/customers', { name: 'Test Box Traders' })).status).toBe(201);
});

describe('a bill part-paid at the counter', () => {
  let id = 0;
  let number = '';
  let cash0 = 0;
  let debt0 = 0;
  let shelf0 = 0;

  beforeAll(async () => {
    const was = await books();
    cash0 = was.value('Cash in Hand');
    debt0 = was.value('Sundry Debtors');
    shelf0 = await shelfOf();
    const raised = await A.call('POST', '/saleInvoices', billBody({ paymentAmount: 3000 }));
    expect(raised.status).toBe(201);
    id = raised.json.id;
    number = raised.json.number;
  });

  it('files no payment while it is unsigned', async () => {
    expect(await notesFor(number)).toEqual([]);
  });

  it('files one signed paper when it is approved', async () => {
    expect((await A.call('PATCH', `/saleInvoices/${id}/status`, { status: 'Approved' })).status).toBe(200);
    const notes = await notesFor(number);
    expect(notes.length).toBe(1);
    expect(notes[0].status).toBe('Approved');
  });

  it('carries exactly the box and settles the bill by it', async () => {
    const note = (await notesFor(number))[0];
    expect(Number(note.paymentAmount)).toBeCloseTo(3000, 2);
    expect(Number(note.allocations[0].allocated)).toBeCloseTo(3000, 2);
  });

  it('puts the 3,000 in the drawer and leaves 2,900 owed', async () => {
    const now = await books();
    expect(now.value('Cash in Hand') - cash0).toBeCloseTo(3000, 2);
    expect(now.value('Sundry Debtors') - debt0).toBeCloseTo(BILL - 3000, 2);
    expect(Number((await findDoc(number))?.balance)).toBeCloseTo(2900, 2);
  });

  it('redraws that paper rather than doubling it when the box is raised', async () => {
    const first = (await notesFor(number))[0];
    const raised = await A.call('PUT', `/saleInvoices/${id}`, billBody({ status: 'Approved', paymentAmount: BILL }));
    expect(raised.status).toBe(200);
    const notes = await notesFor(number);
    expect(notes.length).toBe(1);
    expect(notes[0].number).toBe(first.number);
    expect(Number(notes[0].paymentAmount)).toBeCloseTo(BILL, 2);
    expect(Number(notes[0].balance)).toBeCloseTo(0, 2);
    const now = await books();
    expect(now.value('Cash in Hand') - cash0).toBeCloseTo(BILL, 2);
    expect(now.value('Sundry Debtors') - debt0).toBeCloseTo(0, 2);
  });

  it('takes the paper back when the box is cleared', async () => {
    expect((await A.call('PUT', `/saleInvoices/${id}`, billBody({ status: 'Approved', paymentAmount: 0 }))).status).toBe(200);
    expect(await notesFor(number)).toEqual([]);
    const now = await books();
    expect(now.value('Cash in Hand')).toBeCloseTo(cash0, 2);
    expect(now.value('Sundry Debtors') - debt0).toBeCloseTo(BILL, 2);
  });

  it('and goes with it once the bill itself is removed', async () => {
    const raised = await A.call('POST', '/saleInvoices', billBody({ paymentAmount: 2000 }));
    const secondNumber = raised.json.number;
    expect((await A.call('PATCH', `/saleInvoices/${raised.json.id}/status`, { status: 'Approved' })).status).toBe(200);
    expect((await notesFor(secondNumber)).length).toBe(1);
    expect((await A.call('DELETE', `/saleInvoices/${raised.json.id}`)).status).toBe(200);
    expect(await notesFor(secondNumber)).toEqual([]);
  });

  it('leaves the drawer, the debtors and the shelf as they were but for the bill left open', async () => {
    const now = await books();
    // The first bill is still on the book, unpaid, so its 5,900 is still owed — what has to be
    // back where it started is the money the boxes invented.
    expect(now.value('Cash in Hand')).toBeCloseTo(cash0, 2);
    expect(now.value('Sundry Debtors') - debt0).toBeCloseTo(BILL, 2);
    // Five bags left the shelf with the bill that is still open, and none of the invented
    // payments moved goods a second time.
    expect(await shelfOf()).toBe(shelf0 - 5);
  });
});
