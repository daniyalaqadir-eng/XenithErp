// The chart is four tiers on the screen and three tiers of accounts: Assets › Current Assets ›
// Bank Accounts › HBL Bank. Every account the papers post to is looked up by name, so the
// rebuild that took a level out of the chart had to keep every name that a journal, a salary
// sheet or a customs declaration points at — and it had to refuse the level back. What the
// balance sheet, the trial balance and the import register expect from the chart is checked
// here against the same three rules: no branch deeper than three, a heading never at the end
// of one, and every code the path of the account it hangs under.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let rows: any[] = [];

const byId = (id: number) => rows.find(r => r.id === id);
const levelOf = (a: any): number => {
  let n = 1, cur = a;
  while (cur?.parentId) { cur = byId(cur.parentId); n++; }
  return n;
};
const named = (name: string) => rows.find(r => r.name === name);
const reload = async () => { rows = (await A.call('GET', '/chart-of-accounts')).json.data; };

// The names the rest of the program is written against: a journal line, a payment mode, a
// salary deduction and a customs duty all carry an account's name rather than its number.
const POSTED_TO = [
  'Cash in Hand', 'Petty Cash', 'Undeposited Funds', 'Sundry Debtors',
  'Sales Tax Input on Imports', 'Advance Income Tax on Imports', 'Inventory',
  'Staff Loans & Advances', 'Rent and Tenant Deposits', 'Office Furniture',
  'Accounts Payable', 'Tax Payable', 'Salary Payable', 'Provident Fund Payable',
  'EOBI & Social Security Payable', 'Owner Equity', 'Prior Year Result',
  'Sales Revenue', 'Other Income', 'Cost of Goods Sold',
  'Freight & Transportation', 'Insurance on Imports', 'Port & Terminal Charges',
  'Loading & Unloading', 'Clearing & Agent Fee', 'Documentation & Bill of Lading',
  'Demurrage & Storage', 'Customs Duty & Taxes', 'Salaries & Wages', 'Rent & Utilities',
  'General Expenses'
];

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  await reload();
});

describe('the chart as it ships', () => {
  it('is three levels of accounts deep, and never deeper', () => {
    expect(rows.length).toBeGreaterThan(0);
    const deepest = Math.max(...rows.map(levelOf));
    expect(deepest).toBe(3);
    rows.filter(a => levelOf(a) > 3)
      .forEach(a => expect.fail(`${a.name} stands at level ${levelOf(a)}`));
  });

  it('ends every branch with an account that takes postings', () => {
    // A heading at the third level could hold nothing — the fourth level is the one a posting
    // account would need — so it is a heading with no purpose on the chart.
    rows.filter(a => a.isGroup && levelOf(a) === 3).forEach(a => expect.fail(`${a.name} is a group at the last level`));
  });

  it('numbers every account with the path to it', () => {
    rows.filter(a => a.parentId).forEach(a => {
      const parent = byId(a.parentId);
      expect(a.code.startsWith(`${parent.code}.`), `${a.name} numbered ${a.code}, under ${parent.code}`).toBe(true);
    });
  });

  it('keeps the head of each branch above its accounts', () => {
    // The reading order a chart is meant to have: cash before debtors before stock, creditors
    // before tax before salary, cost of goods before staff before administration.
    const order = rows.filter(a => !a.parentId).map(a => a.code);
    expect(order).toEqual(['1000', '1100', '2000', '3000', '4000', '5000']);
    expect(named('Bank Accounts')?.isGroup).toBe(true);
    expect(named('Physical Cash')?.parentName).toBe('Current Assets');
  });

  it('still holds every name a paper posts to', () => {
    POSTED_TO.forEach(name => {
      const a = named(name);
      expect(a, `${name} is missing from the chart`).toBeTruthy();
      expect(a.isGroup, `${name} must take postings`).toBeFalsy();
      expect(a.isActive, `${name} is switched off`).not.toBe(false);
    });
  });

  it('has no heading that this chart retired', () => {
    ['Cash and Cash Equivalents', 'Trade and Other Receivables', 'Inventories',
      'Advances, Deposits and Loans', 'Tangible Assets', 'Trade Liabilities',
      'Statutory and Staff Dues', "Owner's Capital", 'Reserves and Surplus',
      'Sales of Goods', 'Ancillary Receipts', 'Direct Costs', 'Staff Costs',
      'Administration Costs'].forEach(name => expect(named(name), `${name} came back`).toBeFalsy());
  });

  it('prints a balance sheet and a trial balance off the rebuilt chart', async () => {
    for (const path of ['/reports/balance-sheet', '/reports/trial-balance', '/reports/profit-and-loss']) {
      const r = await A.call('GET', path);
      expect(r.status, path).toBe(200);
      expect((r.json.rows ?? []).length, `${path} printed nothing`).toBeGreaterThan(0);
    }
  });
});

describe('a save that would grow a fourth level', () => {
  it('is refused, and the account is not added', async () => {
    const before = rows.length;
    const atThird = rows.find(a => levelOf(a) === 3 && !a.isGroup)!;
    const r = await A.call('POST', '/chart-of-accounts',
      { name: 'A Fourth Level Branch', parentId: atThird.id, isGroup: false });
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/levels deep/);
    await reload();
    expect(rows.length).toBe(before);
  });

  it('refuses a heading that could hold nothing under it', async () => {
    // A group under a head is the middle of the chart and legal; turning an account that
    // already stands at the third level into a heading is not — nothing could go under it.
    const atSecond = rows.find(a => levelOf(a) === 2 && a.isGroup)!;
    const made = await A.call('POST', '/chart-of-accounts', { name: 'A Spare Account', parentId: atSecond.id });
    expect(made.status).toBe(201);
    const r = await A.call('PUT', `/chart-of-accounts/${made.json.id}`, { isGroup: true });
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/levels deep/);
    expect((await A.call('DELETE', `/chart-of-accounts/${made.json.id}`)).status).toBe(204);
  });

  it('counts the branch a moved account carries, not only the row itself', async () => {
    const head = rows.find(a => levelOf(a) === 1)!.id;
    const g = await A.call('POST', '/chart-of-accounts', { name: 'A Branch Head', parentId: head, isGroup: true });
    expect(g.status).toBe(201);
    const leaf = await A.call('POST', '/chart-of-accounts', { name: 'A Branch Account', parentId: g.json.id });
    expect(leaf.status).toBe(201);
    // The branch is two levels tall, so only a head can take it.
    const atSecond = rows.find(a => a.id !== g.json.id && levelOf(a) === 2 && a.isGroup)!.id;
    const moved = await A.call('PUT', `/chart-of-accounts/${g.json.id}`, { parentId: atSecond });
    expect(moved.status).toBe(400);
    expect(moved.json.error).toMatch(/levels deep/);
    // An edit that keeps the level it stands at is nobody's business — the shape did not change.
    expect((await A.call('PUT', `/chart-of-accounts/${g.json.id}`, { parentId: head })).status).toBe(200);
    await A.call('DELETE', `/chart-of-accounts/${leaf.json.id}`);
    await A.call('DELETE', `/chart-of-accounts/${g.json.id}`);
    await reload();
  });
});

describe('the bank the owner names', () => {
  it('hangs under Bank Accounts as the third level', async () => {
    const banks = named('Bank Accounts')!;
    const added = await A.call('POST', '/chart-of-accounts', { name: 'HBL Bank - Main Branch', parentId: banks.id, isGroup: false });
    expect(added.status).toBe(201);
    expect(added.json.code.startsWith(`${banks.code}.`)).toBe(true);
    await reload();
    const hbl = named('HBL Bank - Main Branch');
    expect(levelOf(hbl)).toBe(3);
    expect(hbl.parentName).toBe('Bank Accounts');
    // A bank account is a place money lives, so it takes postings — and nothing goes under it.
    expect(hbl.isGroup).toBe(false);
    const deeper = await A.call('POST', '/chart-of-accounts', { name: 'Below the Bank', parentId: hbl.id });
    expect(deeper.status).toBe(400);
    expect((await A.call('DELETE', `/chart-of-accounts/${hbl.id}`)).status).toBe(204);
    await reload();
    expect(named('HBL Bank - Main Branch')).toBeFalsy();
  });
});
