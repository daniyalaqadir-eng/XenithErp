// Every period the screens offer is measured off the day the book keeps, not the clock of the
// machine that happens to be serving it: the shop runs on one clock in Karachi and the box it
// is hosted on may be set to another. A window opening on the wrong day counts the wrong
// papers, so the reports for "Today", "This Month" and "This Year" are checked against the day
// the server itself says it is.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, type Api } from './support/api';

let A: Api;
let bookDay = '';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthIndex = (label: string) =>
  MONTHS.findIndex(m => m.toLowerCase() === label.slice(0, 3).toLowerCase());
const figure = async (period: string) =>
  (await A.call('GET', `/dashboard?period=${encodeURIComponent(period)}`)).json;
const firstDayOf = (range: string) => {
  const parts = String(range).split(/[–-]/)[0].trim();
  const m = /(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/.exec(parts);
  return m ? { day: Number(m[1]), month: monthIndex(m[2]), year: Number(m[3]) } : null;
};

beforeAll(async () => {
  A = await api();
  expect((await A.as('demo@xenitherp.com', 'demo123')).status).toBe(200);
  bookDay = await A.today();
});

describe('the day the book keeps', () => {
  // Read when the tests run rather than when the file is collected: the day is only known
  // once the API has answered, and the file is collected before any request goes out.
  const parts = () => {
    const [year, month, day] = bookDay.split('-').map(Number);
    return { year, month: month - 1, day };
  };

  it('is the day the dashboard prints', async () => {
    const printed = /(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/.exec(String((await figure('Today')).todayDate));
    expect(printed, 'the dashboard dates itself').not.toBeNull();
    expect({ day: Number(printed![1]), month: monthIndex(printed![2]), year: Number(printed![3]) })
      .toEqual(parts());
  });

  it('and "Today" opens and shuts on it', async () => {
    const today = await figure('Today');
    const window = firstDayOf(today.periodRange);
    expect(window).toEqual(parts());
    const shuts = String(today.periodRange).split(/[–-]/)[1]?.trim();
    expect(firstDayOf(`${shuts} – ${shuts}`)).toEqual(window);
  });

  it('so "This Month" opens on the first of the book\u2019s month', async () => {
    const { month, year } = parts();
    expect(firstDayOf((await figure('This Month')).periodRange)).toEqual({ day: 1, month, year });
  });

  it('and "This Year" opens on the first of January of the book\u2019s year', async () => {
    const { year } = parts();
    expect(firstDayOf((await figure('This Year')).periodRange)).toEqual({ day: 1, month: 0, year });
  });

  // Two tax reports read the same year out of one window, so they cannot answer with two
  // different figures for the tax collected.
  it('leaves the two tax reports agreeing on the same window', async () => {
    const summary = ((await A.call('GET', '/reports/tax-balance')).json?.rows) || [];
    const columns = ((await A.call('GET', '/reports/tax-balance-by-column')).json?.rows) || [];
    const yearRow = summary.find((r: any) => r.period === 'This Year') || {};
    const collected = columns.reduce((s: number, r: any) => s + Number(r.outputTax || 0), 0);
    expect(Number(yearRow.outputTax || 0)).toBeCloseTo(collected, 2);
  });
});
