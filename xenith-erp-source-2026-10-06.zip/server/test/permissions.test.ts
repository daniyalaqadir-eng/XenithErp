// Does the door keep out the people who do not belong there? Anonymous callers get nothing, a
// role that holds nothing holds nothing, none of the ways a clerk once had to promote himself
// work, a caller cannot pick the server's own keys, and the audit line names whoever did it.
import { beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, SLUG, type Api, type Client } from './support/api';

let A: Api;
let owner: Client;
let clerk: Client;
let clerkId = 0;
let clerkRole = 0;
let adminRole = 0;

const paths = (p: string) => `/api/${SLUG}/${BRANCH}${p}`;

beforeAll(async () => {
  A = await api();
  owner = A;
  clerk = A.client();
});

describe('nobody signed in', () => {
  it.each(['products', 'invoices', 'users'])('is refused %s', async (tail) => {
    expect((await A.call('GET', paths('/' + tail))).status).toBe(401);
  });

  // These three used to slip past the guard because they carry no second slash.
  it.each(['/api/time', '/api/auth/store', '/api/auth/database'])('is refused %s', async (p) => {
    expect((await A.call('GET', p)).status).toBe(401);
  });

  it('is refused the session', async () => {
    expect((await A.call('GET', '/api/auth/session')).status).toBe(401);
  });

  it('is still allowed to log out of nothing', async () => {
    expect((await A.call('POST', '/api/auth/logout')).status).toBe(204);
  });
});

describe('the owner signed in', () => {
  beforeAll(async () => {
    // The username as well as the address: the seed keeps one owner and he signs in both ways.
    const login = await owner.as('muhammad', 'demo123');
    expect(login.status).toBe(200);
    expect(login.json?.user?.isOwner).toBe(true);
  });

  it('reads the store diagnostics', async () => {
    const store = await owner.call('GET', '/api/auth/store');
    expect(store.status).toBe(200);
    expect(Array.isArray(store.json?.data?.companies)).toBe(true);
  });

  it('is told a company that does not exist is a 404, not an invented book', async () => {
    const ghost = await owner.call('GET', `/api/not-a-company-at-all/${BRANCH}/products`);
    expect(ghost.status).toBe(404);
    expect(String(ghost.json?.error)).toMatch(/installation/);
  });

  it('still gets the clock', async () => {
    expect((await owner.call('GET', '/api/time')).status).toBe(200);
  });
});

describe('a role that holds nothing', () => {
  beforeAll(async () => {
    const roles = (await owner.call('GET', paths('/roles'))).json?.data || [];
    adminRole = roles.find((r: any) => r.name === 'Administrator')?.id;
    const made = await owner.call('POST', paths('/roles'), { name: 'Empty Clerk', permissions: ['products:view'] });
    expect(made.status).toBe(201);
    clerkRole = made.json?.data?.id;
    const user = await owner.call('POST', paths('/users'), {
      name: 'Clerk One', email: 'clerk.one@xenith.test', password: 'clerk123', roleId: clerkRole, branchIds: [BRANCH]
    });
    expect(user.status).toBe(201);
    clerkId = user.json?.data?.id;
    const login = await clerk.as('clerk.one@xenith.test', 'clerk123');
    expect(login.status).toBe(200);
    expect(login.json?.user?.isOwner).toBeFalsy();
  });

  it('cannot read the store diagnostics', async () => {
    expect((await clerk.call('GET', '/api/auth/store')).status).toBe(403);
  });

  it('keeps the products his role allows', async () => {
    expect((await clerk.call('GET', paths('/products'))).status).toBe(200);
  });

  // The directory stays readable because screens other than Setup draw on it.
  it('is still served the user directory as a data feed', async () => {
    const read = await clerk.call('GET', paths('/users'));
    expect(read.status).toBe(200);
    expect(Array.isArray(read.json?.data)).toBe(true);
  });
});

describe('the ways a clerk once had of promoting himself', () => {
  it('cannot set the owner password', async () => {
    expect((await clerk.call('PUT', paths('/users/1'), { password: 'pwned123' })).status).toBe(403);
  });

  it('and the owner key still works afterwards', async () => {
    expect((await A.client().as('muhammad', 'demo123')).status).toBe(200);
  });

  it('cannot promote himself to Administrator', async () => {
    expect((await clerk.call('PUT', paths(`/users/${clerkId}`), { roleId: adminRole })).status).toBe(403);
  });

  it('cannot widen his own role', async () => {
    const r = await clerk.call('PUT', paths(`/roles/${clerkRole}`),
      { permissions: ['users:edit', 'roles:edit', 'products:view'] });
    expect(r.status).toBe(403);
  });

  it.each([
    ['add a user', 'POST', '/users', { name: 'X', email: 'x@y.z', password: 'xyz123', roleId: clerkRole, branchIds: [BRANCH] }],
    ['delete a user', 'DELETE', '/users/{id}', undefined],
    ['add a role', 'POST', '/roles', { name: 'Rogue', permissions: ['products:view'] }],
    ['delete a role', 'DELETE', '/roles/{role}', undefined]
  ])('cannot %s', async (_name, method, path, body) => {
    const url = paths(path.replace('{id}', String(clerkId)).replace('{role}', String(clerkRole)));
    expect((await clerk.call(method, url, body)).status).toBe(403);
  });

  it('still edits his own phone', async () => {
    const r = await clerk.call('PUT', paths(`/users/${clerkId}`), { phone: '+92 300 0000000' });
    expect(r.status).toBe(200);
    expect(r.json?.data?.phone).toBeTruthy();
  });

  it('while the owner edits both the role and the clerk', async () => {
    expect((await owner.call('PUT', paths(`/roles/${clerkRole}`), { description: 'touched by the owner' })).status).toBe(200);
    const user = await owner.call('PUT', paths(`/users/${clerkId}`), { name: 'Clerk One Revised' });
    expect(user.status).toBe(200);
    expect(user.json?.data?.name).toBe('Clerk One Revised');
  });
});

describe('a caller picking the server\u2019s own keys', () => {
  let made: { status: number; json: any } = { status: 0, json: null };

  beforeAll(async () => {
    made = await owner.call('POST', paths('/bank-accounts'), {
      id: 999, isOwner: true, accountTitle: 'Keys Test Bank', bankName: 'Xenith Bank',
      accountNumber: '0001', balance: 100
    });
  });

  it('cannot choose the id the row is stored under', async () => {
    expect(made.status).toBe(201);
    expect(made.json?.id).toBeTruthy();
    expect(made.json.id).not.toBe(999);
    const all = (await owner.call('GET', paths('/bank-accounts'))).json?.data || [];
    expect(all.some((b: any) => b.id === 999)).toBe(false);
  });

  // The assertion is on the row the server answered with, not on the body that was sent.
  it('cannot carry the isOwner flag in through a create', () => {
    expect(made.json?.isOwner).not.toBe(true);
  });

  it('cannot rewrite the row id with a PUT either', async () => {
    const edited = await owner.call('PUT', paths(`/bank-accounts/${made.json?.id}`),
      { id: 7, accountTitle: 'Keys Renamed' });
    expect(edited.json?.id).toBe(made.json?.id);
  });
});

describe('the category shelves the menus open', () => {
  // A shelf with no tick in the catalog is a door no role can ever be given: the owner
  // himself used to be answered "You do not have access" on Customer Categories, because
  // the screen existed as an address but never as a permission.
  it('are all listed as screens a role can hold', async () => {
    const cat = await owner.call('GET', paths('/permissions'));
    expect(cat.status).toBe(200);
    const keys = JSON.stringify(cat.json?.data);
    for (const screen of ['cat-customer', 'cat-vendor', 'cat-product', 'cat-brand', 'cat-department', 'cat-designation']) {
      expect(keys).toContain(screen);
    }
  });

  it('are still readable by a clerk, because a party form shows the shelf its row sits on', async () => {
    expect((await clerk.call('GET', paths('/categories?type=customer'))).status).toBe(200);
  });

  it('refuse a clerk whose role never holds the shelf', async () => {
    const r = await clerk.call('POST', paths('/categories'), { name: 'Clerk Shelf', type: 'customer' });
    expect(r.status).toBe(403);
    expect(String(r.json?.error)).toMatch(/customer categories/i);
  });

  it('let the owner file and unfile a row', async () => {
    const made = await owner.call('POST', paths('/categories'), { name: 'Owner Shelf', type: 'customer' });
    expect(made.status).toBe(201);
    expect((await owner.call('DELETE', paths(`/categories/${made.json?.id}`))).status).toBe(204);
  });

  // The kinds no screen reads are closed at the door as well as off the menu, so a row filed
  // under one cannot become data nobody will ever open again.
  it('refuse a kind this build keeps no register for', async () => {
    const r = await owner.call('POST', paths('/categories'), { name: 'Ghost', type: 'tax' });
    expect(r.status).toBe(400);
    expect(String(r.json?.error)).toMatch(/not a register/);
  });
});

describe('the audit line', () => {
  it('names whoever did it and the address it came from', async () => {
    const audit = await owner.call('GET', paths('/settings/activity-log'));
    expect(audit.status).toBe(200);
    const rows = audit.json?.data || audit.json || [];
    const latest = (Array.isArray(rows) ? rows : [])
      .find((r: any) => /Keys Test Bank|Keys Renamed/.test(String(r.record || '')));
    expect(latest).toBeTruthy();
    expect(String(latest.user)).toMatch(/Muhammad/);
    // A hard-coded address in the trail would put the record on a machine that never saw it.
    expect(latest.ipAddress).not.toBe('10.10.4.21');
  });
});
