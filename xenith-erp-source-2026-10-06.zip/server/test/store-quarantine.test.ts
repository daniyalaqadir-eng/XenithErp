// What happens to a book the store can no longer read. A payload that does not parse — a disk
// that filled mid-write, a hand that edited the file, a build that changed the shape — used to be
// deleted on the spot, and the seed data then took its place on the next save. The shop opened the
// next morning on yesterday's demo rows and nobody had to be told it had happened. This is the
// store seam alone, so it needs no API and no HTTP.
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

const dir = mkdtempSync(join(tmpdir(), 'xenith-store-'));
const file = join(dir, 'book.db');
process.env.XENITH_DB = file;
delete process.env.XENITH_FRESH;
delete process.env.XENITH_DB_OFF;

const S = await import('../src/store');

// The store writes behind a timer; a flush is what makes the row land before the next line reads it.
const save = (key: string, value: unknown) => { S.markDirty(key, () => value); S.flushStore(); };
const raw = () => new DatabaseSync(file);
const broken = '{"mockCustomers":[{"name":"Altaf Sons"';   // truncated mid-write, as a full disk leaves it

afterAll(() => {
  // The store's own handle keeps the file open, and Windows will not remove a directory
  // something still has open in it.
  S.closeStore();
  rmSync(dir, { recursive: true, force: true });
});

beforeAll(() => {
  expect(S.openStore()).toBe(true);
  save('ws:test-company', { mockCustomers: [{ name: 'Altaf Sons' }], mockProducts: [] });
});

describe('a book the store can read', () => {
  it('comes back as it was saved', () => {
    expect(S.readSnapshot('ws:test-company')).toEqual({
      mockCustomers: [{ name: 'Altaf Sons' }], mockProducts: []
    });
  });

  it('and is counted among the rows on the diagnostics screen', () => {
    const stats = S.storeStats();
    expect(stats.persisted).toBe(true);
    expect(stats.rows).toBeGreaterThan(0);
    expect(stats.quarantined).toBe(0);
  });
});

describe('a book the store cannot read', () => {
  beforeAll(() => {
    const h = raw();
    h.prepare(`UPDATE snapshots SET payload = ? WHERE key = 'ws:test-company'`).run(broken);
    h.close();
  });

  it('answers nothing, but is not deleted', () => {
    expect(S.readSnapshot('ws:test-company')).toBeNull();
    expect(S.storedKeys()).not.toContain('ws:test-company');
  });

  it('is kept whole, with the reason and the hour it was found', () => {
    const found = S.quarantinedKeys();
    expect(found.length).toBe(1);
    expect(found[0].key).toBe('ws:test-company');
    expect(found[0].reason).toMatch(/JSON/);
    expect(found[0].quarantinedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    const h = raw();
    const kept = h.prepare('SELECT payload FROM quarantine WHERE key = ?').get('ws:test-company') as
      { payload: string };
    h.close();
    // The text exactly as it stood: the customer's own rows are in there, recoverable by hand.
    expect(kept.payload).toBe(broken);
  });

  it('is reported, not hidden, in the statistics the diagnostics screen reads', () => {
    expect(S.storeStats().quarantined).toBe(1);
  });

  it('still lets the shop be rebuilt without losing what was found', () => {
    // This is the half the old code got wrong in both directions: the rebuild had to happen, and
    // the unreadable copy had to survive it.
    save('ws:test-company', { mockCustomers: [], mockProducts: [] });
    expect(S.readSnapshot('ws:test-company')).toEqual({ mockCustomers: [], mockProducts: [] });
    const h = raw();
    const kept = h.prepare('SELECT payload FROM quarantine WHERE key = ?').get('ws:test-company') as
      { payload: string };
    h.close();
    expect(kept.payload).toBe(broken);
  });
});
