// Who is shown what is now a decision somebody makes on the Roles screen: the header's company
// popover, each of the three desks on the Dashboard, and each band inside a desk are ticked
// there. These tests hold the three things that make that real — the ticks are on the matrix as
// read-only screens, the shipped roles start on the desks they have always reached and nowhere
// else, and the company-wide read behind the Executive desk answers to its own tick rather than
// to anybody who happens to be signed in.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, BRANCH, SLUG, type Api, type Client } from './support/api';

let A: Api;
let owner: Client;
const paths = (p: string) => `/api/${SLUG}/${BRANCH}${p}`;

// The same keys the client gates on, written out here because a test that re-derives them from
// the code it is testing would prove nothing.
const SWITCHER = 'company-switcher';
const DESKS = ['dashboard-executive', 'dashboard-salesman', 'dashboard-warehouse'];
const EXEC_BANDS = ['snapshot', 'quick-actions', 'alerts', 'sales-purchases', 'cash', 'profit',
  'collections', 'buyers', 'activity', 'shortcuts'].map(b => `dash-${b}`);
const SM_BANDS = ['alerts', 'kpi', 'tiles', 'bills', 'stock', 'charts'].map(b => `dash-sm-${b}`);
const WH_BANDS = ['kpi', 'actions', 'challans', 'stock'].map(b => `dash-wh-${b}`);
const ALL_UI = [SWITCHER, ...DESKS, ...EXEC_BANDS, ...SM_BANDS, ...WH_BANDS];

const roles: Record<string, string[]> = {};const holds = (name: string, screen: string) => (roles[name] ?? []).includes(`${screen}:view`);

beforeAll(async () => {
  A = await api();
  owner = A;
  expect((await owner.as('muhammad', 'demo123')).status).toBe(200);
  const list = (await owner.call('GET', paths('/roles'))).json?.data || [];
  list.forEach((r: any) => { roles[r.name] = (r.permissions ?? []).map(String); });
});

describe('the matrix offers every interface tick', () => {
  it('lists each one as a screen under the Dashboard module', async () => {
    const cat = await owner.call('GET', paths('/permissions'));
    expect(cat.status).toBe(200);
    const screens = (cat.json?.data?.modules ?? [])
      .filter((m: any) => m.key === 'dashboard')
      .flatMap((m: any) => m.screens as any[]);
    ALL_UI.forEach(key => {
      expect(screens.some((s: any) => s.key === key), key).toBe(true);
    });
  });

  // A band opens no register and changes nothing, so it is offered as a read alone; a row that
  // also carried Edit would be a tick an administrator could set that no code would obey.
  it('offers them read-only, and never as a way to write', async () => {
    const cat = await owner.call('GET', paths('/permissions'));
    const screens = (cat.json?.data?.modules ?? []).flatMap((m: any) => m.screens as any[]);
    ALL_UI.forEach(key => {
      const s = screens.find((x: any) => x.key === key);
      expect(s?.actions, key).toEqual(['view']);
    });
  });
});

describe('the shipped roles start on their own desks', () => {
  it('gives the Accountant the executive and salesman desks, and no gate', () => {
    expect(holds('Accountant', 'dashboard-executive')).toBe(true);
    expect(holds('Accountant', 'dashboard-salesman')).toBe(true);
    expect(holds('Accountant', 'dash-cash')).toBe(true);
    expect(holds('Accountant', 'dash-sm-bills')).toBe(true);
    expect(holds('Accountant', 'dashboard-warehouse')).toBe(false);
    expect(holds('Accountant', 'dash-wh-kpi')).toBe(false);
  });

  it('keeps the Sales Executive on his own desk', () => {
    expect(holds('Sales Executive', 'dashboard-salesman')).toBe(true);
    expect(SM_BANDS.every(b => (roles['Sales Executive'] ?? []).includes(`${b}:view`))).toBe(true);
    expect(holds('Sales Executive', 'dashboard-executive')).toBe(false);
    expect(holds('Sales Executive', 'dash-cash')).toBe(false);
    expect(holds('Sales Executive', 'dashboard-warehouse')).toBe(false);
  });

  it('gives the Store Keeper the terminal bands but not another gate\u2019s', () => {
    expect(holds('Store Keeper', 'dashboard-warehouse')).toBe(true);
    expect(WH_BANDS.every(b => (roles['Store Keeper'] ?? []).includes(`${b}:view`))).toBe(true);
    expect(holds('Store Keeper', 'dash-wh-challans')).toBe(true);
    expect(holds('Store Keeper', 'dashboard-salesman')).toBe(false);
    expect(holds('Store Keeper', 'dash-sm-kpi')).toBe(false);
  });

  // The header popover is not a desk: whoever signs in to a firm with more than one of them
  // has always been able to reach the switch, so every shipped role keeps it.
  it('leaves the header switcher with every role that reached it before', () => {
    ['Accountant', 'Sales Executive', 'Store Keeper'].forEach(name => {
      expect(holds(name, SWITCHER), name).toBe(true);
    });
  });

  it('hands the read-only Auditor every band, because it sees everything', () => {
    ALL_UI.forEach(key => {
      expect(holds('Auditor (Read Only)', key), key).toBe(true);
    });
  });
});

describe('the whole-book read answers to the Executive desk tick', () => {
  let deskless = 0, desklessUser = 0;
  let reader: Client;

  beforeAll(async () => {
    const made = await owner.call('POST', paths('/roles'), {
      name: 'Deskless Clerk', permissions: ['dashboard:view', 'products:view']
    });
    expect(made.status).toBe(201);
    deskless = made.json?.data?.id;
    const user = await owner.call('POST', paths('/users'), {
      name: 'Deskless Person', email: 'deskless@xenith.test', password: 'desk1234',
      roleId: deskless, branchIds: [BRANCH]
    });
    expect(user.status).toBe(201);
    desklessUser = user.json?.data?.id;
    reader = A.client();
    expect((await reader.as('deskless@xenith.test', 'desk1234')).status).toBe(200);
  });

  it('is refused for a role that was never given the desk', async () => {
    const r = await reader.call('GET', paths('/dashboard?period=This Month'));
    expect(r.status).toBe(403);
    expect(String(r.json?.error)).toMatch(/Executive/i);
  });

  // Saving a role writes exactly the ticks it was handed: the one-time top-up that finds a book
  // whose roles predate these screens must not become a stamp that re-adds them on every save.
  it('does not invent interface ticks when a role is saved', async () => {
    const row = ((await owner.call('GET', paths('/roles'))).json?.data || [])
      .find((r: any) => r.id === deskless);
    ALL_UI.forEach(key => {
      expect((row?.permissions ?? []).includes(`${key}:view`), key).toBe(false);
    });
    expect(row?.permissions).toContain('dashboard:view');
  });

  it('answers once the desk is ticked, and the ticks ride the session', async () => {
    const saved = await owner.call('PUT', paths(`/roles/${deskless}`), {
      permissions: ['dashboard:view', 'products:view', 'dashboard-executive:view', 'dash-cash:view']
    });
    expect(saved.status).toBe(200);
    const session = await reader.as('deskless@xenith.test', 'desk1234');
    expect(session.json?.user?.permissions).toContain('dashboard-executive:view');
    const r = await reader.call('GET', paths('/dashboard?period=This Month'));
    expect(r.status).toBe(200);
    expect(r.json?.period).toBeTruthy();
    expect(Array.isArray(r.json?.cashAndBankAccounts)).toBe(true);
  });

  it('and takes the read away again when the tick is cleared', async () => {
    expect((await owner.call('PUT', paths(`/roles/${deskless}`),
      { permissions: ['dashboard:view', 'products:view'] })).status).toBe(200);
    expect((await reader.as('deskless@xenith.test', 'desk1234')).status).toBe(200);
    expect((await reader.call('GET', paths('/dashboard?period=This Month'))).status).toBe(403);
  });

  it('still answers the owner, whose chair is every tick there is', async () => {
    expect((await owner.call('GET', paths('/dashboard?period=This Month'))).status).toBe(200);
  });

  afterAll(async () => {
    await owner.call('DELETE', paths(`/users/${desklessUser}`));
    await owner.call('DELETE', paths(`/roles/${deskless}`));
  });
});
