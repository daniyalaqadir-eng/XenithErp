import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['test/**/*.test.ts'],
    // The API keeps one company's whole book in module-level memory, so a fork per file would
    // give each file its own empty ledger. One process, files run one after another.
    pool: 'forks',
    poolOptions: { forks: { singleFork: true } },
    // A request that never answers is a defect worth finding, but the first call boots the
    // store, the seed and the password pass.
    testTimeout: 20000,
    hookTimeout: 120000
  },
  // The rounding test reads the browser's copy of the rule, which sits one package over.
  server: { fs: { allow: ['..'] } }
});
