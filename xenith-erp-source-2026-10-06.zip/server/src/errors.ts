import type { NextFunction, Request, Response } from 'express';
import { reassertWorkspace } from './tenant.js';

// ─── ERRORS ──────────────────────────────────────────────────────────────────
// Express 4 does not catch a rejected promise, so an `async` route that throws leaves the
// request hanging and the rejection unhandled. `wrap` hands the failure to `next`, which is
// the one path that reaches the central handler in index.ts.
export class ApiError extends Error {
  constructor(public status: number, message: string, public detail?: unknown) {
    super(message);
  }
}

export type AsyncHandler = (req: Request, res: Response, next: NextFunction) => Promise<unknown>;

export const wrap = (fn: AsyncHandler) => (req: Request, res: Response, next: NextFunction) => {
  reassertWorkspace();
  Promise.resolve(fn(req, res, next))
    .then(() => { reassertWorkspace(); })
    .catch((err) => {
      reassertWorkspace();
      next(err);
    });
};
