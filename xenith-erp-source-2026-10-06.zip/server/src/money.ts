// Money is rounded half up and away from zero, and it is rounded on the decimal string rather
// than on the product: 1.005 * 100 is 100.49999999999999 in binary, so a naive Math.round sends
// down a paisa a cashier would carry up, and Math.round takes a negative half towards zero,
// which makes a refund of the same figure land on a different rupee than the sale it reversed.
// The browser keeps a copy of this rule (client/src/utils/money.ts) so a form shows the total
// the books will post; the two copies are pinned to each other by a test.
export const roundMoney = (n: number): number => {
  const value = Number(n) || 0;
  const shifted = Number(`${Math.abs(value)}e2`);
  const cents = Number.isFinite(shifted) ? Math.round(shifted) : Math.round(Math.abs(value) * 100);
  return (value < 0 ? -cents : cents) / 100;
};

// Two names for the same rule, kept because the ledger and the document engine grew apart and
// every one of their hundreds of call sites says a different one.
export const rd = (n: number) => roundMoney(n);
export const r2 = (v: number) => roundMoney(v);
