import { AsyncLocalStorage } from 'node:async_hooks';

// ─── REQUEST-CONTEXTUAL TENANT ───────────────────────────────────────────────
// The open company is process state (§23): the /api gate calls useWorkspace(slug) and every
// handler reads the module collections that now hold that company's book. A handler that
// finishes in the same tick it started is safe, because nothing else runs between the swap
// and the write. A handler that awaits something outside the process is not — Meta's API, an
// SMTP relay, a clock — because whoever arrives during that pause moves the book out from
// under it, and the lines after the await then write into the wrong company.
//
// The context below carries the tenant that asked, so a resuming handler can name the book
// it belongs to and have it put back before it writes anything. The actor travels in the same
// bag: the audit line a handler leaves behind has to name the person it was answering for,
// not whoever the route's default happens to mention.
export type TenantScope = { slug: string; actor?: string; ip?: string };

export const tenantScope = new AsyncLocalStorage<TenantScope>();

let restore: (slug: string) => void = () => {};
// index.ts wires its own useWorkspace here once §23 is in scope.
export function onWorkspaceRestore(fn: (slug: string) => void) { restore = fn; }

// Returns the company the request belongs to, having made the process point at it again.
export function reassertWorkspace(): string {
  const scope = tenantScope.getStore();
  const slug = scope?.slug || '';
  if (slug) restore(slug);
  return slug;
}
