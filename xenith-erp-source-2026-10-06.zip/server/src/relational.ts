import type { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';

// ─── RELATIONAL LAYER ────────────────────────────────────────────────────────
// Phase 1 kept a company's book on disk as one JSON blob per row. This module
// replaces that blob with real tables: one table per collection, one row per
// record, its scalar fields promoted to columns, its nested arrays split into
// child tables keyed to the parent, and indexes on the columns the screens
// filter on — so `SELECT count(*) FROM sale_invoices WHERE status = 'Approved'`
// answers without the API running.
//
// Table shapes are derived from the data they are given, because the API holds
// ~95 workspace collections and 95 hand-written schemas would drift from the
// code on the first renamed field. Each row additionally carries its full JSON in
// `_json`: the columns exist for querying, while the in-memory model gets its
// records back exactly as they were stored.
//
// The store owns the surrounding transaction (see `setWriter` in store.ts), so
// nothing in here opens or commits one.

export const GLOBAL_SCOPE = '*';

type Handle = DatabaseSync;
type Kind = 'rows' | 'entries' | 'settings';

let handle: Handle | null = null;
let syncs = 0;
let rowWrites = 0;

const log = (msg: string) => console.log(`[xenith:db] ${msg}`);

const isScalar = (v: any) =>
  v === null || v === undefined || typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean';
const isPlain = (v: any) => !!v && typeof v === 'object' && !Array.isArray(v);
const sha = (s: string) => createHash('sha1').update(s).digest('hex');

const snake = (s: string) => s
  .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
  .replace(/[^a-zA-Z0-9]+/g, '_')
  .replace(/^_+|_+$/g, '')
  .toLowerCase();

const q = (s: string) => `"${s.replace(/"/g, '""')}"`;

function tableFor(slot: string): string {
  if (slot.startsWith('doc:')) return snake(`doc_${slot.slice(4)}`);
  return snake(slot.replace(/^mock(?=[A-Z])/, ''));
}

// Columns worth indexing: the ones the list pages, the report engine and the
// dashboards filter or join on. Everything else stays a plain column.
const HOT = new Set(['id', 'code', 'number', 'name', 'date', 'status', 'party_id', 'product_id',
  'sku', 'email1', 'phone1', 'is_active', 'branch_id', 'warehouse_id', 'sales_person_id', 'due_date']);

// ─── PLANNING COLUMNS FROM THE ROWS ──────────────────────────────────────────
type Role = { kind: 'column' } | { kind: 'children' };

// The union of keys over the rows: a key that ever holds an array becomes a child
// table, anything else becomes a column (NUMERIC when no row ever puts text in it).
function planFields(rows: any[]): Map<string, Role> {
  const seen = new Map<string, boolean>();
  rows.forEach(row => Object.entries(row || {}).forEach(([k, v]) => {
    if (!snake(k)) return;
    seen.set(k, (seen.get(k) || false) || Array.isArray(v));
  }));
  const plan = new Map<string, Role>();
  seen.forEach((isArray, k) => plan.set(k, isArray ? { kind: 'children' } : { kind: 'column' }));
  return plan;
}

const KEY_FIELDS = ['id', 'code', 'number', 'key', 'sku', 'name'];
const rowKeyOf = (row: any, i: number) => {
  const found = KEY_FIELDS.map(f => (isPlain(row) ? row?.[f] : undefined))
    .find(v => typeof v === 'number' || typeof v === 'string');
  return found === undefined ? `#${i}` : String(found);
};

function cellFor(v: any): any {
  if (v === null || v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;          // SQLite binds no boolean
  if (typeof v === 'number' || typeof v === 'string') return v;
  return JSON.stringify(v);                              // nested object → JSON text
}

type Cell = { value: any; text: boolean; path?: string };
type BuiltChild = { table: string; key: string; seq: number; hash: string; json: string; cols: Map<string, Cell> };
type Built = { key: string; seq: number; hash: string; json: string; cols: Map<string, Cell>; children: BuiltChild[] };

function fillCols(source: Record<string, any>, plan: Map<string, Role>, cols: Map<string, Cell>) {
  Object.entries(source).forEach(([k, v]) => {
    const name = snake(k);
    if (!name) return;
    if (plan.get(k)?.kind === 'children' || Array.isArray(v))
      cols.set(name, { value: JSON.stringify(v), text: true, path: k });
    // Only a real string forces TEXT: a column of numbers with the odd null has to
    // stay NUMERIC, or SQLite would store `party_id` as '101' and no join matches.
    else cols.set(name, { value: cellFor(v), text: typeof v === 'string' || isPlain(v), path: k });
  });
}

// One level of nesting becomes its own table; a second level would need a table
// per grandchild, so it is kept as JSON in the child's column instead.
function buildChildren(list: any[], table: string): BuiltChild[] {
  const plan = planFields(list);
  const used = new Set<string>();
  return list.map((item, i) => {
    let key = rowKeyOf(item, i);
    if (used.has(key)) key = `${key}#${i}`;
    used.add(key);
    const cols = new Map<string, Cell>();
    fillCols(isPlain(item) ? item : { value: item }, plan, cols);
    const json = JSON.stringify(item);
    return { table, key, seq: i, hash: sha(json), json, cols };
  });
}

function buildRows(list: any[], table: string): Built[] {
  const plan = planFields(list);
  const used = new Set<string>();
  return list.map((row, i) => {
    let key = rowKeyOf(row, i);
    if (used.has(key)) key = `${key}#${i}`;   // duplicate ids must not overwrite each other
    used.add(key);
    const cols = new Map<string, Cell>();
    const children: BuiltChild[] = [];
    Object.entries(row || {}).forEach(([k, v]) => {
      if (plan.get(k)?.kind === 'children') buildChildren(v as any[], `${table}_${snake(k)}`).forEach(c => children.push(c));
      else fillCols({ [k]: v }, new Map([[k, { kind: 'column' } as Role]]), cols);
    });
    const json = JSON.stringify(row);
    return { key, seq: i, hash: sha(json), json, cols, children };
  });
}

// ─── SCHEMA ──────────────────────────────────────────────────────────────────
// Column name → declared type, per table.
const knownColumns = new Map<string, Map<string, string>>();
const childTablesOf = new Map<string, Set<string>>();

function declare(tbl: string) {
  const h = handle!;
  h.exec(`CREATE TABLE IF NOT EXISTS ${q(tbl)} (
    _company TEXT NOT NULL, _key TEXT NOT NULL, _seq INTEGER NOT NULL,
    _hash TEXT NOT NULL, _json TEXT NOT NULL, PRIMARY KEY (_company, _key)
  )`);
  h.exec(`CREATE INDEX IF NOT EXISTS ${q(`${tbl.slice(0, 42)}_order_ix`)} ON ${q(tbl)} (_company, _seq)`);
  knownColumns.set(tbl, new Map((h.prepare(`PRAGMA table_info(${q(tbl)})`).all() as { name: string; type: string }[])
    .map(c => [c.name, (c.type || 'TEXT').toUpperCase()])));
}

// A nested array gets its own table: the parent's key plus its position identify
// a line, and the parent link is what a join walks.
function declareChild(tbl: string, parentTbl: string) {
  const h = handle!;
  h.exec(`CREATE TABLE IF NOT EXISTS ${q(tbl)} (
    _company TEXT NOT NULL, _parent TEXT NOT NULL, _key TEXT NOT NULL, _seq INTEGER NOT NULL,
    _hash TEXT NOT NULL, _json TEXT NOT NULL,
    PRIMARY KEY (_company, _parent, _key), FOREIGN KEY (_company, _parent)
      REFERENCES ${q(parentTbl)} (_company, _key) ON DELETE CASCADE
  )`);
  h.exec(`CREATE INDEX IF NOT EXISTS ${q(`${tbl.slice(0, 42)}_parent_ix`)} ON ${q(tbl)} (_company, _parent)`);
  knownColumns.set(tbl, new Map((h.prepare(`PRAGMA table_info(${q(tbl)})`).all() as { name: string; type: string }[])
    .map(c => [c.name, (c.type || 'TEXT').toUpperCase()])));
}

// SQLite has no "create table if not exists with these columns", and the column
// list is only known once rows are in hand, so tables grow by ALTER: a field the
// data starts carrying adds its column the first time it is synced.
//
// A column is then filled from `_json` rather than left to the rows that happen
// to change next, which also heals the case where a field's type was decided from
// too few rows: the column is rebuilt from the stored records, not from a guess.
function addColumns(tbl: string, cols: Map<string, Cell>) {
  const h = handle!;
  if (!knownColumns.has(tbl)) declare(tbl);
  const have = knownColumns.get(tbl)!;
  cols.forEach((cell, name) => {
    const type = cell.text ? 'TEXT' : 'NUMERIC';
    const existing = have.get(name);
    if (existing === type) return;
    if (existing !== undefined) {
      // SQLite refuses to drop an indexed column, so the index goes with it and is
      // rebuilt below once the column has its new type.
      h.exec(`DROP INDEX IF EXISTS ${q(`${tbl.slice(0, 40)}_${name}_ix`)}`);
      h.exec(`ALTER TABLE ${q(tbl)} DROP COLUMN ${q(name)}`);
      h.exec(`ALTER TABLE ${q(tbl)} ADD COLUMN ${q(name)} ${type}`);
      if (cell.path)
        h.prepare(`UPDATE ${q(tbl)} SET ${q(name)} = json_extract(_json, ?)`).run(`$."${cell.path}"`);
    } else {
      h.exec(`ALTER TABLE ${q(tbl)} ADD COLUMN ${q(name)} ${type}`);
      if (cell.path)
        h.prepare(`UPDATE ${q(tbl)} SET ${q(name)} = json_extract(_json, ?) WHERE ${q(name)} IS NULL`)
          .run(`$."${cell.path.replace(/"/g, '')}"`);
    }
    have.set(name, type);
    if (HOT.has(name))
      h.exec(`CREATE INDEX IF NOT EXISTS ${q(`${tbl.slice(0, 40)}_${name}_ix`)} ON ${q(tbl)} (${q(name)})`);
  });
}

function noteChild(parentTbl: string, childTbl: string) {
  const list = childTablesOf.get(parentTbl) || new Set<string>();
  if (!list.has(childTbl)) {
    list.add(childTbl);
    childTablesOf.set(parentTbl, list);
    handle!.prepare('INSERT INTO relational_children (parent_tbl, child_tbl) VALUES (?, ?) ON CONFLICT DO NOTHING')
      .run(parentTbl, childTbl);
  }
}

function dropChildren(parentTbl: string, company: string, key: string) {
  (childTablesOf.get(parentTbl) || new Set<string>()).forEach(t =>
    handle!.prepare(`DELETE FROM ${q(t)} WHERE _company = ? AND _parent = ?`).run(company, key));
}

// ─── WRITING ONE COLLECTION ─────────────────────────────────────────────────
function writeRows(tbl: string, company: string, rows: Built[]): number {
  const h = handle!;
  const merged = new Map<string, Cell>();
  rows.forEach(r => r.cols.forEach((c, name) =>
    merged.set(name, { value: null, text: (merged.get(name)?.text ?? false) || c.text, path: c.path })));
  addColumns(tbl, merged);
  const cols = [...knownColumns.get(tbl)!.keys()].filter(c => !c.startsWith('_')).sort();

  // Child tables must exist before anything references them, so they are declared
  // from the union of the rows being written, not row by row.
  const kids = new Map<string, Map<string, Cell>>();
  rows.forEach(r => r.children.forEach(c => {
    const map = kids.get(c.table) || new Map<string, Cell>();
    c.cols.forEach((cell, name) => map.set(name,
      { value: null, text: (map.get(name)?.text ?? false) || cell.text, path: cell.path }));
    kids.set(c.table, map);
    noteChild(tbl, c.table);
  }));
  kids.forEach((map, childTbl) => {
    if (!knownColumns.has(childTbl)) declareChild(childTbl, tbl);
    addColumns(childTbl, map);
  });

  const existing = new Map<string, string>();
  (h.prepare(`SELECT _key, _hash FROM ${q(tbl)} WHERE _company = ?`).all(company) as
    { _key: string; _hash: string }[]).forEach(r => existing.set(r._key, r._hash));

  const argList = cols.map(q).join(', ');
  const ins = h.prepare(`INSERT INTO ${q(tbl)} (_company, _key, _seq, _hash, _json${
    cols.length ? ', ' + argList : ''}) VALUES (${['_company', '_key', '_seq', '_hash', '_json']
    .concat(cols).map(() => '?').join(', ')})`);
  const upd = h.prepare(`UPDATE ${q(tbl)} SET _seq = ?, _hash = ?, _json = ?${
    cols.length ? ', ' + cols.map(c => `${q(c)} = ?`).join(', ') : ''} WHERE _company = ? AND _key = ?`);
  const drop = h.prepare(`DELETE FROM ${q(tbl)} WHERE _company = ? AND _key = ?`);

  const childInserts = new Map<string, { names: string[]; stmt: ReturnType<Handle['prepare']> }>();
  kids.forEach((_map, childTbl) => {
    const names = [...knownColumns.get(childTbl)!.keys()].filter(c => !c.startsWith('_')).sort();
    childInserts.set(childTbl, {
      names,
      stmt: h.prepare(`INSERT INTO ${q(childTbl)} (_company, _parent, _key, _seq, _hash, _json${
        names.length ? ', ' + names.map(q).join(', ') : ''}) VALUES (${['_company', '_parent', '_key', '_seq', '_hash', '_json']
        .concat(names).map(() => '?').join(', ')})`)
    });
  });
  const delChild = new Map<string, ReturnType<Handle['prepare']>>();
  kids.forEach((_map, childTbl) => delChild.set(childTbl,
    h.prepare(`DELETE FROM ${q(childTbl)} WHERE _company = ? AND _parent = ?`)));

  let writes = 0;
  const keep = new Set<string>();
  rows.forEach(row => {
    keep.add(row.key);
    const before = existing.get(row.key);
    const changed = before !== row.hash;
    const values = cols.map(c => row.cols.get(c)?.value ?? null);
    if (before === undefined) ins.run(company, row.key, row.seq, row.hash, row.json, ...values);
    else if (changed) upd.run(row.seq, row.hash, row.json, ...values, company, row.key);
    if (changed) {
      // Children are rebuilt wholesale for a parent that moved: their content is
      // already covered by the parent's hash, so there is nothing to diff.
      const tables = new Set(row.children.map(c => c.table));
      tables.forEach(t => delChild.get(t)?.run(company, row.key));
      row.children.forEach(child => {
        const found = childInserts.get(child.table);
        if (!found) return;
        found.stmt.run(company, row.key, child.key, child.seq, child.hash, child.json,
          ...found.names.map(n => child.cols.get(n)?.value ?? null));
      });
      writes++;
    }
  });

  existing.forEach((_, key) => {
    if (keep.has(key)) return;
    dropChildren(tbl, company, key);
    drop.run(company, key);
    writes++;
  });
  return writes;
}

// ─── CLASSIFYING A SLOT ──────────────────────────────────────────────────────
type Shaped = { kind: Kind; rows?: any[]; entries?: [string, any][] };

function classify(value: any): Shaped {
  if (Array.isArray(value)) return { kind: 'rows', rows: value };
  // A document engine table reads as { rows, seqs }: records plus its counters.
  if (isPlain(value) && Array.isArray(value.rows)) return { kind: 'rows', rows: value.rows };
  if (isPlain(value) && Object.keys(value).length &&
      Object.values(value).every(v => isPlain(v) && Object.values(v as Record<string, any>).every(isScalar)))
    return { kind: 'entries', entries: Object.entries(value) };
  return { kind: 'settings' };
}

function writeSetting(company: string, key: string, value: any) {
  handle!.prepare(`INSERT INTO workspace_settings (_company, key, value) VALUES (?, ?, ?)
    ON CONFLICT(_company, key) DO UPDATE SET value = excluded.value`).run(company, key, JSON.stringify(value ?? null));
}

// ─── PUBLIC API ──────────────────────────────────────────────────────────────
export function relationalReady(): boolean { return handle !== null; }

export function initRelational(h: Handle) {
  handle = h;
  h.exec(`
    CREATE TABLE IF NOT EXISTS relational_map (slot TEXT PRIMARY KEY, tbl TEXT NOT NULL, kind TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS relational_slots (slot TEXT NOT NULL, _company TEXT NOT NULL,
      synced_at TEXT NOT NULL, PRIMARY KEY (slot, _company));
    CREATE TABLE IF NOT EXISTS relational_children (parent_tbl TEXT NOT NULL, child_tbl TEXT NOT NULL,
      PRIMARY KEY (parent_tbl, child_tbl));
    CREATE TABLE IF NOT EXISTS workspace_settings (_company TEXT NOT NULL, key TEXT NOT NULL,
      value TEXT NOT NULL, PRIMARY KEY (_company, key));
  `);
  // Child tables recorded in earlier runs are needed before the first delete,
  // otherwise a collection that has just emptied leaves orphans behind.
  (h.prepare('SELECT parent_tbl, child_tbl FROM relational_children').all() as
    { parent_tbl: string; child_tbl: string }[]).forEach(r => {
    const list = childTablesOf.get(r.parent_tbl) || new Set<string>();
    list.add(r.child_tbl);
    childTablesOf.set(r.parent_tbl, list);
  });
  return true;
}

// Persist one company's whole book (or the account-level state, under '*').
// Returns the number of rows that actually changed, so a no-op request stays a
// no-op on disk.
export function syncState(company: string, values: Record<string, any>): number {
  if (!handle) return 0;
  const h = handle;
  let writes = 0;
  syncs++;
  Object.entries(values).forEach(([slot, value]) => {
    try {
      const tbl = tableFor(slot);
      const shape = classify(value);
      h.prepare(`INSERT INTO relational_map (slot, tbl, kind) VALUES (?, ?, ?)
        ON CONFLICT(slot) DO UPDATE SET tbl = excluded.tbl, kind = excluded.kind`).run(slot, tbl, shape.kind);
      if (shape.kind === 'settings') {
        writeSetting(company, slot, value);
        writes++;
      } else if (shape.kind === 'entries') {
        writes += writeRows(tbl, company,
          buildRows((shape.entries || []).map(([key, entry]) => ({ key, ...entry })), tbl));
      } else {
        writes += writeRows(tbl, company, buildRows(shape.rows || [], tbl));
        if (isPlain(value)) writeSetting(company, `${slot}.seqs`, value.seqs ?? {});
      }
      // The book only admits it holds this slot once the data is down. Registering
      // first would leave a slot naming a table that a failed write never created.
      h.prepare(`INSERT INTO relational_slots (slot, _company, synced_at) VALUES (?, ?, ?)
        ON CONFLICT(slot, _company) DO UPDATE SET synced_at = excluded.synced_at`)
        .run(slot, company, new Date().toISOString());
    } catch (err) {
      // One collection that will not map must not cost the company the rest of its book.
      log(`sync of ${slot} for ${company} failed: ${(err as Error).message}`);
    }
  });
  rowWrites += writes;
  return writes;
}

export function hasState(company: string): boolean {
  return !!handle?.prepare('SELECT 1 AS x FROM relational_slots WHERE _company = ? LIMIT 1').get(company);
}

// Retire one company's rows for a list of slots, with the bookkeeping that made the book
// admit it held them. A collection that moved out of the shared directory has to leave it,
// or the old copy — holding password hashes nobody can now reach — rides along in every
// backup for the life of the file.
export function dropScopeSlots(company: string, slots: string[]): number {
  const h = handle;
  if (!h) return 0;
  let dropped = 0;
  slots.forEach(slot => {
    const mapped = h.prepare('SELECT tbl, kind FROM relational_map WHERE slot = ?').get(slot) as
      { tbl: string; kind: Kind } | undefined;
    if (mapped) {
      (childTablesOf.get(mapped.tbl) || new Set<string>()).forEach(t => {
        dropped += h.prepare(`DELETE FROM ${q(t)} WHERE _company = ?`).run(company).changes as number;
      });
      if (mapped.kind === 'settings') {
        dropped += h.prepare('DELETE FROM workspace_settings WHERE _company = ? AND (key = ? OR key LIKE ?)')
          .run(company, slot, `${slot}.%`).changes as number;
      } else {
        dropped += h.prepare(`DELETE FROM ${q(mapped.tbl)} WHERE _company = ?`).run(company).changes as number;
        dropped += h.prepare('DELETE FROM workspace_settings WHERE _company = ? AND key = ?')
          .run(company, `${slot}.seqs`).changes as number;
      }
    }
    h.prepare('DELETE FROM relational_slots WHERE slot = ? AND _company = ?').run(slot, company);
  });
  return dropped;
}

// Read a book back into exactly the shape the workspace restore expects. A slot
// the database never saw stays absent, so the seeds still fill a collection this
// build added after the snapshot was written.
export function loadState(company: string): Record<string, any> | null {
  const h = handle;
  if (!h) return null;
  const slots = (h.prepare(`SELECT s.slot, m.tbl, m.kind FROM relational_slots s
    JOIN relational_map m ON m.slot = s.slot WHERE s._company = ?`).all(company) as
    { slot: string; tbl: string; kind: Kind }[]);
  if (!slots.length) return null;
  const settings = new Map<string, any>(
    (h.prepare('SELECT key, value FROM workspace_settings WHERE _company = ?').all(company) as
      { key: string; value: string }[]).map(r => [r.key, JSON.parse(r.value)]));
  const out: Record<string, any> = {};
  slots.forEach(({ slot, tbl, kind }) => {
    if (kind === 'settings') {
      out[slot] = settings.get(slot);
      return;
    }
    const rows = (h.prepare(`SELECT _key, _json FROM ${q(tbl)} WHERE _company = ? ORDER BY _seq`).all(company) as
      { _key: string; _json: string }[]).map(r => JSON.parse(r._json));
    if (kind === 'entries') {
      const obj: Record<string, any> = {};
      rows.forEach((row: any) => {
        const { key, ...rest } = row;
        obj[String(key)] = rest;
      });
      out[slot] = obj;
    } else if (slot.startsWith('doc:')) {
      out[slot] = { rows, seqs: settings.get(`${slot}.seqs`) || {} };
    } else {
      out[slot] = rows;
    }
  });
  return out;
}

// ─── READING A COLLECTION OUT OF SQL ─────────────────────────────────────────
// The other half of persistence: answering a request from the tables instead of
// from the copy of the book that boot hydrated into memory. `queryDocs` states
// what it can prove and returns null for anything else — persistence off, this
// company's collection never synced, a filter on a field no row ever carried —
// and the caller keeps its in-memory answer for those cases.
//
// Rows come back as the `_json` the writer stored, so a record reads byte-for-byte
// like the object the route would have handed out: the columns decide *which* rows
// match, the payload decides what the client sees.

// LIKE's own wildcards have to be escaped or a search for "100%" matches anything.
const likeParam = (s: string) => '%' + s.replace(/[\\%_]/g, c => '\\' + c) + '%';

// Columns of a table, read from the database when this process has not written it
// yet (a server that only answers reads never reaches `declare`).
function columnsOf(tbl: string): Set<string> | null {
  const h = handle;
  if (!h) return null;
  const known = knownColumns.get(tbl);
  if (known) return new Set(known.keys());
  const info = h.prepare(`PRAGMA table_info(${q(tbl)})`).all() as { name: string; type: string }[];
  if (!info.length) return null;
  knownColumns.set(tbl, new Map(info.map(c => [c.name, (c.type || 'TEXT').toUpperCase()])));
  return new Set(info.map(c => c.name));
}

export type DocQuery = {
  company: string;
  slot: string;
  id?: number;
  status?: string;
  search?: string;
  // Header fields a search reads, and the nested arrays whose rows it also reads.
  fields?: string[];
  groups?: { field: string; anyOf: string[] }[];
  // A salesman-scoped actor sees only the paper they raised or were handed.
  own?: { userId: number; salesPersonId: number | null } | null;
};

export function queryDocs(f: DocQuery): any[] | null {
  const h = handle;
  if (!h) return null;
  const mapped = h.prepare('SELECT kind FROM relational_map WHERE slot = ?').get(f.slot) as
    { kind: Kind } | undefined;
  if (!mapped || mapped.kind !== 'rows') return null;
  const tbl = tableFor(f.slot);
  // A company this build only seeded in memory has no rows on disk to answer from.
  if (!h.prepare('SELECT 1 AS x FROM relational_slots WHERE slot = ? AND _company = ? LIMIT 1')
    .get(f.slot, f.company)) return null;
  const cols = columnsOf(tbl);
  if (!cols) return null;

  const where = ['t._company = ?'];
  const args: any[] = [f.company];
  // A field the table has no column for is a field no stored record ever carried,
  // which the in-memory filter would have read as an empty string — so dropping
  // that term is the same answer, not a looser one.
  const has = (tbl2: Set<string> | null, key: string) => !!tbl2 && tbl2.has(key);

  if (f.id !== undefined) {
    if (!has(cols, 'id')) return null;
    where.push('t."id" = ?'); args.push(f.id);
  }
  if (f.status) {
    if (!has(cols, 'status')) return null;
    where.push('t."status" = ?'); args.push(f.status);
  }
  if (f.own) {
    if (!has(cols, 'created_by_id')) return null;
    const terms = ['t."created_by_id" = ?'];
    const vals: any[] = [f.own.userId];
    if (f.own.salesPersonId) {
      if (!has(cols, 'sales_person_id')) return null;
      terms.push('t."sales_person_id" = ?'); vals.push(f.own.salesPersonId);
    }
    where.push(`(${terms.join(' OR ')})`); args.push(...vals);
  }

  const needle = String(f.search || '');
  if (needle) {
    const terms: string[] = [];
    const vals: any[] = [];
    (f.fields || []).forEach(field => {
      const c = snake(field);
      if (!has(cols, c)) return;
      terms.push(`t.${q(c)} LIKE ? ESCAPE '\\'`); vals.push(likeParam(needle));
    });
    (f.groups || []).forEach(group => {
      const childTbl = `${tbl}_${snake(group.field)}`;
      const childCols = columnsOf(childTbl);
      if (!childCols) return;
      const inner = group.anyOf.map(snake).filter(c => has(childCols, c));
      if (!inner.length) return;
      // The line tables hang off their document by (_company, _parent), so one
      // EXISTS answers "this document carries a product by that name".
      terms.push(`EXISTS (SELECT 1 FROM ${q(childTbl)} c WHERE c._company = t._company
        AND c._parent = t._key AND (${inner.map(c => `c.${q(c)} LIKE ? ESCAPE '\\'`).join(' OR ')}))`);
      inner.forEach(() => vals.push(likeParam(needle)));
    });
    where.push(terms.length ? `(${terms.join(' OR ')})` : '0 = 1');
    args.push(...vals);
  }

  const rows = h.prepare(`SELECT t._json AS j FROM ${q(tbl)} t WHERE ${where.join(' AND ')}
    ORDER BY t._seq`).all(...args) as { j: string }[];
  return rows.map(r => JSON.parse(r.j));
}

export function relationalStats() {
  const h = handle;
  if (!h) return { syncs, rowWrites, companies: [], tables: [], children: [] };
  // Config-shaped slots have no table of their own — they live in workspace_settings —
  // and a slot whose write failed after it was mapped can name a table that was never
  // created, so only tables that exist are counted.
  const present = new Set((h.prepare(`SELECT name FROM sqlite_master WHERE type = 'table'`).all() as
    { name: string }[]).map(r => r.name));
  const shaped = (h.prepare(`SELECT slot, tbl, kind FROM relational_map WHERE kind != 'settings'
    ORDER BY slot`).all() as { slot: string; tbl: string; kind: Kind }[])
    .filter(t => present.has(t.tbl));
  const count = (tbl: string) =>
    (h.prepare(`SELECT count(*) AS n FROM ${q(tbl)}`).get() as { n: number }).n;
  return {
    syncs,
    rowWrites,
    companies: (h.prepare(`SELECT _company AS slug, count(*) AS slots, max(synced_at) AS synced_at
      FROM relational_slots GROUP BY _company ORDER BY _company`).all() as
      { slug: string; slots: number; synced_at: string }[]),
    tables: shaped.map(t => ({ ...t, rows: count(t.tbl) })),
    children: (h.prepare('SELECT parent_tbl, child_tbl FROM relational_children ORDER BY parent_tbl').all() as
      { parent_tbl: string; child_tbl: string }[]).filter(r => present.has(r.child_tbl))
      .map(r => ({ ...r, rows: count(r.child_tbl) }))
  };
}
