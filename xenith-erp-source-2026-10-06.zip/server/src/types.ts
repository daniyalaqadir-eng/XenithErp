export enum EntryType {
  Debit = 0,
  Credit = 1
}

export enum SchemeType {
  Normal = 0,
  Scheme = 1
}

export enum PaymentMode {
  Cash = 10,
  Cheque = 20,
  Draft = 30,
  DirectDeposit = 40,
  CreditCard = 50,
  UndepositedFunds = 60
}

export const PaymentModeList = [
  { text: "Cash", value: PaymentMode.Cash },
  { text: "Cheque", value: PaymentMode.Cheque },
  { text: "Draft", value: PaymentMode.Draft },
  { text: "Direct Deposit", value: PaymentMode.DirectDeposit },
  { text: "Credit Card", value: PaymentMode.CreditCard },
  { text: "Undeposited Funds", value: PaymentMode.UndepositedFunds }
];

export enum DiscountType {
  Percent = 1,
  Amount = 2,
  Price = 3
}

export interface Branch {
  id: number;
  name: string;
  code: string;
  isMain: boolean;
  address?: string;
  city?: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  email?: string;
  taxNumber?: string;
  managerName?: string;
  isActive?: boolean;
}

export interface DetailBGroup {
  id: number;
  name: string;
  isDefault: boolean;
  branchIds: number[];
  branches?: Branch[];
}

export interface ProductBreakupItem {
  id: number;
  productBreakupDetailId?: number;
  packagingId: string;
  size: number;
  qty: number;
  saleQty?: number;
}

export interface InvoiceLineItem {
  id: number;
  productId: number;
  productName: string;
  fractionalUnit?: boolean;
  allowChangeQuantity?: boolean;
  quantity: number;
  price: number;
  grossAmount: number;
  discountType: DiscountType;
  discountInPercent?: number;
  discountInAmount?: number;
  discountInPrice?: number;
  discountAmount: number;
  taxRate: number;
  taxAmount: number;
  netAmount: number;
  packagingBreakups?: ProductBreakupItem[];
}

export enum DocumentType {
  CustomerPayment = "CustomerPayment",
  InventoryAdjustment = "InventoryAdjustment",
  JournalEntry = "JournalEntry",
  PurchaseInvoice = "PurchaseInvoice",
  ImportInvoice = "ImportInvoice",
  PurchaseReturn = "PurchaseReturn",
  SaleInvoice = "SaleInvoice",
  PosInvoice = "PosInvoice",
  SaleReturn = "SaleReturn",
  SaleDelivery = "SaleDelivery",
  VendorPayment = "VendorPayment",
  JobOrder = "JobOrder",
  Disassembling = "Disassembling",
  TransferOut = "TransferOut",
  TransferIn = "TransferIn",
  TransferAdvice = "TransferAdvice",
  StockMovement = "StockMovement",
  PosSummary = "PosSummary",
  CashVoucher = "CashVoucher",
  BankVoucher = "BankVoucher",
  CashReceiptVoucher = "CashReceiptVoucher",
  BankReceiptVoucher = "BankReceiptVoucher"
}

export const DocumentTypeList = [
  { text: "Receive Payment", value: DocumentType.CustomerPayment },
  { text: "Stock Adjustment", value: DocumentType.InventoryAdjustment },
  { text: "Journal Entry", value: DocumentType.JournalEntry },
  { text: "Purchase Invoice", value: DocumentType.PurchaseInvoice },
  { text: "Import Invoice", value: DocumentType.ImportInvoice },
  { text: "Purchase Return", value: DocumentType.PurchaseReturn },
  { text: "Sales Invoice", value: DocumentType.SaleInvoice },
  { text: "Pos Invoice", value: DocumentType.PosInvoice },
  { text: "Sales Return", value: DocumentType.SaleReturn },
  { text: "Vendor Payment", value: DocumentType.VendorPayment },
  { text: "Job Order", value: DocumentType.JobOrder },
  { text: "Disassembling", value: DocumentType.Disassembling },
  { text: "Transfer Out", value: DocumentType.TransferOut },
  { text: "Transfer In", value: DocumentType.TransferIn },
  { text: "Transfer Advice", value: DocumentType.TransferAdvice },
  { text: "POS Summary", value: DocumentType.PosSummary },
  { text: "Cash Voucher", value: DocumentType.CashVoucher },
  { text: "Bank Voucher", value: DocumentType.BankVoucher },
  { text: "Cash Receipt Voucher", value: DocumentType.CashReceiptVoucher },
  { text: "Bank Receipt Voucher", value: DocumentType.BankReceiptVoucher }
];

export const DocumentTypeLabels: Record<string, string> = {
  CustomerPayment: "Receive Payment",
  InventoryAdjustment: "Stock Adjustment",
  JournalEntry: "Journal Entry",
  PurchaseInvoice: "Purchase Invoice",
  ImportInvoice: "Import Invoice",
  ImportInvoiceExpense: "Import Invoice Expense",
  PurchaseReturn: "Purchase Return",
  SaleInvoice: "Sales Invoice",
  PosInvoice: "PosInvoice",
  SaleDelivery: "Sales SaleDelivery",
  SaleReturn: "Sales Return",
  VendorPayment: "Vendor Payment",
  JobOrder: "Job Order",
  Disassembling: "Disassembling",
  TransferOut: "Transfer Out",
  TransferIn: "Transfer In",
  TransferAdvice: "Transfer Advice",
  CashVoucher: "Cash Voucher",
  BankVoucher: "Bank Voucher",
  CashReceiptVoucher: "Cash Receipt Voucher",
  BankReceiptVoucher: "Bank Receipt Voucher",
  "JournalEntryDetail:Debit": "Journal Entry",
  "JournalEntryDetail:Credit": "Journal Entry"
};

export interface PurchaseInvoice {
  id: number;
  invoiceNumber: string;
  vendorName: string;
  date: string;
  dueDate: string;
  status: 'Draft' | 'Pending' | 'Approved' | 'Void';
  items: InvoiceLineItem[];
  subTotal: number;
  totalDiscount: number;
  totalTax: number;
  grandTotal: number;
  isReturn?: boolean;
}


// Banking Module

// heads (customer payments, cash sales, advances), so each paper carries its own lines.
export interface BankAccount {
  id: number;
  accountTitle: string;
  bankName: string;
  accountNumber: string;
  balance: number;
  iban?: string;
  branchCode?: string;
  isActive: boolean;
  // The company branch this bank account is held at — separate from branchCode, which is
  // the bank's own branch code printed on the cheque.
  branchId?: number;
  branchName?: string;
  description?: string;
  acceptsChequeBook?: boolean;
  acceptsCreditCard?: boolean;
  linkedAccountId?: number;
  linkedAccountName?: string;
  openingBalanceDate?: string;
}

export interface BankTransaction {
  id: number;
  transactionDate: string;
  description: string;
  credit: number;
  debit: number;
  balance: number;
  bankAccountId: number;
  referenceNumber?: string;
}
