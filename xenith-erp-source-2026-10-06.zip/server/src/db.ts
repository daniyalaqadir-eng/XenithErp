import { Branch, DetailBGroup, PurchaseInvoice, DiscountType } from './types.js';

// One branch ships: the owner asked for a single company with a single location, and the
// branch screen adds the rest back whenever he wants them.
export const mockBranches: Branch[] = [
  { id: 38039, name: 'Main Branch', code: 'BR-01', isMain: true, address: 'Plot 12, Shahrah-e-Faisal', city: 'Karachi', latitude: 24.8607, longitude: 67.0011, phone: '+92 21 3456 7890', email: 'headoffice@xenitherp.com', taxNumber: 'NTN-101-4455-7788', managerName: 'Muhammad', isActive: true }
];

// A new book opens with no groups filed under it; the screen adds the ones the company
// actually trades with.
export let mockDetailBGroups: DetailBGroup[] = [];

export let mockPurchaseInvoices: PurchaseInvoice[] = [];

// The invoices still standing open on a customer account. Aged receivables and the
// period-window reports read this; money already taken in is not here.
export const mockUnsettledDebits: any[] = [];

