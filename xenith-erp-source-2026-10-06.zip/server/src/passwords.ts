import { randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';

// ─── PASSWORD HASHING ────────────────────────────────────────────────────────
// scrypt runs on libuv's thread pool instead of on the event loop: a synchronous hash of
// this cost measured ~51 ms here, so ten people typing a wrong password on the login page
// stopped every other tenant's request for half a second. The output is byte-identical to
// the synchronous call the books were written with, so every stored `scrypt$…` value keeps
// verifying and no password has to be reset.
const derive = promisify(scrypt) as (plain: string, salt: string, keylen: number) => Promise<Buffer>;

// The thread pool is four threads deep by default; letting more than one hash per thread
// queue up just moves the wait, and a long queue is what a scripted attack is after.
const MAX_PARALLEL = 4;
let busy = 0;
const waiting: (() => void)[] = [];
const enter = () => new Promise<void>(done => {
  if (busy < MAX_PARALLEL) { busy++; done(); } else waiting.push(done);
});
const leave = () => {
  busy--;
  const next = waiting.shift();
  if (next) { busy++; next(); }
};

const PREFIX = 'scrypt$';
export const looksHashed = (stored: unknown) => String(stored || '').startsWith(PREFIX);

export async function hashPassword(plain: string): Promise<string> {
  const salt = randomBytes(16).toString('hex');
  await enter();
  try {
    return `${PREFIX}${salt}$${(await derive(String(plain), salt, 32)).toString('hex')}`;
  } finally { leave(); }
}

export async function checkPassword(stored: unknown, plain: unknown): Promise<boolean> {
  if (!looksHashed(stored)) return false;
  const [, salt, hex] = String(stored).split('$');
  const want = Buffer.from(hex, 'hex');
  await enter();
  try {
    const got = await derive(String(plain || ''), salt, want.length);
    return want.length === got.length && timingSafeEqual(want, got);
  } catch {
    // A salt or key length that this call cannot read is a failed password, not a 500.
    return false;
  } finally { leave(); }
}
