import { DatabaseSync } from 'node:sqlite';
import { copyFileSync, existsSync, mkdirSync, renameSync, rmSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';

// ─── SQLITE SNAPSHOT STORE ───────────────────────────────────────────────────
// The API keeps a company's whole book in memory (see the workspace snapshot in
// §23). This module gives that state a home on disk so a restart, a crash or a
// `tsx watch` reload no longer erases what the user typed: each snapshot is one
// JSON payload in one row, keyed by the same name the in-memory map uses.
//
// The store is deliberately write-behind. A route mutates the collections and
// answers immediately; the row is rewritten a few hundred milliseconds later,
// which keeps a burst of saves from serialising a large company over and over.
// Hydration at start-up is still the only *bulk* read, but since Phase 3 a route
// that answers from SQL calls `flushStore()` first, so a save is never hidden from
// the request that follows it.

// Bump when a stored snapshot can no longer be trusted by this build (a renamed
// field, a changed document shape). Stale rows are dropped and the seeds re-run.
export const STORE_VERSION = 1;

type Getter = () => unknown;

const DEFAULT_FILE = 'data/xenith.db';
// The name this software carried before, as a book on disk still carries it. A customer's
// records do not change because the product's name does, so an installation holding the old
// file is moved across at boot. This is the one place the old word may be written: it is a
// filename on someone else's disk, not a name shown to anyone.
const LEGACY_BASENAME = 'nexus.db';

let db: DatabaseSync | null = null;
let file = '';
// Keys with a pending write, each with the closure that produces its latest value.
const pending = new Map<string, Getter>();
let timer: ReturnType<typeof setTimeout> | null = null;
let writes = 0;
let flushes = 0;

const log = (msg: string) => console.log(`[xenith:store] ${msg}`);

// The book this software opens today is called `xenith.db`; a shop that has been trading since
// before the naming still holds its records under the file this build used to write. A
// customer's data does not move because the product's name did, so the move is done here, at
// boot, before either file is opened — and a copy of both names goes into a folder beside them
// first, so a half-finished move can always be undone.
//
// When both names exist the older one wins: a file under the newer name can only have been
// started by this build itself, so it is put aside rather than chosen. Whichever way it goes,
// nothing here deletes a book — it only ever copies.
function adoptLegacyBook(target: string): string {
  const dir = dirname(target);
  const legacy = join(dir, LEGACY_BASENAME);
  if (!existsSync(legacy)) return target;
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  const keep = join(dir, `_before-rename-${stamp}`);
  // A book is three files, and they have to be taken apart in this order — the journal and its
  // sidecar before the main file — so nothing ever meets a main file stripped of writes it had
  // not absorbed yet. Each copy keeps its own name inside its own folder, so either one can be
  // put straight back and opened.
  const parts = (base: string) => ['-shm', '-wal', ''].map(s => base + s).filter(p => existsSync(p));
  const stash = (base: string, where: string) => {
    mkdirSync(where, { recursive: true });
    for (const p of parts(base)) copyFileSync(p, join(where, basename(p)));
  };
  try {
    stash(legacy, join(keep, 'held-under-the-old-name'));
    stash(target, join(keep, 'held-under-the-new-name'));
    for (const p of parts(target)) rmSync(p);
    for (const p of parts(legacy)) renameSync(p, target + p.slice(legacy.length));
    log(`this book was written under an earlier name — moved to ${basename(target)}, both copies kept in ${keep}`);
    return target;
  } catch (err) {
    // Starting with an empty book beside a full one is how a shop loses a day of trading, so a
    // move that cannot be finished stops here rather than opening a fresh file.
    throw new Error(`could not move ${basename(legacy)} to ${basename(target)}: ${(err as Error).message}. `
      + `Nothing was deleted — the book is still at ${legacy}, and copies of both are in ${keep}.`);
  }
}

function schema() {
  const handle = db!;
  handle.exec(`
    CREATE TABLE IF NOT EXISTS store_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS snapshots (
      key TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    -- A payload this build cannot read is still the customer's data. It is moved here,
    -- whole, rather than deleted: see readSnapshot.
    CREATE TABLE IF NOT EXISTS quarantine (
      key TEXT PRIMARY KEY, payload TEXT NOT NULL, reason TEXT NOT NULL, quarantined_at TEXT NOT NULL
    );
  `);
}

// A snapshot the current build cannot understand is worse than no snapshot: it
// would resurrect half-migrated records silently. So a version change clears the
// table and lets the seeds rebuild the demo data from scratch.
function checkVersion() {
  const handle = db!;
  const row = handle.prepare(`SELECT value FROM store_meta WHERE key = 'version'`).get() as
    { value: string } | undefined;
  const stored = Number(row?.value ?? 0);
  if (stored === STORE_VERSION) return;
  handle.prepare(`DELETE FROM snapshots`).run();
  handle.prepare(`INSERT INTO store_meta (key, value) VALUES ('version', ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value`).run(String(STORE_VERSION));
  log(row ? `store version ${stored} → ${STORE_VERSION}: previous snapshots discarded`
    : `initialising ${file}`);
}

export function openStore(): boolean {
  if (db) return true;
  if (process.env.XENITH_DB_OFF === '1') { log('persistence disabled by XENITH_DB_OFF'); return false; }
  file = adoptLegacyBook(process.env.XENITH_DB || DEFAULT_FILE);
  try {
    mkdirSync(dirname(file), { recursive: true });
    db = new DatabaseSync(file);
    db.exec('PRAGMA journal_mode = WAL');
    db.exec('PRAGMA synchronous = NORMAL');
    // The line tables point at their document, so a parent that goes takes its
    // rows with it instead of leaving orphans behind.
    db.exec('PRAGMA foreign_keys = ON');
    schema();
    checkVersion();
    if (process.env.XENITH_FRESH === '1') {
      db.prepare('DELETE FROM snapshots').run();
      log('XENITH_FRESH=1: starting from the seed data');
    }
    return true;
  } catch (err) {
    // The API must still come up if the disk is unhappy — an in-memory-only run is
    // the pre-database behaviour, not a broken server.
    db = null;
    log(`could not open ${file} — running without persistence: ${(err as Error).message}`);
    return false;
  }
}

export function isPersisted() { return db !== null; }

export function storedKeys(): string[] {
  if (!db) return [];
  return (db.prepare('SELECT key FROM snapshots ORDER BY key').all() as { key: string }[]).map(r => r.key);
}

export function readSnapshot<T = any>(key: string): T | null {
  if (!db) return null;
  const row = db.prepare('SELECT payload FROM snapshots WHERE key = ?').get(key) as
    { payload: string } | undefined;
  if (!row) return null;
  try {
    return JSON.parse(row.payload) as T;
  } catch (err) {
    // A half-written or hand-edited payload used to be deleted here, and the seed then took
    // its place on the next save: the shop opened the next morning on yesterday's demo data
    // and nobody had to be told. The unreadable text is moved out of the way whole instead, so
    // the book can be rebuilt AND the rows that were on it read back.
    const reason = (err as Error).message;
    try {
      db.prepare('INSERT OR REPLACE INTO quarantine (key, payload, reason, quarantined_at) VALUES (?, ?, ?, ?)')
        .run(key, row.payload, reason, new Date().toISOString());
      db.prepare('DELETE FROM snapshots WHERE key = ?').run(key);
      log(`row ${key} is unreadable and was quarantined, not dropped: ${reason}`);
    } catch (move) {
      // The copy failing is the worse answer: leave the row where it is and say so.
      log(`row ${key} is unreadable and could not be quarantined, so it was left alone: ${(move as Error).message}`);
    }
    return null;
  }
}

// How many books are sitting in the waiting room. The diagnostics screen shows it, because a
// quarantine nobody reads about is a broken backup with better manners.
export function quarantinedKeys(): { key: string; reason: string; quarantinedAt: string }[] {
  if (!db) return [];
  try {
    return db.prepare('SELECT key, reason, quarantined_at AS quarantinedAt FROM quarantine ORDER BY quarantined_at DESC')
      .all() as { key: string; reason: string; quarantinedAt: string }[];
  } catch { return []; }
}

// A blob the relational tables have absorbed is no longer a backup, it is a
// second copy that will drift — so the import deletes it.
export function dropSnapshot(key: string) {
  if (!db) return;
  db.prepare('DELETE FROM snapshots WHERE key = ?').run(key);
}

// Queue the latest value of `key`. The getter runs at flush time, so a route that
// mutates the same collection twice in one window costs one serialisation.
export function markDirty(key: string, get: Getter) {
  if (!db) return;
  pending.set(key, get);
  if (timer) return;
  const wait = Number(process.env.XENITH_FLUSH_MS ?? 400);
  timer = setTimeout(() => { timer = null; flushStore(); }, Math.max(0, wait));
  // A pending write must never be the reason the process lingers.
  if (typeof timer.unref === 'function') timer.unref();
}

export function flushStore(): number {
  if (!db || pending.size === 0) return 0;
  const keys = [...pending.keys()];
  const now = new Date().toISOString();
  const upsert = db.prepare(`INSERT INTO snapshots (key, payload, updated_at) VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at`);
  let n = 0;
  try {
    db.exec('BEGIN');
    for (const key of keys) {
      const get = pending.get(key);
      pending.delete(key);
      try {
        const value = get!();
        if (writer) writer(key, value, now);
        else upsert.run(key, JSON.stringify(value), now);
        n++;
      } catch (err) {
        // One bad collection must not lose the rest of the flush.
        log(`write for ${key} failed: ${(err as Error).message}`);
      }
    }
    db.exec('COMMIT');
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* the connection is already gone */ }
    log(`flush failed: ${(err as Error).message}`);
    return 0;
  }
  writes += n;
  flushes++;
  return n;
}

// The relational layer takes over the actual writing once it is wired in; the
// blob table above is then only the fallback for a run without it.
export type Writer = (key: string, value: unknown, now: string) => void;
let writer: Writer | null = null;
export function setWriter(next: Writer | null) { writer = next; }
export function getDb(): DatabaseSync | null { return db; }

export function storeStats() {
  return { file: db ? file : null, persisted: db !== null, version: STORE_VERSION,
    rows: storedKeys().length, writes, flushes, pending: pending.size,
    quarantined: quarantinedKeys().length };
}

// Flushes what is queued and releases the file. Exported because a test that points the store at
// its own temporary book cannot delete that book on Windows while this handle is still open.
export function closeStore() {
  if (timer) { clearTimeout(timer); timer = null; }
  flushStore();
  if (!db) return;
  const handle = db;
  db = null;
  try { handle.exec('PRAGMA optimize'); } catch { /* best effort */ }
  try { handle.close(); } catch { /* already closed by the runtime */ }
}

// SIGTERM/SIGINT would otherwise kill the process inside the write-behind window.
// 'exit' is the last synchronous chance there is.
export function watchShutdown() {
  process.on('exit', closeStore);
  ['SIGINT', 'SIGTERM', 'SIGHUP'].forEach(sig =>
    process.on(sig as NodeJS.Signals, () => { closeStore(); process.exit(0); }));
}
