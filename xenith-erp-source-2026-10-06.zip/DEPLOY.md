# Putting Xenith ERP on your own domain

## The machine you need — and the one you don't

A shared hosting plan (the ordinary cPanel/Hostinger/Namecheap "web hosting" that costs a few
hundred rupees a month) cannot run this product. It has no Node process that stays alive, no
way to keep one `.db` file writable between requests, and no permission to run `node:sqlite`.
Uploading the folder there will not "half work" — the API will not start.

The same is true of the **serverless** hosts — Vercel, Netlify, Cloudflare Workers. Their function
runs per request and then stops existing: the disk is a temporary `/tmp` that is wiped between
calls, and nothing is kept in memory from one request to the next. This product stores its book in
one `node:sqlite` file and keeps each company's workspace warm in the process, so on a serverless
host the book would vanish between two clicks and the login would not survive a redirect. The
pages can be hosted there, but then every screen is a form with nowhere to send itself. A VPS is
not the cheaper or the lazier choice — it is the only shape this fits.

What you need is a **VPS**: your own small Linux server. Any of these is enough —

| | |
| --- | --- |
| Size | 1–2 vCPU, 2 GB RAM, 20 GB disk (Hostinger's KVM 2 / Namecheap's Pulsar SSD both fit) |
| System | Ubuntu 22.04 / 24.04 or Debian 12 — pick the "Ubuntu 24.04" template when the panel asks |
| Node | **Node 24** (the version this is built and tested on). Below Node 22.5 there is no
       `node:sqlite` at all; on 22.x it may still need `--experimental-sqlite`, so install 24 |
| Extras | `nginx`, `certbot`, `sqlite3` (the CLI, for backups only) |

One VPS holds any number of companies, and the domain is pointed at it with a single A record.

## The layout on the server

```
/opt/xenith/server/dist        the built API
/opt/xenith/client/dist        the built pages — the API serves these itself
/var/lib/xenith/xenith.db       the book. This one file is the whole business.
```

One process answers both halves on one address, so the browser has no second site to trust and
the login cookie stays first-party. That is also why `XENITH_ORIGIN` is not needed here: it only
exists for a build that splits the pages onto a different host.

## Step by step

Do these as root (or with `sudo`) on the fresh VPS.

**1. The basics**

```bash
apt update && apt upgrade -y
apt install -y curl git nginx sqlite3 ufw
curl -fsSL https://deb.nodesource.com/setup_24.x | bash - && apt install -y nodejs
node -v            # must say v24.x
```

**2. The user that owns the shop**

```bash
useradd --system --create-home --home-dir /opt/xenith --shell /usr/sbin/nologin xenith
mkdir -p /opt/xenith && chown -R xenith:xenith /opt/xenith
```

**3. Get the code there**

There is no GitHub in this loop, and none is needed: the VPS holds the repository and your
Windows machine pushes into it. Once on the server:

```bash
git init --bare /srv/xenith.git
cat > /srv/xenith.git/hooks/post-receive <<'HOOK'
#!/bin/bash
# A push to `main` is a deploy request: take the working tree down, then let the deploy script
# do the building, with the service stopped and a backup taken first.
while read -r old new ref; do
  [ "$ref" = "refs/heads/main" ] || continue
  git --work-tree=/opt/xenith --git-dir=/srv/xenith.git checkout -f main
  /usr/local/bin/xenith-deploy
done
HOOK
chmod +x /srv/xenith.git/hooks/post-receive
cat > /usr/local/bin/xenith-deploy <<'RUN'
#!/bin/bash
set -e
systemctl stop xenith-erp
/usr/local/bin/xenith-backup || true          # a copy before anything changes
cd /opt/xenith
npm ci --omit=dev --prefix server
npm install --prefix client                   # the client's devDependencies are its build tools
npm --prefix server run build
npm --prefix client run build
chown -R xenith:xenith /opt/xenith
systemctl start xenith-erp
RUN
chmod +x /usr/local/bin/xenith-deploy
```

And once on Windows, from this folder:

```bash
git remote add vps ssh://root@<VPS_IP>/srv/xenith.git
git push vps main
```

The book never travels with the code: `server/data/`, `_backups/`, `_removed/` and `xenith.env`
are all git-ignored, so a push carries source and nothing else. The customer's `xenith.db` on the
VPS is a new file, seeded on first boot. Until you put a key on the server, every push asks for
the root password — one line fixes that:

```bash
ssh-keygen -t ed25519                                       # once, if you have no key yet
type "%USERPROFILE%\.ssh\id_ed25519.pub" | ssh root@<VPS_IP> "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys"
```

**4. The service**

```bash
cp deploy/xenith-erp.service /etc/systemd/system/
mkdir -p /var/lib/xenith && chown -R xenith:xenith /var/lib/xenith
systemctl daemon-reload
systemctl enable --now xenith-erp
systemctl status xenith-erp --no-pager
curl -s -o /dev/null -w '%{http_code}\n' localhost:5000/     # 200 = the API is up AND serving the pages
```

**5. The domain**

The domain is bought at Hostinger and the DNS lives there, so the change is made in
**hpanel → Domains → DNS / Nameservers**. A domain that already points somewhere else — at
Vercel, at the registrar's parking page, at the old demo — has to be moved *whole*, or the old
host keeps answering for it:

1. Delete every record that points at the previous host: an `A` for `@` to someone else's IP, and
   a `CNAME` for `www` to e.g. `*.vercel-dns-017.com`. Leaving the `www` CNAME behind is the usual
   way a shop ends up with a working apex and a `www` that 404s.
2. Add the two that point here:

| Type | Name | Content | TTL |
| --- | --- | --- | --- |
| `A` | `@` | the VPS's IPv4 | 300 |
| `A` | `www` | the same IPv4 | 300 |

3. Wait for it to answer, and believe the answer rather than the panel:

```powershell
Resolve-DnsName xenitherp.com -Type A       # must print the VPS's IP
Resolve-DnsName www.xenitherp.com -Type A   # must print the same IP
```

A record you set yesterday can still be cached at 14400 seconds (four hours), which is why the
table says 300: while you are moving a domain, keep the TTL short and raise it afterwards.

If the domain was attached to a project somewhere else (Vercel's **Settings → Domains**), remove
it there too — otherwise that project keeps a claim on the name, and the next person to deploy
into it can answer for your customers' address.

**6. TLS, then the proxy**

```bash
apt install -y certbot python3-certbot-nginx
mkdir -p /var/www/certbot
DOMAIN=xenitherp.com
sed -i "s/pos\.example\.com/$DOMAIN/g" deploy/nginx-xenith.conf
# For this one step, comment out the second (443) server block — its certificate files
# do not exist yet, so nginx would refuse to start.
cp deploy/nginx-xenith.conf /etc/nginx/sites-available/xenith
ln -sf /etc/nginx/sites-available/xenith /etc/nginx/sites-enabled/xenith
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
certbot --nginx -d $DOMAIN -d www.$DOMAIN     # asks for an email, then fixes the conf itself
```

Certbot rewrites the 443 block with the real paths and installs a nightly renewal. Check it:
`certbot renew --dry-run`. Ask for both names on one certificate — a certificate for the bare
domain leaves `www.` answering with a browser warning, and that is the first thing a customer
notices.

**7. Close the doors that should never have been open**

```bash
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
apt install -y fail2ban && systemctl enable --now fail2ban
ss -ltnp                              # node must be listening on 127.0.0.1:5000 only
```

That last line matters: `XENITH_HOST=127.0.0.1` in the unit keeps port 5000 off the public
interface, so plain HTTP around your certificate is not an option anybody can take.

**8. The nightly copy of the book**

```bash
cp deploy/backup.sh /usr/local/bin/xenith-backup && chmod 755 /usr/local/bin/xenith-backup
crontab -e
# 20 3 * * * XENITH_DB=/var/lib/xenith/xenith.db /usr/local/bin/xenith-backup >> /var/log/xenith-backup.log 2>&1
```

Backups that stay on the same disk are not backups. Copy `/var/backups/xenith` off the VPS (the
hosting company's own off-site backup, `rclone` to a bucket, or a weekly `scp`) and keep one copy
the customer cannot reach from the login screen.

**Restore drill — do it once before you tell anyone the shop is live.** On a spare machine:
`gunzip -k xenith-<date>.db.gz`, then `sqlite3 that-file "PRAGMA integrity_check;"` (must say
`ok`), then `SELECT name FROM snapshots ORDER BY key LIMIT 5` (must list `ws:` keys). A backup
nobody has restored is a rumour.

## Before the first customer signs in

### Who sells, and who bought

The seller is not a row inside the book he sells. While he was one, his name stood in the buyer's
Users list, the buyer's own Administrator could edit or switch him off, and the seeded owner
account was a master key that came with every copy. So the vendor is read from the environment
(`XENITH_VENDOR_USER`, `XENITH_VENDOR_PASSWORD`, `XENITH_VENDOR_NAME` — the systemd unit's
`Environment=` lines, or `deploy/.env` on the PM2 shape). He signs in on the same address with
that pair and gets:

- **Subscription & Modules** for any company — the sale is his act alone. The company's own owner,
  Administrator included, is answered `403 … ask your vendor` and sees a read-only plan.
- **New companies**, and the switch between them. A buyer sees only the book he belongs to.
- **Every module**, sold or not: what a firm bought measures the firm, not the man who sold it.

His name never appears in a Users list, a role, or a document; the activity log lines he leaves
say the job (`Vendor`), not the person. His password cannot be changed from the screen and no
setting inside a book can touch him — to move it, edit the environment and restart. A password
shorter than eight characters is ignored, and a production build with no vendor key refuses both
doors rather than falling back to the buyer. The boot line says which shape is running:

```
[xenith:auth] vendor sign-in armed as "xenith-vendor": the subscription and new companies are the vendor's, not the owner's
```

### The first login of the book

The seed book ships with the demo owner — `demo@xenitherp.com`, username `muhammad`, password
`demo123`. On a copy you are handing over, name that owner with `XENITH_OWNER_NAME`,
`XENITH_OWNER_EMAIL`, `XENITH_OWNER_USERNAME` and `XENITH_OWNER_PASSWORD` **before the first boot**,
so the buyer's book opens with his own name and his own first password; a database that has
already been opened keeps its own rows and reads none of these. The server says it out loud at
every boot until the seeded password is gone:

```
[xenith:auth] WARNING: 1 live account(s) still sign in with the seeded password 'demo123' …
```

Change it from **Settings → Users** before the domain is advertised anywhere. While you are there:

- Add the real company, its branches and its warehouses. A book that has never held a record fills
  itself at first boot with a sample trading history — around 114 papers that touch every module, so
  the screens a client opens have something in them — and **Settings → Company Settings → Sample
  Data** loads that set again or takes every one of its rows back out when the buyer starts his own
  trading. `XENITH_DEMO_DATA=0` on the unit keeps a book plain from the first boot.
- Self-service sign-up is closed unless `XENITH_SIGNUPS=1` is set. Leave it closed; people are
  added from the Users screen.
- A new company starts the sale at **Dashboard and Setup** only, so the next firm cannot be handed
  the whole product by accident. Tick what was bought on the Subscription screen before they look.
- Email for password resets needs SMTP under Company Settings. Without it the reset door answers
  503 and an Administrator sets the password from the Users screen instead — which is fine, and
  is worth telling the customer once.

## Updating the shop

One command, from this folder on Windows:

```bash
git push vps main
```

The `post-receive` hook of step 3 stops the service, takes the nightly-style copy, rebuilds both
halves and starts again — which is the same sequence, in the same order, as doing it by hand:

```bash
systemctl stop xenith-erp
/usr/local/bin/xenith-backup                      # a copy before anything changes
cd /opt/xenith && git --git-dir=/srv/xenith.git --work-tree=. checkout -f main
npm ci --omit=dev --prefix server && npm --prefix server run build
npm install --prefix client && npm --prefix client run build
npm test --prefix server                         # the arithmetic, on the real code
systemctl start xenith-erp && journalctl -u xenith-erp -n 30 --no-pager
```

Watch the push: a build that fails inside the hook leaves the service stopped, and the answer is
in the lines the push prints back. `npm test` is deliberately not in the hook — it is the one step
worth running with a person reading it, before the code is pushed at all.

The `.db` file is never part of a deploy — stop the service, replace the code, start again, and
the same book opens with its same rows.

## When something is wrong

| What you see | What it is |
| --- | --- |
| `502 Bad Gateway` | the node process is down — `systemctl status xenith-erp`, then `journalctl -u xenith-erp -n 50` |
| `could not open … running without persistence` in the log | the service user cannot write `/var/lib/xenith` — `chown -R xenith:xenith /var/lib/xenith` |
| Pages load, every screen says "Session expired" | the clock is wrong or the cookie was set over plain HTTP — check `TZ`, and that the site is only ever reached over https |
| A deep link like `/pos` 404s | nginx is serving the pages itself instead of proxying — this build wants the whole location `/` proxied |
| Everyone gets `429` after forty bad logins together | `XENITH_TRUST_PROXY` is not set, so every customer shares one budget of attempts |
| A product sheet fails to arrive with `413` | nginx cuts the body before the API does. The upload caps the file at 6 MB, which reaches the server as ~8 MB of base64 — `client_max_body_size 16m` (what `deploy/nginx-xenith.conf` ships) clears it |
| The shop opened on yesterday's demo data | look at `quarantined` in the diagnostics (`GET /api/auth/store`, Administrator only). A book this build cannot read is put aside whole instead of deleted — `SELECT key, reason, payload FROM quarantine` on the `.db` shows what was found, and the nightly copy shows what it was before |
