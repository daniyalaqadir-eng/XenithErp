export enum EntryType {
  Debit = 0,
  Credit = 1
}

export enum SchemeType {
  Normal = 0,
  Scheme = 1
}

export enum PaymentMode {
  Cash = 10,
  Cheque = 20,
  Draft = 30,
  DirectDeposit = 40,
  CreditCard = 50,
  UndepositedFunds = 60
}

export const PaymentModeList = [
  { text: "Cash", value: PaymentMode.Cash },
  { text: "Cheque", value: PaymentMode.Cheque },
  { text: "Draft", value: PaymentMode.Draft },
  { text: "Direct Deposit", value: PaymentMode.DirectDeposit },
  { text: "Credit Card", value: PaymentMode.CreditCard },
  { text: "Undeposited Funds", value: PaymentMode.UndepositedFunds }
];

export enum DiscountType {
  Percent = 1,
  Amount = 2,
  Price = 3
}

export enum SaleDeliveryStatus {
  Draft = 0,
  Pending = 10,
  Approved = 20,
  InProcess = 25,
  Invoiced = 30,
  Delivered = 35,
  Void = 40
}

export const SaleDeliveryStatusArray = [
  { text: "Draft", value: SaleDeliveryStatus.Draft },
  { text: "Pending", value: SaleDeliveryStatus.Pending },
  { text: "Approved", value: SaleDeliveryStatus.Approved },
  { text: "In Process", value: SaleDeliveryStatus.InProcess },
  { text: "Invoiced", value: SaleDeliveryStatus.Invoiced },
  { text: "Delivered", value: SaleDeliveryStatus.Delivered },
  { text: "Void", value: SaleDeliveryStatus.Void }
];

export enum SaleInvoiceStatus {
  Draft = 0,
  Pending = 10,
  Approved = 20,
  Sent = 30,
  PartiallyPaid = 40,
  Paid = 50,
  Void = 60
}

export const SaleInvoiceStatusArray = [
  { text: "Draft", value: SaleInvoiceStatus.Draft },
  { text: "Pending", value: SaleInvoiceStatus.Pending },
  { text: "Approved", value: SaleInvoiceStatus.Approved },
  { text: "Sent", value: SaleInvoiceStatus.Sent },
  { text: "Partially Paid", value: SaleInvoiceStatus.PartiallyPaid },
  { text: "Paid", value: SaleInvoiceStatus.Paid },
  { text: "Void", value: SaleInvoiceStatus.Void }
];

export interface Branch {
  id: number;
  name: string;
  code: string;
  isMain: boolean;
  address?: string;
  city?: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  email?: string;
  taxNumber?: string;
  managerName?: string;
  isActive?: boolean;
}

export interface MasterGroup {
  id: number;
  name: string;
  code?: string;
  isDefault: boolean;
  isActive: boolean;
}

export interface DetailBGroup {
  id?: number;
  name: string;
  isDefault?: boolean;
  branchIds: number[];
  branches?: Branch[];
}

export interface ProductBreakupItem {
  id?: number;
  productBreakupDetailId?: number;
  packagingId: string;
  size: number;
  qty: number;
  saleQty?: number;
}

export interface InvoiceLineItem {
  id: number;
  productId: number;
  productName: string;
  fractionalUnit?: boolean;
  allowChangeQuantity?: boolean;
  quantity: number;
  price: number;
  grossAmount: number;
  discountType: DiscountType;
  discountInPercent?: number;
  discountInAmount?: number;
  discountInPrice?: number;
  discountAmount: number;
  taxRate: number;
  taxAmount: number;
  netAmount: number;
  packagingBreakups?: ProductBreakupItem[];
}


export interface DashboardData {
  userGreeting: string;
  todayDate: string;
  summary: {
    totalInflow: number;
    totalOutflow: number;
    netProfit: number;
    cashAndBank: number;
    currency: string;
  };
  receivablesAging: {
    totalDue: number;
    current: number;
    days1To30: number;
    days31To60: number;
    days61To90: number;
    days90Plus: number;
  };
  businessHealth: {
    grossProfitRatio: number;
    netProfitRatio: number;
    operatingExpenseRatio: number;
  };
  incomeVsExpense: {
    months: string[];
    income: number[];
    expense: number[];
  };
  topCustomers: { name: string; amount: number; percentage: number }[];
  topProducts: { name: string; salesQty: number; amount: number }[];
  cashAndBankAccounts: { name: string; balance: number; type: string }[];
}

// ─── Banking Module ────────────────────────────────────────────────────────

export interface BankAccount {
  id: number;
  accountTitle: string;
  bankName: string;
  accountNumber: string;
  balance: number;
  iban?: string;
  // The bank's own branch code, as printed on the cheque leaf.
  branchCode?: string;
  isActive: boolean;
  // The company branch this account is held for.
  branchId?: number;
  branchName?: string;
  description?: string;
  acceptsChequeBook?: boolean;
  acceptsCreditCard?: boolean;
  linkedAccountId?: number;
  linkedAccountName?: string;
  openingBalanceDate?: string;
}

export interface BankTransaction {
  id: number;
  transactionDate: string;
  description: string;
  credit: number;
  debit: number;
  balance: number;
  bankAccountId: number;
  referenceNumber?: string;
}

// ─── Inventory Module ──────────────────────────────────────────────────────

export interface InventoryItem {
  id: number;
  name: string;
  sku: string;
  category: string;
  unit: string;
  salePrice: number;
  purchasePrice: number;
  stockQty: number;
  reorderLevel: number;
  isActive: boolean;
}

export interface StockMovement {
  id: number;
  date: string;
  itemName: string;
  sku: string;
  type: 'In' | 'Out' | 'Adjustment' | 'Transfer';
  quantity: number;
  balanceAfter: number;
  reference: string;
  warehouse: string;
  // Set when a saved stock document posted the row.
  docRef?: string;
}

export interface StockAdjustment {
  id: number;
  adjustmentNumber: string;
  date: string;
  itemName: string;
  sku: string;
  reason: string;
  quantityChange: number;
  newBalance: number;
  status: 'Draft' | 'Approved';
  warehouse?: string;
  docRef?: string;
}

// Why a warehouse balance is allowed to change, and which way it moves.
export interface AdjustmentType {
  id: number;
  name: string;
  accountId: number | null;
  accountName: string;
  direction: 'Add' | 'Subtract';
  description: string;
  isActive: boolean;
}

export interface StockValuation {
  id: number;
  date: string;
  narration: string;
  status: 'Scheduled' | 'Completed' | 'Skipped';
  warehouseName: string;
}

// ─── Journal Entries & Petty Cash ──────────────────────────────────────────

export interface JournalEntryLine {
  account: string;
  debit: number;
  credit: number;
  // Why the line exists and whose money it carries: the trial balance only ever sees the
  // account, so the reason and the name have to stand against the line itself.
  description?: string;
  contact?: string;
}

export interface JournalEntry {
  id: number;
  entryNumber: string;
  date: string;
  memo: string;
  reference: string;
  lines: JournalEntryLine[];
  totalDebit: number;
  totalCredit: number;
  status: 'Draft' | 'Approved';
  attachments?: DocAttachment[];
  createdById?: number | null;
  createdByName?: string;
  approvedByName?: string;
  approvedAt?: string;
}

export interface PettyCashVoucher {
  id: number;
  voucherNumber: string;
  date: string;
  payee: string;
  category: string;
  amount: number;
  paymentMode: string;
  status: 'Draft' | 'Approved';
  // The two ledger accounts the voucher moves money between. Optional because vouchers
  // written before the screen was tied to the chart of accounts carry neither.
  accountId?: number;
  accountName?: string;
  expenseAccountId?: number | null;
  expenseAccountName?: string;
}

// ─── Generic Commercial Documents ──────────────────────────────────────────

// A `link` column is a way into another reading of the same register: clicking one asks the
// report for the parameter of that name, so a record number on a line opens its trail.
export type ReportColType = 'text' | 'date' | 'int' | 'qty' | 'money' | 'pct' | 'status' | 'link';

export interface ReportColumn {
  key: string;
  label: string;
  type?: ReportColType;
  // Columns that belong to one figure family print under a shared band heading.
  band?: string;
}

// A report names its own filter form: the viewer renders these instead of guessing
// dropdowns from whichever columns happen to repeat.
export interface ReportParamOption { value: string; label: string }
export interface ReportParam {
  key: string;
  label: string;
  // `asof` is the day the report is struck and drives the header date; `from`/`to` are the
  // window a register is asked for, so the viewer never adds its own pair on top.
  kind: 'pick' | 'check' | 'compare' | 'asof' | 'from' | 'to';
  // The row field this ask cuts. The server offers no filter box for a column its parameter
  // already owns, so the screen reads this to keep one ask per column rather than two.
  col?: string;
  options?: ReportParamOption[];
  // The report says which of its dropdowns lists records, and so should search whatever the
  // book holds against it — three customers today, three hundred next year.
  search?: boolean;
  // A record dropdown is ticked so several names can be asked for at once, unless the report
  // prints one account's own running balance and says so here.
  multi?: boolean;
}

export interface ReportGroupBy {
  key: string;
  head: { label: string; col: string }[];
  // `first` reads the figure once for the document — freight is charged per delivery, not
  // per line, so summing it down the block would multiply it.
  // `ratio` divides the summed `col` by the summed `by` — a band's margin is a rate over the
  // money inside the band, not a total of the per-line rates.
  sums: { label: string; col: string; type?: ReportColType; mode?: 'sum' | 'first' | 'ratio'; by?: string }[];
}

export interface ReportListItem {
  key: string;
  title: string;
  desc: string;
  badge?: string;
  columns: number;
}

export interface ReportGroup {
  name: string;
  label: string;
  color: string;
  reports: ReportListItem[];
}

export interface ReportCatalog {
  groups: ReportGroup[];
  total: number;
}

export interface ReportPayload {
  title: string;
  group?: string;
  desc?: string;
  badge?: string;
  columns: ReportColumn[];
  rows: Record<string, any>[];
  summary: { label: string; value: string }[];
  // Tiles the report reads off its own surviving rows rather than off a column total.
  cards?: { label: string; value: string }[];
  totals?: Record<string, any>;
  closingTotals?: string[];
  // A closing column that runs one line per account names the column holding that account,
  // so the footer closes account by account instead of on whichever row sits last.
  closingGroups?: Record<string, string>;
  // Statements bring their own headings, indentation and subtotals.
  statement?: boolean;
  // Cut by the configured aging bands, so Configure Aging belongs on this report.
  agingDriven?: boolean;
  asOf?: string;
  params?: ReportParam[];
  groupBy?: ReportGroupBy;
  // A second total line that reads each column as a share of one reference column.
  shareRow?: { of: string; cols: string[] };
  // The words the paper copy puts in front of its grand total ("Total (PKR)", "Net Total (PKR)").
  totalsLabel?: string;
  // The columns the reader may cut the register on, each naming the box it asks for: a tick list
  // of the values the book holds, a typed search, or a pair of days. Figures are not narrowed.
  facets?: { key: string; label: string; kind: 'list' | 'text' | 'date'; options?: string[] }[];
  // Rows the register held before the screen's filters, so a count can say what it was cut from.
  rowCount?: number;
}

export interface LedgerAccount {
  id: number;
  code: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense';
  isActive: boolean;
  parentId?: number | null;
  parentName?: string;
  isGroup?: boolean;
  description?: string;
  openingBalance?: number;
  // What the account holds now: its opening moved by every posting, and for a group the
  // roll-up of the accounts under it. The server sends it alongside the record.
  currentBalance?: number;
  bankName?: string;
  accountNumber?: string;
  branchCode?: string;
  branchName?: string;
  iban?: string;
  acceptsChequeBook?: boolean;
  acceptsCreditCard?: boolean;
}

// ─── Sale Invoice ──────────────────────────────────────────────────────────

export interface DocAttachment {
  name: string;
  size: number;
  // The file bytes travel with the record, so an attachment can still be opened later.
  data?: string;
}

export interface CustomFieldValue {
  id: number;
  field: string;
  value: string;
}

export interface Party {
  id: number;
  code: string;
  name: string;
  printName: string;
  displayName: string;
  categoryId: number | null;
  categoryName: string;
  contactPerson: string;
  careOf: string;
  salesPersonId: number | null;
  salesPersonName: string;
  email1: string;
  email2: string;
  email3: string;
  phone1: string;
  phone2: string;
  phone3: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  fax: string;
  ntn: string;
  cnic: string;
  openingBalance: number;
  // What the account stands at today: its opening moved by every posted document. The
  // server sends it alongside the record so the list can print the live figure.
  currentBalance?: number;
  creditLimitAmount: number;
  creditLimitDays: number;
  discountPercent: number;
  withholdingTaxPercent: number;
  isCashCustomer: boolean;
  isSalesTaxRegistered: boolean;
  isTaxFiler: boolean;
  isTaxAgent: boolean;
  isPrincipal: boolean;
  imageUrl: string;
  isActive: boolean;
  attachments: DocAttachment[];
  customFields: CustomFieldValue[];
}

export type Customer = Party;
export type Vendor = Party;

export type CategoryType =
  | 'customer' | 'vendor' | 'product' | 'brand' | 'warehouse' | 'industry'
  | 'leadSource' | 'leadStatus' | 'ticketTag' | 'eventTag' | 'ticketStatus' | 'eventType'
  | 'eventStatus' | 'adjustmentType' | 'tax' | 'customField' | 'tag' | 'employee' | 'department'
  | 'designation' | 'project' | 'consignment' | 'priceLevel' | 'commission';

export interface Category {
  id: number;
  name: string;
  type: CategoryType;
  isActive: boolean;
  // Product categories are filed three deep: a parent that groups the trade, a sub that
  // groups the range inside it, and the category a product sits in. Every other master
  // stays flat, so `parentId` is only ever carried by a row that hangs under another.
  parentId?: number | null;
  // Both read off the register by the server on each row, so a screen never recomputes a
  // level from a list it may have filtered down.
  level?: number;
  parentName?: string;
}

// Units of Measurement: the switchboard the masters pick from. `inUse` is counted by the
// server from the product and item records carrying that unit, so a badge can never be a
// number the screen made up.
export const UOM_BANDS = ['Packaging & Containers', 'Count & Units', 'Area & Surface',
  'Length & Distance', 'Weight & Mass', 'Volume & Liquid', 'Time'] as const;
export type UomBand = typeof UOM_BANDS[number];

export interface Uom {
  id: number;
  code: string;
  name: string;
  band: UomBand;
  isActive: boolean;
  inUse: number;
  usedBy: string[];
}

export interface UomBoard {
  data: Uom[];
  total: number;
  bands: { name: UomBand; total: number; active: number; inUse: number }[];
  stats: { total: number; active: number; inactive: number; inUse: number };
}

export type ProductType = 'Product' | 'Services' | 'Product Variant' | 'Grouped';

export interface ProductTax {
  id: number;
  name: string;
  rate: number;
}

export interface Product {
  id: number;
  code: string;
  name: string;
  type: ProductType;
  unit: string;
  isFractionalUnit: boolean;
  fractionalUnitMode: 'price' | 'quantity';
  isCalculationField: boolean;
  isThirdSchedule: boolean;
  trackInventory: boolean;
  enableBatch: boolean;
  enableSerial: boolean;
  enablePackaging: boolean;
  enableAssemble: boolean;
  enableAddOn: boolean;
  inventoryAccountName: string;
  isPurchased: boolean;
  purchasePrice: number;
  expenseAccountName: string;
  purchaseDiscountAccountName: string;
  purchaseTaxes: ProductTax[];
  isSold: boolean;
  allowPublicAccess: boolean;
  salePrice: number;
  salesAccountName: string;
  salesDiscountAccountName: string;
  saleTaxes: ProductTax[];
  salePriceInclusiveOfTax: boolean;
  maximumRetailPrice: number;
  salesReturnAccountName: string;
  retailPriceExclusiveOfTax: boolean;
  categoryId: number | null;
  categoryName: string;
  brandId: number | null;
  brandName: string;
  principal: string;
  shortName: string;
  sku: string;
  barcode: string;
  weight: number;
  height: number;
  width: number;
  length: number;
  modelNumber: string;
  hsCode: string;
  shortDescription: string;
  description: string;
  tags: string;
  imageUrl: string;
  stockQty: number;
  reorderLevel: number;
  isActive: boolean;
  attachments: DocAttachment[];
  customFields: CustomFieldValue[];
  packings: { id: number; sku: string; barcode: string; salePrice: number; purchasePrice: number; packaging: string; qty: number }[];
  relatedProducts: { id: number; productId: number; productName: string; type: string }[];
  stockLevels: { id: number; warehouse: string; qty: number; reorderLevel: number }[];
}

// One product's stock split across the locations that hold it. Every figure is a quantity
// the stock ledger really posted, so the locations add back up to the product card.
export interface StockBucket {
  name: string;
  opening: number;
  received: number;
  transferredIn: number;
  issued: number;
  transferredOut: number;
  adjusted: number;
  available: number;
}

export interface StockBreakdown {
  product: { id: number; code: string; name: string; sku: string; unit: string; trackInventory: boolean };
  locations: StockBucket[];
  total: StockBucket;
  cardQty: number;
  // Billed on approved invoices and still inside the warehouse — a memo on the issued
  // figure, never a second deduction from it.
  pending: { qty: number; documents: string[] };
}

export interface SalesPerson {
  id: number;
  name: string;
  isSalesman: boolean;
  isOrderBooker: boolean;
  isDeliveryPerson: boolean;
  cashAccountId: number | null;
  cashAccountName: string;
  receivePaymentSeriesId: number | null;
  receivePaymentSeriesName: string;
  canChangePrice: boolean;
  canAddDiscount: boolean;
  isManager: boolean;
  managerId: number | null;
  managerName: string;
  applicationUserId: number | null;
  applicationUserEmail: string;
  branchId: number;
  branchName: string;
  isActive: boolean;
}

export interface NumberSeries {
  id: number;
  kind: 'receivePayment';
  name: string;
  prefix: string;
  nextNumber: number;
}

export interface SalesPersonDocSetting {
  document: string;
  showOrderBooker: boolean;
  showDeliveryPerson: boolean;
  showSalesman: boolean;
}

// ─── Generic document engine (invoices / deliveries / returns / payments / orders) ────

export type DocStatus = 'Draft' | 'Pending' | 'Approved' | 'Void';

export interface DocLine {
  id: number;
  productId: number | null;
  productName: string;
  sku: string;
  unit: string;
  quantity: number;
  price: number;
  discountType: 'Percent' | 'Amount';
  discountValue: number;
  grossAmount: number;
  discountAmount: number;
  amount: number;
  percentage: number;
  expenses: number;
  netValueAfterExpense: number;
  // Only an import line carries these: the invoice value bought at the customs rate, and the
  // share of the duties and charges that makes it a landed cost.
  amountPkr?: number;
  landedCharges?: number;
  landedAmount?: number;
  landedCostPerUnit?: number;
  warehouseId: number | null;
  warehouseName: string;
  // The paper this line was picked out of — the invoice line a challan was cut from. This
  // is what keeps "how much is still outstanding" true across a half-billed bill or a
  // delivery taken in parts.
  sourceNumber?: string;
  sourceLineId?: number;
}

export interface DocPaymentLine {
  id: number;
  paymentMode: string;
  accountId: number | null;
  accountName: string;
  reference: string;
  bankName: string;
  instrumentNumber: string;
  instrumentDate: string;
  documentNumber: string;
  amount: number;
}

export interface DocAllocation {
  id: number;
  description: string;
  date: string;
  dueDate: string;
  totalAmount: number;
  adjustedAmount: number;
  balanceAmount: number;
  allocated: number;
}

export interface DocExpense {
  id: number;
  accountName: string;
  description: string;
  contact: string;
  amount: number;
  // A charge names the head of the book it is spent on, and says whether it has actually
  // gone out of the till or the bank yet. Marking it settled is what files its voucher.
  accountId?: number | null;
  paidVia?: 'Cash' | 'Bank' | 'Unsettled';
  paidAccountId?: number | null;
  paidAccountName?: string;
}

// One line of the customs declaration. A duty marked 'In cost' is a cost of the goods;
// 'Recoverable' is an advance the books claim back and never rides onto the item's cost.
export interface ImportDuty {
  id: number;
  head: string;
  rate: number;
  amount: number;
  treatment: 'In cost' | 'Recoverable';
  accountId: number | null;
  accountName: string;
  challan: string;
  // Every duty line says whether it has been paid and from where: the server answers for all
  // three even when the paper left them blank, so a declaration row always carries them.
  paidVia: 'Cash' | 'Bank' | 'Unsettled';
  paidAccountId: number | null;
  paidAccountName: string;
}

export interface DocCustoms {
  currency: string;
  rate: number;
  cdNumber: string;
  cdDate: string;
  lcNumber: string;
  blNumber: string;
  portOfDischarge: string;
  countryOfOrigin: string;
  agentName: string;
  assessableValue: number;
  duties: ImportDuty[];
}

export interface DocLanded {
  method: string;
  goodsPkr: number;
  dutyInCost: number;
  dutyRecoverable: number;
  charges: number;
  chargesUnsettled: number;
  landedTotal: number;
  perUnit: number;
  shareTotal: number;
}

export interface BizDoc {
  id: number;
  number: string;
  partyId: number | null;
  partyName: string;
  // Whose sale this is, who raised it and who approved it. Only the sale-side tables
  // fill these in, so they are optional for everything else the engine serves.
  salesPersonId?: number | null;
  salesPersonName?: string;
  createdById?: number | null;
  createdByName?: string;
  approvedByName?: string;
  approvedAt?: string;
  date: string;
  dueDate: string;
  receiptDate: string;
  reference: string;
  subject: string;
  comments: string;
  status: DocStatus;
  warehouseId: number | null;
  warehouseName: string;
  orderNumber: string;
  // Derived on the server from the lines: the invoice a challan was cut from.
  // Display and print only — the lines hold the real link.
  sourceNumber?: string;
  // A, B, C among the papers cut out of that source — the second challan against a bill is
  // part B. Read-only, counted on the server from the same list the parent's screen uses.
  sourcePart?: string;
  // The manual gate pass the load leaves the compound on. It is written once, on the bill,
  // and every challan cut out of that bill repeats it.
  gatePass?: string;
  // What carries the load out and who is at the wheel. Written once on the bill, repeated on
  // every challan of that consignment, and printed on the gate pass the watchman checks.
  vehicle?: string;
  driver?: string;
  // How much of a consignment has physically left the gate. Counted on the server from
  // Approved paper alone, so the register, the form and the printed challan agree.
  dispatchState?: 'Not Dispatched' | 'Partial Dispatched' | 'Fully Dispatched';
  // The same question from the receiving end: of the goods a Good Receiving counted in, how
  // much has a vendor's approved bill been raised against it. Server-derived, one yardstick.
  billedState?: 'Not Billed' | 'Part Billed' | 'Fully Billed';
  // Stamped by the software on a challan it filed for itself, and dropped the moment a
  // person saves the paper — the mark means "this is still only a suggestion".
  autoFiled?: boolean;
  shippingAddress: string;
  lines: DocLine[];
  gross: number;
  discountPercent: number;
  discount: number;
  tax: number;
  shippingCharges: number;
  roundOff: number;
  net: number;
  accountId: number | null;
  accountName: string;
  accountReference: string;
  toAccountId: number | null;
  toAccountName: string;
  // A stock movement names where the goods leave on each line and where they land on
  // the header; an adjustment names the reason that decides the direction.
  toWarehouseId: number | null;
  toWarehouseName: string;
  adjustmentTypeId: number | null;
  adjustmentTypeName: string;
  paymentAmount: number;
  autoSettlements: boolean;
  accountAdjustments: boolean;
  paymentLines: DocPaymentLine[];
  allocations: DocAllocation[];
  receivedAllocations: DocAllocation[];
  expenseMethod: string;
  expenses: DocExpense[];
  totalExpenses: number;
  // The customs side of an import invoice: the declaration the goods cleared on, and the
  // landed cost that comes out of it. Only that register fills them in.
  customs?: DocCustoms;
  landed?: DocLanded;
  unadjusted: number;
  balance: number;
  attachments: DocAttachment[];
}
