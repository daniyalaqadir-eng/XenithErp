import React, { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Receipt,
  CreditCard,
  BookOpen,
  Boxes,
  Factory,
  BarChart3,
  Globe,
  Contact2,
  ChevronDown,
  Home as HomeIcon,
  Gift,
  Sliders,
  CalendarRange,
  UserCog,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  collapsed: boolean;
  onToggleCollapsed: () => void;
}

type Item = [string, string];
type Group = { key: string; label: string; icon: React.ReactNode; items: Item[] };

const GROUPS: Group[] = [
  {
    key: 'crm', label: 'CRM', icon: <Contact2 className="w-4 h-4" />,
    items: [
      ['Customers', 'customers'], ['Vendors', 'vendors'], ['Products', 'products'],
      ['Sales Persons', 'sales-persons'],
    ]
  },
  {
    key: 'sales', label: 'Sales', icon: <ShoppingCart className="w-4 h-4" />,
    items: [
      ['Invoices', 'sales-invoices'], ['Delivery Challan', 'delivery-challan'],
      ['Returns', 'doc:sale-return'], ['Receive Payments', 'doc:receive-payment'],
    ]
  },
  {
    key: 'purchase', label: 'Purchase', icon: <Receipt className="w-4 h-4" />,
    items: [
      ['Goods Receiving (GRN)', 'doc:good-receiving'],
      ['Bills / Invoices', 'doc:purchase-bill'], ['Import Invoices', 'doc:import-invoice'],
      ['Make Payments', 'doc:vendor-payment'],
    ]
  },
  {
    key: 'classification', label: 'Classification', icon: <Globe className="w-4 h-4" />,
    items: [
      ['Master Groups (Regions)', 'master-groups'], ['Customer Groups (Detail B)', 'detail-b-groups'],
      ['Branch Locations', 'branch-locations'], ['Product Categories', 'cat:product'], ['Brands', 'cat:brand'],
      ['Units of Measurement', 'uom'],
    ]
  },
  // The ledger and the money that moves through it. Everything here answers a question
  // about accounts, banks or cash — the four vouchers post straight into the ledger, so
  // they live beside the accounts they write to rather than in a folder of their own.
  {
    key: 'accounts', label: 'Accounts', icon: <BookOpen className="w-4 h-4" />,
    items: [
      ['Chart of Accounts', 'chart-of-accounts'],
      ['Cash Payment Vouchers', 'doc:cash-voucher'], ['Bank Payment Vouchers', 'doc:bank-voucher'],
      ['Cash Receipt Vouchers', 'doc:cash-receipt-voucher'],
      ['Bank Receipt Vouchers', 'doc:bank-receipt-voucher'],
      ['Bank Accounts', 'bank-accounts'], ['Journal Entries', 'journal-entries'],
      ['Close Year', 'close-year'],
    ]
  },
  {
    key: 'pos', label: 'POS', icon: <CreditCard className="w-4 h-4" />,
    items: [
      ['POS Terminal', 'pos-terminal'], ['Daily Summary', 'pos-daily-summary'],
      ['Checkout Counters', 'pos-counters'], ['Barcode / QR Templates', 'pos-barcode-templates'],
      ['POS Offline', 'pos-offline'],
    ]
  },
  {
    key: 'inventory', label: 'Inventory', icon: <Boxes className="w-4 h-4" />,
    items: [
      ['Warehouse Terminal', 'warehouse-dashboard'],
      ['Item Master', 'item-master'], ['Stock Movements', 'doc:stock-movement'],
      ['Stock Adjustments', 'doc:stock-adjustment'], ['Stock Audits', 'doc:stock-audit'],
      ['Adjustment Types', 'adjustment-types'], ['Stock Ledger', 'stock-ledger'],
      ['Scheduled Valuations', 'scheduled-valuations'],
    ]
  },
  {
    key: 'manufacturing', label: 'Manufacturing', icon: <Factory className="w-4 h-4" />,
    items: [
      ['Job Orders / Assembling', 'manufacturing-job-orders'], ['Disassembling', 'manufacturing-disassemblies'],
    ]
  },
  {
    key: 'hr', label: 'Human Resources', icon: <UserCog className="w-4 h-4" />,
    items: [
      ['Employees', 'hr-employees'], ['Salary Heads', 'hr-payheads'],
      ['Salary Structures', 'hr-salary-structure'], ['Attendance', 'hr-attendance'],
      ['Leave', 'hr-leave'], ['Loans & Advances', 'hr-loans'],
      ['Salary Sheet', 'hr-salary-sheet'],
    ]
  },
  {
    key: 'setup', label: 'Setup', icon: <Sliders className="w-4 h-4" />,
    items: [
      ['Branches', 'branches'], ['Warehouses', 'warehouses'],
    ]
  },
];

const TOP_ITEMS: [string, string, React.ReactNode][] = [
  ['Home', 'home', <HomeIcon className="w-4 h-4" />],
  ['Dashboard', 'dashboard', <LayoutDashboard className="w-4 h-4" />],
];

const BOTTOM_ITEMS: [string, string, React.ReactNode][] = [
  ['Reports', 'reports', <BarChart3 className="w-4 h-4" />],
  ['Weekly Route', 'weekly-routes', <CalendarRange className="w-4 h-4" />],
  ['Refer And Earn', 'refer-earn', <Gift className="w-4 h-4" />],
];

const groupOfTab = (tab: string) => GROUPS.find(g => g.items.some(([, t]) => t === tab))?.key;

/** The name a screen is known by to the user, for the access-denied notice. */
export const labelOfTab = (tab: string) => {
  const found = GROUPS.flatMap(g => g.items).find(([, t]) => t === tab);
  // A folder is the same screen wearing one location's clothes; the board itself names the
  // warehouse, so the breadcrumb has no business printing a raw id.
  if (!found && tab.startsWith('delivery-challan:')) return 'Delivery Challan';
  if (!found && tab.startsWith('warehouse-dashboard:')) return 'Warehouse Terminal';
  return found ? found[0] : TOP_ITEMS.concat(BOTTOM_ITEMS).find(([, t]) => t === tab)?.[0]
    ?? tab.replace(/[-:]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
};

/** The permission screen a tab opens: the catalogue keys screens by tab, with ':' flattened. */
export const screenOfTab = (tab: string): string | null => {
  if (tab === 'home') return null;
  // Your own profile and your own password belong to the signed-in user, not to a role,
  // so they are not screens an administrator can tick off.
  if (tab === 'my-profile' || tab === 'change-password') return null;
  if (tab.startsWith('report:')) return 'report-viewer';
  // A warehouse's own folder is the same register wearing one location's clothes, so it
  // answers to the Delivery Challan screen rather than to a permission of its own.
  if (tab.startsWith('delivery-challan:')) return 'delivery-challan';
  // The challans of every bill at once are the board itself; the old register address is
  // retired and answers to the same screen rather than to a permission of its own.
  if (tab === 'doc:sale-delivery') return 'delivery-challan';
  // The same trick for the terminal: switching location must not ask for a new permission.
  if (tab.startsWith('warehouse-dashboard:')) return 'warehouse-dashboard';
  return tab.replace(/:/g, '-');
};

/** Tabs the role may open: a screen is reachable with View on the screen itself. */
export const canOpenTab = (tab: string, can: (perm: string) => boolean) => {
  const screen = screenOfTab(tab);
  return !screen || can(`${screen}:view`);
};

const NavItem: React.FC<{
  label: string; tab: string; icon: React.ReactNode; currentTab: string; onSelectTab: (tab: string) => void;
}> = ({ label, tab, icon, currentTab, onSelectTab }) => (
  <button onClick={() => onSelectTab(tab)} aria-current={currentTab === tab ? 'page' : undefined}
    className={`nav-row ${currentTab === tab ? 'is-active' : ''}`}>
    {icon}
    <span className="truncate">{label}</span>
  </button>
);

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onSelectTab, collapsed, onToggleCollapsed }) => {
  const { can } = useAuth();
  const [open, setOpen] = useState<Record<string, boolean>>({});

  // Visible groups keep their own opening animation, but only one of them may be
  // open at a time: opening a section slides the previously open one shut.
  const toggle = (key: string) => setOpen(prev => ({ [key]: !prev[key] }));

  // Tick a screen's View box and only that screen appears: a role that may raise invoices
  // but never see payments loses just the payments entry.
  const itemsOf = (g: Group) => g.items.filter(([, tab]) => canOpenTab(tab, can));
  const visibleGroups = GROUPS.map(g => ({ ...g, shown: itemsOf(g) })).filter(g => g.shown.length > 0);

  // Groups stay closed by default; only the one holding the active screen opens.
  useEffect(() => {
    const g = groupOfTab(currentTab);
    if (g) setOpen(prev => (prev[g] && Object.keys(prev).length === 1 ? prev : { [g]: true }));
  }, [currentTab]);

  const topItems = TOP_ITEMS.filter(([, tab]) => canOpenTab(tab, can));
  const bottomItems = BOTTOM_ITEMS.filter(([, tab]) => canOpenTab(tab, can));

  return (
    <aside className={`fixed top-12 bottom-0 left-0 z-40 bg-white border-r border-gray-200 overflow-y-auto overflow-x-hidden select-none
      transition-[width] duration-300 ease-out ${collapsed ? 'w-0' : 'w-60'} ${collapsed ? '' : 'sidebar-scroll'}`}>
      <div className={`py-2.5 w-60 ${collapsed ? 'pointer-events-none' : ''}`}>
        {topItems.map(([label, tab, icon]) => (
          <NavItem key={tab} label={label} tab={tab} icon={icon} currentTab={currentTab} onSelectTab={onSelectTab} />
        ))}

        <div className="nav-rule" />

        {visibleGroups.map(group => {
          const isOpen = !!open[group.key];
          const isActive = groupOfTab(currentTab) === group.key;
          return (
            <div key={group.key}>
              <button onClick={() => toggle(group.key)}
                aria-expanded={isOpen}
                className={`nav-group-head ${isActive ? 'is-active' : ''}`}>
                <span className="nav-group-icon">
                  <span className={isActive ? 'text-current' : ''}>{group.icon}</span>
                  <span className="truncate">{group.label}</span>
                </span>
                <ChevronDown className={`w-3.5 h-3.5 shrink-0 opacity-70 transition-transform duration-300 ${isOpen ? 'rotate-0' : '-rotate-90'}`} />
              </button>

              {/* The list unfolds by its own rows rather than by a measured height, so a
                  group of two and a group of nine both animate correctly. */}
              <div className="grid transition-[grid-template-rows] duration-300 ease-out"
                style={{ gridTemplateRows: isOpen ? '1fr' : '0fr' }}>
                <div className={`overflow-hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`}>
                  <div className="pb-1">
                    {group.shown.map(([label, tab]) => (
                      <button key={tab} onClick={() => onSelectTab(tab)}
                        aria-current={currentTab === tab ? 'page' : undefined}
                        className={`nav-row is-child ${currentTab === tab ? 'is-active' : ''}`}>
                        <span className="truncate">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        <div className="nav-rule" />

        {bottomItems.map(([label, tab, icon]) => (
          <NavItem key={tab} label={label} tab={tab} icon={icon} currentTab={currentTab} onSelectTab={onSelectTab} />
        ))}

        <button onClick={onToggleCollapsed}
          className="nav-row mt-2.5 !text-[11px] !font-bold uppercase !tracking-[.08em] opacity-80 hover:opacity-100">
          <PanelLeftClose className="w-3.5 h-3.5" />
          <span className="truncate">Collapse menu</span>
        </button>
      </div>

      {collapsed && (
        <button onClick={onToggleCollapsed} title="Expand menu" aria-label="Expand menu"
          className="absolute top-2 left-2 w-8 h-8 rounded-lg bg-white border border-gray-200 shadow-sm flex items-center justify-center text-gray-500 hover:text-[#1e88e5] transition-colors">
          <PanelLeftOpen className="w-4 h-4" />
        </button>
      )}
    </aside>
  );
};

export default Sidebar;
