import React, { useEffect, useRef, useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { activateCompany, addCompany, getCompanies, CompanyEntry } from '../../services/settings.service';
import { AppNotification, getNotifications, markNotificationsRead } from '../../services/notifications.service';
import { DOC_KINDS } from '../../pages/Docs/docKinds';
import { canOpenTab } from './Sidebar';
import { inkOn, plateOn } from '../../utils/inkOn';
import { useTheme } from '../../context/ThemeContext';
import {
  Phone,
  Plus,
  Settings,
  Bell,
  User,
  ChevronDown,
  Menu,
  Building2,
  Users,
  ShieldCheck,
  Check,
  CreditCard,
  KeyRound,
  LogOut
} from 'lucide-react';

interface HeaderProps {
  onQuickCreate: (type: string) => void;
  onNavigate?: (tab: string) => void;
  onToggleSidebar: () => void;
}

interface CreateItem { label: string; tab?: string; action?: string }

// The server names the document collection a notification came from; the browser
// opens it through the doc kind that owns that collection. Three collections predate
// the generic document screen and still have a screen of their own under another name.
const SCREEN_OF_RESOURCE: Record<string, string> = {
  saleInvoices: 'sales-invoices'
};

const tabOfNote = (tab: string) => {
  if (!tab.startsWith('resource:')) return tab;
  const resource = tab.slice('resource:'.length);
  if (SCREEN_OF_RESOURCE[resource]) return SCREEN_OF_RESOURCE[resource];
  const key = Object.keys(DOC_KINDS).find(k => DOC_KINDS[k].resource === resource);
  return key ? `doc:${key}` : 'reports';
};

const TONE_DOT: Record<AppNotification['tone'], string> = {
  danger: 'bg-red-500', warning: 'bg-amber-500', info: 'bg-blue-500', success: 'bg-emerald-500'
};

const CREATE_MENU: { title: string; items: CreateItem[] }[] = [
  {
    title: 'Documents',
    items: [
      { label: 'Sale Invoice', action: 'sale-invoice' },
      { label: 'Delivery Challan', action: 'sale-delivery' },
      { label: 'Sale Return', action: 'sale-return' },
      { label: 'Receive Payment', action: 'receive-payment' },
      { label: 'Good Receiving', action: 'good-receiving' },
      { label: 'Purchase Invoice', action: 'purchase-bill' },
      { label: 'Import Invoice', action: 'import-invoice' },
      { label: 'Make Payment', action: 'vendor-payment' },
      { label: 'Cash Payment Voucher', action: 'cash-voucher' },
      { label: 'Bank Payment Voucher', action: 'bank-voucher' },
      { label: 'Cash Receipt Voucher', action: 'cash-receipt-voucher' },
      { label: 'Bank Receipt Voucher', action: 'bank-receipt-voucher' },
      { label: 'Stock Movement', action: 'stock-movement' },
      { label: 'Stock Adjustment', action: 'stock-adjustment' },
      { label: 'Customer / B-Group', action: 'detail-b-group' },
    ],
  },
  {
    title: 'Lists',
    items: [
      { label: 'Customers', tab: 'customers' },
      { label: 'Vendors', tab: 'vendors' },
      { label: 'Products', tab: 'products' },
      { label: 'Sales Persons', tab: 'sales-persons' },
      { label: 'Users', tab: 'users' },
    ],
  },
  {
    title: 'Categories',
    items: [
      { label: 'Customer Categories', tab: 'cat:customer' },
      { label: 'Vendor Categories', tab: 'cat:vendor' },
      { label: 'Product Categories', tab: 'cat:product' },
      { label: 'Brands', tab: 'cat:brand' },
    ],
  },
  {
    title: 'General',
    items: [
      { label: 'Warehouses', tab: 'warehouses' },
      { label: 'Weekly Route', tab: 'weekly-routes' },
    ],
  },
  {
    title: 'Payroll',
    items: [
      { label: 'Departments', tab: 'cat:department' },
      { label: 'Designations', tab: 'cat:designation' },
    ],
  },
];

// An entry here is a promise that the screen behind it opens, so the list holds only the
// registers this build actually reads somewhere: the party and product shelves, the two
// payroll lists of names, and the papers and lists a clerk raises all day. The old CRM and
// "General" rows (taxes, tags, custom fields, price levels, commissions, consignments,
// industries, projects, leads, tickets, events) were category screens no form ever opened —
// the values typed into them reached nothing — and they are gone rather than hidden.
const tabOfCreateItem = (item: CreateItem) => {
  if (item.tab) return item.tab;
  const a = item.action || '';
  // The same three turns App.tsx makes when a quick-create action arrives.
  if (a === 'sale-invoice') return 'sales-invoices';
  if (a === 'sale-delivery') return 'delivery-challan';
  if (a === 'detail-b-group') return 'detail-b-groups';
  return `doc:${a}`;
};

type MenuKey = 'create' | 'bell' | 'branch' | 'profile';

export const Header: React.FC<HeaderProps> = ({ onQuickCreate, onNavigate, onToggleSidebar }) => {
  const { tenantSlug, tenantName, branches, branchId, setBranchId, enableBranch, setCompany, canSetSubscription } = useTenant();
  const { user, logout, can } = useAuth();
  const { theme, setTheme, themes } = useTheme();
  const barRef = useRef<HTMLElement>(null);
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [showBranchMenu, setShowBranchMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showBell, setShowBell] = useState(false);
  const [notes, setNotes] = useState<AppNotification[]>([]);
  const [companies, setCompanies] = useState<CompanyEntry[]>([]);
  const [adding, setAdding] = useState(false);
  const [newCompany, setNewCompany] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [ownerPassword, setOwnerPassword] = useState('');
  const [companyError, setCompanyError] = useState('');
  // What the vendor has to hand the buyer after opening his firm: the code he will type at
  // sign-in if his name exists at more than one firm, and the account he starts in.
  const [opened, setOpened] = useState<{ name: string; slug: string; email: string } | null>(null);

  // One menu open at a time, and `null` puts them all away.
  const showMenu = (which: MenuKey | null) => {
    setShowCreateMenu(which === 'create');
    setShowBell(which === 'bell');
    setShowBranchMenu(which === 'branch');
    setShowProfileMenu(which === 'profile');
    if (which === 'branch') setCompanyError('');
  };

  // These menus used to be closed by an invisible sheet stretched over the whole page under
  // the same z-50 corner as the bar itself. That sheet answered the click first, so the first
  // click anywhere it covered — the sidebar, the bar's own buttons — was spent dismissing it
  // and never reached the button underneath; the button only worked once he clicked somewhere
  // else first. The bar now listens for the press rather than catching it, and a press that
  // lands outside the bar closes the menu while the click carries on to whoever owns it.
  const anyMenuOpen = showCreateMenu || showBell || showBranchMenu || showProfileMenu;
  useEffect(() => {
    if (!anyMenuOpen) return;
    const onDocDown = (e: MouseEvent) => {
      if (barRef.current?.contains(e.target as Node)) return;
      showMenu(null);
    };
    document.addEventListener('mousedown', onDocDown);
    return () => document.removeEventListener('mousedown', onDocDown);
  }, [anyMenuOpen, showCreateMenu, showBell, showBranchMenu, showProfileMenu]);

  // A clerk is not handed a door that will refuse them on the other side: the same View tick
  // the sidebar and App's guard read decides which of these entries appear at all, and a
  // column with nothing left in it is not shown.
  const createColumns = CREATE_MENU
    .map(col => ({ ...col, items: col.items.filter(i => canOpenTab(tabOfCreateItem(i), can)) }))
    .filter(col => col.items.length);

  const unread = notes.filter(n => !n.read).length;
  const currentBranch = branches.find(b => b.id === branchId) || branches[0];

  useEffect(() => {
    getCompanies(tenantSlug, branchId).then(setCompanies).catch(() => {});
  }, [tenantSlug, branchId]);

  useEffect(() => {
    let live = true;
    const load = () => getNotifications(tenantSlug, branchId)
      .then(d => { if (live) setNotes(d.data); })
      .catch(() => { if (live) setNotes([]); });
    load();
    const id = window.setInterval(load, 60000);
    return () => { live = false; window.clearInterval(id); };
  }, [tenantSlug, branchId]);

  // The line goes quiet the moment it is clicked and the server is told after — the bell
  // should not wait on a round trip to admit the user has seen something.
  const clearNote = (id: string) => {
    setNotes(list => list.map(n => (n.id === id ? { ...n, read: true } : n)));
    markNotificationsRead(tenantSlug, branchId, id).catch(() => {});
  };
  const clearAllNotes = () => {
    setNotes(list => list.map(n => ({ ...n, read: true })));
    markNotificationsRead(tenantSlug, branchId, '*').catch(() => {});
  };

  // The header re-labelling itself is the promise that the API now answers for that
  // company, so it may only happen after the server has agreed to the switch. The menu
  // stays open on a refusal; the reason belongs where the click was made.
  const switchCompany = async (c: CompanyEntry) => {
    if (c.slug === tenantSlug) return;
    try {
      await activateCompany(tenantSlug, branchId, c.slug);
      setCompanyError('');
      setCompany(c.slug, c.name);
      setShowBranchMenu(false);
    } catch (e) {
      setCompanyError(`Could not switch to ${c.name}: ${(e as Error).message}`);
    }
  };

  const createCompany = async () => {
    const name = newCompany.trim();
    if (!name) return;
    try {
      const created = await addCompany(tenantSlug, branchId, {
        name, ownerEmail: ownerEmail.trim(), ownerPassword
      });
      setCompanies(cs => (cs.some(c => c.slug === created.slug) ? cs : [...cs, created]));
      setOpened({ name: created.name, slug: created.slug, email: created.owner?.email ?? '' });
      setNewCompany(''); setOwnerEmail(''); setOwnerPassword('');
      setAdding(false);
      setCompanyError('');
    } catch (e) {
      setCompanyError((e as Error).message);
    }
  };

  return (
    <header ref={barRef} className="bg-white border-b border-gray-200 h-12 flex items-center justify-between gap-2 px-3 sm:px-4 fixed top-0 left-0 right-0 z-50">
      {/* Brand Logo */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <button onClick={onToggleSidebar} title="Toggle menu" aria-label="Toggle menu"
          className="w-8 h-8 rounded-md flex items-center justify-center text-gray-500 hover:text-[#1e88e5] hover:bg-blue-50/60 active:scale-95 transition-all duration-200">
          <Menu className="w-4 h-4" />
        </button>
        <button onClick={() => onNavigate?.('home')} className="flex items-center gap-1.5 font-bold tracking-tight text-gray-800 text-base hover:opacity-80 transition-opacity">
          <div className="w-6 h-6 rounded bg-[#2ec4b6] flex items-center justify-center text-white text-xs shadow-sm">
            <i className="fa fa-chart-pie"></i>
          </div>
          <span className="text-[#2ec4b6] font-extrabold tracking-wider">Xenith</span>
          <span className="text-gray-600 font-semibold text-xs tracking-widest uppercase">ERP</span>
        </button>
      </div>

      {/* Center & Right Navigation Items */}
      <div className="flex items-center gap-2 lg:gap-4 text-xs text-gray-600 min-w-0">
        {/* Support Phone */}
        <div className="hidden xl:flex items-center gap-1 text-gray-500 whitespace-nowrap">
          <Phone className="w-3.5 h-3.5 text-[#2ec4b6] shrink-0" />
          <span>Call Us: +92 322 3805981</span>
        </div>

        {/* Quick Create (+) Dropdown */}
        <div className="relative shrink-0">
          <button
            onClick={() => showMenu(showCreateMenu ? null : 'create')}
            className="btn-xenith-success !px-2.5 !py-1 !rounded-lg !text-[12px]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Create</span>
            <ChevronDown className="hidden sm:block w-3 h-3" />
          </button>

          {showCreateMenu && (
            <>
              {/* The Documents column alone is taller than a short window, so the panel takes
                  whatever height is left under the header and scrolls instead of running off
                  the bottom out of sight. */}
              <div className="absolute right-0 mt-1.5 w-[880px] max-w-[95vw] max-h-[calc(100vh-3.75rem)] overflow-y-auto overscroll-contain app-scroll bg-white border border-gray-200 rounded-2xl shadow-lg p-4 z-50 animate-[popIn_.16s_ease-out_backwards]">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-x-4 gap-y-3">
                  {createColumns.map(col => (
                    <div key={col.title}>
                      <div className="sticky top-0 z-10 bg-white text-[11px] font-extrabold text-gray-400 uppercase tracking-wider mb-1 border-b border-gray-100 pb-1">
                        {col.title}
                      </div>
                      <ul className="space-y-0.5">
                        {col.items.map(item => (
                          <li key={item.label}>
                            <button
                              type="button"
                              onClick={() => {
                                setShowCreateMenu(false);
                                if (item.action) onQuickCreate(item.action);
                                else if (item.tab) onNavigate?.(item.tab);
                              }}
                              className="w-full text-left text-xs py-1 px-1.5 rounded-md truncate text-gray-700 hover:bg-gray-100 hover:text-[#1e88e5] transition-colors"
                            >
                              {item.label}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => showMenu(showBell ? null : 'bell')}
            className={`w-8 h-8 grid place-items-center relative rounded-lg transition-colors ${showBell ? 'bg-gray-100 text-gray-800' : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'}`}
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[15px] h-[15px] px-1 grid place-items-center rounded-full bg-red-500 text-white text-[9px] font-bold leading-none">
                {unread}
              </span>
            )}
          </button>

          {showBell && (
            <>
              <div className="absolute right-0 mt-1.5 w-[340px] bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden animate-[fadeUp_.2s_ease-out_backwards]">
                <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
                  <span className="text-xs font-bold text-gray-800">
                    Notifications
                    <span className="ml-1 font-normal text-gray-400">
                      {notes.length === 0 ? '' : unread ? `· ${unread} open` : '· all read'}
                    </span>
                  </span>
                  <span className="flex items-center gap-3">
                    {unread > 0 && (
                      <button
                        type="button"
                        onClick={clearAllNotes}
                        className="text-[11px] font-bold text-gray-500 hover:text-[#25a195] hover:underline"
                      >
                        Mark all read
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => { onNavigate?.('report:audit-log'); setShowBell(false); }}
                      className="text-[11px] font-bold text-[#25a195] hover:underline"
                    >
                      Activity Log
                    </button>
                  </span>
                </div>
                {notes.length === 0 && (
                  <div className="px-3 py-6 text-center text-xs text-gray-400">Nothing needs your attention.</div>
                )}
                <div className="max-h-[60vh] overflow-y-auto app-scroll">
                  {[...notes].sort((a, b) => Number(a.read) - Number(b.read)).map(n => (
                    <button
                      key={n.id} type="button"
                      onClick={() => { clearNote(n.id); onNavigate?.(tabOfNote(n.tab)); setShowBell(false); }}
                      className="w-full flex items-start gap-2 px-3 py-2 text-left border-b border-gray-50 hover:bg-gray-50 transition-colors"
                    >
                      <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${n.read ? 'bg-gray-200' : TONE_DOT[n.tone]}`} />
                      <span className="min-w-0 flex-1">
                        <span className={`block text-xs font-semibold truncate ${n.read ? 'text-gray-400' : 'text-gray-800'}`}>{n.title}</span>
                        <span className="block text-[11px] text-gray-500 truncate">{n.detail}</span>
                      </span>
                      <span className="text-[10px] text-gray-400 shrink-0 whitespace-nowrap">{n.time}</span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Company / Branch Switcher Dropdown.
            A display tick rather than a data one: which firm to work in is already answered
            for by the vendor-only rule behind the switch, and which branch by the person's own
            branch list. What this tick decides is whether the popover is drawn at all — and
            this is the only handle either act has, so hiding it takes both out of reach.
            Logout does not go with it: the avatar menu and the bar's own button carry that. */}
        {can('company-switcher:view') && (<>
        <div className="relative">
          <button
            onClick={() => showMenu(showBranchMenu ? null : 'branch')}
            className="flex items-center gap-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-300 px-2 py-1 rounded-lg text-xs text-gray-700 transition-colors"
          >
            <Building2 className="w-3.5 h-3.5 text-[#2ec4b6]" />
            <div className="flex flex-col items-start leading-none text-left min-w-0">
              <span className="font-semibold max-w-[10ch] sm:max-w-none truncate">{tenantName.split(' ')[0]}</span>
              <span className="hidden sm:block text-[10px] text-gray-500">{currentBranch?.name}</span>
            </div>
            <ChevronDown className="w-3 h-3 text-gray-400" />
          </button>

          {showBranchMenu && (
            <>
              <div className="absolute right-0 mt-1.5 w-64 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-50 max-h-[70vh] overflow-y-auto app-scroll">
                <div className="px-3 py-1.5 border-b border-gray-100">
                  <div className="font-bold text-gray-800">{tenantName}</div>
                  <div className="text-[11px] text-gray-500">ID: {tenantSlug}</div>
                </div>

                <div className="px-3 py-1 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Switch Company</div>
                {companyError && !adding && <p className="px-3 pb-1 text-[10px] font-semibold text-red-600">{companyError}</p>}
                {/* The open company is the block above, so the list only offers the others. */}
                {companies.filter(c => c.slug !== tenantSlug).length === 0 && (
                  <div className="px-3 py-1.5 text-xs text-gray-400">No other company yet</div>
                )}
                {companies.filter(c => c.slug !== tenantSlug).map(c => (
                  <button key={c.slug}
                    onClick={() => { void switchCompany(c); }}
                    className="w-full text-left px-3 py-1.5 hover:bg-gray-100 flex items-center justify-between text-xs"
                    title={`${c.typeOfOrganization} · ${c.plan}`}
                  >
                    <span className="truncate pr-2">{c.name}</span>
                    <span className="text-[10px] text-gray-400 shrink-0">{c.typeOfOrganization}</span>
                  </button>
                ))}

                {/* Opening a company is part of selling one, so the door only appears for the
                    login the server says may set a sale. */}
                {canSetSubscription && (adding ? (
                  <div className="px-3 py-1.5 space-y-1">
                    <input autoFocus value={newCompany} onChange={e => setNewCompany(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') createCompany(); }}
                      placeholder="New company name" className="input-xenith" />
                    <input value={ownerEmail} onChange={e => setOwnerEmail(e.target.value)}
                      type="email" autoComplete="off" placeholder="Owner's email" className="input-xenith"
                      onKeyDown={e => { if (e.key === 'Enter') createCompany(); }} />
                    <input value={ownerPassword} onChange={e => setOwnerPassword(e.target.value)}
                      type="password" autoComplete="new-password" placeholder="Their first password" className="input-xenith"
                      onKeyDown={e => { if (e.key === 'Enter') createCompany(); }} />
                    <p className="text-[10px] leading-snug text-gray-500">
                      The firm opens with this one account and nothing else. Eight characters or more.
                    </p>
                    {companyError && <p className="text-[10px] font-semibold text-red-600">{companyError}</p>}
                    <div className="flex items-center gap-1">
                      <button onClick={createCompany}
                        disabled={!newCompany.trim() || !/\S+@\S+\.\S+/.test(ownerEmail.trim()) || ownerPassword.length < 8}
                        className="btn-xenith-success !px-2 !py-1 text-[11px] disabled:opacity-40">Add</button>
                      <button onClick={() => { setAdding(false); setCompanyError(''); }} className="btn-xenith-outline !px-2 !py-1 text-[11px]">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => { setAdding(true); setNewCompany(''); setOwnerEmail(''); setOwnerPassword(''); setCompanyError(''); setOpened(null); }}
                    className="w-full text-left px-3 py-1.5 hover:bg-gray-100 text-xs font-bold text-[#2ec4b6] flex items-center gap-1">
                    <Plus className="w-3 h-3" /> ADD COMPANY
                  </button>
                ))}

                {opened && (
                  <div className="mx-3 my-1.5 p-2 rounded-lg bg-blue-50 border border-blue-100 text-[10px] leading-snug text-gray-700">
                    <div className="font-bold text-gray-800">{opened.name} is open</div>
                    <div>Sign-in: <span className="font-mono">{opened.email}</span></div>
                    <div>Company code: <span className="font-mono">{opened.slug}</span></div>
                    <div className="text-gray-500 mt-0.5">Sell this firm its modules from the Subscription screen before handing it over.</div>
                  </div>
                )}

                {enableBranch && (
                  <>
                    <div className="my-1 mx-3 h-px bg-gray-100" />
                    <div className="px-3 py-1 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Switch Branch</div>
                    {branches.map(b => (
                      <button
                        key={b.id}
                        onClick={() => { setBranchId(b.id); setShowBranchMenu(false); }}
                        className="w-full text-left px-3 py-1.5 hover:bg-gray-100 flex items-center justify-between text-xs"
                      >
                        <span className={b.id === branchId ? "font-bold text-[#2ec4b6]" : ""}>{b.name}</span>
                        {b.id === branchId && <Check className="w-3.5 h-3.5 text-[#2ec4b6]" />}
                      </button>
                    ))}
                  </>
                )}

                <div className="my-1 mx-3 h-px bg-gray-100" />
                {(can('company-settings:view') || can('branches:view')) && (
                  <>
                    {can('company-settings:view') && <MenuLink label="Company Settings" icon={<Settings className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('company-settings'); setShowBranchMenu(false); }} />}
                    {can('branches:view') && <MenuLink label="Manage Branches" icon={<Building2 className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('branches'); setShowBranchMenu(false); }} />}
                  </>
                )}
                {can('subscription:view') && <MenuLink label="Subscription" icon={<CreditCard className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('subscription'); setShowBranchMenu(false); }} />}
                <div className="my-1 mx-3 h-px bg-gray-100" />
                <button onClick={logout} className="w-full text-left px-3 py-1.5 hover:bg-red-50 text-xs text-red-600 flex items-center gap-2">
                  <LogOut className="w-3.5 h-3.5" /> Logout
                </button>
              </div>
            </>
          )}
        </div>
        </>)}

        {/* User Profile Avatar */}
        <div className="relative">
          <button onClick={() => showMenu(showProfileMenu ? null : 'profile')}
            className="w-7 h-7 rounded-full border flex items-center justify-center text-[11px] font-bold hover:brightness-95 transition-all"
            style={{ ...plateOn(user?.avatarColor ?? '#1e88e5'), borderColor: 'rgba(0,0,0,.08)' }}
            title={`${user?.name ?? 'User'} · ${user?.roleName ?? ''}`}>
            {(user?.name || 'U').charAt(0).toUpperCase()}
          </button>
          {showProfileMenu && (
            <>
              <div className="absolute right-0 mt-1.5 w-56 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-50 max-h-[calc(100vh-3.75rem)] overflow-y-auto overscroll-contain app-scroll">
                <div className="px-3 py-1.5 border-b border-gray-100">
                  <div className="font-bold text-gray-800 truncate">{user?.name}</div>
                  <div className="text-[11px] text-gray-500 truncate">{user?.email}</div>
                  <div className="text-[10px] font-semibold uppercase tracking-wide text-[#2ec4b6]">{user?.roleName}</div>
                </div>
                <MenuLink label="My Profile" icon={<User className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('my-profile'); setShowProfileMenu(false); }} />
                <MenuLink label="Change Password" icon={<KeyRound className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('change-password'); setShowProfileMenu(false); }} />
                {(can('users:view') || can('roles:view')) && (
                  <>
                    <div className="my-1 mx-3 h-px bg-gray-100" />
                    {can('users:view') && <MenuLink label="Users" icon={<Users className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('users'); setShowProfileMenu(false); }} />}
                    {can('roles:view') && <MenuLink label="User Roles" icon={<ShieldCheck className="w-3.5 h-3.5" />} onClick={() => { onNavigate?.('roles'); setShowProfileMenu(false); }} />}
                  </>
                )}

                {/* Where the whole workspace is read from, so it belongs to the signed-in
                    person and not to one screen: the dashboard picker only offers it to
                    somebody who happens to be looking at the dashboard. */}
                <div className="my-1 mx-3 h-px bg-gray-100" />
                <div className="px-3 py-1 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Appearance</div>
                <div className="px-2.5 pb-1 grid grid-cols-6 gap-1">
                  {themes.map(t => (
                    <button key={t.key} type="button" title={`${t.label} — ${t.hint}`}
                      aria-label={t.label} aria-pressed={theme === t.key}
                      onClick={() => setTheme(t.key)}
                      className={`h-7 rounded-md border transition-transform duration-200 hover:scale-110 ${
                        theme === t.key ? 'border-gray-400 shadow-sm' : 'border-gray-200'}`}
                      style={{ background: t.swatch }}>
                      {theme === t.key && (
                        <Check className="w-3 h-3 mx-auto" style={{ color: inkOn(t.swatch) }} />
                      )}
                    </button>
                  ))}
                </div>

                <div className="my-1 mx-3 h-px bg-gray-100" />
                <button onClick={logout} className="w-full text-left px-3 py-1.5 hover:bg-red-50 text-xs text-red-600 flex items-center gap-2">
                  <LogOut className="w-3.5 h-3.5" /> Logout
                </button>
              </div>
            </>
          )}
        </div>

        {/* Logout — the profile menu carries it once the row gets crowded */}
        <button className="hidden xl:block text-gray-500 hover:text-red-600 p-1 shrink-0" title="Logout" onClick={logout}>
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

const MenuLink: React.FC<{ label: string; icon: React.ReactNode; onClick?: () => void }> = ({
  label, icon, onClick
}) => (
  <button type="button" onClick={onClick}
    className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 text-gray-700 hover:bg-gray-100">
    {icon} {label}
  </button>
);
