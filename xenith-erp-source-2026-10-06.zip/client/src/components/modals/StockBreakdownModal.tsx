import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Info, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { getStockBreakdown } from '../../services/masters.service';
import { StockBreakdown, StockBucket } from '../../types';

const qty = (n: number) => (Number(n) || 0).toLocaleString(undefined, { maximumFractionDigits: 3 });

interface Row {
  key: keyof StockBucket;
  label: string;
  note?: string;
  // A row only shows when this product's own ledger has something in it, so the modal never
  // carries a figure that will stay zero for ever.
  always?: boolean;
  tone?: 'plain' | 'soft' | 'warn';
}

const ROWS: Row[] = [
  { key: 'opening', label: 'Opening Stock', always: true, tone: 'plain' },
  { key: 'received', label: 'Total Purchases', note: 'received on approved goods notes', always: true, tone: 'plain' },
  { key: 'transferredIn', label: 'Transferred In', note: 'arrived from another location', tone: 'soft' },
  { key: 'issued', label: 'Total Sales', note: 'issued on approved invoices and challans', always: true, tone: 'plain' },
  { key: 'transferredOut', label: 'Transferred Out', note: 'sent to another location', tone: 'soft' },
  { key: 'adjusted', label: 'Adjustments', note: 'damage, shrinkage, recount', tone: 'soft' },
];

const TONES: Record<string, string> = {
  plain: 'bg-white',
  soft: 'bg-amber-50/70',
  warn: 'bg-red-50',
};

interface Props {
  productId: number | null;
  onClose: () => void;
}

export const StockBreakdownModal: React.FC<Props> = ({ productId, onClose }) => {
  const { tenantSlug, branchId } = useTenant();
  const [data, setData] = useState<StockBreakdown | null>(null);
  const [failed, setFailed] = useState('');
  const [loc, setLoc] = useState('ALL');

  useEffect(() => {
    if (productId == null) return;
    let live = true;
    setData(null); setFailed(''); setLoc('ALL');
    getStockBreakdown(tenantSlug, branchId, productId)
      .then(d => { if (live) setData(d); })
      .catch(e => { if (live) setFailed(e?.message || 'The stock ledger could not be read'); });
    return () => { live = false; };
  }, [tenantSlug, branchId, productId]);

  if (productId == null) return null;

  const unit = (data?.product.unit || '').toUpperCase();
  const bucket: StockBucket | undefined = !data ? undefined
    : loc === 'ALL' ? data.total
    : data.locations.find(l => l.name === loc) || data.total;

  const shown = ROWS.filter(r => r.always || Math.abs(Number(bucket?.[r.key]) || 0) > 0);
  const negative = !!bucket && bucket.available < 0;

  // The page wrapper carries an entrance transform, and any transform on an ancestor turns
  // a fixed overlay into one measured against that wrapper instead of the window — which is
  // how a box ends up running off the bottom of the screen. The portal puts it back on the
  // window, so the modal is capped by the viewport however tall the page behind it grows.
  return createPortal(
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-label="Stock Breakdown"
        onClick={e => e.stopPropagation()}
        className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden border border-gray-200 flex flex-col max-h-[86vh]"
      >
        <div className="px-4 py-3 border-b border-gray-200 flex items-start justify-between gap-3 bg-gray-50">
          <div className="flex items-start gap-2.5 min-w-0">
            <span className="mt-0.5 w-7 h-7 shrink-0 rounded-lg bg-[#2ec4b6]/15 text-[#1f8c82] grid place-items-center">
              <Info className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-gray-900 leading-tight">Stock Breakdown</h3>
              <p className="text-xs text-gray-600 truncate">
                {data ? `${data.product.name} · ${data.product.code}` : 'Reading the stock ledger...'}
              </p>
            </div>
          </div>
          <button onClick={onClose} title="Close" className="text-gray-400 hover:text-gray-700 p-1 rounded shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto app-scroll text-xs">
          {failed && (
            <p className="text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{failed}</p>
          )}
          {!failed && (
            <>
              <p className="text-[10px] uppercase font-bold tracking-wide text-gray-500 mb-2">Select location:</p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {['ALL', ...(data?.locations.map(l => l.name) || [])].map(name => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => setLoc(name)}
                    className={`px-2.5 py-1 rounded-full border text-[11px] font-semibold transition-colors ${
                      loc === name
                        ? 'border-[#25a195] text-[#1f8c82] bg-white ring-1 ring-[#25a195]'
                        : 'border-gray-300 text-gray-700 bg-white hover:border-gray-400'
                    }`}
                  >
                    {name === 'ALL' ? 'ALL' : name}
                  </button>
                ))}
              </div>

              <div className="rounded-lg border border-gray-200 overflow-hidden">
                {shown.map((r, i) => (
                  <div
                    key={r.key}
                    className={`flex items-start justify-between gap-3 px-3 py-2.5 ${TONES[r.tone || 'plain']} ${
                      i ? 'border-t border-gray-100' : ''
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-[13px] font-semibold text-gray-800 leading-tight">{r.label}</p>
                      {r.note && <p className="text-[10px] text-gray-500 mt-0.5">{r.note}</p>}
                    </div>
                    <p className="text-[13px] font-black text-gray-900 tabular-nums whitespace-nowrap">
                      {qty(Number(bucket?.[r.key]) || 0)} {unit}
                    </p>
                  </div>
                ))}
                <div className={`flex items-center justify-between gap-3 px-3 py-3 border-t-2 border-gray-200 ${
                  negative ? 'bg-red-50' : 'bg-blue-50'
                }`}>
                  <p className={`text-[13px] font-black ${negative ? 'text-red-700' : 'text-blue-800'}`}>
                    Available Stock <span className="font-semibold text-[11px] opacity-80">(To Sell)</span>
                  </p>
                  <p className={`text-sm font-black tabular-nums whitespace-nowrap ${
                    negative ? 'text-red-700' : 'text-blue-800'
                  }`}>
                    {qty(bucket?.available ?? 0)} {unit}
                  </p>
                </div>
              </div>

              {negative && (
                <p className="mt-2 text-[11px] text-red-700">
                  This location has issued more than it holds, so a stock adjustment or a transfer in
                  is needed to bring the card back to the truth.
                </p>
              )}

              {!!data?.pending.qty && loc === 'ALL' && (
                <p className="mt-3 text-[11px] text-gray-600 leading-relaxed">
                  Of the {qty(data.total.issued)} {unit} issued, {qty(data.pending.qty)} is still inside the
                  warehouse on {data.pending.documents.length} approved invoice
                  {data.pending.documents.length === 1 ? '' : 's'} ({data.pending.documents.join(', ')})
                  {' '}awaiting dispatch. It has already been taken out of the figure above.
                </p>
              )}

              {data && !data.locations.length && (
                <p className="mt-3 text-[11px] text-gray-600 leading-relaxed">
                  Nothing has been posted to this product's stock ledger yet, so no location holds any of
                  it. Openings are placed by a Stock Adjustment of the type "Openings".
                </p>
              )}
            </>
          )}
        </div>

        <div className="px-4 py-3 border-t border-gray-200 bg-gray-50 flex justify-end">
          <button onClick={onClose} className="btn-xenith-outline">Close</button>
        </div>
      </div>
    </div>,
    document.body
  );
};
