import React, { useEffect, useState } from 'react';
import { isoDay, monthStart } from '../../utils/dateRange';
import { useTenant } from '../../context/TenantContext';
import { getWarehouses, Warehouse } from '../../services/warehouses.service';
import {
  SaleInvoiceStatusArray,
  SaleDeliveryStatusArray
} from '../../types';
import { X, Calendar, Printer } from 'lucide-react';

interface BulkPrintingModalProps {
  isOpen: boolean;
  onClose: (filterData?: any) => void;
  documentType?: 'SaleInvoice' | 'SaleDelivery';
}

export const BulkPrintingModal: React.FC<BulkPrintingModalProps> = ({
  isOpen,
  onClose,
  documentType = 'SaleInvoice'
}) => {
  const { tenantSlug, branchId } = useTenant();
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('0');
  const [selectedStatus, setSelectedStatus] = useState<string>('null');
  const [filterText, setFilterText] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>(monthStart());
  const [toDate, setToDate] = useState<string>(isoDay());
  const [isPrintingHalfPage, setIsPrintingHalfPage] = useState<boolean>(false);
  const [errors, setErrors] = useState<{ fromDate?: string; toDate?: string }>({});
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);

  useEffect(() => {
    if (!isOpen) return;
    getWarehouses(tenantSlug, branchId)
      .then(hub => setWarehouses(hub.data))
      .catch(() => setWarehouses([]));
  }, [isOpen, tenantSlug, branchId]);

  if (!isOpen) return null;

  const statusList =
    documentType === 'SaleDelivery'
      ? SaleDeliveryStatusArray
      : SaleInvoiceStatusArray;

  const validate = (): boolean => {
    const errs: { fromDate?: string; toDate?: string } = {};
    if (!fromDate) errs.fromDate = 'From date is required.';
    if (!toDate) errs.toDate = 'To date is required.';
    if (fromDate && toDate && new Date(toDate) < new Date(fromDate)) {
      errs.toDate = 'To date must be greater than or equal to From date.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleOk = () => {
    if (!validate()) return;
    onClose({
      customer: selectedCustomer || null,
      warehouseId: selectedWarehouseId !== '0' ? selectedWarehouseId : null,
      status: selectedStatus !== 'null' ? selectedStatus : null,
      filter: filterText,
      from: fromDate,
      to: toDate,
      isPrintingHalfPage
    });
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg overflow-hidden border border-gray-200 text-xs animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center font-bold text-gray-800">
          <div className="flex items-center gap-1.5">
            <Printer className="w-4 h-4 text-[#2ec4b6]" />
            <span>Bulk Printing / Date Range Filter</span>
          </div>
          <button onClick={() => onClose()} className="text-gray-400 hover:text-gray-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-3">
          {/* Customer */}
          <div>
            <label className="block text-gray-700 font-medium mb-1">Customer</label>
            <input
              type="text"
              placeholder="Type customer name to filter..."
              value={selectedCustomer}
              onChange={e => setSelectedCustomer(e.target.value)}
              className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Warehouse & Status */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-700 font-medium mb-1">Warehouse</label>
              <select
                value={selectedWarehouseId}
                onChange={e => setSelectedWarehouseId(e.target.value)}
                className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-blue-500 focus:outline-none"
              >
                <option value="0">-Choose-</option>
                {warehouses.map(w => (
                  <option key={w.id} value={String(w.id)}>{w.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">Status</label>
              <select
                value={selectedStatus}
                onChange={e => setSelectedStatus(e.target.value)}
                className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-blue-500 focus:outline-none"
              >
                <option value="null">Select All</option>
                {statusList.map(s => (
                  <option key={s.value} value={s.value}>
                    {s.text}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Search Filter */}
          <div>
            <label className="block text-gray-700 font-medium mb-1">Search Keywords</label>
            <input
              type="text"
              placeholder="Filter by invoice # or memo..."
              value={filterText}
              onChange={e => setFilterText(e.target.value)}
              className="w-full border border-gray-300 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Date Range: From Date & To Date */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-gray-700 font-medium mb-1">
                From Date <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={fromDate}
                  onChange={e => setFromDate(e.target.value)}
                  className={`w-full border rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 ${
                    errors.fromDate ? 'border-red-400 focus:ring-red-400' : 'border-gray-300 focus:ring-blue-500'
                  }`}
                />
              </div>
              {errors.fromDate && <p className="text-red-500 text-[10px] mt-0.5">{errors.fromDate}</p>}
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">
                To Date <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={toDate}
                  onChange={e => setToDate(e.target.value)}
                  className={`w-full border rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 ${
                    errors.toDate ? 'border-red-400 focus:ring-red-400' : 'border-gray-300 focus:ring-blue-500'
                  }`}
                />
              </div>
              {errors.toDate && <p className="text-red-500 text-[10px] mt-0.5">{errors.toDate}</p>}
            </div>
          </div>

          {/* Print on Half Page Checkbox (Xenith Retail / Distribution) */}
          <div className="pt-2 border-t border-gray-100 flex items-center gap-2">
            <input
              type="checkbox"
              id="halfPageCheck"
              checked={isPrintingHalfPage}
              onChange={e => setIsPrintingHalfPage(e.target.checked)}
              className="rounded border-gray-300 text-[#2ec4b6] focus:ring-0 cursor-pointer"
            />
            <label htmlFor="halfPageCheck" className="text-gray-700 font-medium cursor-pointer">
              Print on half page (A5 / 2 Invoices per sheet)
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-gray-200 flex justify-end gap-2">
          <button onClick={() => onClose()} className="btn-xenith-outline">
            Cancel
          </button>
          <button onClick={handleOk} className="btn-xenith-primary">
            Ok & Print
          </button>
        </div>
      </div>
    </div>
  );
};
