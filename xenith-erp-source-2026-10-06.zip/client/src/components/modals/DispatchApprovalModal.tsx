import React, { useEffect, useMemo, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { createPortal } from 'react-dom';
import { Boxes, Check, PauseCircle, Truck, UserRound, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { getDoc, updateDoc } from '../../services/docs.service';
import { BizDoc } from '../../types';

const num = (v: number) => roundMoney(v).toLocaleString(undefined, { maximumFractionDigits: 2 });

interface Props {
  // The challan register this paper is on, so the modal asks and saves through the same
  // book the board reads it from.
  resource: string;
  challanId: number;
  onClose: (message?: string) => void;
}

interface Row {
  id: number;
  productName: string;
  sku: string;
  unit: string;
  warehouseName: string;
  ordered: number;
}

/**
 * The warehouse's own answer to a load: what the paper promised, what is standing on the
 * truck, and the balance that stays behind on the bill. Nothing here signs the goods out —
 * an administrator still approves the paper — this only writes the quantities down so the
 * approval is a check of the load and not a guess at it.
 */
export const DispatchApprovalModal: React.FC<Props> = ({ resource, challanId, onClose }) => {
  const { tenantSlug, branchId } = useTenant();
  const [doc, setDoc] = useState<BizDoc | null>(null);
  const [failed, setFailed] = useState('');
  const [sending, setSending] = useState<Record<number, number>>({});
  const [vehicle, setVehicle] = useState('');
  const [driver, setDriver] = useState('');
  const [transportShown, setTransportShown] = useState(false);
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let live = true;
    setDoc(null); setFailed(''); setSending({});
    getDoc(resource, tenantSlug, branchId, challanId)
      .then(d => {
        if (!live) return;
        setDoc(d);
        setSending(Object.fromEntries(d.lines.map(l => [l.id, Number(l.quantity) || 0])));
        setVehicle(d.vehicle || '');
        setDriver(d.driver || '');
        setRemarks(d.comments || '');
        setTransportShown(!!(d.vehicle || d.driver));
      })
      .catch(e => { if (live) setFailed(e?.message || 'The challan could not be read.'); });
    return () => { live = false; };
  }, [resource, tenantSlug, branchId, challanId]);

  const rows: Row[] = useMemo(
    () => (doc?.lines || []).map(l => ({
      id: l.id, productName: l.productName, sku: l.sku, unit: l.unit || '',
      warehouseName: l.warehouseName || doc?.warehouseName || '',
      ordered: Math.abs(Number(l.quantity) || 0)
    })),
    [doc]
  );

  // Quantities are boxes and cartons, so a half carton is written as it stands — but a line can
  // never go out carrying more than the paper it was cut from promised.
  const sentQty = (id: number, ordered: number) => Math.max(0, Math.min(ordered, Number(sending[id]) || 0));
  const sendOf = (r: Row) => sentQty(r.id, r.ordered);
  const setSend = (r: Row, v: number) => setSending(s => ({ ...s, [r.id]: v }));
  const sendAll = () => setSending(Object.fromEntries(rows.map(r => [r.id, r.ordered])));
  const holdAll = () => setSending(Object.fromEntries(rows.map(r => [r.id, 0])));

  const orderTotal = rows.reduce((s, r) => s + r.ordered, 0);
  const sendTotal = rows.reduce((s, r) => s + sendOf(r), 0);
  const heldTotal = Math.max(0, roundMoney(orderTotal - sendTotal));
  const emptied = !!rows.length && sendTotal === 0;

  const save = () => {
    if (!doc || saving || emptied) return;
    setSaving(true); setFailed('');
    updateDoc(resource, tenantSlug, branchId, doc.id, {
      ...doc,
      // Untouched here when the section is folded away — the paper keeps what it already said.
      vehicle, driver, comments: remarks,
      lines: doc.lines.map(l => ({ ...l, quantity: sentQty(l.id, Math.abs(Number(l.quantity) || 0)) }))
    })
      .then(r => {
        // The held-back goods are not left as a number on the bill: the register files them
        // as a challan of its own and names it here, so the keeper sees the next load waiting
        // under the same bill instead of having to go and raise one.
        const next = (r?.filedDocs || []).map(d => d.number).join(' and ');
        onClose(!heldTotal
          ? `${doc.number} is written down at the full ${num(sendTotal)}. An administrator still has to sign the load out.`
          : next
            ? `${doc.number} is written down at ${num(sendTotal)} going out. The ${num(heldTotal)} held back is filed as its own challan — ${next} — under the same bill, so an administrator signing both loads is all that is left.`
            : `${doc.number} is written down at ${num(sendTotal)} going out and ${num(heldTotal)} held. An administrator still has to sign the load out.`);
      })
      .catch(e => { setFailed(e?.message || 'The challan could not be saved.'); setSaving(false); });
  };

  // The page wrapper keeps an entrance transform, which would measure a fixed overlay against
  // it instead of the window; the portal puts the box back under the viewport cap. The box is
  // dismissed by Cancel or the cross only — a keeper who clicks past the edge halfway through
  // counting a load must not lose the quantities he typed, and no other box in the app closes
  // that way either.
  return createPortal(
    <div className="fixed inset-0 bg-black/45 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div role="dialog" aria-label="Warehouse Dispatch Approval"
        className="bg-white rounded-lg shadow-xl w-full max-w-3xl overflow-hidden border border-gray-200 flex flex-col max-h-[88vh]">

        <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5 min-w-0">
            <span className="mt-0.5 w-8 h-8 shrink-0 rounded-lg bg-[#2ec4b6]/15 text-[#1f8c82] grid place-items-center">
              <Boxes className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <h3 className="text-sm font-black text-gray-900 leading-tight">Warehouse Dispatch Approval</h3>
              <p className="text-[11px] text-gray-600 mt-0.5">
                {doc
                  ? <><b className="text-emerald-700">{doc.number}</b> · Customer: {doc.partyName || '—'} · Location: {doc.warehouseName || '—'}</>
                  : 'Reading the challan...'}
              </p>
            </div>
          </div>
          <button onClick={() => onClose()} title="Close" className="text-gray-400 hover:text-gray-700 p-1 rounded shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-2.5 bg-emerald-50 border-b border-emerald-100">
          <div className="text-[11px] font-black uppercase tracking-wider text-emerald-800">Warehouse Verification Mode</div>
          <p className="text-[11px] text-emerald-900/80 mt-0.5">
            Enter in <b>Sending Now</b> how many units are actually being loaded onto the truck.
            Whatever the paper carries and is not going out files its own challan when you save.
          </p>
        </div>

        <div className="p-4 overflow-y-auto app-scroll text-xs">
          {failed && (
            <p className="mb-3 text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{failed}</p>
          )}

          {!!rows.length && (
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <span className="text-[11px] font-black uppercase tracking-wider text-gray-600">Items Fulfilment List</span>
              <div className="flex items-center gap-1.5">
                <button type="button" onClick={sendAll}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-emerald-300 bg-emerald-50 text-emerald-700 text-[11px] font-bold hover:bg-emerald-100">
                  <Check className="w-3 h-3" />
                  <span>Send All Items (100%)</span>
                </button>
                <button type="button" onClick={holdAll}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-amber-300 bg-amber-50 text-amber-700 text-[11px] font-bold hover:bg-amber-100">
                  <PauseCircle className="w-3 h-3" />
                  <span>Hold All (0 Sent)</span>
                </button>
              </div>
            </div>
          )}

          {!doc && !failed && (
            <div className="h-24 rounded bg-gray-100 animate-pulse" />
          )}

          {!!doc && !rows.length && (
            <p className="text-gray-600 bg-gray-50 border border-gray-200 rounded px-3 py-3">
              This challan has no product lines on it, so there is nothing to count. The goods
              stay against the bill — a challan is filed when the bill is approved, and a blank
              paper like this one carries nothing out of the gate.
            </p>
          )}

          {!!rows.length && (
            <div className="border border-gray-200 rounded overflow-hidden">
              <table className="xenith-table">
                <thead>
                  <tr className="bg-gray-50 text-[10px] uppercase tracking-wider text-gray-500">
                    <th className="w-[6%] text-center">S#</th>
                    <th className="w-[18%]">Code</th>
                    <th>Product Description</th>
                    <th className="w-[12%] text-right">Ordered Qty</th>
                    <th className="w-[16%] text-right">Sending Now</th>
                    <th className="w-[14%] text-right">Holding (Rest)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {rows.map((r, i) => {
                    const s = sendOf(r);
                    const held = roundMoney(r.ordered - s);
                    return (
                      <tr key={r.id} className="align-top">
                        <td className="text-center text-gray-500 font-bold tabular-nums">{i + 1}</td>
                        <td className="font-mono text-[11px] text-gray-600 break-all">{r.sku || '—'}</td>
                        <td>
                          <div className="font-bold text-gray-800">{r.productName || '—'}</div>
                          {r.warehouseName && <div className="text-[10px] text-gray-500">{r.warehouseName}</div>}
                        </td>
                        <td className="text-right font-bold text-gray-700 tabular-nums">{num(r.ordered)} {r.unit}</td>
                        <td>
                          <input type="number" min="0" max={r.ordered}
                            className="input-xenith text-right font-bold" value={String(sending[r.id] ?? s)}
                            onChange={e => setSend(r, Number(e.target.value))}
                            onBlur={() => setSend(r, s)} />
                        </td>
                        <td className={`text-right font-black tabular-nums ${held > 0 ? 'text-amber-700' : 'text-emerald-600'}`}>
                          {held > 0 ? `${num(held)} ${r.unit}` : `0 (All Sent)`}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50 text-[11px] font-black uppercase tracking-wide text-gray-700">
                    <td colSpan={3} className="px-3 py-2">
                      {rows.length} item{rows.length === 1 ? '' : 's'} on this paper
                    </td>
                    <td className="text-right py-2 tabular-nums">{num(orderTotal)}</td>
                    <td className="text-right py-2 tabular-nums text-emerald-700">{num(sendTotal)}</td>
                    <td className="text-right py-2 tabular-nums text-amber-700">{num(heldTotal)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          {heldTotal > 0 && !!rows.length && (
            <p className="mt-2 text-[11px] text-gray-600">
              The <b>{num(heldTotal)}</b> held back does not stay a figure on{' '}
              <b>{doc?.sourceNumber || doc?.orderNumber || 'the bill'}</b>: saving this paper files it
              as its own challan under the same bill, waiting in this folder for the next truck.
            </p>
          )}
          {emptied && (
            <p className="mt-2 text-[11px] font-bold text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">
              Nothing is going out on this paper. Write at least one line onto the truck, or leave the
              challan as it stands — an empty challan would carry off the bill's hold and deliver nothing.
            </p>
          )}

          {/* Transport is the watchman's question at the gate, so it is asked here rather than
              sent back to the bill. Only a vehicle and a driver — no third answer exists. */}
          {!!rows.length && (
            <div className="mt-4">
              <button type="button" onClick={() => setTransportShown(v => !v)}
                className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-gray-600 hover:text-gray-900">
                <UserRound className="w-3.5 h-3.5" />
                <span>Add Custom Driver Details</span>
                <span className={`transition-transform ${transportShown ? 'rotate-180' : ''}`}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </span>
              </button>
              {transportShown && (
                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-[11px] font-bold text-gray-600 flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-gray-400" /> Vehicle / Transport Service
                    </span>
                    <input className="input-xenith mt-1" placeholder="e.g. CH-BA-1234 · Karachi Road"
                      value={vehicle} onChange={e => setVehicle(e.target.value)} />
                  </label>
                  <label className="block">
                    <span className="text-[11px] font-bold text-gray-600">Driver</span>
                    <input className="input-xenith mt-1" placeholder="Name and phone of the man at the wheel"
                      value={driver} onChange={e => setDriver(e.target.value)} />
                  </label>
                </div>
              )}
              {!transportShown && (
                <p className="mt-1 text-[11px] text-gray-500">
                  {vehicle || driver
                    ? <>Carrying <b>{vehicle || 'no vehicle'}</b>{driver ? <> · driver <b>{driver}</b></> : ''} — the gate pass prints it.</>
                    : 'No transport written on this paper — the goods are being handed over at the counter.'}
                </p>
              )}
            </div>
          )}

          {/* The note the keeper leaves on the paper: this box is the challan's only writing
              surface now, so the remarks that used to live on its form are asked here. */}
          {!!doc && (
            <label className="block mt-4">
              <span className="text-[11px] font-bold text-gray-600">Remarks</span>
              <textarea rows={2} className="input-xenith mt-1"
                placeholder="Anything the gate or the customer should read on this load"
                value={remarks} onChange={e => setRemarks(e.target.value)} />
            </label>
          )}
        </div>

        <div className="px-4 py-3 border-t border-gray-200 bg-gray-50 flex flex-wrap items-center justify-between gap-2">
          <span className="text-[11px] text-gray-500">
            Saving writes the quantities on the challan. An administrator signs the load out; the gate pass
            stays locked until then.
          </span>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => onClose()} className="btn-xenith-outline">
              <span>Cancel</span>
            </button>
            <button type="button" onClick={save} disabled={!doc || !rows.length || emptied || saving}
              className="btn-xenith-success disabled:opacity-50 disabled:cursor-not-allowed">
              <Check className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Confirm & Save Dispatch'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
