import React, { useEffect, useState } from 'react';
import { AlertCircle, Plus, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { AgingBand, getAgingBuckets, saveAgingBuckets } from '../../services/reports.service';

interface Props { onClose: () => void; onSaved: () => void }

interface BandRow { from: string; to: string }

// Every aged report prints its column heading off the band's own numbers, so the settings
// screen shows those same words rather than a name the reports would never read.
const caption = (r: BandRow) => (r.to === '' ? `${r.from || 0}+ Days` : `${r.from || 0} to ${r.to} Days`);
const toText = (b: AgingBand): BandRow => ({ from: String(b.from), to: b.to === null ? '' : String(b.to) });

// The last band always runs to infinity — every aged report needs a column the oldest
// money can land in — so its "To" is cleared.
const normalise = (rows: BandRow[]) => rows.map((r, i) => (i === rows.length - 1 ? { ...r, to: '' } : r));

export const AgingBucketsModal: React.FC<Props> = ({ onClose, onSaved }) => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<BandRow[]>([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAgingBuckets(tenantSlug, branchId)
      .then(b => setRows(normalise(b.map(toText))))
      .catch(e => setError(String(e)))
      .finally(() => setLoading(false));
  }, [tenantSlug, branchId]);

  const patch = (i: number, changes: Partial<BandRow>) =>
    setRows(prev => normalise(prev.map((r, j) => (j === i ? { ...r, ...changes } : r))));

  const addBand = () => setRows(prev => {
    const last = prev[prev.length - 1];
    const from = last ? (Number(last.to) || Number(last.from)) + 1 : 0;
    // The band that was open-ended now stops where the new one starts.
    return normalise([...prev.map((r, i) => (i === prev.length - 1 ? { ...r, to: String(from - 1) } : r)),
      { from: String(from), to: '' }]);
  });

  const save = async () => {
    setError('');
    const norm = normalise(rows);
    // Two open-ended bands would leave the later one dead: a document lands in the first band
    // that covers its age, so the ask is stopped here rather than saved into a silent hole.
    const open = norm.findIndex((r, i) => r.to === '' && i !== norm.length - 1);
    if (open >= 0) { setError(`Only the last band may run without an upper limit — give day ${norm[open].from} onwards a "To"`); return; }
    setSaving(true);
    try {
      const bands: AgingBand[] = norm.map(r => ({
        label: caption(r),
        from: Number(r.from),
        to: r.to === '' ? null : Number(r.to)
      }));
      await saveAgingBuckets(tenantSlug, branchId, bands);
      onSaved();
      onClose();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 animate-[fadeUp_.2s_ease-out_backwards]">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[calc(100vh-2rem)] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
          <div>
            <h2 className="card-title">Configure Aging Buckets</h2>
            <p className="text-[11px] text-gray-400">Bands apply to every aged receivable, payable and stock-aging report.</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-4">
          {loading ? (
            <p className="text-xs text-gray-400 py-6 text-center">Loading bands…</p>
          ) : (
            <table className="xenith-table">
              <thead>
                <tr><th>Band</th><th className="text-right">From (days)</th><th className="text-right">To (days)</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i}>
                    <td className="text-[11px] font-bold text-gray-700 whitespace-nowrap">{caption(r)}</td>
                    <td className="text-right">
                      <input type="number" value={r.from} min={0} onChange={e => patch(i, { from: e.target.value })}
                        className="input-xenith !w-20 text-right tabular-nums" />
                    </td>
                    <td className="text-right">
                      {i === rows.length - 1 && r.to === ''
                        ? <span className="text-[11px] text-gray-400 whitespace-nowrap">no limit</span>
                        : <input type="number" value={r.to} min={0} onChange={e => patch(i, { to: e.target.value })}
                            className="input-xenith !w-20 text-right tabular-nums" />}
                    </td>
                    <td>
                      <button onClick={() => setRows(prev => normalise(prev.filter((_, j) => j !== i)))} disabled={rows.length <= 1}
                        className="text-gray-300 hover:text-red-500 disabled:opacity-30"><Trash2 className="w-3.5 h-3.5" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          <button onClick={addBand} className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-[#1e88e5] hover:underline">
            <Plus className="w-3 h-3" /> Add band
          </button>
        </div>

        {/* The band list scrolls, so a rejection has to sit outside it or it is never seen. */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-gray-100">
          {error && (
            <p className="mr-auto flex items-center gap-1.5 text-[11px] font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" /> {error}
            </p>
          )}
          <button onClick={onClose} className="btn-xenith-outline">Cancel</button>
          <button onClick={save} disabled={saving || loading} className="btn-xenith-success disabled:opacity-50">
            {saving ? 'Saving…' : 'Save and Refresh'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgingBucketsModal;
