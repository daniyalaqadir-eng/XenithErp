import React, { useState, useEffect } from 'react';
import { ProductBreakupItem } from '../../types';
import { X, Plus, Trash2 } from 'lucide-react';

interface ProductBreakupModalProps {
  isOpen: boolean;
  onClose: (items?: ProductBreakupItem[]) => void;
  documentNumber?: string;
  targetQuantity: number;
  initialItems?: ProductBreakupItem[];
}

export const ProductBreakupModal: React.FC<ProductBreakupModalProps> = ({
  isOpen,
  onClose,
  documentNumber = 'PO-1001',
  targetQuantity,
  initialItems = []
}) => {
  const [items, setItems] = useState<ProductBreakupItem[]>(initialItems);
  const [packagingId, setPackagingId] = useState(1001);
  const [packagingNumber, setPackagingNumber] = useState('');
  const [vsize, setVsize] = useState<number>(0);
  const [vqty, setVqty] = useState<number>(0);
  const [isPartiallyBreakup] = useState(false);

  useEffect(() => {
    if (initialItems && initialItems.length > 0) {
      const extracted = initialItems.map(item => {
        const match = item.packagingId.match(/\[(\d+)\]/);
        return match ? parseInt(match[1], 10) : 1000;
      });
      const nextId = Math.max(...extracted) + 1;
      setPackagingId(nextId);
      setPackagingNumber(`${documentNumber}[${nextId}]`);
      setItems(initialItems);
    } else {
      setPackagingNumber(`${documentNumber}[${packagingId}]`);
    }
  }, [isOpen, documentNumber]);

  if (!isOpen) return null;

  const breakupAmount = items.reduce((sum, item) => {
    const q = item.saleQty && item.saleQty > 0 ? item.saleQty : item.qty;
    return sum + q * item.size;
  }, 0);

  const remainingAmount = targetQuantity - breakupAmount;
  const isExceeded = breakupAmount > targetQuantity;
  const isMatched = breakupAmount === targetQuantity;

  const handleGenerateNext = () => {
    const nextId = packagingId + 1;
    setPackagingId(nextId);
    setPackagingNumber(`${documentNumber}[${nextId}]`);
  };

  const handleAddBreakup = () => {
    if (vqty <= 0 || vsize <= 0 || !packagingNumber) return;

    const newItem: ProductBreakupItem = {
      id: Date.now(),
      packagingId: packagingNumber,
      size: Number(vsize),
      qty: Number(vqty)
    };

    setItems([...items, newItem]);
    setVqty(0);
    setVsize(0);
    handleGenerateNext();
  };

  const handleDelete = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl overflow-hidden border border-gray-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
          <span className="font-semibold text-gray-800 text-sm">Product Packaging Breakup</span>
          <button
            onClick={() => onClose()}
            className="text-gray-400 hover:text-gray-600 p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 max-h-[70vh] overflow-y-auto text-xs">
          {/* Summary Status Banner */}
          <div className="flex justify-end items-center gap-4 mb-3 text-xs">
            <div>
              <span className="font-bold text-gray-700">Target Qty: </span>
              <span>{targetQuantity.toLocaleString()}</span>
            </div>
            <div>
              <span className="font-bold text-gray-700">Break up: </span>
              <span className="font-semibold">{breakupAmount.toLocaleString()}</span>
            </div>
            <div
              className={`px-2 py-0.5 rounded font-bold ${
                isMatched
                  ? 'bg-emerald-100 text-emerald-700'
                  : isExceeded
                  ? 'bg-red-100 text-red-700'
                  : 'bg-amber-100 text-amber-700'
              }`}
            >
              Remaining: {remainingAmount.toLocaleString()}
            </div>
          </div>

          <hr className="border-gray-100 mb-4" />

          {/* Packaging Input Row */}
          <div className="grid grid-cols-12 gap-3 mb-4 items-end bg-gray-50 p-3 rounded border border-gray-100">
            <div className="col-span-5">
              <label className="block text-gray-600 font-medium mb-1">Packaging Number</label>
              <div className="flex">
                <input
                  type="text"
                  value={packagingNumber}
                  onChange={e => setPackagingNumber(e.target.value)}
                  className="w-full border border-gray-300 rounded-l px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleGenerateNext}
                  title="Generate next ID"
                  className="bg-[#2ec4b6] hover:bg-[#25a195] text-white px-2.5 rounded-r flex items-center justify-center transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="col-span-3">
              <label className="block text-gray-600 font-medium mb-1">Pack Size (Pcs)</label>
              <input
                type="number"
                value={vsize || ''}
                placeholder="e.g. 24"
                onChange={e => setVsize(Number(e.target.value))}
                className="w-full border border-gray-300 rounded px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-gray-600 font-medium mb-1">Qty (Packs)</label>
              <input
                type="number"
                value={vqty || ''}
                placeholder="e.g. 10"
                onChange={e => setVqty(Number(e.target.value))}
                className="w-full border border-gray-300 rounded px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="col-span-2">
              <button
                type="button"
                onClick={handleAddBreakup}
                disabled={!vqty || !vsize}
                className="w-full bg-[#2ec4b6] hover:bg-[#25a195] disabled:opacity-50 text-white py-1.5 rounded font-medium transition-colors"
              >
                Save
              </button>
            </div>
          </div>

          {/* Breakup Details Table */}
          <div className="border border-gray-200 rounded overflow-hidden">
            <table className="xenith-table">
              <thead>
                <tr>
                  <th>Packaging Number</th>
                  {isPartiallyBreakup && <th>Sales Qty</th>}
                  <th className="text-right">Pack Size</th>
                  <th className="text-right">Qty</th>
                  <th className="text-right">Total Units</th>
                  <th className="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="font-medium text-gray-900">{item.packagingId}</td>
                    {isPartiallyBreakup && (
                      <td>
                        <input
                          type="number"
                          value={item.saleQty || ''}
                          className="w-20 border rounded px-1.5 py-0.5 text-xs"
                          onChange={e => {
                            const val = Number(e.target.value);
                            const updated = [...items];
                            updated[idx].saleQty = val;
                            setItems(updated);
                          }}
                        />
                      </td>
                    )}
                    <td className="text-right">{item.size}</td>
                    <td className="text-right">{item.qty}</td>
                    <td className="text-right font-semibold text-gray-800">
                      {((item.saleQty && item.saleQty > 0 ? item.saleQty : item.qty) * item.size).toLocaleString()}
                    </td>
                    <td className="text-right">
                      <button
                        onClick={() => handleDelete(idx)}
                        className="text-red-500 hover:text-red-700 p-1 rounded"
                        title="Delete Packaging"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-gray-400">
                      No packaging breakdown items added yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
          <button
            onClick={() => onClose()}
            className="btn-xenith-outline"
          >
            Cancel
          </button>
          <button
            onClick={() => onClose(items)}
            className="btn-xenith-primary"
          >
            Apply Breakdown
          </button>
        </div>
      </div>
    </div>
  );
};
