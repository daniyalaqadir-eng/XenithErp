import React, { useEffect, useRef, useState } from 'react';
import { Search, X } from 'lucide-react';

// One search box for every list screen: it waits for typing to settle before asking
// the server, and can be cleared without selecting the text.
export const SearchBox: React.FC<{
  placeholder: string; onSearch: (q: string) => void; className?: string; delay?: number
}> = ({ placeholder, onSearch, className = 'w-72 max-w-full', delay = 250 }) => {
  const [text, setText] = useState('');
  const emit = useRef(onSearch);
  emit.current = onSearch;
  useEffect(() => {
    const t = setTimeout(() => emit.current(text.trim().toLowerCase()), delay);
    return () => clearTimeout(t);
  }, [text, delay]);
  return (
    <span className={`relative inline-block ${className}`}>
      <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
      <input
        type="text"
        className="input-xenith !pl-7 !pr-7 w-full"
        placeholder={placeholder}
        value={text}
        onChange={e => setText(e.target.value)}
      />
      {text && (
        <button type="button" title="Clear search" onClick={() => setText('')}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </span>
  );
};

export default SearchBox;
