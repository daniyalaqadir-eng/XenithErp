import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown } from 'lucide-react';

export interface SelectOption {
  id: number;
  label: string;
  hint?: string;
}

interface SearchSelectProps {
  options: SelectOption[];
  value: number | null;
  onChange: (id: number | null) => void;
  placeholder?: string;
  invalid?: boolean;
  emptyMessage?: string;
}

const MAX_LIST_HEIGHT = 208;

// Widths are measured in the panel's own font, so the list is sized to the text it has to
// show rather than to the narrow field it dropped out of.
let measureCtx: CanvasRenderingContext2D | null | undefined;
const textWidth = (text: string, font: string) => {
  if (measureCtx === undefined) {
    const canvas = document.createElement('canvas');
    measureCtx = canvas.getContext('2d');
  }
  if (!measureCtx) return text.length * 7;
  measureCtx.font = font;
  return measureCtx.measureText(text).width;
};

export const SearchSelect: React.FC<SearchSelectProps> = ({
  options, value, onChange, placeholder = 'Type to search...', invalid = false, emptyMessage = 'No matches found'
}) => {
  const selected = options.find(o => o.id === value);
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState('');
  const [box, setBox] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const q = term.trim().toLowerCase();
  const filtered = q
    ? options.filter(o => o.label.toLowerCase().includes(q) || (o.hint || '').toLowerCase().includes(q))
    : options;

  // The list is painted into document.body because the tables that host this control clip
  // their own overflow, and an absolutely positioned panel inside them is simply cut off —
  // the row looked like it opened on nothing.
  useLayoutEffect(() => {
    if (!open) { setBox(null); return; }
    const place = () => {
      const r = wrapRef.current?.getBoundingClientRect();
      if (!r) return;
      const want = Math.min(MAX_LIST_HEIGHT, 34 + filtered.length * 30);
      const below = window.innerHeight - r.bottom - 8;
      const above = r.top - 8;
      const dropDown = below >= want || below >= above;
      const height = Math.max(60, Math.min(want, dropDown ? below : above));
      const raw = dropDown ? r.bottom + 4 : r.top - height - 4;
      // A field half out of reach can leave no room on either side, so the panel is
      // pulled back inside the window rather than hanging off it.
      const top = Math.max(8, Math.min(raw, window.innerHeight - height - 8));
      // px-3 each side (24) plus the gap between the name and its code.
      const font = (() => {
        const s = inputRef.current ? getComputedStyle(inputRef.current) : null;
        return s ? `12px ${s.fontFamily}` : '12px sans-serif';
      })();
      const need = filtered.reduce(
        (m, o) => Math.max(m, textWidth(o.label, font) + (o.hint ? textWidth(o.hint, font) + 12 : 0)),
        textWidth(placeholder, font)
      ) + 24;
      // Wide enough for the longest line and never narrower than the field it belongs to;
      // the window only caps it when the field itself is already that wide.
      const width = Math.max(r.width, Math.min(window.innerWidth - 16, Math.ceil(need)));
      const left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
      setBox({ top, left, width, height });
    };
    place();
    // Any scrolling ancestor (a dialog body, the page itself) has to move the panel with it.
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
    return () => {
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place);
    };
  }, [open, filtered.length, term]);

  useEffect(() => {
    const onDocDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (wrapRef.current?.contains(t) || listRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDocDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocDown);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const pick = (id: number | null) => {
    onChange(id);
    setTerm('');
    setOpen(false);
    inputRef.current?.blur();
  };

  return (
    <div ref={wrapRef} className="relative text-xs">
      <div className="flex items-center">
        <input
          ref={inputRef}
          type="text"
          className={`input-xenith ${invalid ? 'border-red-400 text-red-500 placeholder-red-400' : ''}`}
          style={{ borderTopRightRadius: 0, borderBottomRightRadius: 0 }}
          placeholder={!selected ? placeholder : selected.label}
          value={selected && !open ? '' : term}
          onFocus={() => setOpen(true)}
          onChange={e => {
            setTerm(e.target.value);
            setOpen(true);
          }}
        />
        <button
          type="button"
          tabIndex={-1}
          onClick={() => setOpen(o => !o)}
          className={`h-[30px] px-1.5 rounded-r border border-l-0 bg-white flex items-center ${invalid ? 'border-red-400' : 'border-gray-300'}`}
        >
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </button>
      </div>

      {open && box && createPortal(
        <div ref={listRef}
          className="fixed bg-white border border-gray-200 rounded shadow-lg z-[80] overflow-y-auto py-1 text-xs"
          // The panel is at least as wide as the field it dropped from, and grows to the
          // longest option instead of cutting a product name to "ERP …" — the whole point of
          // opening the list is to read what is in it. It only stops at the window edge.
          style={{ top: box.top, left: box.left, width: box.width, maxHeight: box.height }}>
          <button type="button" onClick={() => pick(null)}
            className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-400 whitespace-nowrap">
            {placeholder}
          </button>
          {filtered.map(o => (
            <button key={o.id} type="button" onClick={() => pick(o.id)}
              className={`w-full text-left px-3 py-1.5 hover:bg-blue-50 flex items-center gap-3 ${o.id === value ? 'font-bold text-blue-600' : 'text-gray-700'}`}>
              <span className="whitespace-nowrap">{o.label}</span>
              {o.hint && <span className="text-[10px] text-gray-400 whitespace-nowrap">{o.hint}</span>}
            </button>
          ))}
          {filtered.length === 0 && <div className="px-3 py-2 text-center text-gray-400">{emptyMessage}</div>}
        </div>,
        document.body
      )}
    </div>
  );
};
