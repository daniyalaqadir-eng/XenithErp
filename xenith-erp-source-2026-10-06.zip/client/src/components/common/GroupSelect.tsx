import React, { useState } from 'react';
import { Plus, Check, ChevronDown } from 'lucide-react';

interface GroupItem {
  id: number;
  name: string;
}

interface GroupSelectProps {
  groups: GroupItem[];
  value: number | null;
  onChange: (id: number | null) => void;
  groupType?: 'master' | 'detailA' | 'detailB';
  placeholder?: string;
  onAddNewGroup?: (name: string) => void;
}

export const GroupSelect: React.FC<GroupSelectProps> = ({
  groups,
  value,
  onChange,
  groupType = 'detailB',
  placeholder = '-Choose-',
  onAddNewGroup
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreatingInline, setIsCreatingInline] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');

  const selectedGroup = groups.find(g => g.id === value);
  const filteredGroups = groups.filter(g =>
    g.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getAddTagText = () => {
    if (groupType === 'master') return 'Add Master Group';
    if (groupType === 'detailA') return 'Add Detail A Group';
    if (groupType === 'detailB') return 'Add Detail B Group';
    return 'Add group';
  };

  const handleCreateNew = () => {
    if (!newGroupName.trim()) return;
    if (onAddNewGroup) {
      onAddNewGroup(newGroupName.trim());
    }
    setNewGroupName('');
    setIsCreatingInline(false);
    setIsOpen(false);
  };

  return (
    <div className="relative text-xs">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white border border-gray-300 rounded px-2.5 py-1.5 flex items-center justify-between hover:border-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500 text-left"
      >
        <span className={selectedGroup ? 'text-gray-800 font-medium' : 'text-gray-400'}>
          {selectedGroup ? selectedGroup.name : placeholder}
        </span>
        <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
      </button>

      {isOpen && (
        <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded shadow-lg z-50 overflow-hidden">
          {/* Search box */}
          <div className="p-1.5 border-b border-gray-100">
            <input
              type="text"
              placeholder="Type to search..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full border border-gray-200 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Group items list */}
          <div className="max-h-44 overflow-y-auto py-1">
            <button
              type="button"
              onClick={() => {
                onChange(null);
                setIsOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-500"
            >
              {placeholder}
            </button>
            {filteredGroups.map(g => (
              <button
                key={g.id}
                type="button"
                onClick={() => {
                  onChange(g.id);
                  setIsOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-50 flex items-center justify-between text-gray-700"
              >
                <span>{g.name}</span>
                {g.id === value && <Check className="w-3.5 h-3.5 text-blue-600" />}
              </button>
            ))}
            {filteredGroups.length === 0 && !isCreatingInline && (
              <div className="px-3 py-2 text-gray-400 text-center">No groups found</div>
            )}
          </div>

          {/* Inline Add New Group Button / Form */}
          <div className="p-1.5 border-t border-gray-100 bg-gray-50">
            {!isCreatingInline ? (
              <button
                type="button"
                onClick={() => {
                  setIsCreatingInline(true);
                  setNewGroupName(searchTerm);
                }}
                className="w-full text-left px-2 py-1 text-[#2ec4b6] hover:text-[#25a195] font-semibold flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{getAddTagText()}</span>
              </button>
            ) : (
              <div className="space-y-1">
                <input
                  type="text"
                  placeholder="New group name..."
                  value={newGroupName}
                  autoFocus
                  onChange={e => setNewGroupName(e.target.value)}
                  className="w-full border border-gray-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
                <div className="flex justify-end gap-1">
                  <button
                    type="button"
                    onClick={() => setIsCreatingInline(false)}
                    className="text-gray-500 hover:text-gray-700 px-2 py-0.5"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleCreateNew}
                    className="bg-[#2ec4b6] hover:bg-[#25a195] text-white px-2 py-0.5 rounded font-medium"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
