import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown, Search } from 'lucide-react';

export interface ComboOption { value: string; label: string }

const LIST_MAX = 250;
const SEARCH_ROW = 35;
const ROW = 28;

// The panel is painted into document.body: the tables and plates that host these fields
// clip their own overflow, and an absolutely positioned list inside one is simply cut off.
let measureCtx: CanvasRenderingContext2D | null | undefined;
const textWidth = (text: string, font: string) => {
  if (measureCtx === undefined) {
    const canvas = document.createElement('canvas');
    measureCtx = canvas.getContext('2d');
  }
  if (!measureCtx) return text.length * 7;
  measureCtx.font = font;
  return measureCtx.measureText(text).width;
};

/**
 * A dropdown that searches while you type. Used wherever a field lists records — customers,
 * accounts, warehouses — and scrolling to the one name the user came for is the whole job.
 *
 * Given `onToggle` it becomes a tick list instead: every row carries a checkbox, the panel
 * stays open while they are marked, and the ask is several records at once. That is a report
 * filter, where "these three customers" is a question worth asking; a field on a paper still
 * takes one party, so it keeps the plain single pick.
 */
export const ComboSelect: React.FC<{
  options: ComboOption[];
  value?: string;
  onPick?: (value: string) => void;
  selected?: string[];
  onToggle?: (value: string) => void;
  onClearAll?: () => void;
  allLabel?: string;
  placeholder?: string;
  searchPlaceholder?: string;
  disabled?: boolean;
  title?: string;
  ariaLabel?: string;
  className?: string;
}> = ({
  options, value = '', onPick, selected = [], onToggle, onClearAll, allLabel,
  placeholder = '—', searchPlaceholder = 'Type to search...',
  disabled = false, title, ariaLabel, className = ''
}) => {
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState('');
  const [at, setAt] = useState(0);
  const [box, setBox] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const multi = !!onToggle;
  const on = (v: string) => (multi ? selected.includes(v) : v === value);
  const chosen = options.find(o => o.value === value);
  const q = term.trim().toLowerCase();
  const rows = q ? options.filter(o => o.label.toLowerCase().includes(q)) : options;
  // The "All Customers" line is the way out of a tick list, so it sits above the records and
  // takes part in the arrow keys like any other row.
  const items: ComboOption[] = multi && allLabel ? [{ value: '', label: allLabel }, ...rows] : rows;
  const nameOf = (v: string) => options.find(o => o.value === v)?.label ?? v;
  const shown = multi
    ? selected.length === 0
      ? allLabel ?? placeholder
      : selected.length === 1
        ? nameOf(selected[0])
        : `${selected.length} selected`
    : chosen?.label ?? (value || placeholder);
  // "3 selected" has to say which three to whoever hovers it.
  const hover = multi && selected.length ? selected.map(nameOf).join(', ') : title;

  useLayoutEffect(() => {
    if (!open) { setBox(null); return; }
    const place = () => {
      const r = wrapRef.current?.getBoundingClientRect();
      if (!r) return;
      const want = SEARCH_ROW + Math.min(LIST_MAX - SEARCH_ROW, ROW * (items.length + 1));
      const below = window.innerHeight - r.bottom - 8;
      const above = r.top - 8;
      const dropDown = below >= want || below >= above;
      const height = Math.max(SEARCH_ROW + ROW, Math.min(want, dropDown ? below : above));
      const raw = dropDown ? r.bottom + 4 : r.top - height - 4;
      const top = Math.max(8, Math.min(raw, window.innerHeight - height - 8));
      // A company name longer than the field must still be readable — that is the entire
      // reason the list was opened — so the panel grows to its longest line.
      const font = (() => {
        const s = wrapRef.current ? getComputedStyle(wrapRef.current) : null;
        return s ? `12px ${s.fontFamily}` : '12px sans-serif';
      })();
      const need = Math.max(
        textWidth(searchPlaceholder, font) + 44,
        items.reduce((m, o) => Math.max(m, textWidth(o.label, font)), 0) + (multi ? 62 : 40)
      );
      const width = Math.max(r.width, Math.min(window.innerWidth - 16, Math.ceil(need)));
      const left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
      setBox({ top, left, width, height });
    };
    place();
    // Any scrolling ancestor — a dialog body, the page — has to carry the panel with it.
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
    return () => {
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place);
    };
  }, [open, items.length, term, options, searchPlaceholder, allLabel, selected.length]);

  useEffect(() => {
    if (!open) return;
    setAt(Math.max(0, items.findIndex(o => on(o.value))));
    searchRef.current?.focus();
    const onDocDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (wrapRef.current?.contains(t) || listRef.current?.contains(t)) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', onDocDown);
    return () => document.removeEventListener('mousedown', onDocDown);
    // The list is re-anchored by the layout effect above; this one only wires the dismiss.
  }, [open]);

  const hit = (v: string) => {
    if (!multi) {
      onPick?.(v);
      setTerm('');
      setOpen(false);
      return;
    }
    // Marking a row is not answering the question yet, so the panel stays where it is and the
    // typed search stays with it — tick Akbar, type Shah, tick Faheem, close it once.
    if (v === '') onClearAll?.();
    else onToggle!(v);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') { setOpen(false); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); setAt(i => Math.min(i + 1, items.length - 1)); return; }
    if (e.key === 'ArrowUp') { e.preventDefault(); setAt(i => Math.max(i - 1, 0)); return; }
    if (e.key === 'Enter') {
      e.preventDefault();
      const row = items[at] ?? items[0];
      if (row) hit(row.value);
    } else if (e.key === 'Tab' && multi) {
      setOpen(false);
    }
  };

  return (
    <div ref={wrapRef} className="relative">
      <div
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-expanded={open}
        aria-label={ariaLabel}
        aria-disabled={disabled || undefined}
        title={hover}
        onClick={() => !disabled && setOpen(o => !o)}
        onKeyDown={e => {
          if (disabled) return;
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(o => !o); }
        }}
        className={`combo-trigger input-xenith flex items-center justify-between gap-1.5 ${
          disabled ? 'cursor-not-allowed' : 'cursor-pointer'} ${open ? '!border-[var(--accent)]' : ''} ${className}`}
      >
        <span className={`truncate ${chosen || selected.length ? '' : 'text-gray-400'}`}>{shown}</span>
        <ChevronDown className="w-3.5 h-3.5 shrink-0 text-gray-400" />
      </div>

      {open && box && createPortal(
        <div ref={listRef} className="combo-panel fixed z-[80]"
          style={{ top: box.top, left: box.left, width: box.width, height: box.height }}>
          <div className="combo-search">
            <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
            <input ref={searchRef} value={term} placeholder={searchPlaceholder}
              onChange={e => { setTerm(e.target.value); setAt(0); }} onKeyDown={onKey} />
          </div>
          <div className="combo-list">
            {items.map((o, i) => {
              const isAll = multi && o.value === '';
              const ticked = isAll ? selected.length === 0 : on(o.value);
              return (
                <button key={o.value || '—all—'} type="button" data-at={i === at ? '1' : undefined}
                  data-on={ticked ? '1' : undefined}
                  onMouseEnter={() => setAt(i)} onClick={() => hit(o.value)}
                  className="combo-row">
                  <span className="flex items-center gap-2 min-w-0">
                    {multi && (
                      <span className="combo-box" data-on={ticked ? '1' : undefined} aria-hidden="true">
                        {ticked && <Check className="w-3 h-3" strokeWidth={3.5} />}
                      </span>
                    )}
                    <span className={`truncate ${isAll ? 'font-extrabold' : ''}`}>{o.label}</span>
                  </span>
                  {!multi && ticked && <Check className="w-3.5 h-3.5 shrink-0" />}
                </button>
              );
            })}
            {rows.length === 0 && (
              <div className="combo-empty">No match for &ldquo;{term}&rdquo;</div>
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};
