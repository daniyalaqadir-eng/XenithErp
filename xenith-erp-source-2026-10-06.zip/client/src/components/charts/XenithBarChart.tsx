import React, { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';

interface Dataset {
  label: string;
  data: number[];
  color: string;
  hoverColor?: string;
  fill?: boolean;
}

interface XenithBarChartProps {
  labels: string[];
  datasets: Dataset[];
  height?: number;
  currency?: string;
  title?: string;
  showTrendline?: boolean;
}

export const XenithBarChart: React.FC<XenithBarChartProps> = ({
  labels,
  datasets,
  height = 240,
  currency = 'PKR',
  title,
  showTrendline = false
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  // Two charts on one page must not share gradient ids, and a dataset label is free text that
  // cannot be an id, so the browser's own per-instance prefix is stripped down to carry them.
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const fillOf = (label: string) => `url(#dash-${uid}-${label.replace(/[^a-zA-Z0-9]/g, '')})`;
  const gradOf = (label: string) => `dash-${uid}-${label.replace(/[^a-zA-Z0-9]/g, '')}`;
  // The box is left mounted so it can fade, which means it needs something to show while
  // the pointer is between columns: the last column read carries it through the dissolve.
  const [tipIndex, setTipIndex] = useState(0);
  const enterGroup = (i: number) => { setTipIndex(i); setHoverIndex(i); };
  const [activeDatasets, setActiveDatasets] = useState<Record<string, boolean>>(() =>
    datasets.reduce((acc, d) => ({ ...acc, [d.label]: true }), {})
  );

  const toggleDataset = (label: string) => {
    setActiveDatasets(prev => ({ ...prev, [label]: !prev[label] }));
  };

  const visibleDatasets = datasets.filter(d => activeDatasets[d.label]);

  const maxVal = Math.max(
    ...visibleDatasets.flatMap(d => d.data),
    1000
  );

  // Round up maxVal to a nice clean number for scale
  const magnitude = Math.pow(10, Math.floor(Math.log10(maxVal)));
  const niceMax = Math.ceil(maxVal / magnitude) * magnitude;
  const tickCount = 4;
  const ticks = Array.from({ length: tickCount + 1 }, (_, i) => Math.round((niceMax / tickCount) * i));

  const chartPaddingTop = 20;
  const chartPaddingBottom = 30;
  const chartPaddingLeft = 55;
  const chartPaddingRight = 20;
  const plotRef = useRef<HTMLDivElement>(null);
  const [measuredWidth, setMeasuredWidth] = useState(0);
  const chartWidth = measuredWidth || 600;
  const plotHeight = height - chartPaddingTop - chartPaddingBottom;
  const plotWidth = chartWidth - chartPaddingLeft - chartPaddingRight;

  // The plot is drawn in its own pixel space, so its width has to be known. Measuring only
  // through ResizeObserver proved fragile: whenever that callback was throttled or missed, the
  // viewBox kept an old width and `h-auto` scaled the drawing up with it — a chart that grows
  // taller than its card and never stops. Re-measuring on every layout keeps it converging.
  const measure = () => {
    const w = Math.round(plotRef.current?.clientWidth ?? 0);
    if (w > 0) setMeasuredWidth(prev => (prev === w ? prev : w));
  };

  useLayoutEffect(measure);

  useEffect(() => {
    const el = plotRef.current;
    if (!el) return;
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    window.addEventListener('resize', measure);
    return () => {
      ro?.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, []);

  const getBarHeight = (val: number) => {
    return Math.max(2, (val / niceMax) * plotHeight);
  };

  const groupWidth = plotWidth / labels.length;
  const barCount = visibleDatasets.length;
  const barWidth = Math.min(22, (groupWidth * 0.7) / (barCount || 1));
  const barGap = 3;

  // A month view prints "Jan, Feb…", but "This Week"/"This Month" gives one bucket per day and
  // twenty-odd labels then print over each other. So a label is only drawn when its own width
  // fits its column, and the skipped days stay readable through the hover tooltip.
  const widestLabel = labels.length ? Math.max(...labels.map(l => String(l).length)) : 0;
  const labelStep = Math.max(1, Math.ceil((widestLabel * 5.8 + 8) / Math.max(groupWidth, 1)));

  return (
    <div className="w-full relative select-none">
      {/* Chart Header & Legend */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
        {title && <span className="font-bold text-gray-800 text-xs">{title}</span>}
        <div className="flex items-center gap-3 text-xs">
          {datasets.map(d => {
            const isActive = activeDatasets[d.label];
            return (
              <button
                key={d.label}
                type="button"
                onClick={() => toggleDataset(d.label)}
                className={`flex items-center gap-1.5 transition-opacity ${
                  isActive ? 'opacity-100 font-semibold' : 'opacity-40 line-through'
                }`}
              >
                <span
                  className="w-3 h-3 rounded-xs inline-block"
                  style={{ backgroundColor: d.color }}
                ></span>
                <span className="text-gray-700 text-[11px]">{d.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SVG Chart Container */}
      <div ref={plotRef} className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${chartWidth} ${height}`}
          width="100%"
          height={height}
          className="block overflow-visible"
        >
          {/* Each series fades toward the baseline: the column reads as one body of money
              rather than a flat block, and the tallest bar keeps its full colour at the top
              where the eye measures it. */}
          <defs>
            {datasets.map(d => (
              <linearGradient key={d.label} id={gradOf(d.label)} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={d.color} stopOpacity="1" />
                <stop offset="100%" stopColor={d.color} stopOpacity=".42" />
              </linearGradient>
            ))}
          </defs>

          {/* Y-Axis Gridlines and Labels */}
          {ticks.map(tick => {
            const y = chartPaddingTop + plotHeight - (tick / niceMax) * plotHeight;
            return (
              <g key={tick} className="text-[10px] text-gray-400 font-sans">
                <line
                  x1={chartPaddingLeft}
                  y1={y}
                  x2={chartWidth - chartPaddingRight}
                  y2={y}
                  stroke="var(--chart-grid)"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={chartPaddingLeft - 8}
                  y={y + 3}
                  textAnchor="end"
                  fill="var(--faint)"
                  fontSize="9"
                >
                  {tick >= 1000 ? `${(tick / 1000).toFixed(0)}k` : tick}
                </text>
              </g>
            );
          })}

          {/* Bar Groups */}
          {labels.map((lbl, groupIdx) => {
            const groupX = chartPaddingLeft + groupIdx * groupWidth;
            const groupCenterX = groupX + groupWidth / 2;
            const totalBarsWidth = barCount * barWidth + (barCount - 1) * barGap;
            const startX = groupCenterX - totalBarsWidth / 2;
            const isHovered = hoverIndex === groupIdx;

            return (
              <g
                key={lbl}
                onMouseEnter={() => enterGroup(groupIdx)}
                onMouseLeave={() => setHoverIndex(null)}
                className="cursor-pointer"
              >
                {/* Group background highlight. It stays mounted and fades, which also makes the
                    whole column a hit area — testing only the bars themselves made the tooltip
                    flicker as the pointer travelled across the plot. */}
                <rect
                  x={groupX + 2}
                  y={chartPaddingTop}
                  width={groupWidth - 4}
                  height={plotHeight}
                  fill="var(--hover)"
                  rx="4"
                  style={{ opacity: isHovered ? 1 : 0, transition: 'opacity .18s ease' }}
                />

                {/* Individual Bars for Each Dataset */}
                {visibleDatasets.map((dataset, dsIdx) => {
                  const val = dataset.data[groupIdx] || 0;
                  const bHeight = getBarHeight(val);
                  const x = startX + dsIdx * (barWidth + barGap);
                  const y = chartPaddingTop + plotHeight - bHeight;

                  return (
                    <rect
                      key={dataset.label}
                      x={x}
                      y={y}
                      width={barWidth}
                      height={bHeight}
                      fill={fillOf(dataset.label)}
                      rx="3"
                      className="hover:brightness-110"
                      style={{ transition: 'y .22s ease, height .22s ease, filter .15s ease' }}
                    />
                  );
                })}

                {/* X-Axis Label */}
                {groupIdx % labelStep === 0 && (
                <text
                  x={groupCenterX}
                  y={height - 8}
                  textAnchor="middle"
                  fill={isHovered ? 'var(--text)' : 'var(--muted)'}
                  fontSize="10"
                  style={{ transition: 'fill .18s ease' }}
                >
                  {lbl}
                </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Floating tooltip matching ngx-charts-tooltip-content from Chunk 2392 */}
        {(() => {
          const i = Math.min(tipIndex, labels.length - 1);
          // Anchoring every tooltip to its bar centre pushes the first and last months out of
          // the card, so the box changes side near the edges instead of spilling over them.
          const tipCenterPct = ((chartPaddingLeft + (i + 0.5) * groupWidth) / chartWidth) * 100;
          const shiftX = tipCenterPct > 70 ? '-100%' : tipCenterPct < 30 ? '0%' : '-50%';
          const on = hoverIndex !== null;
          return (
          <div
            className="absolute bg-slate-900/90 text-white rounded-md shadow-lg p-2.5 pointer-events-none text-xs z-30"
            style={{
              left: `${tipCenterPct}%`,
              top: '6px',
              transform: `translate(${shiftX}, ${on ? 0 : -4}px)`,
              opacity: on ? 1 : 0,
              transition: 'left .2s ease, transform .2s ease, opacity .16s ease'
            }}
          >
            <div className="font-bold border-b border-slate-700 pb-1 mb-1.5 text-[11px] text-slate-300">
              {labels[i]} Overview
            </div>
            {datasets.map(d => (
              <div key={d.label} className="flex items-center justify-between gap-3 text-[11px] py-0.5">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }}></span>
                  <span>{d.label}:</span>
                </span>
                <span className="font-mono font-bold">
                  {currency} {(d.data[i] || 0).toLocaleString()}
                </span>
              </div>
            ))}
            {datasets.length === 2 && (
              <div className="mt-1.5 pt-1 border-t border-slate-700 flex justify-between gap-3 text-[10px] text-emerald-400 font-bold">
                <span>Net Margin:</span>
                <span>
                  {currency}{' '}
                  {((datasets[0].data[i] || 0) - (datasets[1].data[i] || 0)).toLocaleString()}
                </span>
              </div>
            )}
          </div>
          );
        })()}
      </div>
    </div>
  );
};
