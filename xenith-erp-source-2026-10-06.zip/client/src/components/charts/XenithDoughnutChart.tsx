import React, { useState } from 'react';

interface XenithDoughnutChartProps {
  labels: string[];
  data: number[];
  colors: string[];
  height?: number;
  cutoutPercentage?: number;
  currency?: string;
  centerTitle?: string;
  centerValue?: string;
  reports?: (string | undefined)[];
  onReport?: (reportKey: string) => void;
}

export const XenithDoughnutChart: React.FC<XenithDoughnutChartProps> = ({
  labels,
  data,
  colors,
  height = 200,
  cutoutPercentage = 60,
  currency = 'PKR',
  centerTitle,
  centerValue,
  reports,
  onReport
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  // The centre readout crossfades instead of unmounting, so it keeps showing the slice the
  // pointer just left while that fade plays.
  const [tipIndex, setTipIndex] = useState(0);
  const enterSlice = (i: number) => { setTipIndex(i); setHoverIndex(i); };

  const total = data.reduce((acc, curr) => acc + curr, 0);
  const size = height;
  const center = size / 2;
  const radius = center - 12;
  const strokeWidth = (radius * (100 - cutoutPercentage)) / 100;
  const innerRadius = radius - strokeWidth / 2;

  // Calculate arc slices
  let cumulativeAngle = -Math.PI / 2; // Start from top
  const slices = data.map((val, idx) => {
    const angle = total > 0 ? (val / total) * 2 * Math.PI : 0;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + angle;
    cumulativeAngle = endAngle;

    const percentage = total > 0 ? ((val / total) * 100).toFixed(1) : '0';

    // SVG path for a donut segment
    const x1 = center + innerRadius * Math.cos(startAngle);
    const y1 = center + innerRadius * Math.sin(startAngle);
    const x2 = center + innerRadius * Math.cos(endAngle);
    const y2 = center + innerRadius * Math.sin(endAngle);

    const largeArcFlag = angle > Math.PI ? 1 : 0;

    return {
      label: labels[idx],
      value: val,
      percentage,
      color: colors[idx % colors.length],
      startAngle,
      endAngle,
      x1,
      y1,
      x2,
      y2,
      largeArcFlag
    };
  });

  return (
    <div className="flex flex-wrap items-center gap-4">
      {/* Donut SVG — capped to the card and, together with the legend below, the pair wraps
          into two rows when the card is too narrow to hold them side by side. */}
      <div className="relative shrink-0" style={{ width: size, maxWidth: '100%', aspectRatio: '1 / 1' }}>
        <svg width="100%" height="100%" viewBox={`0 0 ${size} ${size}`}>
          {total === 0 ? (
            <circle
              cx={center}
              cy={center}
              r={innerRadius}
              fill="transparent"
              stroke="var(--chart-grid)"
              strokeWidth={strokeWidth}
            />
          ) : (
            slices.map((slice, idx) => {
              const isHovered = hoverIndex === idx;
              // Arc stroke path
              const pathData = [
                `M ${slice.x1} ${slice.y1}`,
                `A ${innerRadius} ${innerRadius} 0 ${slice.largeArcFlag} 1 ${slice.x2} ${slice.y2}`
              ].join(' ');

              return (
                <path
                  key={idx}
                  d={pathData}
                  fill="transparent"
                  stroke={slice.color}
                  strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                  strokeLinecap="butt"
                  onMouseEnter={() => enterSlice(idx)}
                  onMouseLeave={() => setHoverIndex(null)}
                  className="cursor-pointer hover:brightness-110"
                  style={{
                    opacity: hoverIndex !== null && !isHovered ? 0.55 : 1,
                    transition: 'stroke-width .2s ease, opacity .2s ease, filter .15s ease'
                  }}
                />
              );
            })
          )}
        </svg>

        {/* Center Text — both readings are mounted and fade past each other */}
        <div className="absolute inset-0 pointer-events-none text-center p-2">
          <div className="h-full flex flex-col items-center justify-center"
            style={{ opacity: hoverIndex === null ? 1 : 0, transition: 'opacity .2s ease' }}>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
              {centerTitle || 'TOTAL'}
            </span>
            <span className="text-xs font-black text-gray-900 mt-0.5">
              {centerValue || `${currency} ${total.toLocaleString()}`}
            </span>
          </div>
          {!!slices[tipIndex] && (
          <div className="absolute inset-0 p-2 flex flex-col items-center justify-center"
            style={{ opacity: hoverIndex === null ? 0 : 1, transition: 'opacity .2s ease' }}>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider line-clamp-1">
              {slices[tipIndex].label}
            </span>
            <span className="text-xs font-black text-gray-900 mt-0.5">
              {slices[tipIndex].percentage}%
            </span>
            <span className="text-[10px] text-gray-500 font-mono">
              {currency} {slices[tipIndex].value.toLocaleString()}
            </span>
          </div>
          )}
        </div>
      </div>

      {/* The legend doubles as the switch: press a name to take its slice out of the ring */}
      <div className="flex-1 min-w-[9rem] basis-40 w-full space-y-1.5 text-xs">
        {slices.map((slice, idx) => {
          const isHovered = hoverIndex === idx;
          const report = reports?.[idx];
          return (
            <div
              key={idx}
              role={report ? 'button' : undefined}
              tabIndex={report ? 0 : undefined}
              onMouseEnter={() => enterSlice(idx)}
              onMouseLeave={() => setHoverIndex(null)}
              onClick={report && onReport ? () => onReport(report) : undefined}
              onKeyDown={report && onReport ? e => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onReport(report); }
              } : undefined}
              className={`flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 p-1.5 rounded transition-colors ${
                report ? 'cursor-pointer' : 'cursor-default'
              } ${isHovered ? 'bg-gray-100' : 'hover:bg-gray-50'}`}
            >
              <div className="flex items-center gap-2 min-w-0 flex-1 basis-24">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: slice.color }}
                ></span>
                <span className="font-medium text-gray-700 min-w-0 truncate" title={slice.label}>
                  {slice.label}
                </span>
              </div>
              <div className="flex items-center gap-2 font-mono shrink-0 ml-auto">
                <span className="text-gray-400 text-[10px] whitespace-nowrap">{slice.percentage}%</span>
                <span className="font-bold text-gray-800 text-[11px] whitespace-nowrap">
                  {slice.value.toLocaleString()}
                </span>
                {report && (
                  <span className={`text-[9px] font-sans font-bold uppercase tracking-wide whitespace-nowrap ${
                    isHovered ? 'text-[#25a195]' : 'text-gray-300'
                  }`}>
                    Report &rsaquo;
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
