import React, { useEffect, useMemo, useState } from 'react';
import { Check, Loader2, Star } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import {
  CompanyProfile, PrintTemplate, activateTemplate, createTemplate, getCompanyHub, getPrintingTemplates
} from '../../services/settings.service';
import {
  ACCENTS, FOOTER_OPTIONS, FONT_LINK, LETTERHEAD_OPTIONS, PAPER_OPTIONS, PRINT_THEMES, PrintPrefs, PrintTheme,
  ResolvedDesign, activeTemplateDesign, gridFooter, gridHeader, gridHeaderCss, loadPrintPrefs,
  paperOf, paperWord, resolveDesign, savePrintPrefs, themeCss
} from '../../utils/printDesigns';
import { ExportColumn } from '../../utils/exportTable';
import { downloadExcel } from '../../utils/exportExcel';

// ── the design picker ─────────────────────────────────────────────────────────
// The printed design lives here: the themes the engine knows, the company's saved templates
// for a surface, and a live preview of the real sheet markup. It is a panel on the Settings
// screen rather than a dialogue in front of every print — a sheet's look is decided once,
// not asked for again each time somebody presses PRINT.

const toPrefs = (t: PrintTemplate, base: PrintPrefs): PrintPrefs => ({
  ...base,
  theme: t.design?.theme || base.theme,
  accent: t.design?.accent || '',
  letterhead: (t.design?.letterhead as PrintPrefs['letterhead']) || base.letterhead,
  footer: (t.design?.footer as PrintPrefs['footer']) || base.footer,
  note: t.design?.note ?? base.note,
  pageNumber: t.design?.pageNumber ?? base.pageNumber,
  landscape: t.design?.landscape ?? base.landscape,
  paper: paperOf(t.paper) || ''
});

const toDesign = (p: PrintPrefs) => ({
  theme: p.theme, accent: p.accent, letterhead: p.letterhead, footer: p.footer,
  note: p.note, pageNumber: p.pageNumber, landscape: p.landscape
});

/** A surface's saved templates, matched loosely so a page title still finds its rows. */
const templatesFor = (all: PrintTemplate[], document: string) => {
  const key = document.trim().toLowerCase();
  return all.filter(t => {
    const d = t.document.trim().toLowerCase();
    return d === key || d.includes(key) || key.includes(d);
  });
};

const MiniSheet: React.FC<{ theme: PrintTheme; active: boolean }> = ({ theme, active }) => {
  const a = theme.accent;
  const bar = (w: string, i = 0) => (
    <div key={i} style={{ height: 3, width: w, background: i === 1 ? theme.rule : '#e5e7eb', borderRadius: 2, marginTop: 3 }} />
  );
  const head: Record<PrintTheme['header'], React.ReactNode> = {
    card: <div style={{ display: 'flex', gap: 3, alignItems: 'center', background: theme.band, border: `1px solid ${theme.rule}`,
      borderLeft: `3px solid ${a}`, borderRadius: theme.radius, padding: '3px 4px' }}>
      <div style={{ flex: 1 }}><div style={{ height: 4, width: '58%', background: theme.ink, borderRadius: 2 }} />{bar('80%')}</div>
      <div style={{ height: 4, width: 12, background: a, borderRadius: 2 }} />
    </div>,
    band: <div style={{ borderBottom: `2px solid ${a}`, paddingBottom: 3 }}>
      <div style={{ height: 4, width: '50%', background: theme.ink, borderRadius: 2 }} />{bar('74%')}
    </div>,
    hairline: <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderBottom: `1.5px solid ${a}`, paddingBottom: 3 }}>
      <div style={{ height: 4, width: 34, background: theme.ink, borderRadius: 2 }} />
      <div style={{ height: 3, width: 16, background: theme.muted, borderRadius: 2 }} />
    </div>,
    centered: <div style={{ textAlign: 'center', borderBottom: `2px solid ${a}`, paddingBottom: 3 }}>
      <div style={{ height: 4, width: '46%', background: theme.ink, borderRadius: 2, margin: '0 auto' }} />
      <div style={{ height: 3, width: '62%', background: theme.muted, borderRadius: 2, margin: '3px auto 0' }} />
    </div>,
    block: <div style={{ background: a, borderRadius: theme.radius, padding: '4px 5px', display: 'flex', justifyContent: 'space-between' }}>
      <div style={{ height: 4, width: 30, background: 'rgba(255,255,255,.9)', borderRadius: 2 }} />
      <div style={{ height: 4, width: 14, background: 'rgba(255,255,255,.55)', borderRadius: 2 }} />
    </div>,
    plain: <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: 3 }}>
      <div style={{ height: 4, width: 34, background: theme.ink, borderRadius: 2 }} />
      <div style={{ height: 3, width: 14, background: theme.muted, borderRadius: 2 }} />
    </div>
  };
  return (
    <div className={`rounded-md bg-white p-1.5 transition-shadow ${active ? 'ring-2' : 'border border-gray-200'}`}
      style={active ? { boxShadow: `0 0 0 2px ${a}` } : undefined}>
      <div style={{ minHeight: 58 }}>{head[theme.header]}</div>
      <div className="mt-1.5">{bar('100%', 0)}{bar('92%', 1)}{bar('88%', 0)}</div>
    </div>
  );
};

const sampleRows = [
  ['#', 'Particulars', '12', '48,000.00'],
  ['2', 'Lamin sheet, glossy', '40', '26,400.00'],
  ['3', 'Edge banding roll', '6', '9,750.00']
];

const previewHtml = (d: ResolvedDesign, company: Partial<CompanyProfile>, o: { title: string; subtitle?: string }) =>
  `<!doctype html><html><head><meta charset="utf-8">${FONT_LINK}<style>${themeCss(d)}${gridHeaderCss(d)}
   body{margin:18px}</style></head><body>
   ${gridHeader(d, { title: o.title, subtitle: o.subtitle, company })}
   <table><thead><tr><th>#</th><th>Particulars</th><th style="text-align:right">Qty</th><th style="text-align:right">Amount</th></tr></thead>
   <tbody>${sampleRows.map((r, i) => `<tr><td>${i === 0 ? '1' : r[0]}</td><td>${r[1]}</td>
     <td style="text-align:right">${r[2]}</td><td style="text-align:right">${r[3]}</td></tr>`).join('')}
   <tr class="total"><td></td><td>Total</td><td style="text-align:right">58</td><td style="text-align:right">84,150.00</td></tr>
   </tbody></table>
   ${gridFooter(d, { left: '3 record(s)', company })}
   </body></html>`;

const Field: React.FC<{ label: string; hint?: string; children: React.ReactNode }> = ({ label, hint, children }) => (
  <div>
    <div className="flex items-baseline justify-between gap-2">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">{label}</span>
      {hint && <span className="text-[10px] text-gray-400">{hint}</span>}
    </div>
    <div className="mt-1.5">{children}</div>
  </div>
);

const Chip: React.FC<{ on: boolean; onClick: () => void; label: string; note?: string }> = ({ on, onClick, label, note }) => (
  <button type="button" onClick={onClick} title={note}
    className={`px-2.5 py-1.5 rounded-lg border text-[12px] font-medium transition-colors ${
      on ? 'border-xenith-600 bg-xenith-50 text-xenith-700' : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:bg-gray-50'}`}>
    <span className="inline-flex items-center gap-1.5">{on && <Check className="w-3 h-3" />}{label}</span>
  </button>
);

interface PanelProps {
  /** The surface being designed for, e.g. 'Sale Invoice' — its saved templates list under it. */
  document: string;
  /** Shown on the sheet and in the preview. */
  title: string;
  subtitle?: string;
  /** Called after a template is saved, so a screen listing templates can refresh. */
  onSaved?: () => void;
}

/**
 * The design itself: the themes, the letterhead, the foot, and this surface's saved
 * templates, with the real sheet markup shrinking beside it. It lives on the Settings
 * screen, which is where a company decides what its paper looks like — a print is then one
 * click, not a dialogue in front of every sheet.
 */
export const PrintDesignPanel: React.FC<PanelProps> = ({ document, title, subtitle, onSaved }) => {
  const { tenantSlug, branchId } = useTenant();
  const [prefs, setPrefs] = useState<PrintPrefs>(() => loadPrintPrefs());
  const [company, setCompany] = useState<Partial<CompanyProfile>>({});
  const [templates, setTemplates] = useState<PrintTemplate[]>([]);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');

  const patch = (changes: Partial<PrintPrefs>) => setPrefs(p => ({ ...p, ...changes }));
  const design = useMemo(() => resolveDesign(prefs), [prefs]);

  const readTemplates = React.useCallback(
    () => getPrintingTemplates(tenantSlug, branchId)
      .then(r => setTemplates(r.templates ?? []))
      .catch(() => setTemplates([])),
    [tenantSlug, branchId]
  );

  useEffect(() => {
    getCompanyHub(tenantSlug, branchId).then(h => setCompany(h.profile ?? {})).catch(() => setCompany({}));
    readTemplates();
  }, [tenantSlug, branchId, readTemplates]);

  const mine = templatesFor(templates, document);
  const activeTemplate = mine.find(t => t.isActive);

  const use = async (t: PrintTemplate) => {
    setPrefs(toPrefs(t, prefs));
    setNotice(`Design taken from “${t.name}”.`);
    try { await activateTemplate(tenantSlug, branchId, t.id); readTemplates(); } catch { /* the design still applies */ }
  };

  const saveTemplate = async () => {
    const label = name.trim();
    if (!label) { setNotice('Give the template a name first.'); return; }
    setBusy(true);
    try {
      const created = await createTemplate(tenantSlug, branchId, {
        document, name: label, paper: paperWord(prefs.paper, prefs.landscape),
        description: PRINT_THEMES.find(t => t.key === prefs.theme)?.note ?? 'Saved from the print designer.',
        design: toDesign(prefs)
      });
      await readTemplates();
      setName('');
      setNotice(`“${created.name}” saved for ${document}.`);
      onSaved?.();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const saveDefault = () => {
    savePrintPrefs(prefs);
    setNotice('Saved. Everything that has no template of its own now prints in this design.');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_420px] gap-5">
      <div className="space-y-4 min-w-0">
        <Field label="Design" hint={design.theme.note}>
          <div className="grid grid-cols-3 gap-2">
            {PRINT_THEMES.map(t => (
              <button key={t.key} type="button" onClick={() => patch({ theme: t.key })}
                className="text-left rounded-lg p-1 bg-transparent border-0">
                <MiniSheet theme={t} active={t.key === prefs.theme} />
                <div className={`mt-1 text-[11px] font-semibold ${t.key === prefs.theme ? 'text-xenith-700' : 'text-gray-600'}`}>{t.name}</div>
              </button>
            ))}
          </div>
        </Field>

        <Field label="Brand colour">
          <div className="flex flex-wrap gap-1.5">
            <Chip on={!prefs.accent} onClick={() => patch({ accent: '' })} label="Design's own" />
            {ACCENTS.map(a => (
              <button key={a.value} type="button" title={a.name} onClick={() => patch({ accent: a.value })}
                className="w-7 h-7 rounded-full border-2 transition-transform hover:scale-110"
                style={{ background: a.value, borderColor: prefs.accent === a.value ? '#1d4ed8' : '#fff',
                  boxShadow: prefs.accent === a.value ? '0 0 0 2px #1d4ed8' : '0 0 0 1px #e5e7eb' }} />
            ))}
          </div>
        </Field>

        <Field label="Company letterhead" hint="what sits above the paper">
          <div className="flex flex-wrap gap-1.5">
            {LETTERHEAD_OPTIONS.map(o => (
              <Chip key={o.value} on={prefs.letterhead === o.value} onClick={() => patch({ letterhead: o.value })}
                label={o.label} note={o.note} />
            ))}
          </div>
        </Field>

        <Field label="Page foot" hint="what closes it">
          <div className="flex flex-wrap gap-1.5">
            {FOOTER_OPTIONS.map(o => (
              <Chip key={o.value} on={prefs.footer === o.value} onClick={() => patch({ footer: o.value })}
                label={o.label} note={o.note} />
            ))}
          </div>
          {(prefs.footer === 'note' || prefs.footer === 'both') && (
            <input value={prefs.note} onChange={e => patch({ note: e.target.value })}
              placeholder="Thank you for your business."
              className="input-xenith mt-2 text-[12px]" />
          )}
        </Field>

        <Field label="Sheet" hint="A4, A5 or the counter roll — the printer is fed what is picked here">
          <div className="flex flex-wrap gap-1.5">
            <Chip on={!prefs.paper} onClick={() => patch({ paper: '' })} label="As the screen chooses"
              note="A form with its own paper box, or a list that simply prints, decides." />
            {PAPER_OPTIONS.map(p => (
              <Chip key={p.value} on={prefs.paper === p.value} onClick={() => patch({ paper: p.value })}
                label={p.label} note={p.note} />
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5 mt-1.5">
            <Chip on={prefs.pageNumber} onClick={() => patch({ pageNumber: !prefs.pageNumber })} label="Page numbers" />
            <Chip on={prefs.landscape} onClick={() => patch({ landscape: !prefs.landscape })} label="Landscape"
              note="Turns an A4 or A5 sheet across the page; a roll has no other way to lie." />
          </div>
        </Field>

        <Field label="Saved templates" hint={activeTemplate ? `active: ${activeTemplate.name}` : `${mine.length} for this surface`}>
          {mine.length === 0 ? (
            <p className="text-[11.5px] text-gray-400">No template saved for {document} yet. Set the design below the way you want it and give it a name.</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {mine.map(t => (
                <Chip key={t.id} on={t.id === activeTemplate?.id} onClick={() => use(t)}
                  label={t.name} note={`${t.paper} · ${t.description}`} />
              ))}
            </div>
          )}
        </Field>

        <div className="flex items-end gap-2">
          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">New print template</span>
            <input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') saveTemplate(); }}
              placeholder={`e.g. ${document} — Final tax invoice`} className="input-xenith mt-1.5 text-[12px]" />
          </div>
          <button type="button" onClick={saveTemplate} disabled={busy}
            className="btn-xenith-outline flex items-center gap-1.5 disabled:opacity-50">
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Star className="w-3.5 h-3.5" />} SAVE TEMPLATE
          </button>
        </div>

        <div className="flex items-center gap-3 pt-1">
          <button type="button" onClick={saveDefault} className="btn-xenith-outline">SET AS DEFAULT</button>
          <span className="text-[11px] text-gray-500 truncate">{notice}</span>
        </div>
      </div>

      <div className="lg:sticky lg:top-0 self-start">
        <div className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Preview</div>
        <div className="mt-1.5 rounded-lg border border-gray-200 bg-gray-100 overflow-hidden" style={{ height: 372 }}>
          <iframe title="print-preview" frameBorder={0} srcDoc={previewHtml(design, company, { title, subtitle })}
            style={{ width: 794, height: 1123, transform: 'scale(0.52)', transformOrigin: 'top left', border: 0, background: '#fff' }} />
        </div>
        <p className="mt-1.5 text-[10.5px] text-gray-400 leading-snug">
          The preview is the real sheet markup, shrunk — what prints is exactly this.
        </p>
      </div>
    </div>
  );
};

// ── the buttons that print ───────────────────────────────────────────────────
// A print button puts paper on the printer. It does not open a dialogue first: the design
// a sheet prints in is the template the company saved for that surface in Settings, and a
// report that needs a different look asks for it where it is written.

/**
 * The design to print in right now: the saved default with the surface's active template
 * laid over it. Resolved when the button is pressed, never cached, so a design changed in
 * Settings lands on the very next sheet.
 */
export const usePrintDesign = (document: string) => {
  const { tenantSlug, branchId } = useTenant();
  return async (): Promise<PrintPrefs> =>
    ({ ...loadPrintPrefs(), ...(await activeTemplateDesign(tenantSlug, branchId, document)) });
};

interface MenuButtonProps {
  document: string;
  title: string;
  subtitle?: string;
  label?: React.ReactNode;
  className?: string;
  onPrint: (prefs: PrintPrefs) => void;
}

export const PrintMenuButton: React.FC<MenuButtonProps> = ({ document, label = 'PRINT', className, onPrint }) => {
  const designOf = usePrintDesign(document);
  return (
    <button type="button" onClick={() => designOf().then(onPrint)} className={className || 'btn-xenith-outline'}>{label}</button>
  );
};

interface ExcelButtonProps<T> {
  title: string;
  subtitle?: string;
  org?: string;
  filename: string;
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  landscape?: boolean;
  meta?: (string | undefined | false)[];
  printedBy?: string;
  rowClass?: (row: T) => string;
  label?: React.ReactNode;
  className?: string;
}

// A workbook is paper of another kind: the same design decides its header colour, so the
// branded sheet a screen prints is the branded sheet it exports. One press, one file.
export function ExcelMenuButton<T>({
  title, subtitle, org, filename, columns, rows, footer, landscape, meta, printedBy, rowClass,
  label = 'EXPORT TO EXCEL', className
}: ExcelButtonProps<T>) {
  return (
    <button type="button" className={className || 'btn-xenith-outline'}
      onClick={() => downloadExcel(filename, {
        title, subtitle, org, columns, rows, footer, style: 'branded', landscape, meta, printedBy, rowClass
      })}>{label}</button>
  );
}
