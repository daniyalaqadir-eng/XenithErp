import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { startClock } from './utils/clock';
import './index.css';

// The day is asked for before the first screen paints, so a new paper's Date box already
// holds today's real date instead of whatever the laptop claims. The wait has a ceiling
// inside startClock, so a server that is not answering cannot hold the app behind it.
void startClock().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
});
