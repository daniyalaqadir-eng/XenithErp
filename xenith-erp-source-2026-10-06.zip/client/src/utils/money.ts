// One rounding rule for money, shared by every screen that works a figure out before sending
// it. Money is rounded half up and away from zero, and on the decimal string rather than the
// product: 1.005 * 100 is 100.49999999999999 in binary, so a naive Math.round sends down a
// paisa a cashier carries up, and Math.round takes a negative half towards zero, which makes a
// refund of the same figure land on a different rupee than the sale it reversed. The server
// rounds by exactly this rule (roundMoney in server/src/money.ts), so the total a form shows is
// the total the books post.
export const roundMoney = (n: number): number => {
  const value = Number(n) || 0;
  const shifted = Number(`${Math.abs(value)}e2`);
  const cents = Number.isFinite(shifted) ? Math.round(shifted) : Math.round(Math.abs(value) * 100);
  return (value < 0 ? -cents : cents) / 100;
};
