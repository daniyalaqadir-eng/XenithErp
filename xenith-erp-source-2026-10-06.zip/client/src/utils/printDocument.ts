import { BizDoc, DocLine } from '../types';
import { roundMoney } from './money';
import { CompanyProfile } from '../services/settings.service';
import { esc } from './exportTable';
import {
  FONT_LINK, PrintPaper, PrintPrefs, ResolvedDesign, docFooter, docLetterhead, docSheetCss,
  fontsReady, resolveDesign, themeVars
} from './printDesigns';
import { amountInWords } from './amountInWords';

// Documents print on their own sheet, not as a flat grid: a letterhead, a band naming the
// paper, the party it is drawn on, the line breakdown, the totals and the signatures.
// One iframe carries as many sheets as there are documents, each on its own page.
export type Paper = PrintPaper;

const PAPER_SIZE: Record<Paper, string> = {
  A4: 'A4',
  A5: 'A5',
  // A thermal-style slip: narrow, and as tall as the content needs.
  Receipt: '80mm auto'
};

const money = (v: number) => (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const qty = (v: number) => (Number.isInteger(v) ? String(v) : String(Math.round((Number(v) || 0) * 1000) / 1000));

const sum = (values: (number | undefined)[]) => values.reduce<number>((s, v) => s + Number(v || 0), 0);

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

// A printed voucher dates itself the way a ledger reads: 22 Sept 2026, not 2026-09-22.
const longDate = (iso: string) => {
  const [y, m, d] = String(iso || '').split('-').map(Number);
  return y && m && d ? `${d} ${MONTHS[m - 1]} ${y}` : (iso || '');
};

const CASH_WORD: Record<string, string> = { PKR: 'Rs.', INR: 'Rs.', USD: 'US$', AED: 'AED', GBP: '£', EUR: '€' };

// Amounts on a sheet carry the sign the trade expects, not the currency code.
const cash = (v: number, currency: string) => `${CASH_WORD[currency] ?? currency} ${money(Number(v) || 0)}`;

const wordsOf = (v: number, currency: string) =>
  amountInWords(Number(v) || 0, currency === 'PKR' || currency === 'INR' ? 'Rupees' : currency);

// Stock can sit on each line of a document, leaving the header to say only that it pulled
// from more than one place.
const warehousesOf = (d: BizDoc) => {
  const names = [...new Set(d.lines.map(l => l.warehouseName).filter(Boolean))];
  return names.length ? names.join(', ') : (d.warehouseName && d.warehouseName !== 'Multiple warehouses' ? d.warehouseName : '');
};

// Tax is held once on the document while the sheet prints it line by line, so the header
// amount is shared out in proportion to each line's value and the last line absorbs the
// rounding that a split always leaves behind.
const taxShares = (tax: number, lines: DocLine[]) => {
  const base = sum(lines.map(l => l.amount));
  if (!tax || base <= 0) return lines.map(() => 0);
  let left = tax;
  return lines.map((l, i) => {
    if (i === lines.length - 1) return roundMoney(left);
    const share = roundMoney(tax * Number(l.amount || 0) / base);
    left -= share;
    return share;
  });
};

// The rate a document was taxed at, worked back from the tax it actually carries.
const taxRate = (tax: number, taxable: number) => {
  if (!tax || taxable <= 0) return '';
  const pct = Math.round((Number(tax) / taxable) * 10000) / 100;
  return pct ? ` (${pct}%)` : '';
};

// What the money actually came or went by: the tenders on the document, or the account
// the settlement posted to when no tender line was recorded.
const tendersOf = (d: BizDoc) => {
  const modes = [...new Set((d.paymentLines || []).map(p => p.paymentMode).filter(Boolean))];
  return modes.join(', ') || d.accountName || '';
};

// ---- the sheet vocabulary -------------------------------------------------------------
// Every kind of document is the same sheet with different words on it, so a form says
// which rows it wants and the renderer supplies the values, styling and page breaks.

export type SheetField =
  | 'partyName' | 'address' | 'warehouse' | 'toWarehouse' | 'adjustmentType' | 'salesPerson'
  | 'preparedBy' | 'approvedBy' | 'order' | 'against' | 'reference' | 'subject' | 'narration' | 'account' | 'toAccount'
  | 'gatePass' | 'vehicle' | 'driver'
  | 'dueDate' | 'receiptDate' | 'linkedInvoice' | 'settlement' | 'status';

// The money rows a form holds outside the document header have keys of their own.
export type SheetMetaKey = SheetField | 'date' | 'amount' | 'paymentMode';

// A row is a field key, or that key with the wording this form wants on it.
export type SheetCell<T extends string = SheetField> = T | [T, string];
export type SheetMeta = SheetCell<SheetMetaKey>;

// 'hand' is a signature line the paper leaves for a wet signature: a payment voucher's
// "Received By" is the person who took the money, and the voucher's one box names the head of
// the books instead, so nothing on the sheet can fill that line.
export type SheetSign = 'prepared' | 'approved' | 'party' | 'company' | 'salesPerson' | 'account' | 'hand';

export interface DocSheet {
  // Strip across the top of the page, e.g. "COMMERCIAL VOUCHER". Falls back to the heading
  // the caller passed, then to the document subject.
  band?: string;
  // Boxed rows under the band, three to a line.
  meta: SheetMeta[];
  // Left panel: the party the paper is drawn on. Omit it for a document with no party.
  party?: string;
  partyFields?: SheetCell[];
  // Right panel: where the goods, money or work went.
  detail?: string;
  fields?: SheetCell[];
  // priced = rate, discount and tax per line; plain = rate and amount only;
  // qty = stock moving without a price; none = a paper about money alone;
  // import = a line billed in the exporter's currency and costed in rupees.
  items?: 'priced' | 'plain' | 'qty' | 'none' | 'import';
  // Column that says where each line sits, on a stock sheet.
  whereLabel?: string;
  // goods = a bill a customer settles; order = priced goods that ask for no money yet;
  // credit = a reversal; amount = money moving; import = a bill whose goods are valued in
  // two currencies at once; none = the paper carries no total of its own.
  totals?: 'goods' | 'order' | 'credit' | 'amount' | 'import' | 'none';
  // What the document's own figure is called — 'Amount Received', 'Total Credit', 'Face
  // Value'. It names the boxed row and the written-figures strip under the lines.
  amountLabel?: string;
  // Spell out how the money came in and whether it cleared, above the totals.
  flags?: boolean;
  // Heading of the subject line at the foot of the sheet, which reads "Reason" on a credit
  // note and "Narration" on a stock movement.
  subjectLabel?: string;
  tenderLabel?: string;
  appliedLabel?: string;
  // The customs side of an import invoice: the declaration the goods cleared on, the duty the
  // assessment raised, and the landed cost each unit of goods ends up carrying.
  customsBlock?: boolean;
  signs: [label: string, from: SheetSign][];
  fine?: string;
}

const FIELD: Record<SheetField, { label: string; of: (d: BizDoc) => string }> = {
  partyName: { label: 'Account', of: d => d.partyName || '' },
  address: { label: 'Shipping Address', of: d => d.shippingAddress || '' },
  warehouse: { label: 'Warehouse', of: d => warehousesOf(d) },
  toWarehouse: { label: 'To Warehouse', of: d => d.toWarehouseName || '' },
  adjustmentType: { label: 'Adjustment Type', of: d => d.adjustmentTypeName || '' },
  salesPerson: { label: 'Sales Person', of: d => d.salesPersonName || '' },
  preparedBy: { label: 'Prepared By', of: d => d.createdByName || '' },
  approvedBy: { label: 'Approved By', of: d => d.approvedByName || '' },
  order: { label: 'Order / Challan', of: d => d.orderNumber || '' },
  // The paper this document was cut out of, named on the challan so the goods leaving the
  // warehouse are traceable to a bill that already exists.
  against: { label: 'Against', of: d => d.sourceNumber
    ? `${d.sourceNumber}${d.sourcePart ? ` (Part ${d.sourcePart})` : ''}` : '' },
  reference: { label: 'Reference', of: d => d.reference || '' },
  // The permit the load left the compound on, written once on the bill and repeated on
  // every challan of that consignment. An empty one leaves the row off the sheet.
  gatePass: { label: 'Gate Pass No', of: d => d.gatePass || '' },
  // What carries the load and who is at the wheel — the two lines the watchman checks
  // before the gate opens, and the reason a challan without them is only a wish.
  vehicle: { label: 'Vehicle / Transport', of: d => d.vehicle || '' },
  driver: { label: 'Driver', of: d => d.driver || '' },
  subject: { label: 'Subject', of: d => d.subject || '' },
  // What the money was for and who it came from or went to by hand — the story a voucher
  // tells once its single box has already named the head of the books.
  narration: { label: 'Narration', of: d => d.comments || '' },
  account: { label: 'Account', of: d => d.accountName || '' },
  toAccount: { label: 'To Account', of: d => d.toAccountName || '' },
  dueDate: { label: 'Due Date', of: d => longDate(d.dueDate || '') },
  receiptDate: { label: 'Receipt Date', of: d => longDate(d.receiptDate || '') },
  // A credit note that was raised off a picked bill names that bill — the real link, not the
  // reference someone typed. Only a general return with no bill behind it falls back to it.
  linkedInvoice: { label: 'Linked Invoice', of: d =>
    [...new Set((d.lines || []).map(l => l.sourceNumber).filter(Boolean))].join(', ')
    || d.reference || d.orderNumber || '' },
  settlement: {
    label: 'Settlement Method',
    of: d => Number(d.paymentAmount) > 0 ? `Settled via ${tendersOf(d) || 'Cash'}` : 'On Credit (Adjusted Against Ledger)'
  },
  status: { label: 'Document Status', of: d => d.status || '' }
};

const SIGN: Record<SheetSign, (d: BizDoc, c: Partial<CompanyProfile>) => string> = {
  prepared: d => d.createdByName || d.salesPersonName || '',
  approved: (d, c) => d.approvedByName || c.name || '',
  party: d => d.partyName || '',
  company: (d, c) => c.name || '',
  salesPerson: d => d.salesPersonName || '',
  account: d => d.accountName || '',
  hand: () => ''
};

const keyOf = (c: string | [string, string]) => (Array.isArray(c) ? c[0] : c);
const labelOf = (c: string | [string, string]) => (Array.isArray(c) ? c[1] : undefined);

// A boxed row reads its value from the document; an empty one leaves the row off the page
// so a conditional line never prints a gap.
const metaCell = (c: SheetMeta, d: BizDoc, cur: string, amountLabel = 'Amount'): [string, string] => {
  const key = keyOf(c);
  if (key === 'date') return [labelOf(c) ?? 'Date', longDate(d.date)];
  if (key === 'amount') return [labelOf(c) ?? amountLabel, Number(d.net) ? cash(d.net, cur) : ''];
  if (key === 'paymentMode') return [labelOf(c) ?? 'Payment Mode', tendersOf(d) || 'On Account'];
  const f = FIELD[key as SheetField];
  return [labelOf(c) ?? f.label, f.of(d)];
};

const rowsOf = <T,>(items: T[]) => {
  const rows: T[][] = [];
  for (let i = 0; i < items.length; i += 3) rows.push(items.slice(i, i + 3));
  return rows;
};

// The boxed rows under the band, three to a line.
const metaRows = (meta: SheetMeta[], d: BizDoc, cur: string, amountLabel: string) => {
  const cells = meta.map(c => metaCell(c, d, cur, amountLabel)).filter(([, v]) => v.trim());
  return rowsOf(cells).map(row => `<div class="mr">${row.map(([k, v]) =>
    `<div><span class="k">${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}</div>`).join('');
};

const kv = (k: string, v: string) =>
  `<div class="kv"><span>${esc(k)}</span><b>${esc(v.trim() || 'N/A')}</b></div>`;

// A figure in the totals block: `hi` marks the ones the reader checks twice, `wide` gives
// a line a row of its own so the two-column grid never falls out of step.
const cell = (k: string, v: string, hi = false, wide = false) =>
  `<div class="${hi ? 'hi ' : ''}${wide ? 'wide' : ''}"><span>${esc(k)}</span><b>${esc(v)}</b></div>`;

const bar = (title: string, number: string) =>
  `<div class="bar"><span>${esc(title)}</span><span class="num">${esc(number)}</span></div>`;

// The brand block itself is a design decision, not a sheet one: who the paper is from, and
// how much of them the chosen letterhead mode puts on it.
const lineUnit = (l: DocLine) => `${qty(Number(l.quantity))}${l.unit ? ` ${esc(l.unit)}` : ''}`;

const pricedItems = (lines: DocLine[], gst: number[], cur: string, rate: string) => {
  const net = lines.map((l, n) => Number(l.amount || 0) + (gst[n] || 0));
  return `
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>SKU</th><th>Item Description</th><th class="n">Quantity</th>
      <th class="n">Unit Rate</th><th class="n">Discount</th><th class="n">GST${esc(rate)}</th><th class="n">Net Total</th></tr></thead>
    <tbody>
      ${lines.map((l, n) => `<tr>
        <td class="c">${n + 1}</td>
        <td>${esc(l.sku || '—')}</td>
        <td>${esc(l.productName)}</td>
        <td class="n">${lineUnit(l)}</td>
        <td class="n">${cash(l.price, cur)}</td>
        <td class="n">${l.discountAmount ? cash(l.discountAmount, cur) : '—'}</td>
        <td class="n">${gst[n] ? cash(gst[n] || 0, cur) : '—'}</td>
        <td class="n">${cash(net[n] || 0, cur)}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td colspan="2">Total</td>
        <td class="n">${qty(sum(lines.map(l => l.quantity)))}</td>
        <td></td>
        <td class="n">${cash(sum(lines.map(l => l.discountAmount)), cur)}</td>
        <td class="n">${cash(sum(gst), cur)}</td>
        <td class="n">${cash(sum(net), cur)}</td></tr>
    </tbody>
  </table>`;
};

// A consignment is bought in one money and carried in another, so its goods rows say both: the
// rate and amount the exporter wrote, and what that came to when the rupees were bought at the
// rate on the declaration. The duty and the landed figures are not here — the band that closes
// the declaration says them, and says them once.
const importItems = (lines: DocLine[], cur: string) => `
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>SKU</th><th>Item Description</th><th class="n">Quantity</th>
      <th class="n">Rate (${esc(cur)})</th><th class="n">Discount (${esc(cur)})</th>
      <th class="n">Amount (${esc(cur)})</th><th class="n">Value (PKR)</th></tr></thead>
    <tbody>
      ${lines.map((l, n) => `<tr>
        <td class="c">${n + 1}</td>
        <td>${esc(l.sku || '—')}</td>
        <td>${esc(l.productName)}</td>
        <td class="n">${lineUnit(l)}</td>
        <td class="n">${cash(l.price, cur)}</td>
        <td class="n">${l.discountAmount ? cash(l.discountAmount, cur) : '—'}</td>
        <td class="n">${cash(l.amount, cur)}</td>
        <td class="n">${cash(l.amountPkr ?? l.amount, 'PKR')}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td colspan="2">Total goods</td>
        <td class="n">${qty(sum(lines.map(l => l.quantity)))}</td>
        <td></td>
        <td class="n">${cash(sum(lines.map(l => l.discountAmount)), cur)}</td>
        <td class="n">${cash(sum(lines.map(l => l.amount)), cur)}</td>
        <td class="n">${cash(sum(lines.map(l => l.amountPkr ?? l.amount)), 'PKR')}</td></tr>
    </tbody>
  </table>`;

// A rate list and a return both price the lines without splitting tax across them.
const plainItems = (lines: DocLine[], cur: string, whereLabel?: string) => `
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>SKU</th><th>Item Description</th>
      ${whereLabel ? `<th>${esc(whereLabel)}</th>` : ''}<th class="n">Quantity</th>
      <th class="n">Unit Rate</th><th class="n">Amount</th></tr></thead>
    <tbody>
      ${lines.map((l, n) => `<tr>
        <td class="c">${n + 1}</td>
        <td>${esc(l.sku || '—')}</td>
        <td>${esc(l.productName)}</td>
        ${whereLabel ? `<td>${esc(l.warehouseName || '—')}</td>` : ''}
        <td class="n">${lineUnit(l)}</td>
        <td class="n">${cash(l.price, cur)}</td>
        <td class="n">${cash(l.amount, cur)}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td colspan="2">Total</td>
        ${whereLabel ? '<td></td>' : ''}
        <td class="n">${qty(sum(lines.map(l => l.quantity)))}</td>
        <td></td>
        <td class="n">${cash(sum(lines.map(l => l.amount)), cur)}</td></tr>
    </tbody>
  </table>`;

const qtyItems = (lines: DocLine[], whereLabel?: string) => `
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>Code</th><th>Product Description</th>
      ${whereLabel ? `<th>${esc(whereLabel)}</th>` : ''}<th class="n">Quantity</th><th>Unit</th></tr></thead>
    <tbody>
      ${lines.map((l, n) => `<tr>
        <td class="c">${n + 1}</td>
        <td>${esc(l.sku || '—')}</td>
        <td>${esc(l.productName)}</td>
        ${whereLabel ? `<td>${esc(l.warehouseName || '—')}</td>` : ''}
        <td class="n">${qty(Number(l.quantity))}</td>
        <td>${esc(l.unit || '—')}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td colspan="2">Total</td>
        ${whereLabel ? '<td></td>' : ''}
        <td class="n">${qty(sum(lines.map(l => l.quantity)))}</td>
        <td></td></tr>
    </tbody>
  </table>`;

const itemsTable = (sheet: DocSheet, lines: DocLine[], gst: number[], cur: string, rate: string, kind: string) => {
  if (sheet.items === 'none') return '';
  if (!lines.length) return `<div class="nolines">This ${kind} carries no item lines.</div>`;
  if (sheet.items === 'priced') return pricedItems(lines, gst, cur, rate);
  if (sheet.items === 'import') return importItems(lines, cur);
  if (sheet.items === 'plain') return plainItems(lines, cur, sheet.whereLabel);
  if (sheet.items === 'qty') return qtyItems(lines, sheet.whereLabel);
  return '';
};

// Lines hold their own discounts and the document adds one more on top, so the total the
// reader sees is both together — that is what makes the sheet's arithmetic add up.
// `settled` is whether money has been asked for: a purchase order prices the goods and
// states no payment row at all.
const goodsTotals = (d: BizDoc, cur: string, discTotal: number, rate: string, settled: boolean) => `
  <div class="tfoot">
    ${cell('Gross Product Total', cash(d.gross, cur))}
    ${cell(`Total Discount Allowed${d.discountPercent ? ` (${d.discountPercent}%)` : ''}`,
      discTotal > 0 ? `- ${cash(discTotal, cur)}` : cash(0, cur))}
    ${cell(`Sales Tax / GST${rate}`, cash(d.tax, cur))}
    ${cell('Grand Total', cash(d.net, cur), true)}
    ${settled ? cell('Received Payment', cash(d.paymentAmount, cur)) : ''}
    ${settled ? cell('Unpaid Remaining Balance', cash(d.balance, cur), true) : ''}
    ${d.shippingCharges ? cell('Shipping Charges', cash(d.shippingCharges, cur), false, true) : ''}
    ${d.totalExpenses ? cell('Document Expenses', cash(d.totalExpenses, cur), false, true) : ''}
    ${d.roundOff ? cell('Round Off', `${Number(d.roundOff) < 0 ? '-' : ''}${cash(Math.abs(Number(d.roundOff)), cur)}`, false, true) : ''}
  </div>`;

// What an import owes its vendor, in both of the moneys the paper is written in. Everything the
// consignment cost beyond its goods — the duty, the freight, the agent's fee — is listed on the
// declaration band below this block, so these six rows answer the bill alone: what the goods
// were, what they came to in rupees, what has arrived and what is still due.
const importTotals = (d: BizDoc, cur: string, discTotal: number) => `
  <div class="tfoot">
    ${cell(`Gross Value of the Goods (${cur})`, cash(d.gross, cur))}
    ${cell(`Discount on the Goods (${cur})`, cash(discTotal, cur))}
    ${cell('Goods at the Declaration Rate (PKR)', cash(d.landed?.goodsPkr ?? d.net, 'PKR'))}
    ${cell('Amount Payable to the Vendor (PKR)', cash(d.net, 'PKR'), true)}
    ${cell('Paid to the Vendor (PKR)', cash(d.paymentAmount, 'PKR'))}
    ${cell('Still Owed (PKR)', cash(d.balance, 'PKR'), true)}
  </div>`;

const creditTotals = (d: BizDoc, lines: DocLine[], cur: string) => `
  <div class="tfoot three">
    ${cell('Total Line Items', `${lines.length} Item(s)`)}
    ${cell('Gross Reverted Value', cash(d.gross, cur))}
    ${cell('Total Credit Adjusted', cash(d.net, cur), true)}
  </div>`;

const amountTotals = (d: BizDoc, cur: string) => {
  const signed = (v: number) => `${v < 0 ? '-' : ''}${cash(Math.abs(Number(v) || 0), cur)}`;
  return `
  <div class="tfoot">
    ${d.gross ? cell('Gross Amount', cash(d.gross, cur)) : ''}
    ${d.discount ? cell(`Discount${d.discountPercent ? ` (${d.discountPercent}%)` : ''}`, signed(-Number(d.discount))) : ''}
    ${d.tax ? cell('Tax / GST', cash(d.tax, cur)) : ''}
    ${d.shippingCharges ? cell('Shipping Charges', cash(d.shippingCharges, cur)) : ''}
    ${d.totalExpenses ? cell('Document Expenses', cash(d.totalExpenses, cur)) : ''}
    ${d.roundOff ? cell('Round Off', signed(Number(d.roundOff))) : ''}
    ${cell('Net Amount', cash(d.net, cur), true)}
    ${d.paymentAmount ? cell('Received / Paid', cash(d.paymentAmount, cur)) : ''}
    ${d.balance ? cell('Balance Amount', cash(d.balance, cur), true) : ''}
  </div>`;
};

const totalsBlock = (sheet: DocSheet, d: BizDoc, lines: DocLine[], cur: string, discTotal: number, rate: string) => {
  if (sheet.totals === 'goods' || sheet.totals === 'order') return goodsTotals(d, cur, discTotal, rate, sheet.totals === 'goods');
  if (sheet.totals === 'import') return importTotals(d, cur, discTotal);
  if (sheet.totals === 'credit') return creditTotals(d, lines, cur);
  if (sheet.totals === 'amount') return amountTotals(d, cur);
  return '';
};

// A document that took or gave money in instalments lists the tenders it was settled with.
const paymentTable = (d: BizDoc, sheet: DocSheet, cur: string) => {
  const lines = d.paymentLines || [];
  if (!lines.length) return '';
  return `
  <div class="band">${esc(sheet.tenderLabel || 'Tenders')}</div>
  <table class="grid">
    <thead><tr><th>Payment Mode</th><th>Account</th><th>Instrument</th><th class="n">Amount</th></tr></thead>
    <tbody>${lines.map(p => `<tr>
      <td>${esc(p.paymentMode)}</td><td>${esc(p.accountName || '—')}</td>
      <td>${esc([p.bankName, p.instrumentNumber].filter(Boolean).join(' · ') || '—')}</td>
      <td class="n">${cash(p.amount, cur)}</td></tr>`).join('')}</tbody>
  </table>`;
};

const appliedTable = (d: BizDoc, sheet: DocSheet, cur: string) => {
  const rows = d.allocations || [];
  if (!rows.length) return '';
  return `
  <div class="band">${esc(sheet.appliedLabel || 'Adjusted Against')}</div>
  <table class="grid">
    <thead><tr><th>Particulars</th><th>Date</th><th class="n">Total</th><th class="n">Adjusted</th><th class="n">Balance</th></tr></thead>
    <tbody>${rows.map(a => `<tr>
      <td>${esc(a.description)}</td><td>${esc(longDate(a.date) || '—')}</td>
      <td class="n">${cash(a.totalAmount, cur)}</td><td class="n">${cash(a.allocated, cur)}</td>
      <td class="n">${cash(a.balanceAmount, cur)}</td></tr>`).join('')}</tbody>
  </table>`;
};

const panels = (sheet: DocSheet, d: BizDoc) => {
  const party = sheet.party ? `
    <div class="panel">
      <h4>${esc(sheet.party)}</h4>
      <div class="bd">
        <div class="pt">${esc(d.partyName || '—')}</div>
        ${(sheet.partyFields || []).map(c => {
          const [k, v] = metaCell(c, d, 'PKR');
          return kv(k, v);
        }).join('')}
      </div>
    </div>` : '';
  const detail = (sheet.fields || []).length ? `
    <div class="panel">
      <h4>${esc(sheet.detail || 'Details')}</h4>
      <div class="bd">${(sheet.fields || []).map(c => {
        const [k, v] = metaCell(c, d, 'PKR');
        return kv(k, v);
      }).join('')}</div>
    </div>` : '';
  return party || detail ? `<div class="panels">${party}${detail}</div>` : '';
};

// The customs side of an import invoice prints in rupees whatever currency the goods were
// bought in, because that is the money the books run on. The declaration says what the
// container was assessed on, the duty table says what that assessment raised and whether it
// has actually been paid, and the landed table says how the whole pool of duty and charge was
// divided between the goods — the three together are the reason the item's cost on this paper
// is not the price the vendor wrote.
const DECLARATION_ROWS: [string, (c: NonNullable<BizDoc['customs']>) => string][] = [
  ['Currency / Rate', c => `${c.currency} at ${money(c.rate)} per ${c.currency}`],
  ['CD Number', c => c.cdNumber],
  ['CD Date', c => c.cdDate ? longDate(c.cdDate) : ''],
  ['LC / TT Number', c => c.lcNumber],
  ['Bill of Lading / AWB', c => c.blNumber],
  ['Clearing Agent', c => c.agentName],
  ['Cleared At', c => c.portOfDischarge],
  ['Country of Origin', c => c.countryOfOrigin]
];

// Everything below the declaration is in rupees whatever currency the goods were bought in,
// because that is the money the port, the agent and the customs all took.
const customsBlock = (sheet: DocSheet, d: BizDoc, lines: DocLine[]) => {
  const c = d.customs;
  const l = d.landed;
  if (!sheet.customsBlock || !c) return '';
  const cells = DECLARATION_ROWS.map(([k, of]) => [k, of(c)] as [string, string]).filter(([, v]) => v.trim());
  const duties = c.duties || [];
  const dutyTotal = sum(duties.map(x => x.amount));
  const inCost = duties.filter(x => x.treatment === 'In cost');
  const claimable = duties.filter(x => x.treatment === 'Recoverable');
  const priced = (lines || []).filter(x => x.productName || Number(x.quantity));
  return `
  <div class="band">Customs Declaration</div>
  ${rowsOf(cells).map(row => `<div class="mr">${row.map(([k, v]) =>
    `<div><span class="k">${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}</div>`).join('')}
  ${duties.length ? `
  <table class="grid items">
    <thead><tr><th>Duty / Tax Head</th><th class="n">Rate</th><th class="n">Amount (PKR)</th>
      <th>Booked To</th><th>Treatment</th><th>Challan / Paid</th></tr></thead>
    <tbody>
      ${duties.map(x => `<tr>
        <td>${esc(x.head || '—')}</td>
        <td class="n">${x.rate ? `${qty(x.rate)}%` : '—'}</td>
        <td class="n">${cash(x.amount, 'PKR')}</td>
        <td>${esc(x.accountName || '—')}</td>
        <td>${esc(x.treatment === 'Recoverable' ? 'Claimable back' : 'Into cost of goods')}</td>
        <td>${esc([x.challan, x.paidVia === 'Unsettled' ? 'not paid' : `paid ${x.paidVia}`]
          .filter(Boolean).join(' · ') || '—')}</td></tr>`).join('')}
      <tr class="total"><td>Total on the declaration</td><td></td>
        <td class="n">${cash(dutyTotal, 'PKR')}</td><td colspan="3"></td></tr>
    </tbody>
  </table>
  <div class="note"><span class="k">Assessment</span>${esc(`Assessable value ${money(c.assessableValue)} PKR — goods ${money(l?.goodsPkr ?? 0)} PKR plus the freight and insurance of this consignment. ${money(sum(inCost.map(x => x.amount)))} PKR of duty is a cost of the goods; ${money(sum(claimable.map(x => x.amount)))} PKR is an advance the books claim back and never rides onto their cost.`)}</div>` : ''}
  ${(d.expenses || []).length ? `
  <div class="band">Charges on the Consignment</div>
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>Charged To</th><th>Particulars</th><th>Paid To</th>
      <th class="n">Amount (PKR)</th><th>Settled Via</th></tr></thead>
    <tbody>
      ${(d.expenses || []).map((e, n) => `<tr>
        <td class="c">${n + 1}</td><td>${esc(e.accountName || '—')}</td>
        <td>${esc(e.description || e.accountName || '—')}</td>
        <td>${esc(e.contact || '—')}</td>
        <td class="n">${cash(e.amount, 'PKR')}</td>
        <td>${esc(e.paidVia === 'Unsettled' || !e.paidVia ? 'Not paid yet'
          : `${e.paidVia}${e.paidVia === 'Bank' && e.paidAccountName ? ` — ${e.paidAccountName}` : ''}`)}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td colspan="3">Total charges</td>
        <td class="n">${cash(sum((d.expenses || []).map(e => e.amount)), 'PKR')}</td><td></td></tr>
    </tbody>
  </table>` : ''}
  ${l && priced.length ? `
  <div class="band">Landed Cost · ${esc(l.method === 'Method 2' ? 'charges left on their own heads' : 'charges pushed onto the goods')}</div>
  <table class="grid items">
    <thead><tr><th class="c">S#</th><th>Item</th><th class="n">Quantity</th><th class="n">Share</th>
      <th class="n">Duty &amp; Charges (PKR)</th>
      <th class="n">Landed (PKR)</th><th class="n">Landed / Unit</th></tr></thead>
    <tbody>
      ${priced.map((x, n) => `<tr>
        <td class="c">${n + 1}</td><td>${esc(x.productName)}</td>
        <td class="n">${lineUnit(x)}</td>
        <td class="n">${x.percentage ? `${qty(x.percentage)}%` : '—'}</td>
        <td class="n">${cash(x.landedCharges ?? 0, 'PKR')}</td>
        <td class="n">${cash(x.landedAmount ?? 0, 'PKR')}</td>
        <td class="n">${cash(x.landedCostPerUnit ?? 0, 'PKR')}</td></tr>`).join('')}
      <tr class="total"><td class="c"></td><td>Total</td>
        <td class="n">${qty(sum(priced.map(x => x.quantity)))}</td>
        <td class="n">${qty(l.shareTotal)}%</td>
        <td class="n">${cash(sum(priced.map(x => x.landedCharges ?? 0)), 'PKR')}</td>
        <td class="n">${cash(l.landedTotal, 'PKR')}</td><td></td></tr>
    </tbody>
  </table>
  <div class="tfoot">
    ${cell('Goods Value (PKR)', cash(l.goodsPkr, 'PKR'))}
    ${cell('Duties into the cost', cash(l.dutyInCost, 'PKR'))}
    ${cell('Charges on the paper', cash(l.charges, 'PKR'))}
    ${cell('Duties claimable back', cash(l.dutyRecoverable, 'PKR'))}
    ${cell('Landed Cost of the Consignment', cash(l.landedTotal, 'PKR'), true)}
    ${cell('Landed Cost per Unit', cash(l.perUnit, 'PKR'), true)}
  </div>` : ''}`;
};

const signRow = (signs: [string, SheetSign][], d: BizDoc, c: Partial<CompanyProfile>) =>  signs.length ? `<div class="sig${signs.length < 3 ? ' few' : ''}">${signs.map(([label, from]) =>
    `<div><span class="sl">${esc(label)}</span><span class="sn">${esc(SIGN[from](d, c))}</span></div>`).join('')}</div>` : '';

const DOC_WORD: Record<NonNullable<DocSheet['items']>, string> = {
  priced: 'voucher', plain: 'document', qty: 'note', import: 'consignment', none: 'voucher'
};

const docSheet = (d: BizDoc, opts: DocPrintOptions, sheet: DocSheet, i: number, last: number, ds: ResolvedDesign) => {
  const lines = d.lines.filter(l => l.productName || Number(l.quantity));
  const cur = opts.currency || 'PKR';
  // A consignment is billed in the exporter's money and booked in ours, so its goods rows read
  // in the currency on the declaration while every other figure on the sheet stays rupees.
  const gcur = sheet.items === 'import' ? (d.customs?.currency || cur) : cur;
  const priced = sheet.items === 'priced';
  const gst = priced ? taxShares(Number(d.tax || 0), lines) : [];
  const discTotal = sum(lines.map(l => l.discountAmount)) + Number(d.discount || 0);
  const rate = taxRate(Number(d.tax || 0), Number(d.gross || 0) - discTotal);
  const paid = !Number(d.paymentAmount) ? 'Unpaid' : Number(d.balance) > 0 ? 'Part Paid' : 'Paid';
  const words = sheet.amountLabel ? `${sheet.amountLabel} (In Words)` : undefined;
  const shown = new Set<string>([...sheet.meta, ...(sheet.fields || []), ...(sheet.partyFields || [])].map(keyOf));
  const kind = DOC_WORD[sheet.items || 'none'];
  return `
  <section class="sheet${i === last - 1 ? ' last' : ''}">
    ${docLetterhead(ds, opts.company ?? {})}
    ${bar(sheet.band || opts.label || d.subject || 'DOCUMENT', d.number)}
    ${metaRows(sheet.meta, d, cur, sheet.amountLabel || 'Amount')}
    ${panels(sheet, d)}
    ${itemsTable(sheet, lines, gst, gcur, rate, kind)}
    ${words ? `<div class="words"><span class="k">${esc(words)}</span><b>${esc(wordsOf(d.net, cur))}</b></div>` : ''}
    ${sheet.flags ? `
    <div class="flags">
      <div><span class="k">Payment Received Via</span><b>${esc(tendersOf(d) || 'On Account')}</b></div>
      <div><span class="k">Payment Status</span><b>${esc(paid)}</b></div>
      <div><span class="k">Document Status</span><b>${esc(d.status || '')}</b></div>
    </div>` : ''}
    ${totalsBlock(sheet, d, lines, gcur, discTotal, rate)}
    ${customsBlock(sheet, d, lines)}
    ${paymentTable(d, sheet, cur)}
    ${appliedTable(d, sheet, cur)}
    ${!shown.has('subject') && d.subject ? `<div class="note"><span class="k">${esc(sheet.subjectLabel || 'Subject')}</span>${esc(d.subject)}</div>` : ''}
    ${d.comments ? `<div class="note"><span class="k">Remarks</span>${esc(d.comments)}</div>` : ''}
    ${opts.note ? `<div class="note">${esc(opts.note)}</div>` : ''}
    ${signRow(sheet.signs, d, opts.company ?? {})}
    ${sheet.fine ? `<div class="fine">${esc(sheet.fine)}</div>` : ''}
    ${docFooter(ds, opts.company ?? {})}
  </section>`;
};

export interface DocPrintOptions {
  // The layout this kind of document prints as: its band, rows, columns and signatures.
  // Without one the page is a plain priced voucher.
  sheet?: DocSheet;
  // Heading on the band, e.g. "SALE INVOICE", when the sheet does not name itself.
  label?: string;
  currency?: string;
  company?: Partial<CompanyProfile>;
  paper?: Paper;
  // A closing line under every sheet: terms, a thank-you, or a notice.
  note?: string;
  // The design this sheet prints in. Left out, the saved default for the company is used.
  design?: Partial<PrintPrefs>;
}

export const PLAIN_VOUCHER: DocSheet = {
  meta: ['date', 'paymentMode', 'dueDate'],
  party: 'Billed Account Profile',
  partyFields: ['address'],
  detail: 'Dispatch & Representative',
  fields: ['warehouse', 'salesPerson', 'order', 'reference'],
  items: 'priced',
  totals: 'goods',
  amountLabel: 'Amount Chargeable',
  flags: true,
  signs: [['Prepared By', 'prepared'], ['Customer Signature & Stamp', 'party'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated official voucher · Goods once sold are subject to the company return policy.'
};

export function printDocuments(docs: BizDoc[], opts: DocPrintOptions) {
  const sheets = docs.filter(Boolean);
  if (!sheets.length) return;
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  const doc = frame.contentDocument;
  if (!doc) { frame.remove(); return; }
  const ds = resolveDesign(opts.design);
  // What the screen says wins, then the sheet the active template names, then A4. A roll has
  // no landscape: it is as wide as the printer is and as long as the bill.
  const chosen = opts.paper || ds.prefs.paper || 'A4';
  const paper = `${PAPER_SIZE[chosen]}${ds.prefs.landscape && chosen !== 'Receipt' ? ' landscape' : ''}`;
  const sheet = opts.sheet ?? PLAIN_VOUCHER;
  doc.open();
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(opts.label || 'Documents')}</title>${FONT_LINK}<style>
    ${themeVars(ds)}
    ${docSheetCss()}
    *{box-sizing:border-box}
    body{font:11px/1.5 var(--font);color:var(--ink);margin:0;font-variant-numeric:tabular-nums}
    .sheet{padding:12mm;page-break-after:always}
    .sheet.last{page-break-after:auto}
    table{border-collapse:collapse;width:100%}
    .k{font-size:9px;text-transform:uppercase;letter-spacing:.05em;color:var(--mu);display:block}
    .grid th{background:var(--band);border:1px solid var(--rule);padding:4px 6px;font-size:9px;text-transform:uppercase;letter-spacing:.03em;text-align:left;color:var(--mu)}
    .grid td{border:1px solid var(--rule);padding:4px 6px;vertical-align:top;word-break:break-word}
    .n{text-align:right;white-space:nowrap}
    .c{text-align:center;width:22px}
    tr.total td{font-weight:700;background:var(--tint);border-top:2px solid var(--ac)}
    .nolines{border:1px dashed var(--rule);padding:14px;text-align:center;color:var(--mu);margin:8px 0;font-size:10px}
    .band{font-size:9px;text-transform:uppercase;letter-spacing:.05em;color:var(--mu);margin-top:8px}
    .note{margin-top:8px;font-size:10px;color:var(--ink)}
    .grid{margin-top:6px}
    .bar{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin:8px 0 6px;padding:5px 9px;
      border:1px solid var(--ac);background:var(--tint);border-radius:var(--r)}
    .bar>span:first-child{font-size:13px;font-weight:800;letter-spacing:.03em;text-transform:uppercase;font-family:var(--disp)}
    .bar .num{font-size:12px;font-weight:700}
    .mr{display:flex;gap:6px;margin-bottom:6px}
    .mr>div{flex:1;border:1px solid var(--rule);border-radius:var(--r);padding:4px 7px;font-size:10px;display:flex;justify-content:space-between;align-items:baseline;gap:8px;min-width:0}
    .mr .k{font-size:8.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--mu)}
    .mr b{font-weight:700;text-align:right}
    .panels{display:flex;gap:8px;margin-bottom:8px}
    .panel{flex:1;border:1px solid var(--rule);border-radius:var(--r);min-width:0}
    .panel h4{margin:0;padding:4px 7px;background:var(--band);border-bottom:1px solid var(--rule);font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink)}
    .panel .bd{padding:5px 7px;font-size:10px}
    .pt{font-weight:700;font-size:12px;margin-bottom:2px}
    .kv{display:flex;justify-content:space-between;align-items:baseline;gap:10px;padding:1px 0}
    .kv span{color:var(--mu);white-space:nowrap}
    .kv b{font-weight:600;text-align:right;word-break:break-word}
    .items th{white-space:nowrap}
    .words{display:flex;align-items:baseline;gap:9px;border:1px solid var(--rule);background:var(--zebra);border-radius:var(--r);padding:5px 8px;margin:7px 0 6px;font-size:10px}
    .words .k{text-transform:uppercase;letter-spacing:.04em;color:var(--mu);font-size:9px;white-space:nowrap}
    .words b{font-weight:600;text-transform:capitalize}
    .flags{display:flex;gap:18px;flex-wrap:wrap;font-size:10px;margin:0 0 7px;padding:0 2px}
    .flags>div{display:flex;align-items:baseline;gap:5px}
    .flags .k{display:inline;margin-right:0}
    .tfoot{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));border:1px solid var(--rule);border-radius:var(--r);margin:6px 0}
    .tfoot>div{display:flex;justify-content:space-between;align-items:baseline;gap:10px;padding:4px 8px;font-size:10px;border-bottom:1px solid var(--zebra)}
    .tfoot>div:nth-last-child(-n+2){border-bottom:0}
    .tfoot .wide{grid-column:1/-1}
    .tfoot .hi{background:var(--tint);font-weight:700}
    .tfoot .hi span{color:var(--ac)}
    .tfoot.three{grid-template-columns:repeat(3,minmax(0,1fr))}
    .tfoot.three>div:nth-last-child(-n+2){border-bottom:1px solid var(--zebra)}
    .tfoot.three>div:last-child{border-bottom:0}
    .sig{display:flex;gap:22px;margin-top:16mm;font-size:10px}
    .sig.few{gap:22px;margin-top:20mm}
    .sig>div{flex:1;border-top:1px solid var(--mu);padding-top:4px;text-align:center}
    .sl{display:block;color:var(--ink);font-weight:600}
    .sn{display:block;font-size:9.5px;color:var(--mu);min-height:11px}
    .fine{margin-top:8mm;border-top:1px solid var(--rule);padding-top:5px;font-size:9px;color:var(--mu);text-align:center}
    @page{margin:0;size:${paper}}
  </style></head><body>${sheets.map((d, i) => docSheet(d, opts, sheet, i, sheets.length, ds)).join('')}</body></html>`);
  doc.close();
  const win = frame.contentWindow;
  const run = () => {
    win?.focus();
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      try { frame.remove(); } catch {}
    };
    if (win) {
      win.onafterprint = cleanup;
      win.print();
    }
    window.setTimeout(cleanup, 60000);
  };
  const start = () => {
    if (win && doc.readyState !== 'complete') win.addEventListener('load', run, { once: true });
    else window.setTimeout(run, 60);
  };
  // The chosen typeface has to be in the frame before the printer takes the sheet, or the
  // design arrives in the fallback face and looks like a different template.
  fontsReady(doc).then(start);
}
