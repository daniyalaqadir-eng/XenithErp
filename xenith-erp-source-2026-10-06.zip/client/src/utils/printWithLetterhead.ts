import { BizDoc } from '../types';
import { PosBill } from '../services/pos.service';
import { getCompanyHub } from '../services/settings.service';
import { ExportColumn, PrintBand, PrintOpts, printTable } from './exportTable';
import { activeTemplateDesign } from './printDesigns';
import { DocPrintOptions, printDocuments } from './printDocument';
import { printPosReceipt, ReceiptContext } from './printReceipt';

// A list screen prints the rows it is showing under the company's own letterhead, which
// the screen itself has no reason to hold. The read is best-effort for the same reason.
export type TablePrintOpts<T> = PrintOpts & {
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  bands?: PrintBand<T>[];
  rowClass?: (row: T) => string;
};

export async function printTableWithLetterhead<T>(
  tenantSlug: string, branchId: number | string, opts: TablePrintOpts<T>
) {
  const [hub, design] = await Promise.all([
    getCompanyHub(tenantSlug, branchId).catch(() => null),
    opts.design ? Promise.resolve(opts.design) : activeTemplateDesign(tenantSlug, branchId, opts.title)
  ]);
  printTable({ ...opts, design, company: { name: opts.org, ...hub?.profile } });
}

// A printed document carries the company's own letterhead, so the profile travels with
// it. A settings read that fails should still put paper on the printer. The design comes
// from the template the company set for this paper in Settings, so a print is one click
// and not a dialogue every time. What the caller passed wins.
export async function printDocsWithLetterhead(
  docs: BizDoc[], tenantSlug: string, branchId: number | string, opts: DocPrintOptions
) {
  const [hub, design] = await Promise.all([
    getCompanyHub(tenantSlug, branchId).catch(() => null),
    opts.design ? Promise.resolve(opts.design) : activeTemplateDesign(tenantSlug, branchId, opts.label || '')
  ]);
  printDocuments(docs, {
    ...opts,
    company: { name: opts.company?.name, ...hub?.profile },
    design
  });
}

// A till slip carries the same letterhead as the rest of the company's paper, so the
// profile is read for it too. That read may not hold the cashier's screen, so it is
// best-effort.
export async function printReceiptWithLetterhead(
  bill: PosBill, tenantSlug: string, branchId: number | string, ctx: ReceiptContext = {}
) {
  const [hub, design] = await Promise.all([
    getCompanyHub(tenantSlug, branchId).catch(() => null),
    ctx.design ? Promise.resolve(ctx.design) : activeTemplateDesign(tenantSlug, branchId, 'POS Invoice')
  ]);
  printPosReceipt(bill, {
    ...ctx,
    company: { name: ctx.company?.name, ...hub?.profile },
    design
  });
}
