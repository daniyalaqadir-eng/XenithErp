import { useEffect, useRef } from 'react';

// A second click on the sidebar entry you are already standing on asks that screen to read
// itself again. The ask comes from App's selectTab; the screen that is mounted answers it.
//
// It is an ask rather than a re-mount on purpose: a screen whose clerk is halfway through a
// bill keeps everything he has typed, because answering only means fetching the books afresh.
// One screen is mounted at a time, so a single answering slot is enough.
type Reload = () => void;

let answering: Reload | null = null;

export const requestScreenReload = () => { answering?.(); };

export const useScreenReload = (reload: Reload) => {
  const latest = useRef(reload);
  latest.current = reload;
  useEffect(() => {
    const answer: Reload = () => latest.current();
    answering = answer;
    return () => { if (answering === answer) answering = null; };
  }, []);
};
