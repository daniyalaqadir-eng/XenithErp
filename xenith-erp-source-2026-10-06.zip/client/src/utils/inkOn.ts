// ── readable ink on a filled badge ──────────────────────────────────────────
// Avatar circles are painted with whichever colour the profile carries, and that palette runs
// from deep blue to a mid teal that is far too light to carry white letters. So the ink is not
// assumed to be white: both candidate inks are measured against the background and the one with
// the better contrast ratio wins.

const channel = (v: number) => {
  const c = v / 255;
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
};

const luminance = (color: string): number | null => {
  const h = color.replace('#', '');
  const hex = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null;
  const [r, g, b] = [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16));
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
};

const NEAR_BLACK = '#111827';
const DARK_L = luminance(NEAR_BLACK) as number;
const WHITE_L = 1;

/** Small letters on a filled badge need the ordinary 4.5:1; the switch to 3:1 only applies
 *  at 18pt and above, which no chip in this app reaches. */
const MIN_RATIO = 4.5;

const ratioOf = (bgL: number, inkL: number) =>
  (Math.max(bgL, inkL) + 0.05) / (Math.min(bgL, inkL) + 0.05);

const channelOf = (color: string, i: number) => {
  const h = color.replace('#', '');
  const hex = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
  return parseInt(hex.slice(i * 2, i * 2 + 2), 16);
};

/** '#rgb' or '#rrggbb' in, and whichever of near-black or white is easier to read on it. */
export const inkOn = (bg: string | null | undefined): string => {
  const l = bg ? luminance(bg) : null;
  if (l === null) return '#FFFFFF';
  return ratioOf(l, DARK_L) > ratioOf(l, WHITE_L) ? NEAR_BLACK : '#FFFFFF';
};

/** A fill paired with an ink that actually clears 4.5:1 on it.
 *
 *  `inkOn` alone is not enough for a mid tone: on a red as deep as `#e63946` near-black
 *  reads at 4.26 and white at 4.18, so picking the winner of the two still leaves the
 *  initials failing. Rather than ship a label nobody can read, the plate itself walks
 *  toward black a few percent at a time until white letters pass — colours light or dark
 *  enough to carry an ink are returned untouched, so a profile's colour only shifts in the
 *  narrow band where it was unreadable either way. */
export const plateOn = (bg: string | null | undefined): { background: string; color: string } => {
  const fallback = { background: bg ?? '', color: '#FFFFFF' };
  const l = bg ? luminance(bg) : null;
  if (l === null || bg === undefined || bg === null) return fallback;
  if (Math.max(ratioOf(l, DARK_L), ratioOf(l, WHITE_L)) >= MIN_RATIO) {
    return { background: bg, color: inkOn(bg) };
  }
  let step = 0;
  let candidate = bg;
  while (step < 1) {
    step += 0.04;
    candidate = `#${[0, 1, 2].map(i =>
      Math.round(channelOf(bg, i) * (1 - step)).toString(16).padStart(2, '0')).join('')}`;
    if (ratioOf(luminance(candidate) as number, WHITE_L) >= MIN_RATIO) {
      return { background: candidate, color: '#FFFFFF' };
    }
  }
  return fallback;
};
