// The parts are read locally on purpose: a UTC ISO cut moves the day back for a PKT morning,
// which would silently drop yesterday's documents. The day itself comes from the internet
// clock in ./clock, so a register, a report period and a paper's default date all open on
// the day the company is actually standing in — not the one the laptop claims.
import { companyNow } from './clock';
export { companyNow };

export const isoDay = (d = companyNow()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export const monthStart = () => {
  const now = companyNow();
  return isoDay(new Date(now.getFullYear(), now.getMonth(), 1));
};
