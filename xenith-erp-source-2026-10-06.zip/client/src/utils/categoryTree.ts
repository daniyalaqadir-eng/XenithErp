import { Category } from '../types';

// Product categories are filed three deep: the parent groups the trade, the sub groups the
// range inside it, and the category is the leaf a product actually sits in. The tree travels
// in `parentId`, so a screen works out which level a row sits at instead of trusting a
// number the row stored for itself.
export const CATEGORY_MAX_LEVEL = 3;

export const parentOf = (cats: Category[], c: Category | null | undefined): Category | null =>
  (c?.parentId == null ? null : cats.find(x => x.id === c.parentId) ?? null);

// Root first, the row itself last.
export const trailOf = (cats: Category[], id: number | null | undefined): Category[] => {
  const out: Category[] = [];
  let cur = id == null ? null : cats.find(c => c.id === id) ?? null;
  while (cur && out.length < CATEGORY_MAX_LEVEL) { out.unshift(cur); cur = parentOf(cats, cur); }
  return out;
};

// The shelf a row sits on: every level above it, root first. A list cell and a printed sheet
// read the branch from here so they name it the same way the reports do.
export const shelfOf = (cats: Category[], id: number | null | undefined): string[] =>
  trailOf(cats, id).slice(0, -1).map(c => c.name);

export const levelOf = (cats: Category[], id: number | null | undefined) => trailOf(cats, id).length;

export const rootsOf = (cats: Category[]) => cats.filter(c => !parentOf(cats, c));

export const childrenOf = (cats: Category[], id: number | null | undefined) =>
  id == null ? [] : cats.filter(c => Number(c.parentId) === Number(id));

// The three boxes a product is filed by. A product sits at whichever level its owner took it
// to, so the trail of the stored row fills the box that level belongs in and leaves the ones
// below it empty until something is chosen under it.
export const filingLevels = (cats: Category[], id: number | null | undefined) => {
  const t = trailOf(cats, id);
  return { parentId: t[0]?.id ?? null, subId: t[1]?.id ?? null, leafId: t[2]?.id ?? null };
};
