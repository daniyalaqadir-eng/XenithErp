import { PosBill } from '../services/pos.service';
import { roundMoney } from './money';
import { CompanyProfile } from '../services/settings.service';
import { esc } from './exportTable';
import {
  FONT_LINK, FONT_STACK, PrintPrefs, ResolvedDesign, docFooter, docLetterhead,
  docSheetCss, fontsReady, resolveDesign, themeVars
} from './printDesigns';
import { barsOf } from './printLabels';

// A counter slip is not a voucher: it comes out of a thermal roll 80 or 58 mm wide, one
// column deep, and the customer walks away with it before the paper has cooled. The A4
// sheet renderer would spend half its width on signature boxes nobody signs at a till,
// so the slip gets its own page.

export interface ReceiptContext {
  // The words on the counter's own Receipt Template field: 'POS Thermal 80mm', 'POS
  // Thermal 58mm', 'POS A4 Invoice', 'POS A5 Invoice'. Anything unknown prints on 80mm.
  template?: string;
  outletAddress?: string;
  cashier?: string;
  copies?: number;
  company?: Partial<CompanyProfile>;
  currency?: string;
  // Stamped across a proof sheet so a setup preview can never leave the counter as change.
  stamp?: string;
  footer?: string;
  // A sheet-size receipt (POS A4 / A5) is a company document, so it carries the printed
  // design in force: its own letterhead block and closing footer. A thermal roll keeps the
  // centred till head either way — there is no room on 80mm for either.
  design?: Partial<PrintPrefs>;
}

interface PaperSpec { page: string; width: number; font: number; table: boolean }

const PAPERS: Record<'thermal80' | 'thermal58' | 'a4' | 'a5', PaperSpec> = {
  thermal80: { page: '80mm auto', width: 80, font: 11, table: false },
  thermal58: { page: '58mm auto', width: 58, font: 9.5, table: false },
  a4: { page: 'A4', width: 104, font: 12, table: true },
  a5: { page: 'A5', width: 100, font: 11.5, table: true }
};

// The counter names its paper in words; the roll it fits is what the printer needs.
const paperOf = (template = ''): PaperSpec => {
  const t = template.toLowerCase();
  if (t.includes('58')) return PAPERS.thermal58;
  if (t.includes('a4')) return PAPERS.a4;
  if (t.includes('a5')) return PAPERS.a5;
  return PAPERS.thermal80;
};

const money = (v: number) => (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const qty = (v: number) => (Number.isInteger(v) ? String(v) : String(Math.round((Number(v) || 0) * 1000) / 1000));

const CURRENCY_WORD: Record<string, string> = { PKR: 'PKR', INR: 'INR', USD: 'USD', AED: 'AED', GBP: 'GBP', EUR: 'EUR' };

const shortDate = (iso: string) => {
  const [y, m, d] = String(iso || '').split('-');
  return y && m && d ? `${d}/${m}/${y}` : (iso || '');
};

// The tax rate is held on the line products, not on the bill, so the slip works it back
// from the tax the bill actually carries.
const taxPercentOf = (b: PosBill) => {
  const taxable = (Number(b.grandTotal) || 0) - (Number(b.tax) || 0);
  if (!b.tax || taxable <= 0) return 0;
  return Math.round((b.tax / taxable) * 10000) / 100;
};

const row = (label: string, value: string, bold = false) =>
  `<div class="row${bold ? ' b' : ''}"><span>${esc(label)}</span><b>${esc(value)}</b></div>`;

const barcodeOf = (code: string) => {
  let x = 0;
  return barsOf(code, 42).map((bw, i) => {
    const bar = i % 2 === 0 ? `<rect x="${x}" y="0" width="${bw}" height="24" fill="#111"/>` : '';
    x += bw + 0.6;
    return bar;
  }).join('');
};

const shopHead = (c: Partial<CompanyProfile>, ctx: ReceiptContext, paper: PaperSpec, design: ResolvedDesign | null) => {
  // On sheet paper the letterhead is the design's own — a receipt and the invoice of the
  // same sale then agree about where the address sits and how the brand block looks.
  if (design) return docLetterhead(design, c);
  return `
  <div class="hd">
    ${c.logo ? `<img class="logo" src="${esc(c.logo)}" alt="" style="max-height:${paper.table ? '16mm' : '11mm'}" />` : ''}
    <div class="nm">${esc(c.name || 'Xenith ERP')}</div>
    <div class="ad">${[c.addressLine1, c.addressLine2, c.city, c.state].filter(Boolean).map(esc).join('<br/>')}</div>
    ${ctx.outletAddress ? `<div class="ad">${esc(ctx.outletAddress)}</div>` : ''}
    <div class="ad">${[c.phone && `Ph ${c.phone}`, c.email].filter(Boolean).map(esc).join(' · ')}</div>
    <div class="ad">${[c.ntn && `NTN ${c.ntn}`].filter(Boolean).map(esc).join(' · ')}</div>
  </div>`;
};

const title = (b: PosBill) =>
  b.type === 'Return' ? 'SALES RETURN SLIP' : b.status === 'Void' ? 'VOID / CANCELLED' : 'SALE RECEIPT';

const metaRows = (b: PosBill, ctx: ReceiptContext) => [
  ['Bill No', b.number],
  ['Date', `${shortDate(b.date)} ${b.time || ''}`.trim()],
  ['Counter', b.counterName],
  ['Cashier', ctx.cashier || b.cashier],
  ['Customer', b.customerName]
].map(([k, v]) => row(k as string, v as string)).join('');

// A thermal roll is too narrow for a rate column beside a product name, so each line takes
// two rows there and a real table only on sheet paper.
const linesBlock = (b: PosBill, paper: PaperSpec) => {
  if (paper.table) {
    return `
    <table class="ln">
      <thead><tr><th>#</th><th class="l">Item</th><th class="n">Qty</th><th class="n">Rate</th>
        <th class="n">Disc</th><th class="n">Amount</th></tr></thead>
      <tbody>
        ${b.lines.map((l, i) => `<tr>
          <td>${i + 1}</td>
          <td class="l">${esc(l.productName)}<i>${esc(l.sku || '—')}</i></td>
          <td class="n">${esc(qty(l.quantity))}</td>
          <td class="n">${money(l.price)}</td>
          <td class="n">${l.discountPercent ? `${l.discountPercent}%` : '—'}</td>
          <td class="n">${money(l.amount)}</td></tr>`).join('')}
      </tbody>
    </table>`;
  }
  return b.lines.map((l, i) => `
    <div class="li">
      <div class="t">${i + 1}. ${esc(l.productName)}</div>
      <div class="row s"><span>${esc(qty(l.quantity))} × ${money(l.price)}${l.discountPercent ? ` <em>-${l.discountPercent}%</em>` : ''}</span><b>${money(l.amount)}</b></div>
    </div>`).join('');
};

const totalsBlock = (b: PosBill, cur: string) => {
  const pct = taxPercentOf(b);
  const items = Math.round(b.lines.reduce((s, l) => s + (Number(l.quantity) || 0), 0) * 1000) / 1000;
  // The tenders are what the customer handed over, so the amount actually put on the
  // counter only earns its own row when it differs from them.
  const tendered = roundMoney(b.payments.reduce((s, p) => s + (Number(p.amount) || 0), 0));
  return `
    <div class="dbl"></div>
    ${row('Gross Sales', money(b.subtotal))}
    ${b.discount ? row('Discount', `- ${money(b.discount)}`) : ''}
    ${row(`Tax${pct ? ` (${pct}%)` : ''}`, money(b.tax))}
    ${row(`${b.type === 'Return' ? 'Total Refund' : 'Net Payable'} (${cur})`, money(b.grandTotal), true)}
    <div class="dbl"></div>
    ${b.payments.map(p => row(p.mode, money(p.amount))).join('')}
    ${Math.abs(tendered - (Number(b.cashReceived) || 0)) > 0.004 ? row('Tendered', money(b.cashReceived)) : ''}
    ${b.change ? row('Change Due', money(b.change)) : ''}
    ${row('Items', String(items))}`;
};

const foot = (b: PosBill, ctx: ReceiptContext, design: ResolvedDesign | null) => `
  <div class="bc"><svg viewBox="0 0 ${Math.max(1, 42 * 2.5)} 24" preserveAspectRatio="none">${barcodeOf(b.number)}</svg>
    <div class="mono">${esc(b.number)}</div></div>
  ${design ? docFooter(design, ctx.company ?? {}) : `<div class="fn">${esc(ctx.footer || (b.type === 'Return'
    ? 'Refund credited against this slip. Returned goods are checked before the amount is released.'
    : 'Thank you for shopping with us. Goods once sold are exchangeable within 7 days against this slip.'))}</div>`}
  <div class="fn dim">Computer generated slip · Xenith ERP · ${shortDate(b.date)} ${esc(b.time || '')}</div>`;

const slip = (
  b: PosBill, ctx: ReceiptContext, paper: PaperSpec, cur: string,
  copy: number, copies: number, design: ResolvedDesign | null
) => `
  <div class="rcp">
    ${ctx.stamp ? `<div class="stamp">${esc(ctx.stamp)}</div>` : ''}
    ${b.status === 'Void' ? '<div class="stamp void">VOID</div>' : ''}
    ${shopHead(ctx.company ?? {}, ctx, paper, design)}
    <div class="dash"></div>
    <div class="ttl">${esc(title(b))}</div>
    <div class="dash"></div>
    ${metaRows(b, ctx)}
    <div class="solid"></div>
    ${linesBlock(b, paper)}
    ${totalsBlock(b, cur)}
    <div class="dash"></div>
    ${foot(b, ctx, design)}
    ${copies > 1 ? `<div class="cp dim">${copy === 1 ? 'CUSTOMER COPY' : 'MERCHANT COPY'} · ${copy}/${copies}</div>` : ''}
  </div>`;

export function printPosReceipt(bill: PosBill, ctx: ReceiptContext = {}) {
  if (!bill) return;
  const paper = paperOf(ctx.template);
  const design = paper.table ? resolveDesign(ctx.design) : null;
  const cur = CURRENCY_WORD[ctx.currency ?? 'PKR'] ?? 'PKR';
  const copies = Math.max(1, Math.round(ctx.copies || 1));
  const slips = Array.from({ length: copies }, (_, i) => slip(bill, ctx, paper, cur, i + 1, copies, design)).join('');

  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  const doc = frame.contentDocument;
  if (!doc) { frame.remove(); return; }
  doc.open();
  // A counter slip keeps the monospace face of a thermal printer; a sheet-size receipt is
  // a document and takes the app's own type.
  const face = paper.table ? FONT_STACK : '"Consolas","Courier New",monospace';
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(bill.number)}</title>${FONT_LINK}<style>
    ${design ? `${themeVars(design)}${docSheetCss()}` : ''}
    *{box-sizing:border-box}
    body{margin:0;color:#111;background:#fff;font:${paper.font}px ${face};line-height:1.35}
    .rcp{width:${paper.width}mm;margin:0 auto;padding:${paper.table ? '8mm 6mm' : '2mm 0'};page-break-after:always}
    .rcp:last-child{page-break-after:auto}
    .hd{text-align:center}
    .logo{max-width:80%;margin-bottom:1mm}
    .nm{font-weight:700;letter-spacing:.04em;text-transform:uppercase}
    .tm{font-size:.8em;letter-spacing:.08em;text-transform:uppercase;opacity:.75}
    .ad{font-size:.78em;line-height:1.3;margin-top:.4mm}
    .ttl{text-align:center;font-weight:700;letter-spacing:.1em;text-transform:uppercase;margin:1mm 0}
    .stamp{text-align:center;font-weight:700;letter-spacing:.12em;border:1.5px dashed #111;padding:1mm;margin-bottom:1.5mm}
    .stamp.void{border-style:solid;margin-top:-1mm}
    .dash{border-top:1px dashed #666;margin:1.5mm 0}
    .solid{border-top:1px solid #111;margin:1.5mm 0}
    .dbl{border-top:3px double #111;margin:1.5mm 0}
    .row{display:flex;justify-content:space-between;align-items:baseline;gap:2mm}
    .row span{overflow:hidden;text-overflow:ellipsis}
    .row b{font-weight:700;white-space:nowrap}
    .row.b{font-size:1.12em}
    .row.s{font-size:.82em}
    .row.s span{opacity:.85}
    .li{margin:1mm 0}
    .li .t{word-break:break-word}
    em{font-style:normal;opacity:.8}
    table.ln{width:100%;border-collapse:collapse;margin-top:1mm}
    .ln th{border-bottom:1px solid #111;font-size:.8em;text-transform:uppercase;letter-spacing:.03em;padding:1mm;text-align:right}
    .ln th.l{text-align:left}
    .ln th:first-child{text-align:center}
    .ln td{border-bottom:1px dotted #999;padding:1mm;text-align:right;vertical-align:top}
    .ln td:first-child{text-align:center}
    .ln td.l{text-align:left}
    .ln td.l i{display:block;font-size:.75em;font-style:normal;opacity:.6}
    .bc{margin:2mm 0 1mm;text-align:center}
    .bc svg{width:90%;height:9mm}
    .mono{font-size:.78em;letter-spacing:.14em}
    .fn{font-size:.76em;text-align:center;margin-top:1mm;word-break:break-word}
    .dim{opacity:.65}
    .cp{font-size:.72em;text-align:center;margin-top:1.5mm;letter-spacing:.08em}
    @page{margin:0;size:${paper.page}}
  </style></head><body>${slips}</body></html>`);
  doc.close();
  const win = frame.contentWindow;
  const run = () => {
    win?.focus();
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      try { frame.remove(); } catch {}
    };
    if (win) {
      win.onafterprint = cleanup;
      win.print();
    }
    window.setTimeout(cleanup, 60000);
  };
  fontsReady(doc).then(() => {
    if (win && doc.readyState !== 'complete') win.addEventListener('load', run, { once: true });
    else window.setTimeout(run, 60);
  });
}
