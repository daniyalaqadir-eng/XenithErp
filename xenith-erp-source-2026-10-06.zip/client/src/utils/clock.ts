// The day the software works on is asked for, not assumed. The API reads the clock off the
// internet (see §0 of server/src/index.ts) because a laptop whose clock was moved back can
// otherwise spend a whole day writing papers dated in the past. The browser is told the true
// instant once before its first screen paints and then keeps ticking on its own clock between
// two readings, so every date field opens on that day on its own — nothing has to be written
// beside it to explain where the date came from.
const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const ZONE = 'Asia/Karachi';
const REFRESH_MS = 5 * 60 * 1000;
// The first reading is worth waiting a moment for, since a form that opens on the laptop's own
// day is the exact mistake this clock exists to prevent. It is a wait with a ceiling: a server
// that is not answering must never hold the whole app behind it.
const BOOT_WAIT_MS = 1200;

// The parts are read in the company's zone and rebuilt as local parts, so a helper written
// against plain local time never has to learn anything about timezones.
const wallFmt = new Intl.DateTimeFormat('en-GB', {
  timeZone: ZONE, hourCycle: 'h23',
  year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'
});

let offsetMs = 0;
let syncedAt = 0;

// The instant this browser believes it is, corrected by the last reading.
const trueNow = () => new Date(Date.now() + offsetMs);

// A Date whose *local* parts read as the company's wall clock, so every helper already
// written against local time (isoDay, monthStart, report periods) becomes correct without
// learning anything about timezones.
export const companyNow = (): Date => {
  const p: Record<string, string> = {};
  for (const part of wallFmt.formatToParts(trueNow())) p[part.type] = part.value;
  return new Date(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second));
};

const sync = async () => {
  if (syncedAt && Date.now() - syncedAt < 30 * 1000) return;
  try {
    const body = await (await fetch(`${API_BASE}/api/time`)).json();
    // The server answers with the instant it holds, whether that came off the internet or,
    // when the internet was silent, off its own machine. Either way it is a better reading
    // than a laptop whose clock somebody moved.
    const instant = Date.parse(String(body?.iso || ''));
    if (Number.isFinite(instant)) offsetMs = instant - Date.now();
    syncedAt = Date.now();
  } catch { /* the day already on screen stands until the server answers */ }
};

// Asked once before the app paints, then re-asked on a timer, so a book left open across
// midnight still writes its next paper on the day it is actually standing in.
export const startClock = async (): Promise<void> => {
  await Promise.race([sync(), new Promise(resolve => setTimeout(resolve, BOOT_WAIT_MS))]);
  window.setInterval(() => void sync(), REFRESH_MS);
};
