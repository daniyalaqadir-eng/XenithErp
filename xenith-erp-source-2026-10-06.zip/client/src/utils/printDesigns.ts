import { CompanyProfile, getPrintingTemplates } from '../services/settings.service';

// ── printed paper designs ─────────────────────────────────────────────────────
// Every sheet the app prints — a report grid, a voucher, a till slip — is drawn from one
// design. A design is data (colours, rules, header shape), never a second copy of the
// markup, so adding a look means adding an object here and the picker lists it on its own.
export type LetterheadMode = 'full' | 'compact' | 'logo' | 'none';
export type FooterMode = 'strip' | 'note' | 'both' | 'none';
export type HeaderShape = 'band' | 'card' | 'hairline' | 'centered' | 'block' | 'plain';

export interface PrintTheme {
  key: string;
  name: string;
  note: string;
  accent: string;
  ink: string;
  muted: string;
  band: string;
  zebra: string;
  rule: string;
  header: HeaderShape;
  radius: number;
}

export const PRINT_THEMES: PrintTheme[] = [
  {
    key: 'modern', name: 'Modern Card', accent: '#1e88e5', ink: '#111827', muted: '#6b7280',
    band: '#f5f8fc', zebra: '#fafbfc', rule: '#e6ebf1', header: 'card', radius: 10,
    note: 'Soft header panel, an accent edge, airy rows. The everyday look.'
  },
  {
    key: 'classic', name: 'Classic Ledger', accent: '#1e88e5', ink: '#1f2937', muted: '#6b7280',
    band: '#f3f4f6', zebra: '#fafafa', rule: '#d1d5db', header: 'band', radius: 0,
    note: 'Ruled table, boxed header. Reads like an audited statement.'
  },
  {
    key: 'minimal', name: 'Minimal Executive', accent: '#111827', ink: '#111827', muted: '#6b7280',
    band: '#ffffff', zebra: '#ffffff', rule: '#e5e7eb', header: 'hairline', radius: 0,
    note: 'No fills at all. Hairlines and whitespace carry the structure.'
  },
  {
    key: 'corporate', name: 'Corporate Letterhead', accent: '#0f4c81', ink: '#1f2937', muted: '#5b6472',
    band: '#eef3f8', zebra: '#f7fafc', rule: '#d7e0ea', header: 'centered', radius: 0,
    note: 'Centred brand block between two rules, the way a printed letterhead reads.'
  },
  {
    key: 'contrast', name: 'Bold Contrast', accent: '#111827', ink: '#111827', muted: '#4b5563',
    band: '#111827', zebra: '#f9fafb', rule: '#d1d5db', header: 'block', radius: 4,
    note: 'Dark header block with reversed type and a strong figure line.'
  },
  {
    key: 'mono', name: 'Print Safe Grey', accent: '#374151', ink: '#111827', muted: '#4b5563',
    band: '#f3f4f6', zebra: '#f9fafb', rule: '#cbd5e1', header: 'plain', radius: 0,
    note: 'Greyscale only — for photocopiers, faxes and black-and-white printers.'
  }
];

export const themeOf = (key?: string): PrintTheme =>
  PRINT_THEMES.find(t => t.key === key) ?? PRINT_THEMES[0];

// The brand colour is the one thing a company will always want to change, so it is a
// choice on top of a design rather than a separate design.
export const ACCENTS = [
  { name: 'Brand Blue', value: '#1e88e5' },
  { name: 'Teal', value: '#0d9488' },
  { name: 'Navy', value: '#0f4c81' },
  { name: 'Emerald', value: '#16a34a' },
  { name: 'Amber', value: '#d97706' },
  { name: 'Crimson', value: '#be123c' },
  { name: 'Violet', value: '#6d28d9' },
  { name: 'Graphite', value: '#334155' }
];

export const LETTERHEAD_OPTIONS: { value: LetterheadMode; label: string; note: string }[] = [
  { value: 'full', label: 'Full letterhead', note: 'Logo, name, address, phone, email and tax numbers.' },
  { value: 'compact', label: 'Compact', note: 'Name on one line, contact details under it.' },
  { value: 'logo', label: 'Brand mark only', note: 'Logo and name — nothing else above the paper.' },
  { value: 'none', label: 'No letterhead', note: 'Start straight on the content.' }
];

export const FOOTER_OPTIONS: { value: FooterMode; label: string; note: string }[] = [
  { value: 'strip', label: 'Contact strip', note: 'Address, phone and email along the foot.' },
  { value: 'note', label: 'Custom note', note: 'Your own closing line, terms or a thank-you.' },
  { value: 'both', label: 'Note + contact strip', note: 'Closing line above the contact strip.' },
  { value: 'none', label: 'Nothing', note: 'Leave the foot of the page empty.' }
];

// The three sheets a voucher prints on. A template names one of these and the printer gets
// exactly that, so the paper written on a template card is what comes out of the machine.
export type PrintPaper = 'A4' | 'A5' | 'Receipt';

export const PAPER_OPTIONS: { value: PrintPaper; label: string; note: string }[] = [
  { value: 'A4', label: 'A4', note: 'The full office page.' },
  { value: 'A5', label: 'A5', note: 'Half the page — a shorter bill.' },
  { value: 'Receipt', label: '80 mm slip', note: 'The narrow roll at the counter.' }
];

// A template's paper as it is written in the book: the sheet, and which way round it lies.
export const paperWord = (paper: PrintPaper | '', landscape: boolean) => {
  if (!paper) return 'Paper as the screen chooses';
  const roll = PAPER_OPTIONS.find(p => p.value === paper)?.label || 'A4';
  return paper === 'Receipt' ? '80mm Receipt' : `${roll} ${landscape ? 'Landscape' : 'Portrait'}`;
};

/** Reads a paper back out of any wording a book or a screen used for it. */
export const paperOf = (v?: string): PrintPaper | undefined => {
  const t = String(v || '').trim().toLowerCase();
  if (!t) return undefined;
  if (t.includes('receipt') || t.includes('slip') || t.includes('80') || t.includes('58')) return 'Receipt';
  if (t.includes('a5')) return 'A5';
  if (t.includes('a4')) return 'A4';
  return undefined;
};

export interface PrintPrefs {
  theme: string;
  accent: string;
  letterhead: LetterheadMode;
  footer: FooterMode;
  note: string;
  pageNumber: boolean;
  landscape: boolean;
  // Which sheet the printer is fed. Left blank, the screen that prints decides it — a form
  // with its own paper box outranks anything saved here.
  paper: PrintPaper | '';
  // Money columns keep their own decimals so a report never rounds a paisa away silently.
  decimals: 'default' | 'whole' | 'two';
}

export const DEFAULT_PRINT_PREFS: PrintPrefs = {
  theme: 'modern', accent: '', letterhead: 'full', footer: 'both',
  note: 'Thank you for your business.', pageNumber: true, landscape: false, paper: '', decimals: 'default'
};

const PREFS_KEY = 'quantcore.print.prefs.v1';

export function loadPrintPrefs(): PrintPrefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return { ...DEFAULT_PRINT_PREFS };
    return { ...DEFAULT_PRINT_PREFS, ...(JSON.parse(raw) as Partial<PrintPrefs>) };
  } catch { return { ...DEFAULT_PRINT_PREFS }; }
}

export function savePrintPrefs(p: PrintPrefs) {
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); } catch { /* a private window simply forgets it */ }
}

/**
 * A surface's saved templates are matched loosely, because the name a screen prints under
 * ("Sale Invoice") and the name a template was filed under need not be identical.
 */
export const templateMatches = (filedUnder: string, document: string) => {
  const a = document.trim().toLowerCase();
  const b = filedUnder.trim().toLowerCase();
  return !!a && !!b && (a === b || b.includes(a) || a.includes(b));
};

/**
 * The design a document prints in when nobody asked for one: the template the company has
 * marked active for that surface, laid over the saved default. A template that names no
 * design, and a template read that fails, both leave the default standing — the printer
 * must still get paper.
 */
export async function activeTemplateDesign(
  tenantSlug: string, branchId: number | string, document: string
): Promise<Partial<PrintPrefs>> {
  if (!document) return {};
  const templates = await getPrintingTemplates(tenantSlug, branchId)
    .then(r => r.templates || []).catch(() => []);
  const template = templates.find(t => t.isActive && templateMatches(t.document, document));
  if (!template?.design) return {};
  const picked: Partial<PrintPrefs> = {
    theme: template.design.theme, accent: template.design.accent,
    letterhead: template.design.letterhead as LetterheadMode, footer: template.design.footer as FooterMode,
    note: template.design.note, pageNumber: template.design.pageNumber,
    landscape: template.design.landscape, paper: paperOf(template.paper) || ''
  };
  // A template that leaves a knob blank inherits the default rather than blanking it out.
  // An empty accent is not blank — it is the template asking for the design's own colour,
  // and an empty paper is the template leaving the sheet to the screen that prints.
  (Object.keys(picked) as (keyof PrintPrefs)[]).forEach(k => {
    if (k !== 'accent' && (picked[k] === undefined || picked[k] === null || picked[k] === '')) delete picked[k];
  });
  return picked;
}

/** The design in force for one sheet: saved defaults, with anything the caller passes winning. */
export interface ResolvedDesign {
  prefs: PrintPrefs;
  theme: PrintTheme;
  accent: string;
  radius: number;
}

export function resolveDesign(over: Partial<PrintPrefs> = {}): ResolvedDesign {
  const prefs = { ...loadPrintPrefs(), ...over };
  const theme = themeOf(prefs.theme);
  return { prefs, theme, accent: prefs.accent || theme.accent, radius: theme.radius };
}

const px = (n: number) => `${n}px`;

// The Google copy of the interface fonts. A print iframe is its own document, so the
// faces have to be declared there too or the sheet silently drops back to Segoe UI.
export const FONT_STACK = '"Manrope","Plus Jakarta Sans","Segoe UI",Arial,sans-serif';
export const DISPLAY_STACK = '"Plus Jakarta Sans","Manrope","Segoe UI",Arial,sans-serif';
export const FONT_HREF =
  'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap';

export const FONT_LINK = `<link rel="stylesheet" href="${FONT_HREF}" />`;

/** The palette as custom properties, so a sheet can theme itself without rebuilding CSS. */
export const themeVars = (d: ResolvedDesign): string =>
  `:root{--ac:${d.accent};--ink:${d.theme.ink};--mu:${d.theme.muted};--band:${d.theme.band};` +
  `--zebra:${d.theme.zebra};--rule:${d.theme.rule};--r:${px(d.theme.radius)};--tint:${d.accent}12;` +
  `--font:${FONT_STACK};--disp:${DISPLAY_STACK}}`;

// Awaited before the sheet is handed to the printer, with a ceiling: a machine with no
// internet must still print, just in the fallback face.
export const fontsReady = (doc: Document, cap = 900): Promise<void> => {
  const fonts = (doc as any).fonts;
  if (!fonts?.ready) return Promise.resolve();
  return Promise.race([
    fonts.ready.then(() => undefined).catch(() => undefined),
    new Promise<void>(r => window.setTimeout(r, cap))
  ]);
};

/** One rule block every surface shares; `extra` lets a sheet add its own vocabulary. */
export const themeCss = (d: ResolvedDesign, extra = ''): string => {
  const { theme: t, accent, prefs } = d;
  const dark = t.header === 'block';
  const hair = t.header === 'hairline' || t.header === 'plain';
  return `
    ${themeVars(d)}
    *{box-sizing:border-box}
    /* --fs and --pad are the two numbers a wide register is fitted with: the sheet is measured
       against the page before it prints, and a register that will not sit at the reading size
       is stepped down instead of having its dates broken in half. */
    body{font:var(--fs,9.5px)/1.45 var(--font);color:var(--ink);margin:0;font-variant-numeric:tabular-nums;
      -webkit-print-color-adjust:exact;print-color-adjust:exact}
    h1,h2,h3{font-family:var(--disp);letter-spacing:-.015em;margin:0}
    table{width:100%;border-collapse:collapse;table-layout:auto}
    thead{display:table-header-group}
    tfoot{display:table-footer-group}
    tr{break-inside:avoid;page-break-inside:avoid}
    th{background:${dark ? accent : 'var(--band)'};${dark ? 'color:#fff;' : 'color:var(--mu);'}border-bottom:${hair ? '.5px' : '1px'} solid ${dark ? accent : 'var(--rule)'};
      padding:calc(var(--pad,5px) + 1px) var(--pad,5px);font-size:calc(var(--fs,9.5px) - .8px);font-weight:800;
      text-transform:uppercase;letter-spacing:.05em;line-height:1.25;vertical-align:bottom;white-space:normal}
    td{border-bottom:${hair ? '.5px' : '1px'} solid var(--rule);padding:var(--pad,5px) var(--pad,5px);
      vertical-align:top}
    /* A register is held to one line per cell: a date or a figure that wraps mid-token is a
       mis-read waiting to happen, and the fit pass shrinks the type until the row sits. A
       voucher keeps ordinary wrapping, because its narration column is written to be long. */
    table.reg td{white-space:nowrap}
    /* The columns that hold a party's full name or a line description are the only ones in the
       register allowed a second line. */
    table.reg td.w{white-space:normal;min-width:10ch;max-width:38ch;overflow-wrap:anywhere}
    tbody tr:nth-child(even) td{background:var(--zebra)}
    /* The rows a statement carries its own hierarchy in. They are named after the screen's, so
       a group head and a closing figure read the same on paper as they do in the register — and
       each one outranks the standing zebra, which otherwise paints over them on even rows. */
    tbody tr.total td{font-weight:800;background:var(--tint);border-top:1.5px solid var(--ac);border-bottom:0;color:var(--ink)}
    tbody tr.sh td{background:var(--band);color:var(--ink);font-weight:800;text-transform:uppercase;
      letter-spacing:.05em;font-size:calc(var(--fs,9.5px) - .5px);border-top:1px solid var(--rule)}
    tbody tr.sg td{font-weight:700;color:var(--ink)}
    /* The strip that closes every page: the column head repeats above it, so the foot only has
       to say what paper this is and who printed it. */
    tfoot td{border:0;background:none;padding:6px 0 0;font-size:calc(var(--fs,9.5px) - 1px);color:var(--mu);white-space:normal}
    tfoot .rf{display:flex;justify-content:space-between;gap:14px;border-top:1px solid var(--rule);padding-top:4px}
    tfoot .rf b{color:var(--ink);font-weight:700}
    .empty{padding:10px;border:1px dashed var(--rule);color:var(--mu);font-size:10px;border-radius:var(--r)}
    .ac{color:var(--ac)}
    .k{font-size:calc(var(--fs,9.5px) - 1px);text-transform:uppercase;letter-spacing:.07em;color:var(--mu);display:block;font-weight:700}
    @page{${pageBox(prefs)}}
    ${extra}`;
};

/** The margin every sheet leaves the paper, in mm — the pager measures against the same number. */
export const PAGE_PAD_MM = 12;

/** The sheet and its margins, from the paper the design names — A4, A5 or the counter roll. */
export const pageBox = (prefs: PrintPrefs, pad = PAGE_PAD_MM): string => {
  const roll = prefs.paper === 'Receipt' ? '80mm auto'
    : `${prefs.paper || 'A4'} ${prefs.landscape ? 'landscape' : 'portrait'}`;
  return `size:${roll};margin:${pad}mm${prefs.paper === 'Receipt' ? ' 6mm' : ''}`;
};

/** The printable box of the sheet the design asks for, in the 96dpi pixels the engine lays out at. */
export const pageBoxPx = (prefs: PrintPrefs): { w: number; h: number } => {
  const mm = 3.779527559;
  const pad = prefs.paper === 'Receipt' ? 6 : PAGE_PAD_MM;
  const sheet = prefs.paper === 'A5' ? [148, 210] : prefs.paper === 'Receipt' ? [80, 297 * 4] : [210, 297];
  const [a, b] = prefs.landscape && prefs.paper !== 'Receipt' ? [sheet[1], sheet[0]] : sheet;
  return { w: Math.round((a - 2 * pad) * mm), h: (b - 2 * pad) * mm };
};

const line = (v?: string) => escText(v);

export const escText = (v: unknown) => String(v ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// The company block, in whichever of the four letterhead modes is switched on. Reports use
// it too, which is what makes a printed register carry the same face as a voucher.
export const contactLine = (c: Partial<CompanyProfile>) =>
  [c.phone && `Phone: ${c.phone}`, c.email, c.ntn && `NTN: ${c.ntn}`, c.contactPerson && `Attn: ${c.contactPerson}`]
    .filter(Boolean).map(line).join('  ·  ');

export const addressLine = (c: Partial<CompanyProfile>) =>
  [c.addressLine1, c.addressLine2, [c.city, c.state].filter(Boolean).join(', '), c.country]
    .filter(Boolean).map(line).join(', ');

const logoImg = (c: Partial<CompanyProfile>, cls: string) =>
  c.logo ? `<img class="${cls}" src="${escText(c.logo)}" alt="" />` : '';

export interface SheetBrand {
  org?: string;
  title: string;
  subtitle?: string;
  company?: Partial<CompanyProfile>;
  // What the paper is answering, as short labelled facts ("Period 01-04-2026 – 30-04-2026"),
  // laid out in their own strip under the brand block. They used to be crammed into the
  // subtitle, where a register with six filters on it printed as an unreadable grey wall.
  meta?: (string | undefined | false)[];
  // Two facts a printed register is asked to name before anything else: the filing it sits under
  // ("Sales Invoice Detail Report [Summary View]") and the stretch of the calendar it was cut
  // for. They print as a pair, one in each corner, the way a filed paper is stamped.
  filing?: string;
  windowBlock?: string;
  // The headline figures, read off the rows the filters kept. A sheet with four of these across
  // the top answers the reader's first question before the register answers the second.
  cards?: { label: string; value: string; hot?: boolean }[];
  // Who drew the paper, so a printed register carried out of the shop can be traced back.
  printedBy?: string;
  printedAt?: string;
}

/** The facts a register was cut by, in one strip: each is "Label value", the label in small caps. */
export const metaStrip = (o: SheetBrand): string => {
  const bits = (o.meta ?? []).filter(Boolean).map(String);
  if (!bits.length) return '';
  return `<div class="meta">${bits.map(b => {
    const i = b.indexOf(':');
    return i > 0 && i < 22
      ? `<span class="m"><b>${escText(b.slice(0, i))}</b>${escText(b.slice(i + 1))}</span>`
      : `<span class="m">${escText(b)}</span>`;
  }).join('')}</div>`;
};

/** The stamp a report sheet carries under its brand: two corner facts and the headline figures. */
export const sheetStamp = (o: SheetBrand): string => {
  const corners = [o.filing, o.windowBlock].filter(Boolean);
  const cards = (o.cards ?? []).slice(0, 4);
  return `${corners.length ? `<div class="corners">${
    o.filing ? `<span>Report Categorization: <b>${escText(o.filing)}</b></span>` : ''}${
    o.windowBlock ? `<span>Duration Window Block: <b>${escText(o.windowBlock)}</b></span>` : ''}${
    corners.length === 1 ? '<span></span>' : ''}</div>` : ''}${
    cards.length ? `<div class="cards">${cards.map(c => `<div class="c${c.hot ? ' hi' : ''}">
      <span class="cl">${escText(c.label)}</span><span class="cv">${escText(c.value)}</span></div>`).join('')}</div>` : ''}`;
};

/** Header above a report or list: the brand block, then what the paper is and who it is for. */
export const gridHeader = (d: ResolvedDesign, o: SheetBrand): string => {
  const { prefs, accent, theme: t } = d;
  const c = o.company ?? {};
  const name = c.name || o.org || 'Xenith ERP';
  const mode = prefs.letterhead;
  const head = `<div class="what"><div class="k">Report</div><h1>${escText(o.title)}</h1>${
    o.subtitle ? `<div class="sub">${escText(o.subtitle)}</div>` : ''}</div>`;
  const logo = logoImg(c, 'lg');
  const addr = mode === 'full' ? addressLine(c) : contactLine(c);
  const kind = c.typeOfOrganization ? `<div class="ct">${escText(c.typeOfOrganization)}</div>` : '';
  const brand = (extraCls = '') => `<div class="l">${logo}<div class="who${extraCls}">
      <div class="cn">${escText(name)}</div>${mode === 'full' ? kind : ''}${
      mode === 'none' || mode === 'logo' ? '' : `<div class="cad">${addr}</div>`}</div></div>`;
  // A sheet with no letterhead on it is the reader's own choice: the title takes the whole
  // width instead of leaving a gap where the brand block used to sit.
  if (mode === 'none') {
    return `<header class="nt"><div class="what"><h1>${escText(o.title)}</h1>${
      o.subtitle ? `<div class="sub">${escText(o.subtitle)}</div>` : ''}</div>${
      o.printedAt ? `<div class="pr">Printed ${escText(o.printedAt)}${o.printedBy ? ` · ${escText(o.printedBy)}` : ''}</div>` : ''
    }</header>${sheetStamp(o)}${metaStrip(o)}`;
  }
  const body = (() => {
    switch (t.header) {
      case 'centered':
        return `<header class="hc">
          <div class="cb">${logo}<div class="cn">${escText(name)}</div>${
            mode === 'full' ? kind : ''}${mode === 'full' ? `<div class="cad">${addressLine(c)}</div>` : ''}</div>
          <div class="ttl"><div class="k">Report</div><h1>${escText(o.title)}</h1>${
            o.subtitle ? `<div class="sub">${escText(o.subtitle)}</div>` : ''}</div>
        </header>`;
      case 'block':
        return `<header class="hb" style="background:${accent}">
          ${brand(' on-dark')}${head}
        </header>`;
      case 'hairline':
      case 'plain':
        return `<header class="hs">${brand()}${head}</header>
          <div class="rule" style="border-top:1.5px solid ${accent}"></div>`;
      case 'band':
        return `<header class="bs">${brand()}${head}</header>`;
      default:
        return `<header class="cs"><span class="edge" style="background:${accent}"></span>${brand()}${head}</header>`;
    }
  })();
  // The logo-only mode is a brand mark and nothing else, so the contact lines are dropped
  // rather than moved — the reader asked for a clean sheet, not a smaller letterhead.
  return `${body}${sheetStamp(o)}${metaStrip(o)}`;
};

/** The rules a grid header's own classes need, on top of themeCss. */
export const gridHeaderCss = (d: ResolvedDesign): string => `
  header{display:flex;gap:14px;align-items:flex-start;margin-bottom:7px;padding:9px 11px}
  header .l{display:flex;align-items:center;gap:9px;flex:1;min-width:0}
  header .who{min-width:0}
  header .what{text-align:right;flex-shrink:0;max-width:44%}
  header .what .k{text-align:right}
  header h1{font-size:15.5px;font-weight:800;line-height:1.15}
  header .sub{font-size:8.5px;color:var(--mu);margin-top:3px;line-height:1.45}
  .cn{font-size:15px;font-weight:800;font-family:var(--disp);letter-spacing:-.015em;line-height:1.15}
  .ct{font-size:7.5px;text-transform:uppercase;letter-spacing:.16em;color:var(--mu);margin-top:1px}
  .cad{font-size:8.5px;color:var(--mu);margin-top:2px;line-height:1.4}
  .lg{max-height:38px;max-width:120px;object-fit:contain;flex-shrink:0}
  .cs{background:var(--band);border:1px solid var(--rule);border-radius:var(--r);position:relative;padding-left:15px}
  .cs .edge{position:absolute;left:0;top:0;bottom:0;width:3.5px;border-radius:var(--r) 0 0 var(--r)}
  .bs{border-bottom:1.5px solid ${d.accent};border-radius:0;padding-left:0;padding-right:0}
  .hb{color:#fff;border-radius:var(--r);padding:10px 13px}
  .hb .cad,.hb .sub,.hb .ct,.hb .k{color:rgba(255,255,255,.82)}
  .hs{padding:0 0 5px;border:0;display:flex;justify-content:space-between;align-items:flex-end;gap:14px}
  .rule{margin:-1px 0 8px}
  .hc{display:block;text-align:center;border-bottom:2px solid ${d.accent};padding-bottom:7px}
  .hc .cb{display:flex;flex-direction:column;align-items:center;gap:1px}
  .hc .ttl{margin-top:5px}
  .hc .what,.hc h1,.hc .sub,.hc .k{text-align:center}
  .nt{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:1.5px solid ${d.accent};
    padding:0 2px 5px;margin-bottom:7px}
  .nt .pr{font-size:8.5px;color:var(--mu);text-align:right}
  /* What the register is filed under and the window it was cut for, stamped one to each corner,
     with the headline figures read off the kept rows laid across the top of the paper. */
  .corners{display:flex;justify-content:space-between;align-items:baseline;gap:10px 18px;flex-wrap:wrap;
    margin:-3px 0 8px;padding:0 2px;font-size:8.5px;color:var(--mu)}
  .corners b{color:var(--ink);font-weight:800;text-transform:uppercase;letter-spacing:.04em}
  .cards{display:flex;gap:7px;margin:0 0 10px}
  .cards .c{flex:1 1 0;min-width:0;border:1.5px solid var(--rule);border-radius:var(--r);padding:5px 7px;text-align:center}
  .cards .cl{display:block;font-size:7.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--mu);font-weight:800}
  .cards .cv{display:block;font-size:12px;font-weight:800;color:var(--ink);margin-top:2px;white-space:nowrap;
    overflow:hidden;text-overflow:ellipsis}
  .cards .c.hi{border-color:${d.accent}55;background:var(--tint)}
  .cards .c.hi .cv{color:${d.accent}}
  /* What the register was cut by, in its own strip: a wall of capitals under the letterhead
     used to be the only way six filters got on paper, and it read as noise. */
  .meta{display:flex;flex-wrap:wrap;gap:2px 16px;margin:0 0 10px;padding:5px 10px;background:var(--tint);
    border-left:3px solid var(--ac);border-radius:0 var(--r) var(--r) 0;font-size:8.5px;color:var(--ink)}
  .meta .m{max-width:48%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .meta b{font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:var(--mu)}
  .meta b::after{content:':' ;margin-right:4px}
  .hf{margin-top:10px;padding-top:5px;border-top:1px solid var(--rule);display:flex;justify-content:space-between;
    align-items:baseline;gap:12px;font-size:8.5px;color:var(--mu)}
  .hf .note{font-style:italic;color:var(--ink);font-size:9px}
  .hf .sg{display:block;text-align:center;font-size:8px;letter-spacing:.1em;text-transform:uppercase;
    color:var(--mu);margin-top:3px}
  .hf b{color:var(--ink);font-weight:800}
`;

export interface SheetFoot {
  // What the paper holds, in words: "30 record(s)", or a statement's own closing line.
  left?: string;
  company?: Partial<CompanyProfile>;
  printedAt?: string;
  printedBy?: string;
}

/** Foot of a report: the closing note, the contact strip and the record count. */
export const gridFooter = (d: ResolvedDesign, o: SheetFoot): string => {
  const { prefs } = d;
  const c = o.company ?? {};
  const note = prefs.footer === 'note' || prefs.footer === 'both' ? prefs.note : '';
  const strip = prefs.footer === 'strip' || prefs.footer === 'both' ? contactLine(c) : '';
  const printed = `Printed ${escText(o.printedAt || new Date().toLocaleString())}${
    o.printedBy ? ` · ${escText(o.printedBy)}` : ''}`;
  // The page count is filled in once the sheet has been laid out — a browser cannot count
  // its own pages, so the number is measured and written into the marker before printing.
  const count = [o.left ? escText(o.left) : '',
    prefs.pageNumber ? '<span data-pages>1 page</span>' : ''].filter(Boolean).join(' · ');
  const right = `${count ? `<b>${count}</b> · ` : ''}${printed}`;
  if (!note && !strip) return `<footer class="hf"><span></span><span>${right}</span></footer>`;
  return `<footer class="hf">
    <span>${note ? `<span class="note">${escText(note)}</span>` : ''}${
      strip ? `${note ? ' — ' : ''}${strip}` : ''}</span>
    <span>${right}</span>
  </footer>`;
};

/**
 * The strip a table carries at the foot of every page it breaks over. The letterhead is only
 * on the first sheet, so a page found loose on a printer has to name the paper, the business
 * it belongs to and how many records it holds.
 */
export const runFoot = (
  d: ResolvedDesign, o: { cols: number; title?: string; company?: Partial<CompanyProfile>; left?: string }
): string => {
  if (!d.prefs.pageNumber) return '';
  const c = o.company ?? {};
  const who = escText(c.name || '');
  return `<tfoot><tr><td colspan="${o.cols}"><div class="rf">
    <span>${who}${o.title ? ` · <b>${escText(o.title)}</b>` : ''}</span>
    <span>${escText(o.left ?? '')}</span>
  </div></td></tr></tfoot>`;
};

// ── the voucher surface ───────────────────────────────────────────────────────
// A printed document is not a table under a header: the brand block owns the top of the
// paper and the foot carries the closing line. Both come from the same design so a voucher
// and the report of the same sale agree with each other.

const SHAPE_CLASS: Record<HeaderShape, string> = {
  band: 'lhd-band', card: 'lhd-card', hairline: 'lhd-line', plain: 'lhd-line',
  centered: 'lhd-centre', block: 'lhd-block'
};

export const docLetterhead = (d: ResolvedDesign, c: Partial<CompanyProfile>): string => {
  const mode = d.prefs.letterhead;
  if (mode === 'none') return '';
  const name = escText(c.name || 'Xenith ERP');
  const logo = c.logo ? `<img class="logo" src="${escText(c.logo)}" alt="" />` : '';
  const addr = mode === 'full' ? addressLine(c) : '';
  const contact = mode === 'full' || mode === 'compact' ? contactLine(c) : '';
  const kind = mode === 'logo' ? ' only' : mode === 'compact' ? ' one' : '';
  return `<div class="lhd ${SHAPE_CLASS[d.theme.header]}${kind}">
    ${mode === 'compact' ? '' : logo}
    <div class="who">${logo ? `<span class="lgw">${logo}</span>` : ''}<div class="nm">
      <div class="cn">${name}</div>
      ${mode === 'full' && c.typeOfOrganization ? `<div class="cd">${escText(c.typeOfOrganization)}</div>` : ''}
      ${addr ? `<div class="cl">${addr}</div>` : ''}
    </div></div>
    ${contact ? `<div class="cta">${contact}</div>` : ''}
  </div>`;
};

export const docFooter = (d: ResolvedDesign, c: Partial<CompanyProfile>): string => {
  const { footer, note } = d.prefs;
  if (footer === 'none') return '';
  const strip = footer === 'strip' || footer === 'both' ? contactLine(c) : '';
  const line = footer === 'note' || footer === 'both' ? note : '';
  if (!strip && !line) return '';
  return `<div class="pfoot">${line ? `<span class="pn">${escText(line)}</span>` : ''}${
    strip ? `<span class="ps">${strip}</span>` : ''}</div>`;
};

/** Rules for the two blocks above; a sheet layers its own structure on top of these. */
export const docSheetCss = (): string => `
  .lhd{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;padding-bottom:6px;border-bottom:2px solid var(--ac)}
  .lhd .who{display:flex;align-items:center;gap:9px;min-width:0}
  .lhd .nm{min-width:0}
  .lhd .cn{font-family:var(--disp);font-size:19px;font-weight:800;letter-spacing:-.02em;line-height:1.15;color:var(--ac)}
  .lhd .cd{font-size:9px;text-transform:uppercase;letter-spacing:.16em;color:var(--mu);margin-top:1px}
  .lhd .cl{font-size:9.5px;color:var(--mu);line-height:1.45}
  .lhd .cta{font-size:9.5px;color:var(--mu);text-align:right;line-height:1.5;flex-shrink:0}
  .lhd .logo{max-height:46px;max-width:150px;object-fit:contain}
  .lhd .lgw{display:flex}
  .lhd-centre{display:block;text-align:center;border-bottom-width:2.5px}
  .lhd-centre .who{justify-content:center;flex-direction:column;align-items:center;gap:2px}
  .lhd-centre .cta{text-align:center;margin-top:3px}
  .lhd-card{background:var(--band);border:1px solid var(--rule);border-left:4px solid var(--ac);border-radius:var(--r);padding:8px 11px}
  .lhd-line{border-bottom:.5px solid var(--rule);padding-bottom:5px}
  .lhd-block{background:var(--ac);color:#fff;padding:9px 12px;border-radius:var(--r);border-bottom:0}
  .lhd-block .cn,.lhd-block .cd,.lhd-block .cl,.lhd-block .cta{color:#fff}
  .lhd-block .cd,.lhd-block .cl,.lhd-block .cta{opacity:.82}
  .lhd.one{align-items:center}
  .lhd.one .nm{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap}
  .lhd.one .cn{font-size:15px}
  .lhd.only .cn{font-size:17px}
  .pfoot{margin-top:8px;padding-top:5px;border-top:1px solid var(--rule);display:flex;justify-content:space-between;
    gap:14px;font-size:9px;color:var(--mu)}
  .pfoot .pn{font-style:italic;color:var(--ink)}
`;
