// Singular and plural form of a master's name, so a heading reads "23 Units of Measurement" and
// not "…Measurements".

export function singular(word: string): string {
  if (!word) return '';
  const trimmed = word.trim();

  // Irregular / common accounting terms
  const irregulars: Record<string, string> = {
    categories: 'category',
    companies: 'company',
    deliveries: 'delivery',
    inventories: 'inventory',
    parties: 'party',
    branches: 'branch',
    taxes: 'tax',
    classes: 'class',
    busses: 'bus'
  };

  const lower = trimmed.toLowerCase();
  if (irregulars[lower]) {
    return irregulars[lower];
  }

  if (trimmed.endsWith('ies')) {
    return trimmed.slice(0, -3) + 'y';
  }
  if (trimmed.endsWith('es') && (trimmed.endsWith('shes') || trimmed.endsWith('ches') || trimmed.endsWith('sses') || trimmed.endsWith('xes'))) {
    return trimmed.slice(0, -2);
  }
  if (trimmed.endsWith('s') && !trimmed.endsWith('ss')) {
    return trimmed.slice(0, -1);
  }

  return trimmed;
}

export function plural(word: string): string {
  if (!word) return '';
  const trimmed = word.trim();
  if (trimmed.endsWith('y') && !/[aeiou]y$/i.test(trimmed)) {
    return trimmed.slice(0, -1) + 'ies';
  }
  if (trimmed.endsWith('s') || trimmed.endsWith('sh') || trimmed.endsWith('ch') || trimmed.endsWith('x') || trimmed.endsWith('z')) {
    return trimmed + 'es';
  }
  return trimmed + 's';
}
