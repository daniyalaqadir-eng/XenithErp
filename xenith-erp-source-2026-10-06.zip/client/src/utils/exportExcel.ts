import { ExportColumn } from './exportTable';
import { resolveDesign } from './printDesigns';
import { isoDay } from './dateRange';

// ── styled spreadsheet export ─────────────────────────────────────────────────
// An .xlsx file is a zip of XML parts, and a zip that stores its entries uncompressed costs
// a few hundred bytes of header bookkeeping. Writing one here means the spreadsheet opens
// with its colours, number formats, frozen header and column filters intact — no library in
// the bundle, and none of a CSV's habit of throwing every format except the digits away.
//
// Two looks sit behind the one the app sends: `branded` carries the printed design's colour
// and its letterhead block, `clean` keeps the structure without the fills, and `plain` is the
// grid alone for feeding into another tool that brings its own formatting.

export type ExcelStyle = 'branded' | 'clean' | 'plain';

const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const RNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

const hex = (v: string) => v.replace('#', '').toUpperCase();

// ── the numbers ───────────────────────────────────────────────────────────────
interface XfSpec {
  b?: 1; i?: 1; sz?: number; color?: string; fill?: string; align?: 'r' | 'c';
  fmt?: string; bottom?: 1; top?: 1; wrap?: 1; indent?: number;
}

const MONEY = /^([-+]?[\d,]*\d)(\.\d+)?$/;
const CURRENCY = /^([^"\d\s]{1,6}\.?)\s*([-+]?[\d,]*\d(?:\.\d+)?)$/;
const CUR_NEG = /^([^"\d\s]{1,6}\.?)\s*\(\s*([\d,]*\d(?:\.\d+)?)\s*\)$/;
const PERCENT = /^([-+]?[\d,]*\d(?:\.\d+)?)\s*%$/;
const ACCOUNTING = /^\(\s*([\d,]*\d(?:\.\d+)?)\s*\)$/;

// A figure column is the app's own declaration that its cells hold money or counts, so
// only those cells become real numbers. Codes like 1100.1 and dates stay exactly as shown.
const asNumber = (raw: string | number, numeric: boolean) => {
  if (!numeric) return null;
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) return null;
    return { v: raw, fmt: Number.isInteger(raw) ? '#,##0' : '#,##0.00' };
  }
  const s = String(raw).trim();
  if (!s) return null;
  const pct = PERCENT.exec(s);
  if (pct) {
    const n = Number(pct[1].replace(/,/g, ''));
    return Number.isFinite(n) ? { v: n / 100, fmt: '0.00%' } : null;
  }
  const acc = ACCOUNTING.exec(s);
  if (acc) {
    const n = Number(acc[1].replace(/,/g, ''));
    return Number.isFinite(n) ? { v: -n, fmt: '#,##0.00;[Red](#,##0.00)' } : null;
  }
  if (MONEY.test(s)) {
    const n = Number(s.replace(/,/g, ''));
    return Number.isFinite(n) ? { v: n, fmt: s.includes('.') ? '#,##0.00' : '#,##0' } : null;
  }
  const cur = CURRENCY.exec(s);
  if (cur) {
    const n = Number(cur[2].replace(/,/g, ''));
    if (!Number.isFinite(n)) return null;
    const mark = cur[1].endsWith('.') ? cur[1] : `${cur[1]}.`;
    return { v: n, fmt: `"${mark}" #,##0.00;[Red]-"${mark}" #,##0.00` };
  }
  // A ledger's own way of writing a negative: PKR (980.25).
  const curn = CUR_NEG.exec(s);
  if (curn) {
    const n = Number(curn[2].replace(/,/g, ''));
    if (!Number.isFinite(n)) return null;
    const mark = curn[1].endsWith('.') ? curn[1] : `${curn[1]}.`;
    return { v: -n, fmt: `"${mark}" #,##0.00;[Red]-"${mark}" #,##0.00` };
  }
  return null;
};

const colLetter = (n: number) => {
  let s = '';
  for (let i = n; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + ((i - 1) % 26)) + s;
  return s;
};

const cell = (v: string | number) => {
  let s = String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  if (/^[=+\-@]/.test(s)) {
    s = `'${s}`;
  }
  return s;
};
const xml = (v: unknown) => cell(String(v ?? ''))
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ── workbook assembly ─────────────────────────────────────────────────────────
class Styles {
  private fonts: XfSpec[] = [];
  private fills: string[] = [];
  private borders: string[] = [];
  private xfs: XfSpec[] = [];
  private cache = new Map<string, number>();
  private fmts = new Map<string, number>();

  id(spec: XfSpec) {
    const k = JSON.stringify(spec);
    let i = this.cache.get(k);
    if (i === undefined) { i = this.xfs.length; this.xfs.push(spec); this.cache.set(k, i); }
    return i;
  }

  private fmtId(f?: string) {
    if (!f) return 0;
    let id = this.fmts.get(f);
    if (id === undefined) { id = 164 + this.fmts.size; this.fmts.set(f, id); }
    return id;
  }

  private fontId(s: XfSpec) {
    const key = `${s.b ? 1 : 0}|${s.i ? 1 : 0}|${s.sz || 10}|${s.color || ''}`;
    let i = this.fonts.findIndex(f => `${f.b ? 1 : 0}|${f.i ? 1 : 0}|${f.sz || 10}|${f.color || ''}` === key);
    if (i < 0) { this.fonts.push(s); i = this.fonts.length - 1; }
    return i;
  }

  private fillId(color?: string) {
    if (!color) return 0;
    let i = this.fills.indexOf(color);
    if (i < 0) { this.fills.push(color); i = this.fills.length - 1; }
    return i + 2;
  }

  private borderId(s: XfSpec) {
    const kind = s.bottom ? 'b' : s.top ? 't' : '';
    let i = this.borders.indexOf(kind);
    if (i < 0) { this.borders.push(kind); i = this.borders.length - 1; }
    return i;
  }

  toXml() {
    // Every xf has to be resolved before the tables it points into can be counted and
    // written: an xf adds its font, fill, border and number format as it is built.
    const xfs = this.xfs.map(s => {
      const alignment = (s.align || s.wrap)
        ? `<alignment${s.align ? ` horizontal="${s.align === 'r' ? 'right' : 'center'}"` : ''}` +
          `${s.wrap ? ' wrapText="1"' : ''}/>` : '';
      const xf = `<xf xfId="0" fontId="${this.fontId(s)}" fillId="${this.fillId(s.fill)}"` +
        ` borderId="${this.borderId(s)}" numFmtId="${this.fmtId(s.fmt)}" applyFont="1" applyFill="1"` +
        ` applyBorder="1"${s.fmt ? ' applyNumberFormat="1"' : ''}${alignment ? ' applyAlignment="1"' : ''}`;
      return alignment ? `${xf}>${alignment}</xf>` : `${xf}/>`;
    }).join('');
    const numFmts = [...this.fmts.entries()];
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<styleSheet xmlns="${NS}">` +
      (numFmts.length
        ? `<numFmts count="${numFmts.length}">${numFmts.map(([f, id]) =>
          `<numFmt numFmtId="${id}" formatCode="${xml(f)}"/>`).join('')}</numFmts>` : '') +
      `<fonts count="${this.fonts.length || 1}">${this.fonts.map(f =>
        // No theme part ships, so the default ink is written out rather than pointed at
        // theme index 1 — a theme colour with no theme is one more thing to explain away.
        `<font>${f.b ? '<b/>' : ''}${f.i ? '<i/>' : ''}<sz val="${f.sz || 10}"/>` +
        `<color rgb="FF${hex(f.color || '#000000')}"/>` +
        `<name val="Manrope"/><family val="2"/></font>`).join('') || '<font><sz val="10"/><name val="Manrope"/></font>'}</fonts>` +
      `<fills count="${this.fills.length + 2}"><fill><patternFill patternType="none"/></fill>` +
      `<fill><patternFill patternType="gray125"/></fill>` +
      this.fills.map(c => `<fill><patternFill patternType="solid"><fgColor rgb="FF${hex(c)}"/>` +
        `<bgColor indexed="64"/></patternFill></fill>`).join('') + '</fills>' +
      `<borders count="${this.borders.length || 1}">` +
      (this.borders.length ? this.borders.map(k =>
        `<border>${k === 'b' ? '<bottom style="thin"><color rgb="FFD7DDE6"/></bottom>' : ''}` +
        `${k === 't' ? '<top style="medium"><color rgb="FF1E88E5"/></top>' : ''}</border>`).join('')
        : '<border><left/><right/><top/><bottom/><diagonal/></border>') + '</borders>' +
      `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
      `<cellXfs count="${this.xfs.length}">${xfs}</cellXfs>` +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
      '</styleSheet>';
  }
}

export interface ExcelOpts<T> {
  title: string;
  subtitle?: string;
  org?: string;
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  style?: ExcelStyle;
  // Left out, the accent of the design saved for printing is used, so the workbook and the
  // paper the same list prints on match.
  accent?: string;
  landscape?: boolean;
  // The asks the register was cut by, one labelled fact per line, and who drew the file —
  // a workbook forwarded by mail has to say what it is answering without anyone asking.
  meta?: (string | undefined | false)[];
  printedBy?: string;
  // The same hierarchy the paper carries: a group head, a sub-group, a closing figure.
  rowClass?: (row: T) => string;
}

// Excel's own paper codes; the workbook prints on the sheet the design names.
const PAPER_CODE: Record<string, string> = { A4: '9', A5: '11', Letter: '1' };

// Excel's own print header and footer are a mini-language: `&` opens a code, so a title that
// carries one has to double it or the rest of the line is read as a command.
const hf = (v: string) => xml(v.replace(/&/g, '&&'));

export function buildExcel<T>(o: ExcelOpts<T>): { xml: string }[] {
  const style = o.style ?? 'branded';
  const design = resolveDesign();
  const accent = o.accent || design.accent;
  const s = new Styles();
  const branded = style === 'branded';
  const zebra = branded ? '#F4F7FB' : undefined;
  const band = branded ? '#E7ECF4' : undefined;

  const stTitle = s.id({ b: 1, sz: 16, color: branded ? accent : '#111827' });
  const stWhat = s.id({ b: 1, sz: 11, color: '#111827' });
  const stSub = s.id({ sz: 10, color: '#6B7280' });
  const stHead = s.id({ b: 1, sz: 10, color: '#FFFFFF', fill: branded ? accent : '#334155', bottom: 1, align: 'c', wrap: 1 });
  const stHeadR = s.id({ b: 1, sz: 10, color: '#FFFFFF', fill: branded ? accent : '#334155', bottom: 1, align: 'r', wrap: 1 });
  const stText = s.id({ sz: 10, bottom: 1 });
  const stTextZ = s.id({ sz: 10, bottom: 1, fill: zebra });
  const stRight = (fmt: string) => s.id({ sz: 10, bottom: 1, align: 'r', fmt });
  const stRightZ = (fmt: string) => s.id({ sz: 10, bottom: 1, align: 'r', fmt, fill: zebra });
  // A group head is a row the reader scans for orientation, not a row of data: it carries
  // its own fill and outranks the standing zebra, exactly as the band does on paper.
  const stBandText = s.id({ b: 1, sz: 10, color: '#111827', fill: band, bottom: 1 });
  const stBandNum = (fmt: string) => s.id({ b: 1, sz: 10, color: '#111827', fill: band, bottom: 1, align: 'r', fmt });
  const stGroupText = s.id({ b: 1, sz: 10, bottom: 1 });
  const stGroupNum = (fmt: string) => s.id({ b: 1, sz: 10, bottom: 1, align: 'r', fmt });
  const stTotText = s.id({ b: 1, sz: 10, top: 1 });
  const stTotNum = (fmt: string) => s.id({ b: 1, sz: 10, top: 1, align: 'r', fmt });
  const stFoot = s.id({ sz: 9, color: '#6B7280' });

  const rows: string[] = [];
  let rowIndex = 1;
  // The title band spans the columns the sheet actually has: a merged range that reaches past
  // the dimension Excel works out for itself is a second way to be told the file is broken.
  const width = Math.max(1, o.columns.length);
  const blanks = (sid: number) => Array.from({ length: width - 1 },
    (_, n) => `<c r="${colLetter(n + 2)}${rowIndex}" s="${sid}"/>`).join('');
  const textCell = (sid: number, v: string) =>
    `<c r="A${rowIndex}" s="${sid}" t="inlineStr"><is><t xml:space="preserve">${xml(v)}</t></is></c>`;
  const push = (cells: string[]) => { rows.push(`<row r="${rowIndex}">${cells.join('')}</row>`); rowIndex++; };

  // A workbook that opens straight on a header row has no title to point at; the branded
  // and clean sheets carry their identity above it — the business, the report, and the asks
  // the register was cut by, one per line so each stays readable in a single glance.
  const cover: { sid: number; text: string }[] = style === 'plain' ? []
    : style === 'clean'
      ? [{ sid: stTitle, text: o.title }, ...(o.subtitle ? [{ sid: stSub, text: o.subtitle }] : [])]
      : [
        { sid: stTitle, text: o.org || 'Xenith ERP' },
        { sid: stWhat, text: `${o.title}${o.subtitle ? `  ·  ${o.subtitle}` : ''}` },
        ...(o.meta ?? []).filter(Boolean).map(m => ({ sid: stSub, text: String(m) }))
      ];
  const merged = cover.map((_, i) => i + 1);
  cover.forEach(line => push([textCell(line.sid, line.text), blanks(line.sid)]));
  if (cover.length) push([]);

  const headRow = rowIndex;
  push(o.columns.map((c, n) => {
    const ref = `${colLetter(n + 1)}${headRow}`;
    const sid = c.align === 'right' ? stHeadR : stHead;
    return `<c r="${ref}" s="${sid}" t="inlineStr"><is><t xml:space="preserve">${xml(c.label)}</t></is></c>`;
  }));

  o.rows.forEach((row, i) => {
    const kind = o.rowClass?.(row) ?? '';
    const z = branded && !kind && i % 2 === 1;
    push(o.columns.map((c, n) => {
      const ref = `${colLetter(n + 1)}${rowIndex}`;
      const raw = c.value(row);
      const num = asNumber(raw, c.align === 'right');
      // The row's own rank decides its face: a group head is filled, a sub-group is bold,
      // a closing figure carries the rule — the same three the paper uses.
      const sid = num
        ? kind === 'sh' ? stBandNum(num.fmt)
          : kind === 'sg' ? stGroupNum(num.fmt)
            : kind === 'total' ? stTotNum(num.fmt)
              : z ? stRightZ(num.fmt) : stRight(num.fmt)
        : kind === 'sh' ? stBandText
          : kind === 'sg' ? stGroupText
            : kind === 'total' ? stTotText
              : z ? stTextZ : stText;
      return num
        ? `<c r="${ref}" s="${sid}"><v>${num.v}</v></c>`
        : `<c r="${ref}" s="${sid}" t="inlineStr"><is><t xml:space="preserve">${xml(cell(raw))}</t></is></c>`;
    }));
  });

  // The filter covers the register's own rows and stops there: a grand total caught inside the
  // range is a row Excel can hide, and a total that can be hidden is a wrong answer.
  const lastDataRow = rowIndex - 1;
  if (o.footer?.some(v => v !== undefined && v !== '')) {
    const foot = rowIndex;
    push(o.columns.map((c, n) => {
      const v = o.footer?.[n];
      if (v === undefined || v === '') return `<c r="${colLetter(n + 1)}${foot}" s="${stTotText}"/>`;
      const num = asNumber(v, c.align === 'right');
      return num
        ? `<c r="${colLetter(n + 1)}${foot}" s="${stTotNum(num.fmt)}"><v>${num.v}</v></c>`
        : `<c r="${colLetter(n + 1)}${foot}" s="${stTotText}" t="inlineStr"><is><t xml:space="preserve">${xml(v)}</t></is></c>`;
    }));
  }

  // The line a workbook is traced back by: how many rows it holds and who drew it, so a
  // file forwarded by mail still says whose export it was and when.
  if (style !== 'plain') {
    const who = o.printedBy ? ` by ${o.printedBy}` : '';
    const line = `${o.rows.length.toLocaleString('en-US')} record${o.rows.length === 1 ? '' : 's'} · Exported ${
      new Date().toLocaleString()}${who} · Xenith ERP`;
    push([textCell(stFoot, line), blanks(stFoot)]);
    merged.push(rowIndex - 1);
  }
  const lastRow = rowIndex - 1;

  const widths = o.columns.map((c, n) => {
    const longest = Math.max(c.label.length, ...o.rows.slice(0, 400)
      .map(r => String(c.value(r) ?? '').length));
    return `<col min="${n + 1}" max="${n + 1}" width="${Math.min(46, Math.max(9, longest + 3))}" customWidth="1"/>`;
  }).join('');

  const lastCol = colLetter(width);
  const merges = width < 2 ? [] : merged;
  const paper = PAPER_CODE[design.prefs.paper] ?? '9';

  const sheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<worksheet xmlns="${NS}" xmlns:r="${RNS}">` +
    // fitToPage is what makes the fitToWidth below mean anything; without it Excel prints a
    // wide register across nine sheets of paper and hopes the reader staples them.
    `<sheetPr><tabColor rgb="FF${hex(accent)}"/><pageSetUpPr fitToPage="1"/></sheetPr>` +
    `<dimension ref="A1:${lastCol}${lastRow}"/>` +
    `<sheetViews><sheetView workbookViewId="0" showGridLines="${style === 'plain' ? 'true' : 'false'}">` +
    `<pane ySplit="${headRow}" topLeftCell="A${headRow + 1}" activePane="bottomLeft" state="frozen"/>` +
    `</sheetView></sheetViews>` +
    `<sheetFormatPr defaultRowHeight="15"/>` +
    `<cols>${widths}</cols>` +
    `<sheetData>${rows.join('')}</sheetData>` +
    `<autoFilter ref="A${headRow}:${lastCol}${lastDataRow}"/>` +
    (merges.length ? `<mergeCells count="${merges.length}">${
      merges.map(m => `<mergeCell ref="A${m}:${lastCol}${m}"/>`).join('')}</mergeCells>` : '') +
    `<pageMargins left="0.4" right="0.4" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>` +
    `<pageSetup paperSize="${paper}" orientation="${o.landscape ? 'landscape' : 'portrait'}" fitToWidth="1" fitToHeight="0"/>` +
    `<headerFooter><oddHeader>&amp;L&amp;"Manrope,Bold"${hf((o.org || 'Xenith ERP').toUpperCase())}` +
    `&amp;R&amp;"Manrope,Bold"${hf(o.title)}</oddHeader>` +
    `<oddFooter>&amp;L&amp;"Manrope,Regular"${hf(
      `${o.rows.length.toLocaleString('en-US')} record${o.rows.length === 1 ? '' : 's'}`
    )}&amp;C&amp;"Manrope,Regular"Page &amp;P of &amp;N&amp;R&amp;"Manrope,Regular"${hf(o.printedBy || 'Xenith ERP')}</oddFooter>` +
    `</headerFooter>` +
    `</worksheet>`;

  const sheetName = (o.title || 'Report').replace(/[\\/*?:[\]]/g, '').slice(0, 28) || 'Report';
  const stamp = new Date().toISOString().slice(0, 19);

  return [
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
      `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
      `<Default Extension="xml" ContentType="application/xml"/>` +
      `<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` +
      `<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>` +
      `<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
      `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
      `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
      `</Types>` },
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
      `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>` +
      `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
      `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
      `</Relationships>` },
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ` +
      `xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ` +
      `xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
      `<dc:title>${xml(o.title)}</dc:title><dc:creator>${xml(o.org || 'Xenith ERP')}</dc:creator>` +
      `<cp:lastModifiedBy>${xml(o.printedBy || o.org || 'Xenith ERP')}</cp:lastModifiedBy>` +
      (o.meta?.filter(Boolean).length
        ? `<dc:subject>${xml(o.meta.filter(Boolean).map(String).join(' · '))}</dc:subject>` : '') +
      `<dcterms:created xsi:type="dcterms:W3CDTF">${stamp}Z</dcterms:created>` +
      `<dcterms:modified xsi:type="dcterms:W3CDTF">${stamp}Z</dcterms:modified>` +
      `</cp:coreProperties>` },
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">` +
      `<Application>Xenith ERP</Application><Company>${xml(o.org || '')}</Company>` +
      `</Properties>` },
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      // CT_Workbook is an ordered sequence: workbookPr has to sit before sheets, and Excel 2016+
      // refuses the whole package rather than tolerate the swap.
      `<workbook xmlns="${NS}" xmlns:r="${RNS}"><workbookPr defaultThemeVersion="166925"/><sheets>` +
      `<sheet name="${xml(sheetName)}" sheetId="1" r:id="rId1"/>` +
      `</sheets></workbook>` },
    { xml: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
      `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
      `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>` +
      `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
      `</Relationships>` },
    { xml: s.toXml() },
    { xml: sheet }
  ];
}

// Part order matters only to the reader; these are the paths inside the zip.
const PART_PATHS = [
  '[Content_Types].xml', '_rels/.rels', 'docProps/core.xml', 'docProps/app.xml',
  'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/worksheets/sheet1.xml'
];

const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

const crc32 = (b: Uint8Array) => {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
};

/** Entries are stored, not deflated: the XML compresses poorly for the code it would cost. */
function zipStore(parts: { path: string; data: Uint8Array<ArrayBuffer> }[]): BlobPart[] {
  const now = new Date();
  const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
  const dosDate = ((Math.max(1980, now.getFullYear()) - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  const chunks: BlobPart[] = [];
  const central: number[] = [];
  let offset = 0;

  const u16 = (n: number) => [n & 255, (n >> 8) & 255];
  const u32 = (n: number) => [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255];
  const bytes = (a: number[]) => Uint8Array.from(a);

  for (const p of parts) {
    const name = bytes(Array.from(new TextEncoder().encode(p.path)));
    const crc = crc32(p.data);
    const head = bytes([
      ...u32(0x04034b50), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(dosTime), ...u16(dosDate),
      ...u32(crc), ...u32(p.data.length), ...u32(p.data.length), ...u16(name.length), ...u16(0)
    ]);
    chunks.push(head, name, p.data);
    central.push(...[
      ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(dosTime), ...u16(dosDate),
      ...u32(crc), ...u32(p.data.length), ...u32(p.data.length), ...u16(name.length),
      ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)
    ], ...Array.from(name));
    offset += head.length + name.length + p.data.length;
  }

  const cd = bytes(central);
  const eocd = bytes([
    ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(parts.length), ...u16(parts.length),
    ...u32(cd.length), ...u32(offset), ...u16(0)
  ]);
  chunks.push(cd, eocd);
  return chunks;
}

// The workbook as the bytes a file holds, standing apart from the download so the sheet a
// client saves and the sheet the server reads back are the same thing — a test can feed these
// very bytes through the bulk upload and prove the two halves of the app speak one format.
export function excelBytes<T>(o: ExcelOpts<T>): Uint8Array<ArrayBuffer> {
  const enc = new TextEncoder();
  const parts = buildExcel(o).map((p, i) => ({ path: PART_PATHS[i], data: enc.encode(p.xml) }));
  const chunks = zipStore(parts) as Uint8Array[];
  const total = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const c of chunks) { out.set(c, at); at += c.length; }
  return out;
}

export function downloadExcel<T>(filename: string, o: ExcelOpts<T>) {
  const blob = new Blob([excelBytes(o)], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename.replace(/\.csv$/, '')}-${isoDay()}.xlsx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
