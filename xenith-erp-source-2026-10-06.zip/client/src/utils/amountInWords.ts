// Printed bills and credit notes close with the chargeable amount spelled out, and the
// local convention groups by lakh and crore rather than by thousand and million. The server's
// own /api/utils/number-to-words follows the same reading, so a figure checked on screen and the
// figure signed on paper are the same words.

const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen',
  'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
// The names above the hundreds, indexed by the pair they carry: the digits left of the last
// three are read in twos from the right — Thousand, Lakh, Crore, Arab.
const SCALES = ['', 'Thousand', 'Lakh', 'Crore', 'Arab', 'Kharab'];

const under100 = (n: number): string =>
  n < 20 ? ONES[n] : [TENS[Math.floor(n / 10)], n % 10 ? ONES[n % 10] : ''].filter(Boolean).join(' ');

const under1000 = (n: number): string => {
  const h = Math.floor(n / 100), r = n % 100;
  return [h ? `${ONES[h]} Hundred` : '', r ? `${h ? 'and ' : ''}${under100(r)}` : ''].filter(Boolean).join(' ');
};

const said = (n: number): string => {
  const digits = String(n);
  const head = digits.length > 3 ? digits.slice(0, -3) : '';
  const pairs: number[] = [];
  for (let i = head.length; i > 0; i -= 2) pairs.unshift(Number(digits.slice(Math.max(0, i - 2), i)));
  const tail = Number(digits.slice(-3));
  return [...pairs.map((p, i) => p ? `${under100(p)} ${SCALES[pairs.length - i]}` : ''),
    tail ? under1000(tail) : ''].filter(Boolean).join(' ');
};

export function amountInWords(amount: number, currency = 'Rupees'): string {
  const value = Number.isFinite(Number(amount)) ? Number(amount) : 0;
  const abs = Math.abs(value);
  let whole = Math.floor(abs);
  let paisa = Math.round((abs - whole) * 100);
  // Paisa that rounds up into a rupee is written as the rupee it became, so the words never
  // disagree with the rounded figure printed beside them.
  if (paisa >= 100) { whole += 1; paisa -= 100; }
  // Past 99 Kharab the numbering has no name left for a group; the figure beats a wrong word.
  if (whole > 99999999999999) return `${currency} ${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} Only`;

  // A figure under a rupee still has a rupees line to write, or fifty paisa on their own print
  // as "and Fifty Paisa Only" — an "and" with nothing before it on a signed paper.
  const words = [
    value < 0 ? 'Minus' : '',
    `${said(whole) || 'Zero'} ${currency}`,
    paisa ? `and ${said(paisa)} Paisa` : ''
  ].filter(Boolean).join(' ');
  return `${words} Only`;
}
