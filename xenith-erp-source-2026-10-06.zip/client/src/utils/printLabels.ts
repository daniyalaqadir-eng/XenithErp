import { PosTemplate } from '../services/pos.service';
import { esc } from './exportTable';
import { FONT_LINK, FONT_STACK, fontsReady } from './printDesigns';

export interface LabelItem {
  name: string;
  sku: string;
  price: number;
  taxPct?: number;
  expiry?: string;
}

// One template and the products cut from it. Several sheets go to the printer together,
// each keeping its own sticker size, so mixed label stocks print in one job.
export interface LabelSheet {
  tpl: PosTemplate;
  items: LabelItem[];
}

// The bar/QR artwork is only as real as the code behind it, but a stable pattern per
// code keeps the proof sheet identical between previews and prints.
export const barsOf = (seed: string, count: number) => {
  let h = 2166136261;
  for (const ch of seed) h = (h ^ ch.charCodeAt(0)) * 16777619 >>> 0;
  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    h = (h * 1103515245 + 12345) >>> 0;
    out.push(1 + (h >>> 27) % 3);
  }
  return out;
};

const mm = (v: number, min: number) => `${Math.max(min, Math.round(v || 0))}mm`;

const barcodeArt = (code: string) => {
  let x = 0;
  return barsOf(code, 42).map((bw, i) => {
    const el = i % 2 === 0 ? `<rect x="${x}" y="0" width="${bw}" height="26" fill="#111"/>` : '';
    x += bw + 0.6;
    return el;
  }).join('');
};

const qrArt = (code: string) =>
  barsOf(code, 21 * 21).map((v, i) => (v % 2 === 0
    ? `<rect x="${i % 21}" y="${Math.floor(i / 21)}" width="1" height="1" fill="#111"/>` : '')).join('');

const label = (t: PosTemplate, item: LabelItem, company: string) => {
  const code = `${t.prefix || ''}${item.sku}${t.suffix || ''}`;
  const price = t.priceLabel === 'Gross Price' ? item.price * 1.18 : item.price;
  const artH = mm(Math.max(6, Math.round((t.paperHeight || 30) * (t.kind === 'QR Code' ? 0.42 : 0.3))), 6);
  const art = t.kind === 'QR Code'
    ? `<svg viewBox="0 0 21 21" class="qr" style="height:${artH}">${qrArt(code)}</svg>`
    : `<svg viewBox="0 0 100 26" preserveAspectRatio="none" style="height:${artH}">${barcodeArt(code)}</svg>`;
  return `
    <div class="label" style="width:${mm(t.paperWidth, 10)};height:${mm(t.paperHeight, 8)};padding:${mm(t.margin ?? 2, 0)}">
      ${t.headerText ? `<div class="c b">${esc(t.headerText)}</div>` : ''}
      ${t.showCompany ? `<div class="c">${esc(company)}</div>` : ''}
      ${art}
      <div class="c mono">${esc(code)}</div>
      ${t.showName ? `<div class="t">${esc(item.name)}</div>` : ''}
      ${t.showSku ? `<div class="t dim">SKU: ${esc(item.sku)}</div>` : ''}
      ${t.showPrice ? `<div class="t b">PKR ${price.toLocaleString()}</div>` : ''}
      ${t.showTax ? `<div class="t dim">Incl. tax ${item.taxPct ?? 0}%</div>` : ''}
      ${t.showExpiry && item.expiry ? `<div class="t dim">EXP ${esc(item.expiry)}</div>` : ''}
      ${t.footerText ? `<div class="c">${esc(t.footerText)}</div>` : ''}
    </div>`;
};

const sheet = (s: LabelSheet, company: string) => {
  const copies = Math.max(1, Math.round(s.tpl.copies || 1));
  const cells = s.items.flatMap(item =>
    Array.from({ length: copies }, () => label(s.tpl, item, company))).join('');
  // Font size belongs to the sheet, not the page, because the sheets can differ.
  return `<div class="page" style="font-size:${Math.max(5, s.tpl.fontSize || 8)}pt">
    <div class="sheet">${cells}</div>
  </div>`;
};

// Labels are cut to the template's own millimetres, so the proof is the size that goes on
// the printer — a 50 × 30 sticker scaled to A4 would not fit the shelf tag.
export function printLabels(sheets: LabelSheet[], company: string) {
  const pages = sheets.filter(s => s.tpl && s.items.length).map(s => sheet(s, company)).join('');
  if (!pages) return;
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  const doc = frame.contentDocument;
  if (!doc) { frame.remove(); return; }
  doc.open();
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>Barcode labels</title>${FONT_LINK}<style>
    *{box-sizing:border-box}
    body{margin:0;font-family:${FONT_STACK};color:#111;font-variant-numeric:tabular-nums}
    .page{page-break-after:always}
    .page:last-child{page-break-after:auto}
    .sheet{display:flex;flex-wrap:wrap}
    .label{overflow:hidden;display:flex;flex-direction:column;justify-content:space-between;
      line-height:1.2;page-break-inside:avoid}
    svg{display:block;width:100%}
    .qr{width:auto;max-width:100%;margin:0 auto}
    .c{text-align:center;white-space:nowrap;overflow:hidden}
    .b{font-weight:700}
    .dim{opacity:.7}
    .mono{font-family:"Consolas","Courier New",monospace;letter-spacing:-.02em}
    .t{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    @page{margin:0}
  </style></head><body>${pages}</body></html>`);
  doc.close();
  const win = frame.contentWindow;
  const run = () => {
    win?.focus();
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      try { frame.remove(); } catch {}
    };
    if (win) {
      win.onafterprint = cleanup;
      win.print();
    }
    window.setTimeout(cleanup, 60000);
  };
  fontsReady(doc).then(() => {
    if (win && doc.readyState !== 'complete') win.addEventListener('load', run, { once: true });
    else window.setTimeout(run, 60);
  });
}
