import { CompanyProfile } from '../services/settings.service';
import {
  FONT_LINK, PAGE_PAD_MM, PrintPrefs, ResolvedDesign, fontsReady, gridFooter, gridHeader,
  gridHeaderCss, pageBoxPx, resolveDesign, runFoot, themeCss
} from './printDesigns';

export interface ExportColumn<T> {
  label: string;
  value: (row: T) => string | number;
  align?: 'left' | 'right';
  // A column whose content is a name, a narration or anything a clerk may write long. Only
  // these are allowed a second line on paper — a date or a figure that wraps mid-token is a
  // mis-read waiting to happen, so every other column is held to one line and fitted.
  wrap?: boolean;
}

export const esc = (v: unknown) => String(v ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// A totals line lined up with the columns it sits under: pass the column count and the
// cells that carry a figure, keyed by their column index.
export const footerRow = (n: number, cells: Record<number, string>) =>
  Array.from({ length: n }, (_, i) => cells[i] ?? '');

export interface PrintOpts {
  title: string;
  subtitle?: string;
  org?: string;
  landscape?: boolean;
  // A report like the Business Summary draws its own cover and panels instead of the
  // generic brand header, so it hands over the markup and the rules it needs.
  headerHtml?: string;
  css?: string;
  footRight?: string;
  // "Page 1 of N" needs the real page count, which only exists once the sheet is laid out.
  pager?: boolean;
  // The company whose letterhead the paper carries, and the design it is printed in — the
  // template the company set for this surface in Settings, or the saved default.
  company?: Partial<CompanyProfile>;
  design?: Partial<PrintPrefs>;
  // What the sheet was cut by, as labelled facts. They print in their own strip under the
  // letterhead so a register carried out of the shop says what it is answering.
  meta?: (string | undefined | false)[];
  // The stamp a report sheet carries under its letterhead: which filing it is, the window it was
  // cut for, and the four figures the reader looks for first.
  filing?: string;
  windowBlock?: string;
  cards?: { label: string; value: string; hot?: boolean }[];
  printedBy?: string;
}

// The whole sheet as one string, with no part of it touched by the browser that prints it.
// Kept apart from the frame that carries it so the same paper a clerk sends to the printer can
// be laid out on a screen, saved as a PDF, or read back by a test without a dialog in the way.
export const sheetHtml = (opts: PrintOpts, bodyHtml: string, footLeft: string, design: ResolvedDesign) => {
  const printedAt = opts.footRight?.replace(/^Printed /, '') || new Date().toLocaleString();
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(opts.title)}</title>${FONT_LINK}<style>
    ${themeCss(design)}
    ${gridHeaderCss(design)}
    h2{font-size:11px;margin:16px 0 5px;color:${design.accent};text-transform:uppercase;letter-spacing:.05em}
    /* The line a band is named after: a register printed in blocks carries one of these above
       each document. It is the darkest line on the paper on purpose — the reference sheet the
       reader works from puts the group's own figures on it, so it has to outrank the rows under
       it rather than read as one more tinted strip. */
    .band-name{background:var(--ink)!important;color:#fff;font-weight:800;font-size:10px;
      letter-spacing:.05em;border:0}
    td.band-name{background:var(--ink)!important;color:#fff;padding:5px 8px;white-space:normal;
      border-top:1.5px solid var(--ac);font-variant-numeric:tabular-nums}
    td.band-name .bw{display:flex;justify-content:space-between;align-items:baseline;gap:10px 14px;flex-wrap:wrap}
    td.band-name .bn{text-transform:uppercase;font-weight:800}
    td.band-name .bf{font-size:calc(var(--fs,9.5px) - .5px);font-weight:700;letter-spacing:.02em;opacity:.92}
    /* The column head a band carries inside itself, so a reader lost in the third group of the
       day never has to look back up the sheet for what a column is. */
    tr.colh th{background:var(--band)!important;color:var(--mu);border-bottom:1px solid var(--ac);
      font-size:calc(var(--fs,9.5px) - 1.2px)}
    ${opts.css ?? ''}
  </style></head><body>
    ${opts.headerHtml ?? gridHeader(design, {
      org: opts.org, title: opts.title, subtitle: opts.subtitle, company: opts.company,
      meta: opts.meta, printedBy: opts.printedBy, printedAt,
      filing: opts.filing, windowBlock: opts.windowBlock, cards: opts.cards
    })}
    ${bodyHtml}
    ${gridFooter(design, {
      left: footLeft, company: opts.company, printedAt, printedBy: opts.printedBy
    })}
  </body></html>`;
};

const printShell = (
  opts: PrintOpts, build: (design: ResolvedDesign) => string, footLeft: string
) => {
  const design = resolveDesign({
    ...opts.design,
    // A wide register is landscape because of its own data, which outranks a preference:
    // no design choice makes a 20-column stock ledger readable in portrait.
    landscape: opts.landscape ?? opts.design?.landscape ?? false
  });
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  const doc = frame.contentDocument;
  if (!doc) { frame.remove(); return; }
  const showPager = design.prefs.pageNumber || !!opts.pager;
  doc.open();
  doc.write(sheetHtml(opts, build(design), footLeft, design));
  doc.close();
  const win = frame.contentWindow;
  const run = () => {
    // The frame is collapsed to 0x0 so it never flashes on screen, but that also makes its
    // layout meaningless. Widening it to the printed page (still 0 tall, so still invisible)
    // is what lets the content be measured — first for the fit, then for the page count.
    let box = pageBoxPx(design.prefs);
    frame.style.width = `${box.w}px`;
    let fits = fitTable(doc, box.w);
    // A register that will not sit inside the margins at a readable size is wider than the
    // paper, not than the design: turn the sheet round rather than print the last three
    // columns off the edge, where the clerk never sees them.
    if (!fits && !design.prefs.landscape && design.prefs.paper !== 'Receipt') {
      const style = doc.createElement('style');
      style.textContent = `@page{size:${design.prefs.paper || 'A4'} landscape;margin:${PAGE_PAD_MM}mm}`;
      doc.head.appendChild(style);
      design.prefs.landscape = true;
      box = pageBoxPx(design.prefs);
      frame.style.width = `${box.w}px`;
      fits = fitTable(doc, box.w);
    }
    if (showPager) {
      // Every page carries its own repeated column head and running foot, so the room left for
      // rows is the sheet minus those two — and a little more, because a page that lands a row
      // short of the break is a clean sheet while one row over is a stray line on the next page.
      const table = doc.querySelector('table');
      const repeat = (table?.querySelector('thead')?.offsetHeight ?? 0)
        + (table?.querySelector('tfoot')?.offsetHeight ?? 0);
      // A thermal roll has no page to break on — the paper is cut when the printing stops —
      // so counting "pages" for it would only state a number the clerk cannot check.
      const roll = design.prefs.paper === 'Receipt';
      const usable = Math.max(120, (box.h - repeat) * 0.97);
      const h = Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight);
      const pages = roll ? 1 : Math.max(1, Math.ceil((h - repeat) / usable));
      doc.querySelectorAll('[data-pages]').forEach(el => {
        el.textContent = `${pages} page${pages === 1 ? '' : 's'}`;
      });
    }
    win?.focus();
    win?.print();
    // The dialog stays open until the clerk answers it, and the spooler keeps reading this
    // document while it does. Tearing the frame down on a short timer has handed a queue a
    // blank sheet on a slow machine, so it goes when printing is over — with a ceiling for
    // the browser that never fires the event.
    let dropped = false;
    const drop = () => { if (dropped) return; dropped = true; frame.remove(); };
    win?.addEventListener('afterprint', drop, { once: true });
    window.setTimeout(drop, 30000);
  };
  // Web fonts are declared in the print document itself, so they have to be fetched before
  // the sheet is handed to the printer — with a ceiling, because a machine with no internet
  // must still print, just in the fallback face. The fit is measured after them, because a
  // register that fits in the fallback face can overflow in the real one.
  fontsReady(doc).then(() => {
    // The iframe needs one paint before print() picks up the stylesheet.
    if (win && doc.readyState !== 'complete') win.addEventListener('load', run, { once: true });
    else window.setTimeout(run, 60);
  });
};

/**
 * A register is printed at the size it was designed for until its own columns say otherwise:
 * the sheet is measured against the page, and a table wider than the paper is stepped down —
 * type first, then the room between cells — until it sits inside the margins. Nothing wraps
 * mid-figure to make the fit, and a register that will not fit at a readable size at all keeps
 * the smallest step and lets the clerk turn it to landscape or drop a column.
 */
const fitTable = (doc: Document, pageW: number): boolean => {
  const table = doc.querySelector('table') as HTMLTableElement | null;
  if (!table) return true;
  const root = doc.documentElement;
  const steps = [[9.5, 5], [9, 4.5], [8.5, 4], [8, 3.5], [7.5, 3]] as const;
  for (const [fs, pad] of steps) {
    root.style.setProperty('--fs', `${fs}px`);
    root.style.setProperty('--pad', `${pad}px`);
    if (table.scrollWidth <= pageW + 1) return true;
  }
  return false;
};

// A line register reads one document at a time, so its paper has to say which document each
// line belongs to and close that block with its own figures — the way the screen lays it out.
export interface PrintBand<T> {
  heading: string;
  rows: T[];
  // The band's figures, worded for the dark line that names it ("Gross : 12,300 · Net : 11,000").
  totals?: string;
  // The same figures once more, this time standing in the columns they belong to, so a reader
  // can run a column down the bands and add them in their head. The word naming the line rides
  // in whichever cell the caller left for it.
  totalCells?: (string | undefined)[];
}

const rowHtml = <T,>(columns: ExportColumn<T>[], r: T, rowClass?: (row: T) => string) => {
  const right = (c: ExportColumn<T>) => (c.align === 'right' ? 'right' : 'left');
  const cls = rowClass?.(r) ?? '';
  return `<tr${cls ? ` class="${cls}"` : ''}>${columns.map(c =>
    `<td class="${c.wrap ? 'w' : ''}" style="text-align:${right(c)}">${esc(c.value(r))}</td>`).join('')}</tr>`;
};

const totalRowHtml = <T,>(columns: ExportColumn<T>[], footer?: (string | undefined)[]) => {
  const right = (c: ExportColumn<T>) => (c.align === 'right' ? 'right' : 'left');
  return footer?.some(v => v !== undefined && v !== '')
    ? `<tr class="total">${columns.map((c, i) =>
      `<td class="${c.wrap ? 'w' : ''}" style="text-align:${right(c)}">${esc(footer?.[i] ?? '')}</td>`).join('')}</tr>`
    : '';
};

// The register's own table, shared by the printer and by anything that lays the same paper out
// without feeding a machine. `tfoot` is the strip repeated at the foot of every page; it comes
// in already built because it belongs to the design, not to the rows. `rowClass` lets a screen
// say which of its rows are group heads and which are the closing figure, so the paper carries
// the same hierarchy the reader saw on screen.
export const tableHtml = <T,>(
  columns: ExportColumn<T>[], rows: T[], footer?: (string | undefined)[], bands?: PrintBand<T>[],
  footHtml?: string, rowClass?: (row: T) => string
) => {
  const right = (c: ExportColumn<T>) => (c.align === 'right' ? 'right' : 'left');
  const head = columns.map(c => `<th class="${c.wrap ? 'w' : ''}" style="text-align:${right(c)}">${esc(c.label)}</th>`).join('');
  const tf = footHtml ?? '';
  if (!bands) return `<table class="reg"><thead><tr>${head}</tr></thead><tbody>${
    rows.map(r => rowHtml(columns, r, rowClass)).join('')}${totalRowHtml(columns, footer)}</tbody>${tf}</table>`;
  const foot = totalRowHtml(columns, footer);
  const bandHead = (b: PrintBand<T>) =>
    `<tr><td colspan="${columns.length}" class="band-name"><span class="bw"><span class="bn">${esc(b.heading)
    }</span>${b.totals ? `<span class="bf">${esc(b.totals)}</span>` : ''}</span></td></tr>`;
  const bodies = bands.map(b => {
    // The band's own figures ride twice: worded along the dark line that names it, and once
    // more standing in the columns they belong to, which is how a reader checks a column
    // against the register's closing total without turning the page.
    const cells = (b.totalCells ?? []).map(v => v ?? '');
    return `<tbody>${bandHead(b)}${`<tr class="colh">${head}</tr>`}${
      b.rows.map(r => rowHtml(columns, r, rowClass)).join('')}${
      cells.length ? totalRowHtml(columns, cells)
        // A band that only wordes its figures has no cells to stand them in, so its foot keeps
        // the single right-run line the screen shows for it.
        : (b.totals ? `<tr class="total"><td colspan="${columns.length}" style="text-align:right">${esc(b.totals)}</td></tr>` : '')
    }</tbody>`;
  }).join('') + (foot ? `<tbody>${foot}</tbody>` : '');
  return `<table class="reg"><thead><tr>${head}</tr></thead>${bodies}${tf}</table>`;
};

// What the paper holds, in words a clerk reads rather than a string a programmer writes.
const recordWord = (n: number) => `${n.toLocaleString('en-US')} record${n === 1 ? '' : 's'}`;

export function printTable<T>(opts: PrintOpts & {
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  bands?: PrintBand<T>[];
  // Wide tables (documents, stock ledgers) come out unreadable in portrait.
  landscape?: boolean;
  rowClass?: (row: T) => string;
}) {
  const count = opts.bands ? opts.bands.reduce((s, b) => s + b.rows.length, 0) : opts.rows.length;
  const left = recordWord(count);
  printShell(opts, d => tableHtml(
    opts.columns, opts.rows, opts.footer, opts.bands,
    runFoot(d, {
      cols: opts.columns.length, title: opts.title,
      company: d.prefs.letterhead === 'none' ? undefined : opts.company, left
    }), opts.rowClass
  ), left);
}

export interface PrintSection<T> {
  heading?: string;
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  note?: string;
}

// A report like the Business Summary is several tables under one cover, so it prints as one
// sheet instead of one print dialogue per panel.
export function printSections(opts: PrintOpts & {
  sections: PrintSection<any>[];
}) {
  const count = opts.sections.reduce((s, x) => s + x.rows.length, 0);
  const left = recordWord(count);
  printShell(opts, d => opts.sections.map(sec =>
    `${sec.heading ? `<h2>${esc(sec.heading)}</h2>` : ''}${
      sec.rows.length
        ? tableHtml(sec.columns, sec.rows, sec.footer, undefined,
          runFoot(d, { cols: sec.columns.length, title: opts.title, company: opts.company, left }))
        : `<div class="empty">${esc(sec.note ?? 'There is no activity')}</div>`}`
  ).join(''), left);
}

// The escape hatch for reports that own their page: cover, panels and tables all come from
// the caller, so the sheet can be laid out exactly like the printed statement should read.
export function printSheet(opts: PrintOpts & { bodyHtml: string; footLeft?: string }) {
  printShell(opts, () => opts.bodyHtml, opts.footLeft ?? '');
}
