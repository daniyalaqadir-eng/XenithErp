import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

/**
 * A theme is only a set of surface colours: every card, table and input in the workspace
 * reads them from CSS variables, so switching paints the whole screen without touching a
 * single page. The accent colours of charts and status chips stay as their author chose.
 */
export interface ThemeDef {
  key: string;
  label: string;
  hint: string;
  /** The colour the picker shows for this theme. */
  swatch: string;
  /** A dark surface: the pale status tints are remapped for it in index.css. */
  night?: boolean;
}

export const THEMES: ThemeDef[] = [
  { key: 'light', label: 'Light', hint: 'Classic white workspace', swatch: '#ffffff' },
  { key: 'mist', label: 'Mist', hint: 'Cool grey surfaces', swatch: '#e4eaf2' },
  { key: 'graphite', label: 'Graphite', hint: 'Neutral slate grey', swatch: '#dbe1e8' },
  { key: 'sand', label: 'Sand', hint: 'Warm paper tone', swatch: '#f3e7d3' },
  { key: 'mocha', label: 'Mocha', hint: 'Coffee and taupe', swatch: '#e0d3c3' },
  { key: 'mint', label: 'Mint', hint: 'Fresh green tint', swatch: '#dcf0e6' },
  { key: 'rose', label: 'Blush', hint: 'Soft rose paper', swatch: '#f6dfe4' },
  { key: 'lilac', label: 'Lilac', hint: 'Quiet violet tint', swatch: '#e3d9f6' },
  { key: 'dark', label: 'Dark', hint: 'Low light for long shifts', swatch: '#1b2432', night: true },
  { key: 'midnight', label: 'Midnight', hint: 'Deep blue night mode', swatch: '#0f1b33', night: true },
  { key: 'noir', label: 'Noir', hint: 'Charcoal black', swatch: '#171a1f', night: true },
  { key: 'forest', label: 'Forest', hint: 'Deep green night mode', swatch: '#12211c', night: true }
];

const STORAGE_KEY = 'xenith_theme';

const storedTheme = () => {
  const saved = localStorage.getItem(STORAGE_KEY);
  return THEMES.some(t => t.key === saved) ? (saved as string) : 'light';
};

interface ThemeContextType {
  theme: string;
  setTheme: (key: string) => void;
  themes: ThemeDef[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState(storedTheme);

  // The attribute lives on <html> so the page behind the workspace, the scrollbars and
  // any portal'd panel all read the same set of variables. `data-night` is the shared
  // hook the pale-tint overrides hang on, so a new dark theme needs no extra CSS.
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    if (THEMES.find(t => t.key === theme)?.night) document.documentElement.dataset.night = '1';
    else delete document.documentElement.dataset.night;
  }, [theme]);

  const setTheme = useCallback((key: string) => {
    if (!THEMES.some(t => t.key === key)) return;
    localStorage.setItem(STORAGE_KEY, key);
    setThemeState(key);
  }, []);

  const value = useMemo(() => ({ theme, setTheme, themes: THEMES }), [theme, setTheme]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used inside ThemeProvider');
  return ctx;
};

/** The accents a page picks by hand are chosen against a white card, where a saturated hue
 *  reads as ink. On a night surface the same colour sinks into the dark, so each one has a
 *  lighter twin of its own family. A hue that is not listed — a chart series, the brand
 *  mark — is left exactly as its author wrote it. */
const NIGHT_INK: Record<string, string> = {
  '#1e88e5': '#7db8f7', '#1565c0': '#93c5fd', '#5f7cff': '#a5b4fc', '#845ec2': '#b79bf0',
  '#2ec4b6': '#5eead4', '#25a195': '#5eead4', '#1ba396': '#5eead4', '#178a80': '#5eead4',
  '#ff9f1c': '#ffbd5c', '#c77700': '#fcd34d', '#e63946': '#fca5a5', '#dc2626': '#fca5a5',
  '#d81b60': '#f9a8d4', '#f7b32b': '#ffd166'
};

/** The same table read the other way. These hand-picked hues were lifted off a mock drawn
 *  on pure white, and a brand teal or a light indigo is 2 to 3.5:1 as 11px text — so a day
 *  theme steps each one down to the member of its family that clears 4.5:1. The depth is
 *  measured against the warmest tinted panel in the theme set rather than white, since a
 *  value that only passes on white sinks on a sand or mocha card. The hue never changes,
 *  only its depth: a pink heading stays pink. */
const DAY_INK: Record<string, string> = {
  '#1e88e5': '#1358a8', '#1565c0': '#1358a8', '#5f7cff': '#4338ca', '#845ec2': '#6b21a8',
  '#2ec4b6': '#0f7268', '#25a195': '#0f7268', '#1ba396': '#0f7268', '#178a80': '#0f7268',
  '#ff9f1c': '#9c4807', '#f7b32b': '#8c5406', '#c77700': '#9a3412',
  '#e63946': '#b91c1c', '#dc2626': '#b91c1c', '#d81b60': '#be185d'
};

/** Resolve a hand-picked accent for the surface it is about to be painted on, so text and
 *  icons keep their colour family but stay readable in every theme. */
export const useInk = () => {
  const { theme } = useTheme();
  const night = !!THEMES.find(t => t.key === theme)?.night;
  const map = night ? NIGHT_INK : DAY_INK;
  return (colour?: string) => (colour ? map[colour.toLowerCase()] ?? colour : colour);
};
