import React, { createContext, useCallback, useContext, useState, useEffect } from 'react';
import { Branch } from '../types';
import { useAuth } from './AuthContext';

interface TenantContextType {
  tenantSlug: string;
  branchId: number;
  tenantName: string;
  /** Every branch in the company. */
  allBranches: Branch[];
  /** Branches the signed-in user may work in. */
  branches: Branch[];
  enableBranch: boolean;
  displayTaxAuthorityNumber: boolean;
  currency: string;
  /** Whether this login may change what the company was sold — the vendor's act. */
  canSetSubscription: boolean;
  setBranchId: (id: number) => void;
  setCompany: (slug: string, name: string) => void;
  refreshBranches: () => void;
  setBranchEnabled: (enabled: boolean) => void;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export const TenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, setLicensedScreens } = useAuth();
  // Whose book this session is in comes from the sign-in, not from a name written into this
  // file: an installation can hold several companies, and a user belongs to exactly one of them.
  const [tenantSlug, setTenantSlug] = useState(user?.companySlug || '');
  const [branchId, setBranchId] = useState(user?.branchIds?.[0] ?? 38039);
  const [tenantName, setTenantName] = useState(user?.companyName || '');
  const [enableBranch, setEnableBranch] = useState(true);
  const [displayTaxAuthorityNumber] = useState(true);
  const [currency, setCurrency] = useState('PKR');
  // Who owns the sale is the server's answer, not a guess made from the role's ticks: with a
  // vendor key configured even the company's own owner is shown a plan he cannot edit.
  const [canSetSubscription, setCanSetSubscription] = useState(true);
  // The company the login opens holds one branch; the list is replaced by the server's answer
  // the moment it loads, so this only covers the first paint.
  const [allBranches, setAllBranches] = useState<Branch[]>([
    { id: 38039, name: 'Main Branch', code: 'BR-01', isMain: true }
  ]);
  const [reloadKey, setReloadKey] = useState(0);

  const refreshBranches = useCallback(() => setReloadKey(k => k + 1), []);

  // A sign-in, a stored session being re-read at boot and a registration all hand over the book
  // the account lives in. Following it here is what keeps every screen below pointed at the
  // company this cookie answers for — the server refuses any other one outright.
  useEffect(() => {
    const slug = user?.companySlug;
    if (!slug || slug === tenantSlug) return;
    setTenantSlug(slug);
    if (user?.companyName) setTenantName(user.companyName);
    const mine = user?.branchIds || [];
    if (mine.length && !mine.includes(branchId)) setBranchId(mine[0]);
  }, [user?.companySlug, user?.companyName, user?.branchIds, tenantSlug, branchId]);

  useEffect(() => {
    if (!tenantSlug) return;
    fetch(`/api/${tenantSlug}/${branchId}/branches`)
      .then(res => res.json())
      .then(data => { if (Array.isArray(data)) setAllBranches(data); })
      .catch(() => {});
  }, [tenantSlug, branchId, reloadKey]);

  // "Multiple branches" is a company switch, so it is read from the server.
  useEffect(() => {
    if (!tenantSlug) return;
    fetch(`/api/${tenantSlug}/${branchId}/tenant-info`)
      .then(res => res.json())
      .then(info => {
        if (typeof info?.enableBranch === 'boolean') setEnableBranch(info.enableBranch);
        if (info?.currency) setCurrency(info.currency);
        if (typeof info?.canSetSubscription === 'boolean') setCanSetSubscription(info.canSetSubscription);
        // The name the company is registered under, which is not the name in the seed.
        if (info?.tenantName) setTenantName(info.tenantName);
        // Whichever company is open, only the modules sold to it can be reached.
        setLicensedScreens(Array.isArray(info?.licensedScreens) ? info.licensedScreens : null);
      })
      .catch(() => setLicensedScreens(null));
  }, [tenantSlug, branchId, reloadKey, setLicensedScreens]);

  // A user may only work in the branches assigned to them. Branch ids are
  // per-company, so a user whose assignment does not cover this company
  // (a second or third company on the same login) sees all of them.
  const allowed = user?.branchIds?.length ? user.branchIds : null;
  const assigned = allowed ? allBranches.filter(b => allowed.includes(b.id)) : allBranches;
  const branches = assigned.length ? assigned : allBranches;

  // One switch moves every :tenant-scoped screen onto the new company.
  const setCompany = (slug: string, name: string) => {
    setTenantSlug(slug);
    setTenantName(name);
  };

  // Whichever company is open, the selected branch has to exist inside it.
  useEffect(() => {
    if (!allBranches.length) return;
    if (!allBranches.some(b => b.id === branchId)) setBranchId(branches[0]?.id ?? allBranches[0].id);
  }, [tenantSlug, allBranches]);

  return (
    <TenantContext.Provider
      value={{
        tenantSlug, branchId, tenantName, branches, allBranches, enableBranch,
        displayTaxAuthorityNumber, currency, canSetSubscription,
        setBranchId, setCompany, refreshBranches,
        setBranchEnabled: setEnableBranch
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (!context) throw new Error('useTenant must be used within TenantProvider');
  return context;
};
