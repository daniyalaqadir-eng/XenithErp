import React, { createContext, useCallback, useContext, useMemo, useState, useEffect } from 'react';
import { authService, AuthUser } from '../services/auth.service';

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  login: (identifier: string, password: string, company?: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  /** "<screen>:<action>" lookup against the signed-in user's role. */
  can: (permission: string) => boolean;
  /** Whether any screen inside a menu branch is visible, so the branch itself can show. */
  canModule: (module: string) => boolean;
  /** Screens the open company bought; roles may not reach past this. Null until it loads. */
  setLicensedScreens: (screens: string[] | null) => void;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  saveProfile: (patch: Partial<AuthUser>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = 'xenith_auth';
const LEGACY_KEY = 'xenith_auth';

function readStored(): { token: string; user: AuthUser } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    // A session saved before the roles upgrade has no screen permissions, and one saved before
    // a user belonged to a named company has no book to open. Both start over: an address that
    // is not known is worse than a login screen, because every request below it would be sent
    // to nobody's company.
    return Array.isArray(parsed?.user?.permissions) && Array.isArray(parsed?.user?.modules)
      && typeof parsed?.user?.companySlug === 'string' && parsed.user.companySlug
      ? parsed : null;
  } catch {
    return null;
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [stored] = useState(readStored);
  const [user, setUser] = useState<AuthUser | null>(stored?.user || null);
  const [token, setToken] = useState<string | null>(stored?.token || null);
  const [licensed, setLicensed] = useState<Set<string> | null>(null);

  const setLicensedScreens = useCallback((screens: string[] | null) => {
    setLicensed(screens ? new Set(screens) : null);
  }, []);

  useEffect(() => {
    localStorage.removeItem(LEGACY_KEY);
    if (token && user) localStorage.setItem(STORAGE_KEY, JSON.stringify({ token, user }));
    else localStorage.removeItem(STORAGE_KEY);
  }, [token, user]);

  // The stored user is a snapshot of the grants as they stood when someone signed in, so a
  // screen this build added would stay invisible to every open tab until that person happened
  // to sign out. The boot therefore reads the live copy once and adopts it.
  //  A 401 is answered differently from any other failure: the server has said this token is
  // dead, which also means the cached grants behind it cannot be trusted any more, so the
  // session is dropped and the login screen asks for it. Anything else — a server that is
  // still starting, a dropped request — leaves the session alone, because throwing away a
  // working sign-in over a hiccup is the worse mistake.
  useEffect(() => {
    if (!token) return;
    authService.session(token)
      .then(res => setUser(res.user))
      .catch((err: any) => {
        if (err?.status === 401) { setToken(null); setUser(null); }
      });
  }, []);

  const login = async (identifier: string, password: string, company?: string) => {
    const res = await authService.login(identifier, password, company);
    setToken(res.token); setUser(res.user);
  };

  const register = async (name: string, email: string, password: string) => {
    const res = await authService.register(name, email, password);
    setToken(res.token); setUser(res.user);
  };

  const logout = () => {
    if (token) authService.logout(token).catch(() => {});
    setToken(null); setUser(null);
  };

  // A role can only be ticked as far as the company was sold, so the licence trims
  // every check without rewriting the stored grants when a module lapses.
  const can = useCallback((permission: string) => {
    if (!user?.permissions?.includes(permission)) return false;
    // The vendor is the one who sets the sale, so a company's own purchase cannot trim his menus.
    if (user.isVendor || !licensed) return true;
    return licensed.has(permission.slice(0, permission.lastIndexOf(':')));
  }, [user, licensed]);
  const canModule = useCallback((module: string) => !!user?.modules?.includes(module), [user]);

  const changePassword = async (currentPassword: string, newPassword: string) => {
    if (!token) throw new Error('Sign in again to change your password');
    await authService.changePassword(token, currentPassword, newPassword);
  };

  const saveProfile = async (patch: Partial<AuthUser>) => {
    if (!token) throw new Error('Sign in again to update your profile');
    const res = await authService.updateProfile(token, patch);
    setUser(res.user);
  };

  const value = useMemo(
    () => ({ user, token, login, register, logout, can, canModule, setLicensedScreens, changePassword, saveProfile }),
    [user, token, can, canModule, setLicensedScreens, changePassword, saveProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
