export const ROUTE_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;
export type RouteDay = typeof ROUTE_DAYS[number];
export type RouteFrequency = 'Weekly' | 'Alternative days' | 'Fortnightly';

export interface RouteStop {
  customerId: number; day: RouteDay; time: string; note: string;
  customerName?: string; customerCode?: string; city?: string; phone?: string; address?: string; due?: number;
}

export interface WeeklyRoute {
  id: number; name: string; code: string;
  branchId: number; branchName: string;
  salesmanId: number | null; salesmanName: string;
  deliverymanId: number | null; deliverymanName: string;
  vehicleNumber: string; frequency: RouteFrequency;
  isActive: boolean; notes: string;
  days: Record<RouteDay, boolean>;
  daysRun: RouteDay[];
  customers: number;
  stops: RouteStop[];
}

export interface RoutePartyOption { id: number; name: string; code: string; city: string; phone: string; address: string; due: number }

export interface RouteHub {
  data: WeeklyRoute[]; total: number; active: number;
  days: RouteDay[]; frequencies: RouteFrequency[];
  branches: { id: number; name: string }[];
  salesmen: { id: number; name: string }[];
  deliverymen: { id: number; name: string }[];
  customers: RoutePartyOption[];
  vehicles: string[];
}

export interface DayPlan {
  data: {
    id: number; name: string; code: string; frequency: RouteFrequency; branchName: string;
    salesmanName: string; deliverymanName: string; vehicleNumber: string; stops: RouteStop[];
  }[];
  day: RouteDay; days: RouteDay[]; routes: number; totalStops: number; customers: number; collectionValue: number;
}

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const send = (method: string, body: any): RequestInit => ({
  method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
});

export async function getWeeklyRoutes(s: string, b: number | string): Promise<RouteHub> {
  return json(await fetch(`${root(s, b)}/weekly-routes`));
}

export async function getDayPlan(s: string, b: number | string, day: string): Promise<DayPlan> {
  return json(await fetch(`${root(s, b)}/weekly-routes/plan?day=${encodeURIComponent(day)}`));
}

export async function saveWeeklyRoute(s: string, b: number | string, body: Partial<WeeklyRoute>): Promise<WeeklyRoute> {
  const r: { data: WeeklyRoute } = await json(await fetch(`${root(s, b)}/weekly-routes`, send('POST', body)));
  return r.data;
}

export async function updateWeeklyRoute(
  s: string, b: number | string, id: number, body: Partial<WeeklyRoute>
): Promise<WeeklyRoute> {
  const r: { data: WeeklyRoute } = await json(await fetch(`${root(s, b)}/weekly-routes/${id}`, send('PUT', body)));
  return r.data;
}

export async function deleteWeeklyRoute(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${root(s, b)}/weekly-routes/${id}`, { method: 'DELETE' }));
}
