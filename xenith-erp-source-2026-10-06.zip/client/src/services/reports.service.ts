import { ReportCatalog, ReportPayload } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

export async function getReportCatalog(s: string, b: number | string): Promise<ReportCatalog> {
  const res = await fetch(`${API_BASE}/api/${s}/${b}/reports`);
  if (!res.ok) throw new Error('Report catalog not available');
  return res.json();
}

// A report's declared parameters filter on the server, so its totals close over the same
// rows the screen shows instead of over the whole book. The screen's own column filters travel
// beside them (`filt[…]`) for the same reason: a ticked filter has to move the tiles, the
// footer and the printed paper along with the table.
export async function getReport(
  s: string, b: number | string, name: string, asOf = '', param: Record<string, string> = {},
  filt: Record<string, string> = {}
): Promise<ReportPayload> {
  const q = new URLSearchParams();
  if (asOf) q.set('asOf', asOf);
  for (const [k, v] of Object.entries(param)) if (v && v !== 'all') q.set(`param[${k}]`, v);
  for (const [k, v] of Object.entries(filt)) if (v && v !== 'all') q.set(`filt[${k}]`, v);
  const query = q.toString();
  const res = await fetch(`${API_BASE}/api/${s}/${b}/reports/${name}${query ? `?${query}` : ''}`);
  const data = await res.json().catch(() => null);
  // Which report was refused, and by whose rule: "Report not available" reads as a broken
  // link, while the server's own line tells the clerk to take the tick up with his
  // administrator.
  if (!res.ok) throw new Error(data?.error || 'Report not available');
  return data;
}

// The Business Summary is laid out by the server as tiles, money sections and journal
// lines rather than one grid, so it has its own payload shape.
export interface SummaryTileItem { date: string; number: string; party: string; status: string; amount: number }
export interface SummaryTile { label: string; count: number; amount: number; items: SummaryTileItem[] }
export interface SummaryRow {
  date: string; description: string; account: string; contact: string;
  debit: number; credit: number; balance: number;
}
export interface SummarySection {
  key: string; label: string; accounts: string[];
  opening: number; closing: number; inflow: number; outflow: number; rows: SummaryRow[];
}
export interface JournalRow { date: string; account: string; contact: string; description: string; debit: number; credit: number }
export interface BusinessSummary {
  from: string; to: string; tiles: SummaryTile[]; sections: SummarySection[];
  journals: JournalRow[];
}

export async function getBusinessSummary(
  s: string, b: number | string, from = '', to = ''
): Promise<BusinessSummary> {
  const q = new URLSearchParams();
  if (from) q.set('from', from);
  if (to) q.set('to', to);
  const res = await fetch(`${API_BASE}/api/${s}/${b}/reports/business-summary?${q}`);
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || 'Business summary not available');
  return data.data;
}

export interface AgingBand { label: string; from: number; to: number | null }
export async function getAgingBuckets(s: string, b: number | string): Promise<AgingBand[]> {
  const res = await fetch(`${API_BASE}/api/${s}/${b}/settings/aging-buckets`);
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || 'Aging settings not available');
  return data.data;
}

export async function saveAgingBuckets(s: string, b: number | string, bands: AgingBand[]): Promise<AgingBand[]> {
  const res = await fetch(`${API_BASE}/api/${s}/${b}/settings/aging-buckets`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bands })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || 'Could not save the aging bands');
  return data.data;
}
