import { Branch } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const send = (method: string, body: any): RequestInit => ({
  method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
});

// ─── Permission catalog ─────────────────────────────────────────────────────
export interface PermActionDef { key: string; label: string; hint: string }
export interface PermScreenDef { key: string; label: string; actions: string[]; sub?: string }
export interface PermModuleDef { key: string; label: string; bucket: string; screens: PermScreenDef[]; actions: string[] }
export interface PermissionCatalog {
  actions: PermActionDef[];
  screens: PermScreenDef[];
  modules: PermModuleDef[];
  buckets: { name: string; modules: PermModuleDef[] }[];
  total: number;
}

export async function getPermissionCatalog(s: string, b: number | string): Promise<PermissionCatalog> {
  const r: { data: PermissionCatalog } = await json(await fetch(`${root(s, b)}/permissions`));
  return r.data;
}

// ─── Subscription: the modules sold to a company ─────────────────────────────
export interface LicenseModule { key: string; label: string; bucket: string; screens: { key: string; label: string }[]; permissions: number }
// `screens` narrows the sale to single features inside the bought modules. Null (or
// absent) is not "nothing" — it is every feature those modules carry, which is also
// how a feature added by a later build reaches a company that bought the module.
export interface CompanyLicense {
  plan: string; seats: number; renewsOn: string; status: string;
  modules: string[]; screens?: string[] | null;
}
export interface LicenseInfo {
  license: CompanyLicense; plan: string[]; modules: LicenseModule[];
  companies: { id: number; name: string; slug: string; plan: string; license: CompanyLicense }[];
  totalModules: number; totalScreens: number;
  licensedScreens: string[]; alwaysOnScreens: string[];
  // False when the login reading this is not the vendor: the plan is his to see, not to edit.
  canSetSale?: boolean;
}

export async function getLicense(s: string, b: number | string): Promise<LicenseInfo> {
  const r: { data: LicenseInfo } = await json(await fetch(`${root(s, b)}/license`));
  return r.data;
}
export async function saveLicense(
  s: string, b: number | string,
  body: { slug: string; modules: string[]; plan: string; seats: number; screens: string[] | null }
): Promise<{ license: CompanyLicense; licensedScreens: string[] }> {
  const r: { data: CompanyLicense; licensedScreens: string[] } =
    await json(await fetch(`${root(s, b)}/license`, send('PUT', body)));
  return { license: r.data, licensedScreens: r.licensedScreens };
}

// ─── Roles ───────────────────────────────────────────────────────────────────
export interface RoleRow {
  id: number; name: string; description: string; isSystem: boolean;
  // Marks the role whose users only ever see — and only ever wait for approval on —
  // the sale documents they raised themselves.
  salesmanScoped?: boolean;
  permissions: string[]; userCount: number; granted: number; of: number;
}

export async function getRoles(s: string, b: number | string): Promise<RoleRow[]> {
  const r: { data: RoleRow[] } = await json(await fetch(`${root(s, b)}/roles`));
  return r.data;
}
export async function saveRole(s: string, b: number | string, body: Partial<RoleRow>): Promise<RoleRow> {
  const r: { data: RoleRow } = await json(await fetch(`${root(s, b)}/roles`, send('POST', body)));
  return r.data;
}
export async function updateRole(s: string, b: number | string, id: number, body: Partial<RoleRow>): Promise<RoleRow> {
  const r: { data: RoleRow } = await json(await fetch(`${root(s, b)}/roles/${id}`, send('PUT', body)));
  return r.data;
}
export async function deleteRole(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${root(s, b)}/roles/${id}`, { method: 'DELETE' }));
}

// ─── Users ───────────────────────────────────────────────────────────────────
export interface UserRow {
  id: number; name: string; email: string; username: string; phone: string;
  roleId: number; roleName: string; isOwner: boolean; isActive: boolean;
  avatarColor: string; lastLogin: string | null; branchIds: number[];
  permissions: string[]; branchNames: string[];
}

export async function getUsers(s: string, b: number | string): Promise<{ data: UserRow[]; roles: { id: number; name: string; description: string }[]; branches: Branch[]; total: number; active: number }> {
  return json(await fetch(`${root(s, b)}/users`));
}
export async function saveUser(s: string, b: number | string, body: Partial<UserRow> & { password?: string }): Promise<UserRow> {
  const r: { data: UserRow } = await json(await fetch(`${root(s, b)}/users`, send('POST', body)));
  return r.data;
}
export async function updateUser(s: string, b: number | string, id: number, body: Partial<UserRow> & { password?: string }): Promise<UserRow> {
  const r: { data: UserRow } = await json(await fetch(`${root(s, b)}/users/${id}`, send('PUT', body)));
  return r.data;
}
export async function deleteUser(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${root(s, b)}/users/${id}`, { method: 'DELETE' }));
}

// ─── Branches ────────────────────────────────────────────────────────────────
export interface BranchSettings {
  enabled: boolean; crossBranchStock: boolean; separateNumberSeries: boolean; showBranchOnDocuments: boolean;
}

export async function getBranchSettings(s: string, b: number | string): Promise<{ settings: BranchSettings; total: number; active: number }> {
  const r: { data: BranchSettings; total: number; active: number } = await json(await fetch(`${root(s, b)}/branch-settings`));
  return { settings: r.data, total: r.total, active: r.active };
}
export async function updateBranchSettings(s: string, b: number | string, body: BranchSettings): Promise<BranchSettings> {
  const r: { data: BranchSettings } = await json(await fetch(`${root(s, b)}/branch-settings`, send('PUT', body)));
  return r.data;
}
export async function saveBranch(s: string, b: number | string, body: Partial<Branch>): Promise<Branch> {
  const r: { data: Branch } = await json(await fetch(`${root(s, b)}/branches`, send('POST', body)));
  return r.data;
}
export async function updateBranch(s: string, b: number | string, id: number, body: Partial<Branch>): Promise<Branch> {
  const r: { data: Branch } = await json(await fetch(`${root(s, b)}/branches/${id}`, send('PUT', body)));
  return r.data;
}
export async function deleteBranch(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${root(s, b)}/branches/${id}`, { method: 'DELETE' }));
}
