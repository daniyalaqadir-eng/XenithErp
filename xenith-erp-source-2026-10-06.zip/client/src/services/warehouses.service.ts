import { Branch } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const send = (method: string, body: any): RequestInit => ({
  method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
});

export interface Warehouse {
  id: number; name: string; code: string; branchId: number; branchName: string;
  isDefault: boolean; isMoveable: boolean; isActive: boolean;
  address: string; city: string; phone: string; email: string; managerName: string;
  stock: number; documents: number;
  // The login that works this location. A keeper posted here sees this warehouse's delivery
  // folder and no other; a person posted to nothing — an owner or an administrator — still
  // sees the whole book. managerName is the name typed on the paper; this is the account.
  applicationUserId?: number | null;
  keeperName?: string;
}

export interface WarehouseSettings {
  enabled: boolean;
  trackStockPerWarehouse: boolean;
  allowNegativeStock: boolean;
  requireWarehouseOnDocuments: boolean;
}

export interface WarehouseHub {
  data: Warehouse[]; total: number; active: number;
  settings: WarehouseSettings; branches: Branch[];
}

export async function getWarehouses(s: string, b: number | string): Promise<WarehouseHub> {
  return json(await fetch(`${root(s, b)}/warehouses`));
}

export async function saveWarehouse(s: string, b: number | string, body: Partial<Warehouse>): Promise<Warehouse> {
  const r: { data: Warehouse } = await json(await fetch(`${root(s, b)}/warehouses`, send('POST', body)));
  return r.data;
}

export async function updateWarehouse(s: string, b: number | string, id: number, body: Partial<Warehouse>): Promise<Warehouse> {
  const r: { data: Warehouse } = await json(await fetch(`${root(s, b)}/warehouses/${id}`, send('PUT', body)));
  return r.data;
}

export async function deleteWarehouse(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${root(s, b)}/warehouses/${id}`, { method: 'DELETE' }));
}

export async function updateWarehouseSettings(
  s: string, b: number | string, body: Partial<WarehouseSettings>
): Promise<WarehouseSettings> {
  const r: { data: WarehouseSettings } = await json(await fetch(`${root(s, b)}/warehouse-settings`, send('PUT', body)));
  return r.data;
}

// ── a location's own terminal ───────────────────────────────────────────────────
// What the keeper of one gate asks of a screen: what stands here, what has left, what is
// still waiting to be signed out. Every figure is read from the same papers the registers
// hold, so a tile here and a row on the dispatch board can never disagree.
export interface WarehouseDash {
  warehouse: {
    id: number; name: string; code: string; address: string; city: string; phone: string;
    managerName: string; keeperName: string; isMoveable: boolean;
  };
  folders: { id: number; name: string; code: string; stock: number; pending: number }[];
  kpis: {
    stockUnits: number; skus: number; dispatched: number;
    pending: number; transfersOut: number; inward: number;
  };
  outward: {
    id: number; number: string; date: string; status: string; partyName: string;
    gatePass: string; vehicle: string; driver: string; qty: number;
  }[];
  stock: { sku: string; productName: string; qty: number; unit: string }[];
}

export async function getWarehouseDashboard(
  s: string, b: number | string, warehouseId?: number | null
): Promise<WarehouseDash | null> {
  const q = warehouseId ? `?warehouseId=${warehouseId}` : '';
  const r = await json<{ data: WarehouseDash | null }>(
    await fetch(`${root(s, b)}/warehouse-dashboard${q}`));
  return r.data;
}
