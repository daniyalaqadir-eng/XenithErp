import { BizDoc, DocStatus } from '../types';
const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const url = (resource: string, s: string, b: number | string) => `${root(s, b)}/${resource}`;

// A save answers with the paper itself plus whatever the register filed alongside it:
// approving a bill files one challan per warehouse, and deleting a bill takes back the
// untouched drafts it filed. The screen says so out loud instead of leaving the keeper to
// find the work.
export type SavedDoc = BizDoc & { filedDocs?: BizDoc[] };
export type RemovedDocs = { removedDocs?: BizDoc[] };

// The sale side reads the session to work out whose paperwork a document is and who may
// approve it, so every call carries the bearer token when one is stored.
function authHeaders(): Record<string, string> {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}
const call = (href: string, init: RequestInit = {}) =>
  fetch(href, { ...init, headers: { ...(init.headers || {}), ...authHeaders() } });

export async function getDocs(resource: string, s: string, b: number | string, search = '', status = ''): Promise<{ data: BizDoc[]; total: number }> {
  const p = new URLSearchParams({ search, status });
  return json(await call(`${url(resource, s, b)}?${p}`));
}

export async function getDoc(resource: string, s: string, b: number | string, id: number): Promise<BizDoc> {
  return json(await call(`${url(resource, s, b)}/${id}`));
}

// ── the dispatch board ──────────────────────────────────────────────────────────
// One row per bill with the challans cut out of it hanging beneath, because a keeper reads
// deliveries as "what does this customer still have coming" rather than as a list of papers.
// Everything here is counted in quantities; the ledger already answers the money question.
export interface BoardItem { name: string; sku: string; unit: string; qty: number; billed: number; sent: boolean }
export interface BoardChallan {
  id: number; number: string; date: string; status: DocStatus; part: string;
  gatePass: string; vehicle: string; driver: string; warehouseName: string;
  state: 'Not Dispatched' | 'Partial Dispatched' | 'Fully Dispatched';
  qty: number; items: BoardItem[];
}
export interface BoardRow {
  id: number; number: string; date: string; partyName: string; paymentMode: string;
  status: DocStatus; warehouseName: string; net: number; balance: number;
  orderQty: number; dispatchedQty: number; holdQty: number;
  // What no challan has written down yet, signed or not. The hold above is counted from
  // approved paper; this is what a new challan may still be raised for.
  claimableQty: number;
  state: 'Not Dispatched' | 'Partial Dispatched' | 'Fully Dispatched';
  challans: BoardChallan[];
}
export interface BoardFolder { id: number; name: string; code: string; bills: number; challans: number; awaiting: number }

export async function getDispatchBoard(
  s: string, b: number | string, opts: { q?: string; warehouseId?: number | null; state?: string } = {}
): Promise<{ rows: BoardRow[]; folders: BoardFolder[] }> {
  const p = new URLSearchParams();
  if (opts.q) p.set('q', opts.q);
  if (opts.warehouseId) p.set('warehouseId', String(opts.warehouseId));
  if (opts.state) p.set('state', opts.state);
  const r = await json<{ data: { rows: BoardRow[]; folders: BoardFolder[] } }>(
    await call(`${root(s, b)}/dispatch-board?${p}`));
  return r.data;
}

// What the register is about to hand out, and the day a new paper may not go under: the
// newest Approved paper of this register, plus whether the signed-in person may back-date
// past it. The form asks before it writes so the rule can be shown, not just enforced.
export interface DocProposal { number: string; dateFloor: string; canBackdate: boolean }

export async function getDocProposedNumber(
  resource: string, s: string, b: number | string, warehouseId?: number | null
): Promise<DocProposal> {
  // A warehouse-wise register numbers each gate's own book, so the form asks with the
  // warehouse in hand — the number it shows must be the number the save will get.
  const q = warehouseId ? `?warehouseId=${warehouseId}` : '';
  return json<DocProposal>(await call(`${url(resource, s, b)}/proposed-number${q}`));
}

export async function saveDoc(resource: string, s: string, b: number | string, body: Partial<BizDoc>): Promise<SavedDoc> {
  return json(await call(url(resource, s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}

export async function updateDoc(resource: string, s: string, b: number | string, id: number, body: Partial<BizDoc>): Promise<SavedDoc> {
  return json(await call(`${url(resource, s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}

export async function setDocStatus(resource: string, s: string, b: number | string, id: number, status: DocStatus): Promise<SavedDoc> {
  return json(await call(`${url(resource, s, b)}/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) }));
}

export async function approveDocs(
  resource: string, s: string, b: number | string, ids: number[]
): Promise<{ data: BizDoc[]; total: number; filedDocs?: BizDoc[] }> {
  return json(await call(`${url(resource, s, b)}/approve-selected`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) }));
}

export async function saveBulkDoc(resource: string, s: string, b: number | string, body: { date: string; rows: Partial<BizDoc>[] }): Promise<{ data: BizDoc[]; total: number; filedDocs?: BizDoc[] }> {
  return json(await call(`${url(resource, s, b)}/bulk`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}

export async function deleteDoc(resource: string, s: string, b: number | string, id: number): Promise<RemovedDocs> {
  return json<RemovedDocs>(await call(`${url(resource, s, b)}/${id}`, { method: 'DELETE' }));
}

// ── The order → invoice → delivery chain ────────────────────────────────────
// What a source paper still has left to take, line by line. The server works the
// remaining quantity out so a half-billed order and a part-delivered invoice can never
// be counted twice by two different people on the same day.
export interface PendingSourceLine {
  id: number;
  productId: number | null;
  productName: string;
  sku: string;
  unit: string;
  qty: number;
  price: number;
  discountType: string;
  discountValue: number;
  warehouseId: number | null;
  warehouseName: string;
  taken: number;
  remaining: number;
}
export interface PendingSource {
  id: number;
  number: string;
  date: string;
  dueDate: string;
  reference: string;
  subject: string;
  partyId: number | null;
  partyName: string;
  warehouseName: string;
  // For a challan picked out of a bill, the order that bill itself came from.
  sourceNumber: string;
  shippingAddress: string;
  salesPersonId: number | null;
  salesPersonName: string;
  tax: number;
  discount: number;
  shippingCharges: number;
  value: number;
  lines: PendingSourceLine[];
}

export async function getPendingSources(resource: string, s: string, b: number | string, opts: { partyId?: number | null; except?: number | null } = {}): Promise<PendingSource[]> {
  const p = new URLSearchParams({
    partyId: opts.partyId ? String(opts.partyId) : '',
    except: opts.except ? String(opts.except) : ''
  });
  const r = await json<{ data: PendingSource[] }>(await call(`${url(resource, s, b)}/pending-sources?${p}`));
  return r.data;
}

export interface ChainPart {
  id: number;
  number: string;
  date: string;
  status: DocStatus;
  part: string;
  resource: string;
  label: string;
  partyName: string;
  warehouseName: string;
  approvedByName: string;
  summary: string;
  lines: { productName: string; sku: string; unit: string; quantity: number }[];
}
export interface ChainLine {
  id: number;
  productName: string;
  sku: string;
  unit: string;
  qty: number;
  taken: number;
  remaining: number;
  sourceNumber: string;
  sourceLineId: number | null;
}

export async function getDocChain(resource: string, s: string, b: number | string, id: number): Promise<{ parts: ChainPart[]; lines: ChainLine[] }> {
  const r = await json<{ data: { parts: ChainPart[]; lines: ChainLine[] } }>(await call(`${url(resource, s, b)}/${id}/chain`));
  return r.data;
}
