import { BankAccount, BankTransaction } from '../types';

// Same rule as every other service: no VITE_API_URL means the page and the API share one
// origin, which is how the deployed book is served.
const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

function bankAccountUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/bank-accounts`; }
function transactionUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/bank-transactions`; }

// Mutations must surface the server's reason, or the modals silently stay open.
async function write<T>(res: Response, fallback: string): Promise<T> {
  const data = await res.json().catch(() => null) as any;
  if (!res.ok) throw new Error(data?.error || data?.message || fallback);
  return data as T;
}

// Bank Accounts
export async function getBankAccounts(s: string, b: number | string, pageSize=50, pageIndex=0, sortField='accountTitle', sortDirection='asc', search=''): Promise<{data:BankAccount[];total:number}> {
  const p = new URLSearchParams({pageSize:String(pageSize),pageIndex:String(pageIndex),sortField,sortDirection,search});
  return (await fetch(`${bankAccountUrl(s,b)}?${p}`)).json();
}
export async function getBankAccountById(s: string, b: number | string, id: number): Promise<BankAccount> {
  return (await fetch(`${bankAccountUrl(s,b)}/${id}`)).json();
}
export async function addBankAccount(s: string, b: number | string, body: Partial<BankAccount>): Promise<BankAccount> {
  return write(await fetch(bankAccountUrl(s,b),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}), 'Failed to save bank account');
}
export async function updateBankAccount(s: string, b: number | string, id: number, body: Partial<BankAccount>): Promise<BankAccount> {
  return write(await fetch(`${bankAccountUrl(s,b)}/${id}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}), 'Failed to update bank account');
}
export async function deleteBankAccount(s: string, b: number | string, id: number): Promise<void> {
  await write(await fetch(`${bankAccountUrl(s,b)}/${id}`,{method:'DELETE'}), 'Failed to delete bank account');
}

// Bank Transactions (read-only)
export async function getBankTransactions(s: string, b: number | string, pageSize=50, pageIndex=0, sortField='transactionDate', sortDirection='desc', search='', bankAccountId?: number): Promise<{data:BankTransaction[];total:number}> {
  const p = new URLSearchParams({pageSize:String(pageSize),pageIndex:String(pageIndex),sortField,sortDirection,search});
  if (bankAccountId !== undefined) p.set('bankAccountId', String(bankAccountId));
  return (await fetch(`${transactionUrl(s,b)}?${p}`)).json();
}
