import { JournalEntry } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

const closeUrl = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}/close-year`;

// Closing a year writes a journal and seals a stretch of days, so the server needs to know
// whose chair is signing it off.
function authHeaders(): Record<string, string> {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

async function write<T>(res: Response, fallback: string): Promise<T> {
  const data = await res.json().catch(() => null) as any;
  if (!res.ok) throw new Error(data?.error || data?.message || fallback);
  return data as T;
}

export interface BookClose {
  id: number;
  from: string;
  to: string;
  closedAt: string;
  closedBy: string;
  revenue: number;
  cogs: number;
  operating: number;
  otherIncome: number;
  netProfit: number;
  papers: number;
  journalId: number | null;
  journalNumber: string;
}

export interface CloseYearRow {
  year: number;
  label: string;
  from: string;
  to: string;
  state: 'Open' | 'Partly closed' | 'Closed';
  close: BookClose | null;
  netProfit: number;
}

export interface CloseYearState {
  closes: BookClose[];
  years: CloseYearRow[];
  financialYearStart: string;
  carriedHead: string;
  closedThrough: string;
  openFrom: string;
  today: string;
  canClose: boolean;
  canReopen: boolean;
  suggestedTo: string;
  papersStillOpen: number;
}

export interface ClosingLine {
  account: string;
  debit: number;
  credit: number;
  description: string;
}

export interface ClosingPreview {
  from: string;
  to: string;
  period: string;
  lines: ClosingLine[];
  figures: {
    revenue: number;
    cogs: number;
    operating: number;
    otherIncome: number;
    grossProfit: number;
    netProfit: number;
  };
  net: number;
  totalDebit: number;
  totalCredit: number;
  papers: number;
  drafts: number;
}

export async function getCloseYearState(s: string, b: number | string): Promise<CloseYearState> {
  return write(await fetch(closeUrl(s, b), { headers: authHeaders() }), 'The closing register could not be read');
}

export async function previewCloseYear(s: string, b: number | string, to: string): Promise<ClosingPreview> {
  const p = new URLSearchParams({ to });
  return write(await fetch(`${closeUrl(s, b)}/preview?${p}`, { headers: authHeaders() }),
    'This period could not be read');
}

export async function closeBooks(s: string, b: number | string, to: string): Promise<{
  close: BookClose; journal: JournalEntry | null; closedThrough: string; openFrom: string;
}> {
  return write(await fetch(closeUrl(s, b), {
    method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify({ to })
  }), 'The books could not be closed');
}

export async function reopenBooks(s: string, b: number | string, id: number): Promise<{
  closedThrough: string; openFrom: string; remaining: BookClose[];
}> {
  return write(await fetch(`${closeUrl(s, b)}/${id}/reopen`, {
    method: 'POST', headers: authHeaders()
  }), 'The year could not be reopened');
}
