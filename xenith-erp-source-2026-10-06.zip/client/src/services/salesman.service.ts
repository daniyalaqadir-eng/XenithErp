import { DocStatus } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

export interface SalesmanSummary {
  user: { id: number; name: string; email: string; roleName: string };
  salesPerson: { id: number; name: string; branchName: string } | null;
  approvalNote: string;
  totals: {
    salesThisMonth: number; salesAllTime: number; collections: number;
    outstanding: number; customers: number;
  };
  queue: {
    pending: { count: number; amount: number };
    drafts: { count: number; amount: number };
    approved: number;
  };
  pipeline: { key: string; label: string; count: number; amount: number }[];
  months: { key: string; label: string; value: number }[];
  topProducts: { name: string; qty: number; amount: number }[];
  // His bills measured by the dispatch board's own yardstick: what his parties were billed
  // for and what has actually been signed out of a gate.
  dispatch: {
    bills: number; fully: number; part: number; none: number;
    holdUnits: number; unsigned: number;
  };
  // Every item on the shelf with the building that holds it, so a quote down the phone is
  // a fact rather than a guess.
  stock: { sku: string; productName: string; unit: string; total: number; places: { warehouseName: string; qty: number }[] }[];
  /** Whose desk an administrator is looking at; null when this is the reader's own page. */
  viewingAs: { id: number; name: string } | null;
  /** The salesmen whose desk an administrator may turn this page to. */
  asOptions: { id: number; name: string; roleName: string }[];
  recent: {
    id: number; resource: string; number: string; label: string; partyName: string;
    date: string; status: DocStatus; net: number; approvedByName: string;
    dispatch: {
      orderQty: number; dispatchedQty: number; holdQty: number;
      state: 'Not Dispatched' | 'Partial Dispatched' | 'Fully Dispatched';
      challans: { number: string; status: DocStatus }[];
    } | null;
  }[];
}

/** One person's own paperwork, already pooled by the server. `as` previews another salesman. */
export async function getSalesmanSummary(
  s: string, b: number | string, token: string, as?: number | null
): Promise<SalesmanSummary> {
  const res = await fetch(`${API_BASE}/api/${s}/${b}/salesman-summary${as ? `?as=${as}` : ''}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data.data as SalesmanSummary;
}
