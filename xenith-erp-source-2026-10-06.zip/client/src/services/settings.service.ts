export interface CompanyProfile {
  name: string; typeOfOrganization: string; slug: string;
  addressLine1: string; addressLine2: string; country: string; state: string; city: string; zip: string;
  email: string; phone: string; contactPerson: string; fax: string; ntn: string; cnic: string;
  logo: string; signature: string;
}

export type SettingValue = boolean | string | number;

export interface SettingField {
  key: string; label: string; kind: 'flag' | 'text' | 'number' | 'select'; def: SettingValue;
  options?: string[]; hint?: string; note?: string; warning?: string;
  lock?: boolean; min?: number; max?: number;
}
export interface SettingSection { id: string; title: string; fields: SettingField[] }

export interface CompanyOptions {
  orgTypes: string[]; countries: string[]; states: Record<string, string[]>;
  currencies: string[]; taxAuthorities: string[]; months: string[];
}

export interface LinkedBranch { id: number; name: string; code: string; city: string; isMain: boolean }
export interface CompanyEntry { id: number; name: string; slug: string; typeOfOrganization: string; plan: string; isActive: boolean }

export interface CompanyHub {
  profile: CompanyProfile; sections: SettingSection[]; settings: Record<string, SettingValue>;
  options: CompanyOptions; linkedBranches: LinkedBranch[]; linkedBranchIds: number[]; companies: CompanyEntry[];
}

export interface SmtpSettings {
  useOwnAddress: boolean; host: string; port: number; username: string; fromName: string;
  fromEmail: string; secure: boolean; passwordSet: boolean;
}

export interface WhatsAppAccount {
  id: number; pin: string; phoneId: string; whatsappId: string; token: string; connected: boolean;
  hasToken?: boolean; graphVersion?: string;
}
// One customer's slice of the due list, as the reminder composer reads it.
export interface ReminderGroup {
  customerId: number | null; name: string; phone: string;
  papers: number; amount: number; overdue: number; pastDueDays: number;
}
export interface ReminderPaper {
  number: string; date: string; dueDate: string; status: string; balance: number; pastDue: number;
}
export interface ReminderDraft {
  customerId: number; customer: string; to: string; total: number; lines: ReminderPaper[]; text: string;
}
// A send that Meta turned down stays in this register with its answer on it.
export interface WhatsAppMessage {
  id: number; date: string; to: string; subject: string; text: string;
  status: 'Sent' | 'Failed'; reference: string; error: string; http: number; account: string;
}
export interface ApiKey { id: number; applicationName: string; key: string; status: 'Active' | 'Inactive'; createdDate: string; lastUsed: string }
export interface TemplateDesign {
  theme?: string; accent?: string; letterhead?: string; footer?: string;
  note?: string; pageNumber?: boolean; landscape?: boolean;
}
export interface PrintTemplate {
  id: number; document: string; name: string; paper: string; description: string;
  custom: boolean; isActive: boolean; design?: TemplateDesign;
}
export interface LoyaltyTier { name: string; minPoints: number; discountPercent: number }
export interface LoyaltyProgram {
  enabled: boolean; pointsPerAmount: number; redeemPoints: number; redeemValue: number; expiryMonths: number; tiers: LoyaltyTier[];
}
export interface ActivityEntry { id: number; date: string; user: string; action: string; screen: string; record: string; ipAddress: string }

// ─── Sample trading history ──────────────────────────────────────────────────
// What the book holds right now, row by row, per register. The server counts its own rows so the
// screen cannot claim a paper that was never posted.
export interface SampleBookState {
  loadedAt: string; counts: Record<string, number>; total: number; skipped: string[]; fresh: boolean;
}
// One press's answer: what was raised or taken back, what the subscription would not let
// through, and anything that failed — all three shown as they came.
export interface SampleBookRun {
  added?: Record<string, number>; removed?: Record<string, number>;
  skipped: string[]; failed: string[]; counts?: Record<string, number>; note?: string;
}

export const getSampleBook = async (s: string, b: number | string) =>
  json<SampleBookState>(await fetch(`${root(s, b)}/settings/sample-book`));
// Filling the book raises every paper through the normal saving routes, so the press is slower
// than a save and the screen says so while it runs.
export const loadSampleBook = async (s: string, b: number | string) =>
  json<SampleBookRun>(await send(`${root(s, b)}/settings/sample-book`, 'POST', {}));
export const clearSampleBook = async (s: string, b: number | string) =>
  json<SampleBookRun>(await fetch(`${root(s, b)}/settings/sample-book`, {
    method: 'DELETE', headers: authHeaders()
  }));

export interface ReferralStep { title: string; text: string }
export interface ReferralInfo {
  code: string; url: string; points: number; voucher: number; headline: string;
  steps: ReferralStep[]; shareUrl: string; logs: PointLog[]; redeemTiers: number[];
}
export interface PointLog { id: number; date: string; points: number; description: string; type: 'Earned' | 'Redeemed' | 'Bonus'; action: string }

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(()  => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

// A WhatsApp send spends the company's own quota, so the server asks who is sending. The bearer
// token rides along on every settings write rather than being repeated per call.
const authHeaders = (): Record<string, string> => {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch { return {}; }
};

const send = (url: string, method: 'POST' | 'PUT', body: unknown) =>
  fetch(url, {
    method, headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify(body)
  });

// ─── Company profile + the declarative settings schema ───────────────────────
export async function getCompanyHub(s: string, b: number | string): Promise<CompanyHub> {
  return json(await fetch(`${root(s, b)}/settings/company`));
}

export async function saveCompanyHub(
  s: string, b: number | string, body: { profile?: Partial<CompanyProfile>; settings?: Record<string, SettingValue>; linkedBranchIds?: number[] }
): Promise<{ profile: CompanyProfile; settings: Record<string, SettingValue>; linkedBranchIds: number[] }> {
  return json(await send(`${root(s, b)}/settings/company`, 'PUT', body));
}

// ─── SMTP ────────────────────────────────────────────────────────────────────
export const getSmtp = async (s: string, b: number | string) =>
  json<SmtpSettings>(await fetch(`${root(s, b)}/settings/smtp`));
export const saveSmtp = async (s: string, b: number | string, body: Partial<SmtpSettings> & { password?: string }) =>
  json<SmtpSettings>(await send(`${root(s, b)}/settings/smtp`, 'PUT', body));

// ─── WhatsApp Business accounts ──────────────────────────────────────────────
export async function getWhatsAppAccounts(s: string, b: number | string): Promise<WhatsAppAccount[]> {
  return (await json<{ data: WhatsAppAccount[] }>(await fetch(`${root(s, b)}/settings/whatsapp-accounts`))).data;
}
export const addWhatsAppAccount = async (s: string, b: number | string, body: Partial<WhatsAppAccount>) =>
  json<WhatsAppAccount>(await send(`${root(s, b)}/settings/whatsapp-accounts`, 'POST', body));
export const updateWhatsAppAccount = async (s: string, b: number | string, id: number, body: Partial<WhatsAppAccount>) =>
  json<WhatsAppAccount>(await send(`${root(s, b)}/settings/whatsapp-accounts/${id}`, 'PUT', body));
export async function deleteWhatsAppAccount(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${root(s, b)}/settings/whatsapp-accounts/${id}`, { method: 'DELETE' });
}
export const linkWhatsApp = async (s: string, b: number | string) =>
  json<{ loginUrl: string; hint: string }>(await send(`${root(s, b)}/settings/whatsapp-accounts/link`, 'POST', {}));

// ── due reminders over WhatsApp ──────────────────────────────────────────────
// The words are composed server-side off the customer due list, so a reminder can never disagree
// with what the owner sees under Reports.
export async function getWhatsAppReminders(s: string, b: number | string): Promise<ReminderGroup[]> {
  return (await json<{ data: ReminderGroup[] }>(await fetch(`${root(s, b)}/whatsapp/reminders`))).data;
}
export const getWhatsAppReminder = async (s: string, b: number | string, customerId: number) =>
  json<ReminderDraft>(await fetch(`${root(s, b)}/whatsapp/reminders/${customerId}`));
export const sendWhatsApp = async (s: string, b: number | string, body: { to: string; text: string; subject?: string; accountId?: number }) =>
  json<WhatsAppMessage>(await send(`${root(s, b)}/whatsapp/send`, 'POST', body));
export async function getWhatsAppMessages(s: string, b: number | string, search = ''): Promise<WhatsAppMessage[]> {
  return (await json<{ data: WhatsAppMessage[] }>(await fetch(`${root(s, b)}/whatsapp/messages?${new URLSearchParams({ search })}`))).data;
}

// ─── API keys ────────────────────────────────────────────────────────────────
export async function getApiKeys(s: string, b: number | string, search = ''): Promise<ApiKey[]> {
  return (await json<{ data: ApiKey[] }>(await fetch(`${root(s, b)}/settings/api-keys?${new URLSearchParams({ search })}`))).data;
}
export const createApiKey = async (s: string, b: number | string, applicationName: string) =>
  json<ApiKey>(await send(`${root(s, b)}/settings/api-keys`, 'POST', { applicationName }));
export const updateApiKey = async (s: string, b: number | string, id: number, body: Partial<Pick<ApiKey, 'status'>> & { regenerate?: boolean }) =>
  json<ApiKey>(await send(`${root(s, b)}/settings/api-keys/${id}`, 'PUT', body));
export async function deleteApiKey(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${root(s, b)}/settings/api-keys/${id}`, { method: 'DELETE' });
}

// ─── Printing templates ──────────────────────────────────────────────────────
export async function getPrintingTemplates(s: string, b: number | string): Promise<{ documents: string[]; templates: PrintTemplate[] }> {
  return json(await fetch(`${root(s, b)}/settings/printing-templates`));
}
export const activateTemplate = async (s: string, b: number | string, id: number) =>
  json<{ document: string; templates: PrintTemplate[] }>(await send(`${root(s, b)}/settings/printing-templates/${id}/activate`, 'PUT', {}));
// "0" is not a template — it is the paper asking for the design set in Settings instead of
// any saved template, which is how a company gets back to plain printing.
export const deactivateTemplate = async (s: string, b: number | string, document: string) =>
  json<{ document: string; templates: PrintTemplate[] }>(await send(
    `${root(s, b)}/settings/printing-templates/0/activate?${new URLSearchParams({ document })}`, 'PUT', {}));
export const createTemplate = async (s: string, b: number | string, body: { document: string; name: string; paper?: string; description?: string; design?: TemplateDesign }) =>
  json<PrintTemplate>(await send(`${root(s, b)}/settings/printing-templates`, 'POST', body));
export async function deleteTemplate(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${root(s, b)}/settings/printing-templates/${id}`, { method: 'DELETE' });
}

// ─── Loyalty + activity log ──────────────────────────────────────────────────
export const getLoyalty = async (s: string, b: number | string) =>
  json<LoyaltyProgram>(await fetch(`${root(s, b)}/settings/loyalty`));
export const saveLoyalty = async (s: string, b: number | string, body: Partial<LoyaltyProgram>) =>
  json<LoyaltyProgram>(await send(`${root(s, b)}/settings/loyalty`, 'PUT', body));

export async function getActivityLog(s: string, b: number | string, search = '', user = ''): Promise<{ data: ActivityEntry[]; users: string[] }> {
  const p = new URLSearchParams({ search, user });
  return json(await fetch(`${root(s, b)}/settings/activity-log?${p}`));
}

// ─── Companies (header switcher) ─────────────────────────────────────────────
export async function getCompanies(s: string, b: number | string): Promise<CompanyEntry[]> {
  return (await json<{ data: CompanyEntry[] }>(await fetch(`${root(s, b)}/settings/companies`))).data;
}
// Opening a firm is selling to it, so the first account is named at the same time: a book that
// opened on the seeded password would be handed over already unsafe.
export const addCompany = async (s: string, b: number | string, body: {
  name: string; typeOfOrganization?: string;
  ownerName?: string; ownerEmail?: string; ownerUsername?: string; ownerPassword?: string;
}) => json<CompanyEntry & { owner?: { name: string; email: string; username: string } }>(
  await send(`${root(s, b)}/settings/companies`, 'POST', body));
export const activateCompany = async (s: string, b: number | string, slug: string) =>
  json<{ data: CompanyEntry[]; active: CompanyEntry }>(await send(`${root(s, b)}/settings/companies/active`, 'PUT', { slug }));

// ─── Refer and earn ──────────────────────────────────────────────────────────
export const getReferral = async (s: string, b: number | string) =>
  json<ReferralInfo>(await fetch(`${root(s, b)}/referral`));
export const redeemPoints = async (s: string, b: number | string, points: number, description = '') =>
  json<{ points: number; log: PointLog }>(await send(`${root(s, b)}/referral/redeem`, 'POST', { points, description }));
