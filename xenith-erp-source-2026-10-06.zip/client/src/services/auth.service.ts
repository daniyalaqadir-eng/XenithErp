const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  username: string;
  phone: string;
  roleId: number;
  roleName: string;
  isOwner: boolean;
  // Signed in with the server's vendor key, which is not a row in any company's book.
  isVendor?: boolean;
  isActive: boolean;
  avatarColor: string;
  lastLogin: string | null;
  branchIds: number[];
  // "<screen>:<action>" ticks, plus the menu branches those screens make visible.
  permissions: string[];
  modules: string[];
  // A salesman-scoped role sees only its own sale-side paper, and it waits for approval.
  salesmanScoped?: boolean;
  salesPersonId?: number | null;
  salesPersonName?: string;
  // The company this account signs into. A name exists in one book, not in the whole
  // installation, so the screens read their address from here instead of assuming one.
  companySlug?: string;
  companyName?: string;
}
export interface AuthResponse { token: string; user: AuthUser; }

async function post(path: string, body: any, token?: string): Promise<any> {
  const res = await fetch(`${API_BASE}/api/auth/${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  // The status rides on the error because some refusals ask for one more field rather than
  // meaning "wrong": a name that signs in at two companies needs the company code with it.
  if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status });
  return data;
}

export const authService = {
  // The first field accepts either the email or the short username. The company code is only
  // needed when that name is live in more than one firm on the same installation.
  login: (email: string, password: string, company?: string): Promise<AuthResponse> =>
    post('login', { email, password, company }),
  register: (name: string, email: string, password: string): Promise<AuthResponse> => post('register', { name, email, password }),
  requestPassword: (email: string): Promise<{ message: string }> => post('request-password', { email }),
  resetPassword: (email: string, code: string, newPassword: string): Promise<{ message: string }> => post('reset-password', { email, code, newPassword }),
  changePassword: (token: string, currentPassword: string, newPassword: string): Promise<{ message: string }> =>
    post('change-password', { currentPassword, newPassword }, token),
  updateProfile: (token: string, patch: Partial<AuthUser>): Promise<{ user: AuthUser }> =>
    fetch(`${API_BASE}/api/auth/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(patch)
    }).then(async res => {
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Request failed');
      return data;
    }),
  // What the server currently believes this token's user may open. A session sitting in the
  // browser was written when the app had fewer screens, so this is how a new one arrives
  // without everyone having to sign out after an upgrade. The status rides along on the
  // error because 401 means something different from "the server is not answering yet".
  session: (token: string): Promise<{ user: AuthUser }> =>
    fetch(`${API_BASE}/api/auth/session`, { headers: { Authorization: `Bearer ${token}` } })
      .then(async res => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status });
        return data;
      }),
  logout: (token: string): Promise<void> => fetch(`${API_BASE}/api/auth/logout`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  }).then(() => undefined)
};
