import { InventoryItem, StockMovement, StockAdjustment, AdjustmentType, StockValuation } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

function itemsUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/inventory/items`; }
function movementsUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/inventory/stock-movements`; }
function adjustmentsUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/inventory/adjustments`; }
function adjustmentTypesUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/adjustment-types`; }
function valuationsUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/stock-valuations`; }

// Item Master
export async function getItems(s: string, b: number | string, search = ''): Promise<{ data: InventoryItem[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${itemsUrl(s, b)}?${p}`)).json();
}
export async function addItem(s: string, b: number | string, body: Partial<InventoryItem>): Promise<InventoryItem> {
  return (await fetch(itemsUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}
export async function updateItem(s: string, b: number | string, id: number, body: Partial<InventoryItem>): Promise<InventoryItem> {
  return (await fetch(`${itemsUrl(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}
export async function deleteItem(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${itemsUrl(s, b)}/${id}`, { method: 'DELETE' });
}

// Stock Movement
export async function getMovements(s: string, b: number | string, search = ''): Promise<{ data: StockMovement[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${movementsUrl(s, b)}?${p}`)).json();
}
export async function addMovement(s: string, b: number | string, body: Partial<StockMovement> & { itemId: number }): Promise<StockMovement> {
  return (await fetch(movementsUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}

// Stock Adjustments
export async function getAdjustments(s: string, b: number | string, search = ''): Promise<{ data: StockAdjustment[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${adjustmentsUrl(s, b)}?${p}`)).json();
}
export async function addAdjustment(s: string, b: number | string, body: Partial<StockAdjustment> & { itemId: number }): Promise<StockAdjustment> {
  return (await fetch(adjustmentsUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}

// Adjustment Types master
export async function getAdjustmentTypes(s: string, b: number | string, search = ''): Promise<{ data: AdjustmentType[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${adjustmentTypesUrl(s, b)}?${p}`)).json();
}
export async function saveAdjustmentType(s: string, b: number | string, body: Partial<AdjustmentType>): Promise<AdjustmentType> {
  return (await fetch(adjustmentTypesUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}
export async function updateAdjustmentType(s: string, b: number | string, id: number, body: Partial<AdjustmentType>): Promise<AdjustmentType> {
  return (await fetch(`${adjustmentTypesUrl(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}
export async function deleteAdjustmentType(s: string, b: number | string, id: number): Promise<string | null> {
  const r = await fetch(`${adjustmentTypesUrl(s, b)}/${id}`, { method: 'DELETE' });
  if (r.ok) return null;
  return ((await r.json().catch(() => ({}))) as { error?: string }).error ?? 'This type could not be deleted';
}

// Where each product actually sits. The item card holds one number, while the same
// product can be spread across several warehouses.
export interface StockMapRow { sku: string; productName: string; warehouseName: string; qty: number }
export async function getStockMap(s: string, b: number | string): Promise<{ data: StockMapRow[]; total: number; warehouses: string[] }> {
  return (await fetch(`${API_BASE}/api/${s}/${b}/inventory/stock-map`)).json();
}

// Scheduled valuations
export async function getStockValuations(s: string, b: number | string): Promise<{ data: StockValuation[]; total: number }> {
  return (await fetch(valuationsUrl(s, b))).json();
}
export async function saveStockValuation(s: string, b: number | string, body: Partial<StockValuation>): Promise<StockValuation> {
  return (await fetch(valuationsUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json();
}
export async function deleteStockValuation(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${valuationsUrl(s, b)}/${id}`, { method: 'DELETE' });
}
