import { JournalEntry } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

function journalUrl(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/journal-entries`; }

// The server writes who raised and who approved an entry, so every call carries the session.
function authHeaders(): Record<string, string> {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

async function write<T>(res: Response, fallback: string): Promise<T> {
  const data = await res.json().catch(() => null) as any;
  if (!res.ok) throw new Error(data?.error || data?.message || fallback);
  return data as T;
}

export async function getJournalEntries(s: string, b: number | string, search = ''): Promise<{ data: JournalEntry[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${journalUrl(s, b)}?${p}`, { headers: authHeaders() })).json();
}

// The register counts its own run, so the paper shows the number it will be saved under
// instead of a blank box the clerk has to invent. The date floor and the back-dating grant
// come from the same call, so the warning the clerk reads is the rule the save applies.
export interface JournalProposal { number: string; dateFloor: string; canBackdate: boolean }

export async function getJournalProposal(s: string, b: number | string): Promise<JournalProposal> {
  const r = await fetch(`${journalUrl(s, b)}/proposed-number`, { headers: authHeaders() })
    .then(res => res.json()).catch(() => null) as Partial<JournalProposal> | null;
  return { number: r?.number ?? '', dateFloor: r?.dateFloor ?? '', canBackdate: r?.canBackdate !== false };
}

export async function getJournalEntry(s: string, b: number | string, id: number): Promise<JournalEntry> {
  return write(await fetch(`${journalUrl(s, b)}/${id}`, { headers: authHeaders() }), 'Journal entry not found');
}

export async function addJournalEntry(s: string, b: number | string, body: Partial<JournalEntry>): Promise<JournalEntry> {
  return write(await fetch(journalUrl(s, b), {
    method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify(body)
  }), 'Failed to save journal entry');
}

export async function updateJournalEntry(s: string, b: number | string, id: number, body: Partial<JournalEntry>): Promise<JournalEntry> {
  return write(await fetch(`${journalUrl(s, b)}/${id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify(body)
  }), 'Failed to update journal entry');
}

export async function setJournalStatus(s: string, b: number | string, id: number, status: 'Draft' | 'Approved'): Promise<JournalEntry> {
  return write(await fetch(`${journalUrl(s, b)}/${id}/status`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify({ status })
  }), `Failed to mark the entry ${status.toLowerCase()}`);
}

export async function deleteJournalEntry(s: string, b: number | string, id: number): Promise<void> {
  const res = await fetch(`${journalUrl(s, b)}/${id}`, { method: 'DELETE', headers: authHeaders() });
  if (!res.ok) {
    const data = await res.json().catch(() => null) as any;
    throw new Error(data?.error || data?.message || 'Failed to delete journal entry');
  }
}
