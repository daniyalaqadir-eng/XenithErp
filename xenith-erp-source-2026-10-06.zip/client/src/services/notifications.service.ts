export interface AppNotification {
  id: string;
  tone: 'danger' | 'warning' | 'info' | 'success';
  title: string;
  detail: string;
  time: string;
  tab: string;
  /** Whose bell this is: read state belongs to the signed-in user, not the company. */
  read: boolean;
}

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

// The server marks alerts read against the person who sent the call, so the token rides along.
function authHeaders(): Record<string, string> {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

export async function getNotifications(s: string, b: number | string): Promise<{ data: AppNotification[]; total: number; unread: number }> {
  const res = await fetch(`${API_BASE}/api/${s}/${b}/notifications`, { headers: authHeaders() });
  if (!res.ok) throw new Error('Notifications unavailable');
  return res.json();
}

/** One line by its id, or every line the bell is holding when `id` is '*'. */
export async function markNotificationsRead(s: string, b: number | string, id: string): Promise<void> {
  await fetch(`${API_BASE}/api/${s}/${b}/notifications/read`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(id === '*' ? { all: true } : { id })
  });
}
