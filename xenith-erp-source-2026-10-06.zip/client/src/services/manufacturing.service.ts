export interface MfgLine {
  productId: number | null; productName: string; sku: string; batch: string;
  quantity: number; cost: number; costPercent: number; amount: number;
}
export interface MfgExpense { accountName: string; description: string; amount: number }
export interface MfgAttachment { name: string; size: number }

export type MfgKindKey = 'job-orders' | 'disassemblies';
export type MfgStatus = 'Draft' | 'Confirmed' | 'Completed' | 'Cancelled';
export type MfgMethod = 'Method 1' | 'Method 2';

export interface MfgDoc {
  id: number; kind: 'JobOrder' | 'Disassembly'; number: string; date: string; dueDate: string; reference: string;
  productId: number | null; productName: string; quantity: number; calculationMethod: MfgMethod;
  inputs: MfgLine[]; outputs: MfgLine[]; expenses: MfgExpense[];
  comments: string; attachments: MfgAttachment[]; status: MfgStatus;
  materialCost: number; expenseCost: number; totalCost: number; producedQty: number; unitCost: number;
}

export interface MfgItem {
  id: number; name: string; sku: string; unit: string;
  stockQty: number; cost: number; price: number; batch: boolean; serial: boolean;
}

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const base = (kind: MfgKindKey, s: string, b: number | string) => `${root(s, b)}/manufacturing/${kind}`;

export async function getMfgItems(s: string, b: number | string): Promise<MfgItem[]> {
  const data = await json<{ data: MfgItem[] }>(await fetch(`${root(s, b)}/manufacturing/items`));
  return data.data;
}

export async function getMfgDocs(
  kind: MfgKindKey, s: string, b: number | string, search = '', status = ''
): Promise<{ data: MfgDoc[]; total: number }> {
  const p = new URLSearchParams({ search, status });
  return json(await fetch(`${base(kind, s, b)}?${p}`));
}

export async function getMfgProposedNumber(kind: MfgKindKey, s: string, b: number | string): Promise<string> {
  const r = await json<{ number: string }>(await fetch(`${base(kind, s, b)}/proposed-number`));
  return r.number;
}

export async function saveMfgDoc(kind: MfgKindKey, s: string, b: number | string, body: Partial<MfgDoc>): Promise<MfgDoc> {
  return json(await fetch(base(kind, s, b), {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }));
}

export async function updateMfgDoc(
  kind: MfgKindKey, s: string, b: number | string, id: number, body: Partial<MfgDoc>
): Promise<MfgDoc> {
  return json(await fetch(`${base(kind, s, b)}/${id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }));
}

export async function deleteMfgDoc(kind: MfgKindKey, s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${base(kind, s, b)}/${id}`, { method: 'DELETE' });
}
