import { DetailBGroup, MasterGroup } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

async function json<T>(req: Promise<Response>): Promise<T> {
  const res = await req;
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const send = (method: string, body: any): RequestInit => ({
  method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
});

// Master groups are company-wide (a region is not a branch's own), detail B groups are read
// through a branch because the branch list they carry is the current branch's view of access.
export const getMasterGroups = (s: string) =>
  json<MasterGroup[]>(fetch(`${API_BASE}/api/${s}/masterGroups`));

export const saveMasterGroup = (s: string, body: Partial<MasterGroup>) =>
  json<MasterGroup>(fetch(`${API_BASE}/api/${s}/masterGroups`, send('POST', body)));

export const updateMasterGroup = (s: string, id: number, body: Partial<MasterGroup>) =>
  json<MasterGroup>(fetch(`${API_BASE}/api/${s}/masterGroups/${id}`, send('PUT', body)));

export const deleteMasterGroup = (s: string, id: number) =>
  json<{ success: boolean }>(fetch(`${API_BASE}/api/${s}/masterGroups/${id}`, { method: 'DELETE' }));

export const markMasterGroupDefault = (s: string, id: number) =>
  json<{ success: boolean }>(fetch(`${API_BASE}/api/${s}/masterGroups/${id}/MarkAsDefault`, { method: 'PATCH' }));

export const getDetailBGroups = (s: string, b: number | string) =>
  json<DetailBGroup[]>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups`));

export const getDetailBGroup = (s: string, b: number | string, id: number) =>
  json<DetailBGroup>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups/${id}`));

export const saveDetailBGroup = (s: string, b: number | string, body: Partial<DetailBGroup>) =>
  json<DetailBGroup>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups`, send('POST', body)));

export const updateDetailBGroup = (s: string, b: number | string, id: number, body: Partial<DetailBGroup>) =>
  json<DetailBGroup>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups/${id}`, send('PUT', body)));

export const deleteDetailBGroup = (s: string, b: number | string, id: number) =>
  json<{ success: boolean }>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups/${id}`, { method: 'DELETE' }));

export const markDetailBGroupDefault = (s: string, b: number | string, id: number) =>
  json<{ success: boolean }>(fetch(`${API_BASE}/api/${s}/${b}/detailbgroups/${id}/default`, { method: 'PATCH' }));
