// The HR book: staff, their pay scheme, attendance, leave, advances and the payroll run
// that settles all of it. Every call is per company and branch like the rest of the API.
import { Branch } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}
const send = (method: string, body?: any): RequestInit => ({
  method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body ?? {})
});
const q = (params: Record<string, any>) => {
  const s = Object.entries(params)
    .filter(([, v]) => v !== '' && v !== null && v !== undefined)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join('&');
  return s ? `?${s}` : '';
};

// A month key like 2026-09 is what the API carries; the desk reads names.
const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const monthNamed = (m: string) => {
  const [y, mm] = String(m || '').split('-').map(Number);
  return `${MONTH_SHORT[(mm || 1) - 1]} ${y || ''}`.trim();
};

export type PayHeadKind = 'Earning' | 'Deduction';
export type PayHeadBasis = 'Fixed' | 'Basic %' | 'Gross %';
export type HrMark = 'Present' | 'Absent' | 'Half Day' | 'Leave' | 'Off' | 'Holiday' | 'On Duty';
export type LeaveStatus = 'Applied' | 'Approved' | 'Rejected' | 'Cancelled';
export type SheetStatus = 'Draft' | 'Approved' | 'Paid';

export interface LedgerAccountRef { id: number; code: string; name: string; type: string }
export interface IdName { id: number; name: string }
export interface UserRef { id: number; name: string; username: string }

export interface MarkTally {
  Present: number; Absent: number; 'Half Day': number; Leave: number;
  Off: number; Holiday: number; 'On Duty': number;
}

export interface Employee extends Record<string, any> {
  id: number; code: string; name: string; fatherName: string; cnic: string;
  gender: 'Male' | 'Female' | 'Other'; phone: string; email: string; address: string; city: string;
  departmentId: number | null; designationId: number | null; grade: string; branchId: number;
  employmentType: string; status: string; joiningDate: string; confirmationDate: string;
  exitDate: string; exitReason: string; basicSalary: number; bankName: string; bankAccount: string;
  weeklyOff: string; userId: number | null; photo: string; notes: string; isActive: boolean;
  departmentName: string; designationName: string; branchName: string; userName: string;
  gross: number; withheld: number; net: number; serviceMonths: number; loanBalance: number;
  pendingLeave: number; marks: { counts: MarkTally; marked: number; total: number; unmarked: number; unpaidLeave: number; unpaidDays: number; overtimeHours: number; lateDays: number; filled: boolean };
}

export interface EmployeeHub {
  data: Employee[]; total: number; active: number; payrollCost: number;
  departments: IdName[]; designations: IdName[]; branches: Branch[]; users: UserRef[];
  grades: string[]; employmentTypes: string[]; statuses: string[]; weeklyOffs: string[];
  accounts: LedgerAccountRef[];
}

export const getEmployees = async (s: string, b: number | string, filters: Record<string, any> = {})
  : Promise<EmployeeHub> => json(await fetch(`${root(s, b)}/hr/employees${q(filters)}`));
export const saveEmployee = async (s: string, b: number | string, body: Partial<Employee>)
  : Promise<Employee> => (await json<{ data: Employee }>(await fetch(`${root(s, b)}/hr/employees`, send('POST', body)))).data;
export const updateEmployee = async (s: string, b: number | string, id: number, body: Partial<Employee>)
  : Promise<Employee> => (await json<{ data: Employee }>(await fetch(`${root(s, b)}/hr/employees/${id}`, send('PUT', body)))).data;
export const deleteEmployee = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/employees/${id}`, { method: 'DELETE' }));

export interface PayHead extends Record<string, any> {
  id: number; code: string; name: string; kind: PayHeadKind; basis: PayHeadBasis;
  rate: number; amount: number; accountId: number | null; accountName: string;
  auto: boolean; rule: '' | 'PerfectAttendance' | 'LoanRecovery' | 'AdvanceRecovery';
  taxable: boolean; sequence: number; isActive: boolean; description: string;
  usedBy: number; onSheets: number;
}
export interface PayHeadHub {
  data: PayHead[]; total: number; kinds: PayHeadKind[]; bases: PayHeadBasis[];
  accounts: LedgerAccountRef[];
}
export const getPayHeads = async (s: string, b: number | string): Promise<PayHeadHub> =>
  json(await fetch(`${root(s, b)}/hr/payheads`));
export const savePayHead = async (s: string, b: number | string, body: Partial<PayHead>)
  : Promise<PayHead> => (await json<{ data: PayHead }>(await fetch(`${root(s, b)}/hr/payheads`, send('POST', body)))).data;
export const updatePayHead = async (s: string, b: number | string, id: number, body: Partial<PayHead>)
  : Promise<PayHead> => (await json<{ data: PayHead }>(await fetch(`${root(s, b)}/hr/payheads/${id}`, send('PUT', body)))).data;
export const deletePayHead = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/payheads/${id}`, { method: 'DELETE' }));

export interface StructureLine {
  headId: number; name: string; kind: PayHeadKind; basis: PayHeadBasis;
  rate: number; amount: number; auto: boolean;
}
export interface SalaryStructureView {
  employeeId: number; code: string; name: string; department: string; designation: string;
  grade: string; joiningDate: string; status: string; isActive: boolean;
  basic: number; lines: StructureLine[]; revisedOn: string; notes: string; saved: boolean;
  gross: number; deductions: number; net: number;
  history?: { date: string; note: string; basic: number; gross: number }[];
}
export interface StructureHub {
  data: SalaryStructureView[]; total: number; payrollCost: number;
  heads: { id: number; code: string; name: string; kind: PayHeadKind; basis: PayHeadBasis; rate: number; amount: number; auto: boolean; isActive: boolean }[];
  earnings: PayHead[]; deductions: PayHead[];
}
export const getStructures = async (s: string, b: number | string): Promise<StructureHub> =>
  json(await fetch(`${root(s, b)}/hr/salary-structures`));
export const getStructure = async (s: string, b: number | string, employeeId: number)
  : Promise<SalaryStructureView> => (await json<{ data: SalaryStructureView }>(
    await fetch(`${root(s, b)}/hr/salary-structures/${employeeId}`))).data;
export const saveStructure = async (s: string, b: number | string, employeeId: number,
  body: { basic: number; lines: StructureLine[]; revisedOn?: string; notes?: string })
  : Promise<SalaryStructureView> => (await json<{ data: SalaryStructureView }>(
    await fetch(`${root(s, b)}/hr/salary-structures/${employeeId}`, send('PUT', body)))).data;
export const resetStructure = async (s: string, b: number | string, employeeId: number)
  : Promise<SalaryStructureView> => (await json<{ data: SalaryStructureView }>(
    await fetch(`${root(s, b)}/hr/salary-structures/${employeeId}`, { method: 'DELETE' }))).data;

export interface AttendanceRow {
  employeeId: number; code: string; name: string; department: string; designation: string;
  weeklyOff: string; days: Record<string, HrMark>; note: string;
  counts: MarkTally; marked: number; total: number; unmarked: number; unpaidLeave: number;
  unpaidDays: number; overtimeHours: number; lateDays: number; filled: boolean;
  tally: MarkTally;
}
export interface AttendanceHub {
  data: AttendanceRow[]; month: string; monthLabel: string; months: string[]; days: number;
  marks: HrMark[]; weeklyOff: string; total: number; filled: number; absentDays: number; leaveDays: number;
}
export const getAttendance = async (s: string, b: number | string, month: string)
  : Promise<AttendanceHub> => json(await fetch(`${root(s, b)}/hr/attendance${q({ month })}`));
// A row is the employee's whole month: the server replaces what it holds with what is sent.
export const putAttendance = async (s: string, b: number | string, month: string, rows: {
  employeeId: number; days: Record<string, HrMark>; overtimeHours?: number; lateDays?: number; note?: string;
}[]) => json<{ data: any[]; warning: string }>(
  await fetch(`${root(s, b)}/hr/attendance`, send('PUT', { month, rows })));
export const markAttendanceDay = async (s: string, b: number | string, body: {
  employeeId: number; month: string; day: number; mark: HrMark;
}) => json(await fetch(`${root(s, b)}/hr/attendance/mark`, send('POST', body)));

export interface LeaveType {
  id: number; code: string; name: string; daysPerYear: number; carryForward: number;
  paid: boolean; requiresProof: boolean; isActive: boolean; description: string; applied: number;
}
export interface LeaveBalanceRow {
  leaveTypeId: number; code: string; name: string; paid: boolean;
  entitled: number; used: number; pending: number; carryForward: number; remaining: number;
}
export interface LeaveApplication extends Record<string, any> {
  id: number; number: string; employeeId: number; leaveTypeId: number; from: string; to: string;
  days: number; halfDay: boolean; reason: string; addressOnLeave: string; status: LeaveStatus;
  appliedOn: string; decidedOn: string; decidedBy: string; decisionNote: string;
  employeeName: string; employeeCode: string; department: string; leaveTypeName: string;
  paid: boolean; monthLabel: string;
}
export interface LeaveHub {
  data: LeaveApplication[]; total: number; pending: number; types: LeaveType[];
  statuses: LeaveStatus[]; employees: { id: number; code: string; name: string }[];
  year: number;
  balances: { employeeId: number; code: string; name: string; department: string; rows: LeaveBalanceRow[] }[];
}
export const getLeave = async (s: string, b: number | string, filters: Record<string, any> = {})
  : Promise<LeaveHub> => json(await fetch(`${root(s, b)}/hr/leave${q(filters)}`));
export const saveLeave = async (s: string, b: number | string, body: Partial<LeaveApplication>)
  : Promise<LeaveApplication> => (await json<{ data: LeaveApplication }>(
    await fetch(`${root(s, b)}/hr/leave`, send('POST', body)))).data;
export const updateLeave = async (s: string, b: number | string, id: number, body: Partial<LeaveApplication>)
  : Promise<LeaveApplication> => (await json<{ data: LeaveApplication }>(
    await fetch(`${root(s, b)}/hr/leave/${id}`, send('PUT', body)))).data;
export const decideLeave = async (s: string, b: number | string, id: number, status: LeaveStatus, note = '')
  : Promise<LeaveApplication> => (await json<{ data: LeaveApplication }>(
    await fetch(`${root(s, b)}/hr/leave/${id}/decide`, send('POST', { status, note })))).data;
export const deleteLeave = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/leave/${id}`, { method: 'DELETE' }));
export const saveLeaveType = async (s: string, b: number | string, body: Partial<LeaveType>)
  : Promise<LeaveType> => (await json<{ data: LeaveType }>(
    await fetch(`${root(s, b)}/hr/leave-types`, send('POST', body)))).data;
export const updateLeaveType = async (s: string, b: number | string, id: number, body: Partial<LeaveType>)
  : Promise<LeaveType> => (await json<{ data: LeaveType }>(
    await fetch(`${root(s, b)}/hr/leave-types/${id}`, send('PUT', body)))).data;
export const deleteLeaveType = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/leave-types/${id}`, { method: 'DELETE' }));

export interface EmployeeLoan extends Record<string, any> {
  id: number; number: string; employeeId: number; kind: string; purpose: string;
  sanctionedOn: string; amount: number; installments: number; installmentAmount: number;
  deducted: number; balance: number; status: 'Active' | 'Closed' | 'Cancelled';
  startMonth: string; recoveredMonths: string[]; accountId: number | null; accountName: string;
  journalId: number | null; remarks: string;
  employeeName: string; employeeCode: string; department: string; installmentsPaid: number;
  left: number; journalNumber: string; nextInstallment: number;
}
export interface LoanHub {
  data: EmployeeLoan[]; total: number; kinds: string[]; statuses: string[];
  outstanding: number; sanctioned: number; recovered: number; activeEmployees: number;
  employees: { id: number; code: string; name: string }[]; accounts: LedgerAccountRef[]; months: string[];
}
export const getLoans = async (s: string, b: number | string, filters: Record<string, any> = {})
  : Promise<LoanHub> => json(await fetch(`${root(s, b)}/hr/loans${q(filters)}`));
export const saveLoan = async (s: string, b: number | string, body: Partial<EmployeeLoan>)
  : Promise<EmployeeLoan> => (await json<{ data: EmployeeLoan }>(
    await fetch(`${root(s, b)}/hr/loans`, send('POST', body)))).data;
export const updateLoan = async (s: string, b: number | string, id: number, body: Partial<EmployeeLoan>)
  : Promise<EmployeeLoan> => (await json<{ data: EmployeeLoan }>(
    await fetch(`${root(s, b)}/hr/loans/${id}`, send('PUT', body)))).data;
export const deleteLoan = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/loans/${id}`, { method: 'DELETE' }));

export interface PayItem { headId: number; name: string; amount: number }
export interface LoanRecovery { loanId: number; number: string; kind: string; amount: number }
export interface PayrollLine extends Record<string, any> {
  employeeId: number; employeeCode: string; employeeName: string; department: string;
  designation: string; grade: string; basic: number; earnings: PayItem[]; deductions: PayItem[];
  absence: number; extraEarnings: PayItem[]; extraDeductions: PayItem[];
  gross: number; totalDeductions: number; net: number;
  payableDays: number; present: number; absent: number; halfDays: number; leaves: number;
  offs: number; unpaidDays: number; paid: boolean; recoveries: LoanRecovery[]; remarks: string;
}
export interface SheetTotals {
  employees: number; gross: number; deductions: number; netPayable: number; unpaidDays: number; paidLines: number;
}
export interface SalarySheetHead extends SheetTotals {
  id: number; number: string; month: string; monthLabel: string; status: SheetStatus;
  payThrough: string; accountId: number | null; accountName: string;
  deductForAbsence: boolean; recoverLoans: boolean;
  journalId: number | null; paymentJournalId: number | null; journalNumber: string;
  paymentJournalNumber: string; createdOn: string; approvedOn: string; paidOn: string; notes: string;
}
export interface SalarySheetView extends SalarySheetHead {
  lines: PayrollLine[];
  byHead: { head: string; kind: PayHeadKind; amount: number }[];
  byDepartment: { department: string; gross: number; net: number; staff: number }[];
}
export interface SalarySheetHub {
  data: SalarySheetHead[]; total: number; months: string[]; draft: number; approved: number;
  headcount: number; heads: { id: number; name: string; kind: PayHeadKind }[];
  accounts: LedgerAccountRef[]; payThrough: string[]; settings: HrSettings;
}
export interface HrSettings {
  payDaysInMonth: number; weeklyOff: string; deductForAbsence: boolean; recoverLoans: boolean;
  paySalaryThrough: string; defaultPayAccountName: string;
}
export interface HrSummary {
  data: {
    headcount: number; active: number; onLeave: number; resigned: number; monthlyGross: number;
    monthlyNet: number; advancesOutstanding: number; attendanceMarked: number; attendanceTotal: number;
    pendingLeave: number; sheet: SalarySheetHead | null; month: string; monthLabel: string; departments: number;
  };
  months: string[];
}
export const getHrSummary = async (s: string, b: number | string): Promise<HrSummary> =>
  json(await fetch(`${root(s, b)}/hr/summary`));
export const getHrSettings = async (s: string, b: number | string)
  : Promise<{ data: HrSettings; payThrough: string[]; accounts: LedgerAccountRef[] }> =>
    json(await fetch(`${root(s, b)}/hr/settings`));
export const saveHrSettings = async (s: string, b: number | string, body: Partial<HrSettings>)
  : Promise<HrSettings> => (await json<{ data: HrSettings }>(
    await fetch(`${root(s, b)}/hr/settings`, send('PUT', body)))).data;

export const getSheets = async (s: string, b: number | string): Promise<SalarySheetHub> =>
  json(await fetch(`${root(s, b)}/hr/salary-sheets`));
export const getSheet = async (s: string, b: number | string, id: number)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets/${id}`))).data;
export const previewSheet = async (s: string, b: number | string, month: string, opts: Record<string, any> = {})
  : Promise<{ data: { month: string; monthLabel: string; lines: PayrollLine[] } & SheetTotals & {
    unmarked: string[]; byDepartment: SalarySheetView['byDepartment']; byHead: SalarySheetView['byHead'];
  }; settings: HrSettings }> => json(await fetch(`${root(s, b)}/hr/salary-sheets/preview${q({ month, ...opts })}`));
export const createSheet = async (s: string, b: number | string, body: Record<string, any>)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets`, send('POST', body)))).data;
export const updateSheet = async (s: string, b: number | string, id: number, body: Record<string, any>)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets/${id}`, send('PUT', body)))).data;
export const approveSheet = async (s: string, b: number | string, id: number)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets/${id}/approve`, send('POST')))).data;
export const unapproveSheet = async (s: string, b: number | string, id: number)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets/${id}/unapprove`, send('POST')))).data;
export const paySheet = async (s: string, b: number | string, id: number, body: Record<string, any>)
  : Promise<SalarySheetView> => (await json<{ data: SalarySheetView }>(
    await fetch(`${root(s, b)}/hr/salary-sheets/${id}/pay`, send('POST', body)))).data;
export const deleteSheet = async (s: string, b: number | string, id: number) =>
  json(await fetch(`${root(s, b)}/hr/salary-sheets/${id}`, { method: 'DELETE' }));

export interface PayslipRow extends PayrollLine {
  number: string; month: string; monthLabel: string; status: SheetStatus; paidOn: string;
}
export const getPayslips = async (s: string, b: number | string, employeeId: number)
  : Promise<{ data: PayslipRow[]; employee: Employee; total: number }> =>
    json(await fetch(`${root(s, b)}/hr/payslips/${employeeId}`));
