import {
  Party, Product, Category, CategoryType, SalesPerson, SalesPersonDocSetting, NumberSeries, StockBreakdown,
  Uom, UomBand, UomBoard
} from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}`;

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

// ─── Customers / Vendors ───────────────────────────────────────────────────
export type PartyResource = 'customers' | 'vendors';

const partyUrl = (kind: PartyResource, s: string, b: number | string) => `${root(s, b)}/${kind}`;

export async function getParties(kind: PartyResource, s: string, b: number | string, search = ''): Promise<{ data: Party[]; total: number }> {
  const p = new URLSearchParams({ search });
  return json(await fetch(`${partyUrl(kind, s, b)}?${p}`));
}
export async function getParty(kind: PartyResource, s: string, b: number | string, id: number): Promise<Party> {
  return json(await fetch(`${partyUrl(kind, s, b)}/${id}`));
}
export async function getPartyProposedNumber(kind: PartyResource, s: string, b: number | string): Promise<string> {
  const r: { number: string } = await json(await fetch(`${partyUrl(kind, s, b)}/proposed-number`));
  return r.number;
}
export async function saveParty(kind: PartyResource, s: string, b: number | string, body: Partial<Party>): Promise<Party> {
  return json(await fetch(partyUrl(kind, s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function updateParty(kind: PartyResource, s: string, b: number | string, id: number, body: Partial<Party>): Promise<Party> {
  return json(await fetch(`${partyUrl(kind, s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function deleteParty(kind: PartyResource, s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${partyUrl(kind, s, b)}/${id}`, { method: 'DELETE' });
}

// ─── Categories / Brands ───────────────────────────────────────────────────
export async function getCategories(s: string, b: number | string, type: CategoryType | '' = '', search = ''): Promise<{ data: Category[]; total: number }> {
  const p = new URLSearchParams({ type, search });
  return json(await fetch(`${root(s, b)}/categories?${p}`));
}
export async function addCategory(s: string, b: number | string, name: string, type: CategoryType,
  parentId: number | null = null): Promise<Category> {
  return json(await fetch(`${root(s, b)}/categories`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, type, parentId })
  }));
}
export async function deleteCategory(s: string, b: number | string, id: number): Promise<void> {
  // A category other records stand on cannot be dropped out from under them, and the reason
  // the register refused has to reach the screen that asked for it.
  await json(await fetch(`${root(s, b)}/categories/${id}`, { method: 'DELETE' }));
}

// ─── Units of Measurement ──────────────────────────────────────────────────
// The board the masters pick their unit from. Every read carries the count of records
// using each unit, so the switchboard's badge and a product's own unit cannot drift apart.
const uomUrl = (s: string, b: number | string) => `${root(s, b)}/uoms`;

export async function getUoms(s: string, b: number | string, search = '', status = ''): Promise<UomBoard> {
  const p = new URLSearchParams({ search, status });
  return json(await fetch(`${uomUrl(s, b)}?${p}`));
}
export async function addUom(s: string, b: number | string, body: { code: string; name: string; band: UomBand }): Promise<Uom> {
  return json(await fetch(uomUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function updateUom(s: string, b: number | string, id: number, body: Partial<Uom>): Promise<Uom> {
  return json(await fetch(`${uomUrl(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
// A unit still carrying records refuses to go; the server's reason is shown on the card.
export async function deleteUom(s: string, b: number | string, id: number): Promise<void> {
  await json(await fetch(`${uomUrl(s, b)}/${id}`, { method: 'DELETE' }));
}

// ─── Products ──────────────────────────────────────────────────────────────

const productsUrl = (s: string, b: number | string) => `${root(s, b)}/products`;

export async function getProducts(s: string, b: number | string, search = ''): Promise<{ data: Product[]; total: number }> {
  const p = new URLSearchParams({ search });
  return json(await fetch(`${productsUrl(s, b)}?${p}`));
}
export async function getProduct(s: string, b: number | string, id: number): Promise<Product> {
  return json(await fetch(`${productsUrl(s, b)}/${id}`));
}
// Where a product's stock actually sits, worked out by the ledger on the spot rather than
// stored a second time, so the modal cannot disagree with the figure on the row that opened it.
export async function getStockBreakdown(s: string, b: number | string, id: number): Promise<StockBreakdown> {
  return json(await fetch(`${productsUrl(s, b)}/${id}/stock-breakdown`));
}
export async function getProductProposedNumber(s: string, b: number | string): Promise<string> {
  const r: { number: string } = await json(await fetch(`${productsUrl(s, b)}/proposed-number`));
  return r.number;
}
export async function saveProduct(s: string, b: number | string, body: Partial<Product>): Promise<Product> {
  return json(await fetch(productsUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function updateProduct(s: string, b: number | string, id: number, body: Partial<Product>): Promise<Product> {
  return json(await fetch(`${productsUrl(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function deleteProduct(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${productsUrl(s, b)}/${id}`, { method: 'DELETE' });
}

// ─── Bulk upload of products ────────────────────────────────────────────────
// The sheet is read by the server, which answers row by row with what it made of each one. The
// screen never guesses a verdict: it shows the answer's own columns, numbers and problems back.
export interface BulkTemplateColumn { label: string; field: string; required: boolean; note: string }
export interface BulkTemplate {
  columns: BulkTemplateColumn[];
  examples: Record<string, string | number>[];
  units: { code: string; name: string }[];
  categories: string[];
  brands: string[];
  types: string[];
  tips: string[];
}
export interface BulkRowVerdict { line: number; values: Record<string, string>; problems: string[] }
export interface BulkAnswer {
  read: number; ready: number; bad: number;
  ignored: string[]; columns: string[];
  rows: BulkRowVerdict[]; more: number; applied: boolean;
  created?: { code: string; name: string }[];
  skipped?: { line: number; name: string; reason: string }[];
}

export async function getProductBulkTemplate(s: string, b: number | string): Promise<BulkTemplate> {
  return json(await fetch(`${productsUrl(s, b)}/bulk-template`));
}

// One door, two presses: `apply` off is the check that writes nothing, `apply` on is the press
// that files the rows it vouched for.
export async function uploadProductBulk(
  s: string, b: number | string, file: string, name: string, apply: boolean
): Promise<BulkAnswer> {
  return json(await fetch(`${productsUrl(s, b)}/bulk`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ file, name, apply })
  }));
}

// ─── Sales Persons ─────────────────────────────────────────────────────────
const spUrl = (s: string, b: number | string) => `${root(s, b)}/salesPersons`;

export async function getSalesPersons(s: string, b: number | string, search = ''): Promise<{ data: SalesPerson[]; total: number }> {
  const p = new URLSearchParams({ search });
  return json(await fetch(`${spUrl(s, b)}?${p}`));
}
export async function saveSalesPerson(s: string, b: number | string, body: Partial<SalesPerson>): Promise<SalesPerson> {
  return json(await fetch(spUrl(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function updateSalesPerson(s: string, b: number | string, id: number, body: Partial<SalesPerson>): Promise<SalesPerson> {
  return json(await fetch(`${spUrl(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
}
export async function deleteSalesPerson(s: string, b: number | string, id: number): Promise<void> {
  await fetch(`${spUrl(s, b)}/${id}`, { method: 'DELETE' });
}

// ─── Number series (assigned to a sales person) ────────────────────────────
export async function getNumberSeries(s: string, b: number | string, kind?: NumberSeries['kind']): Promise<NumberSeries[]> {
  const p = kind ? `?kind=${kind}` : '';
  const r: { data: NumberSeries[] } = await json(await fetch(`${root(s, b)}/numberSeries${p}`));
  return r.data;
}
export async function saveNumberSeries(s: string, b: number | string, body: Partial<NumberSeries>): Promise<NumberSeries> {
  const r: { data: NumberSeries } = await json(await fetch(`${root(s, b)}/numberSeries`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }));
  return r.data;
}

export async function getSalesPersonSettings(s: string, b: number | string): Promise<SalesPersonDocSetting[]> {
  const r: { data: SalesPersonDocSetting[] } = await json(await fetch(`${root(s, b)}/settings/salesPerson`));
  return r.data;
}
export async function saveSalesPersonSettings(s: string, b: number | string, rows: SalesPersonDocSetting[]): Promise<SalesPersonDocSetting[]> {
  const r: { data: SalesPersonDocSetting[] } = await json(await fetch(`${root(s, b)}/settings/salesPerson`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(rows)
  }));
  return r.data;
}
