import { LedgerAccount } from '../types';

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';

function url(s: string, b: number | string) { return `${API_BASE}/api/${s}/${b}/chart-of-accounts`; }

async function write<T>(res: Response, fallback: string): Promise<T> {
  const data = await res.json().catch(() => null) as any;
  if (!res.ok) throw new Error(data?.error || data?.message || fallback);
  return data as T;
}

export async function getLedgerAccounts(s: string, b: number | string, search = ''): Promise<{ data: LedgerAccount[]; total: number }> {
  const p = new URLSearchParams({ search });
  return (await fetch(`${url(s, b)}?${p}`)).json();
}

export async function getProposedLedgerCode(s: string, b: number | string, type: string, parentId?: number | null): Promise<string> {
  const p = new URLSearchParams({ type });
  if (parentId) p.set('parentId', String(parentId));
  const r = await fetch(`${url(s, b)}/proposed-code?${p}`).then(r => r.json()).catch(() => null) as { proposedCode?: string } | null;
  return r?.proposedCode ?? '';
}

export async function addLedgerAccount(s: string, b: number | string, body: Partial<LedgerAccount>): Promise<LedgerAccount> {
  return write(await fetch(url(s, b), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }), 'Failed to save account');
}

export async function updateLedgerAccount(s: string, b: number | string, id: number, body: Partial<LedgerAccount>): Promise<LedgerAccount> {
  return write(await fetch(`${url(s, b)}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }), 'Failed to update account');
}

export async function deleteLedgerAccount(s: string, b: number | string, id: number): Promise<void> {
  await write(await fetch(`${url(s, b)}/${id}`, { method: 'DELETE' }), 'Failed to delete account');
}
