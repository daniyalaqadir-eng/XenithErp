export interface PosCounter {
  id: number;
  code: string;
  name: string;
  warehouseId: number | null;
  warehouseName: string;
  terminalCount: number;
  printerName: string;
  receiptTemplate: string;
  cashDrawerLimit: number;
  autoPrint: boolean;
  allowDiscount: boolean;
  maxDiscountPercent: number;
  openShift: boolean;
  shiftTiming: string;
  isActive: boolean;
  address: string;
  remarks: string;
}

export interface PosTemplate {
  id: number;
  code: string;
  name: string;
  kind: 'Barcode' | 'QR Code';
  symbology: string;
  paperWidth: number;
  paperHeight: number;
  margin: number;
  fontSize: number;
  showName: boolean;
  showSku: boolean;
  showPrice: boolean;
  showTax: boolean;
  showCompany: boolean;
  showExpiry: boolean;
  prefix: string;
  suffix: string;
  priceLabel: 'Sale Price' | 'Retail Price' | 'Gross Price';
  copies: number;
  headerText: string;
  footerText: string;
  isActive: boolean;
}

export interface PosProduct {
  id: number;
  name: string;
  sku: string;
  barcode: string;
  unit: string;
  price: number;
  taxPercent: number;
  categoryName: string;
  stockQty: number;
  trackStock: boolean;
  batch: boolean;
  serial: boolean;
}

export interface PosBillLine {
  id: number;
  productId: number | null;
  productName: string;
  sku: string;
  unit: string;
  quantity: number;
  price: number;
  discountPercent: number;
  amount: number;
}

export interface PosBill {
  id: number;
  number: string;
  date: string;
  time: string;
  counterId: number;
  counterName: string;
  cashier: string;
  customerName: string;
  type: 'Sale' | 'Return';
  status: 'Settled' | 'Open' | 'Void';
  lines: PosBillLine[];
  subtotal: number;
  discount: number;
  tax: number;
  grandTotal: number;
  payments: { mode: string; amount: number }[];
  cashReceived: number;
  change: number;
}

export interface PosDailySummary {
  datewise: { date: string; bills: number; grossSales: number; returns: number; discounts: number; tax: number; netSales: number; cash: number; card: number; wallet: number; bank: number }[];
  counterwise: { counterId: number; counterName: string; bills: number; items: number; averageBill: number; netSales: number; cash: number; card: number; wallet: number; bank: number; voided: number }[];
  totals: { bills: number; netSales: number; cash: number; card: number; wallet: number; tax: number; discounts: number };
  openedShifts: number;
  activeCounters: number;
}

const API_BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const root = (s: string, b: number | string) => `${API_BASE}/api/${s}/${b}/pos`;

// The session lives in localStorage under the same key the other services read, so the
// till talks to the API the same way the rest of the app does. A missing token still sends
// the request: the server answers 401 and json() turns that into the message the screen shows.
function authHeaders(): Record<string, string> {
  try {
    const token = JSON.parse(localStorage.getItem('xenith_auth') || 'null')?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch { return {}; }
}

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data as T;
}

const send = (url: string, method: string, body?: any) =>
  fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });

export const getPosCounters = async (s: string, b: number | string, search = ''): Promise<{ data: PosCounter[]; total: number }> =>
  json(await send(`${root(s, b)}/counters?search=${encodeURIComponent(search)}`, 'GET'));
export const savePosCounter = async (s: string, b: number | string, body: Partial<PosCounter>): Promise<PosCounter> =>
  json(await send(`${root(s, b)}/counters`, 'POST', body));
export const updatePosCounter = async (s: string, b: number | string, id: number, body: Partial<PosCounter>): Promise<PosCounter> =>
  json(await send(`${root(s, b)}/counters/${id}`, 'PUT', body));
export const deletePosCounter = async (s: string, b: number | string, id: number): Promise<{ ok: boolean }> =>
  json(await send(`${root(s, b)}/counters/${id}`, 'DELETE'));

export const getPosTemplates = async (s: string, b: number | string, search = '', kind = ''): Promise<{ data: PosTemplate[]; total: number }> =>
  json(await send(`${root(s, b)}/barcode-templates?search=${encodeURIComponent(search)}&kind=${encodeURIComponent(kind)}`, 'GET'));
export const savePosTemplate = async (s: string, b: number | string, body: Partial<PosTemplate>): Promise<PosTemplate> =>
  json(await send(`${root(s, b)}/barcode-templates`, 'POST', body));
export const updatePosTemplate = async (s: string, b: number | string, id: number, body: Partial<PosTemplate>): Promise<PosTemplate> =>
  json(await send(`${root(s, b)}/barcode-templates/${id}`, 'PUT', body));
export const deletePosTemplate = async (s: string, b: number | string, id: number): Promise<{ ok: boolean }> =>
  json(await send(`${root(s, b)}/barcode-templates/${id}`, 'DELETE'));

export const getPosProducts = async (s: string, b: number | string, search = '', category = ''): Promise<{ data: PosProduct[]; total: number }> =>
  json(await send(`${root(s, b)}/products?search=${encodeURIComponent(search)}&category=${encodeURIComponent(category)}`, 'GET'));

export const getPosBills = async (s: string, b: number | string, q: { from?: string; to?: string; counterId?: string | number; search?: string } = {}): Promise<{ data: PosBill[]; total: number }> => {
  const p = new URLSearchParams({ from: q.from ?? '', to: q.to ?? '', counterId: String(q.counterId ?? ''), search: q.search ?? '' });
  return json(await send(`${root(s, b)}/bills?${p}`, 'GET'));
};
export const savePosBill = async (s: string, b: number | string, body: any): Promise<PosBill> =>
  json(await send(`${root(s, b)}/bills`, 'POST', body));

export const getPosDailySummary = async (s: string, b: number | string, from = '', to = '', counterId = 'All'): Promise<PosDailySummary> =>
  json(await send(`${root(s, b)}/daily-summary?from=${from}&to=${to}&counterId=${encodeURIComponent(counterId)}`, 'GET'));
