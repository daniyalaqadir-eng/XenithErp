import React, { useEffect, useState } from 'react';
import { TenantProvider, useTenant } from './context/TenantContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AuthScreen } from './pages/Auth/AuthScreen';
import { Header } from './components/layout/Header';
import { Sidebar, screenOfTab, labelOfTab } from './components/layout/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { SalesmanDashboard } from './pages/Sales/SalesmanDashboard';
import Home from './pages/Home';
import { SaleInvoices } from './pages/Sales/SaleInvoices';
import { DeliveryChallans } from './pages/Sales/DeliveryChallans';
import { WarehouseDashboard } from './pages/Warehouse/WarehouseDashboard';
import { DetailBGroupList } from './pages/DetailBGroup/DetailBGroupList';
import { MasterGroupList } from './pages/MasterGroup/MasterGroupList';
import { BranchLocations } from './pages/Classification/BranchLocations';
import { UnitsOfMeasurement } from './pages/Classification/UnitsOfMeasurement';
import { BankAccounts } from './pages/Banking/BankAccounts';
import { JournalEntries } from './pages/Banking/JournalEntries';
import { ItemMaster } from './pages/Inventory/ItemMaster';
import { PartyPage } from './pages/Masters/PartyPage';
import { ProductsPage } from './pages/Masters/ProductPage';
import { SalesPersonsPage } from './pages/Masters/SalesPersonsPage';
import { CategoryPage, CATEGORY_TITLES } from './pages/Masters/CategoryPage';
import { CategoryType } from './types';
import { StockLedger } from './pages/Inventory/StockLedger';
import { AdjustmentTypes } from './pages/Inventory/AdjustmentTypes';
import { ScheduledValuations } from './pages/Inventory/ScheduledValuations';
import { Reports } from './pages/Reports/Reports';
import { ReportViewer } from './pages/Reports/ReportViewer';
import BusinessSummaryReport from './pages/Reports/BusinessSummaryReport';
import { ChartOfAccounts } from './pages/Accounts/ChartOfAccounts';
import CloseYear from './pages/Accounts/CloseYear';
import { DocWorkspace } from './pages/Docs/DocListPage';
import { DOC_KINDS } from './pages/Docs/docKinds';
import { PosTerminal } from './pages/Pos/PosTerminal';
import { CheckoutCounters } from './pages/Pos/CheckoutCounters';
import { BarcodeTemplates } from './pages/Pos/BarcodeTemplates';
import { PosDailySummary } from './pages/Pos/PosDailySummary';
import { PosOffline } from './pages/Pos/PosOffline';
import { ManufacturingDocs, MFG_BY_TAB } from './pages/Manufacturing/ManufacturingDocs';
import { CompanySettings } from './pages/Setup/CompanySettings';
import { UsersPage } from './pages/Setup/Users';
import { RolesPage } from './pages/Setup/Roles';
import { BranchesPage } from './pages/Setup/Branches';
import { WarehousesPage } from './pages/Setup/Warehouses';
import { EmployeesPage } from './pages/Hr/Employees';
import { PayHeadsPage } from './pages/Hr/PayHeads';
import { SalaryStructurePage } from './pages/Hr/SalaryStructure';
import { AttendanceSheetPage } from './pages/Hr/AttendanceSheet';
import { LeavePage } from './pages/Hr/Leave';
import { LoansPage } from './pages/Hr/Loans';
import { SalarySheetPage } from './pages/Hr/SalarySheet';
import { SubscriptionPage } from './pages/Setup/Subscription';
import { WeeklyRoutesPage } from './pages/Setup/WeeklyRoutes';
import { MyProfilePage } from './pages/Setup/MyProfile';
import { AccessDenied } from './pages/common/AccessDenied';
import { ScreenNotFound } from './pages/common/ScreenNotFound';
import { ReferAndEarn } from './pages/ReferAndEarn';
import { ThemeProvider } from './context/ThemeContext';
import { requestScreenReload } from './utils/screenReload';

// Browser zoom shrinks the CSS viewport, and a 14rem rail that keeps pushing the content
// at that point is what makes text spill out of the cards. Below this width the rail
// floats over the page as a drawer and the content keeps its full width.
const NARROW_QUERY = '(max-width: 1100px)';

const useNarrowViewport = () => {
  const [narrow, setNarrow] = useState(() => window.matchMedia(NARROW_QUERY).matches);
  useEffect(() => {
    const mq = window.matchMedia(NARROW_QUERY);
    const onChange = (e: MediaQueryListEvent) => setNarrow(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);
  return narrow;
};

// The address bar carries the open screen, so any of them can be bookmarked, shared or
// reached with the browser's back button. A tab key keeps its ':' groups as path segments:
// doc:sale-invoice -> /doc/sale-invoice, report:xyz -> /report/xyz, home -> /.
const tabToPath = (tab: string) => (tab === 'home' ? '/' : `/${tab.replace(/:/g, '/')}`);
const pathToTab = (path: string) => {
  const [head, ...rest] = path.replace(/^\/+|\/+$/g, '').split('/');
  return !head ? 'home' : rest.length ? `${head}:${rest.join(':')}` : head;
};

// The tab keys App.tsx knows how to draw. A bookmarked address for a screen that was renamed
// or removed would otherwise render a blank content area.
const DIRECT_TABS = new Set([
  'home', 'dashboard', 'sales-invoices', 'delivery-challan', 'warehouse-dashboard', 'detail-b-groups', 'master-groups', 'branch-locations',
  'uom',
  'customers', 'vendors', 'products', 'sales-persons', 'company-settings', 'refer-earn',
  'bank-accounts', 'item-master', 'stock-ledger', 'adjustment-types', 'scheduled-valuations',
  'journal-entries', 'reports', 'report:business-summary-report', 'chart-of-accounts', 'close-year',
  'pos-terminal', 'pos-counters', 'pos-barcode-templates', 'pos-daily-summary', 'pos-offline',
  'users', 'roles', 'branches', 'warehouses',
  'hr-employees', 'hr-payheads', 'hr-salary-structure', 'hr-attendance', 'hr-leave', 'hr-loans', 'hr-salary-sheet',
  'subscription', 'weekly-routes', 'my-profile', 'change-password'
]);

const hasScreen = (tab: string) =>
  DIRECT_TABS.has(tab) ||
  // A warehouse's own folder of the board is the same screen with one location picked.
  /^delivery-challan:\d+$/.test(tab) ||
  /^warehouse-dashboard:\d+$/.test(tab) ||
  (tab.startsWith('report:') && tab !== 'report:business-summary-report') ||
  (tab.startsWith('doc:') && !!DOC_KINDS[tab.slice(4)]) ||
  (tab.startsWith('manufacturing-') && !!MFG_BY_TAB[tab]) ||
  (tab.startsWith('cat:') && (CATEGORY_TITLES as Record<string, string>)[tab.slice(4)] !== undefined);

// The challan register and its blank paper are gone: a challan is read and worked on the
// dispatch board alone, which files its own papers. Anything still naming the old screen —
// a bookmark, the browser's back button, a link from another deck — lands on the board.
const retiredTab = (tab: string) => (tab === 'doc:sale-delivery' ? 'delivery-challan' : tab);

// The same company read from three desks. This is a preview bar, not a permission grant: a
// salesman is never handed the company-wide page, and a bar with one live button is a label,
// so it hides itself.
type DeckKey = 'executive' | 'salesman' | 'warehouse';

const DECKS: { key: DeckKey; label: string; note: string }[] = [
  { key: 'executive', label: 'Executive Overview', note: 'The whole company on one page' },
  { key: 'salesman', label: 'Salesman View', note: 'Only the paperwork raised in my own name' },
  { key: 'warehouse', label: 'Warehouse', note: 'One gate: the stock standing here and the challans going out' }
];

const MainApp: React.FC = () => {
  const { can, user } = useAuth();
  const narrow = useNarrowViewport();
  const [currentTab, setTabInUrl] = useState<string>(() => retiredTab(pathToTab(window.location.pathname)));
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => window.matchMedia(NARROW_QUERY).matches);
  const [newInvoiceNonce, setNewInvoiceNonce] = useState(0);
  const [docNonce, setDocNonce] = useState(0);
  // Which desk the Dashboard tab is standing at, and which gate the warehouse preview is at.
  // Null means "nobody has picked yet", which is answered by the role below.
  const [deck, setDeck] = useState<DeckKey | null>(null);
  const [previewWarehouse, setPreviewWarehouse] = useState<number | null>(null);

  // Every screen-change writes the URL; back/forward arrive through popstate instead.
  const setCurrentTab = (tab: string) => {
    const to = retiredTab(tab);
    setTabInUrl(to);
    const path = tabToPath(to);
    if (path !== window.location.pathname) window.history.pushState(null, '', path);
  };
  useEffect(() => {
    const onPop = () => setTabInUrl(retiredTab(pathToTab(window.location.pathname)));
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const railOpen = !sidebarCollapsed;
  const railPushes = railOpen && !narrow;

  // Picking a screen from the drawer should hand the page back to the content, and picking
  // the screen that is already open should read it again — the register under his eyes is
  // the one place a clerk expects a second click to do something. The screen answers the
  // ask itself, so a paper mid-typing keeps what has been put on it.
  const selectTab = (tab: string) => {
    if (retiredTab(tab) === currentTab) requestScreenReload();
    else setCurrentTab(tab);
    if (narrow) setSidebarCollapsed(true);
  };

  // The role decides what the signed-in user may open; the sidebar already hides the rest.
  // A tab this build cannot draw at all is not a permission problem, so it skips the guard
  // and lands on the not-found card instead.
  const known = hasScreen(currentTab);
  const guardScreen = screenOfTab(currentTab);
  const denied = known && guardScreen && !can(`${guardScreen}:view`) ? labelOfTab(currentTab) : null;

  // Which decks this person may look at. The role's own tick for a desk decides whether it is
  // drawn at all; the rules behind it stay, so ticking a tab can never hand the company-wide
  // page to a salesman or the warehouse desk to somebody who has never seen a stock ledger.
  const openDecks = DECKS.filter(d => can(`dashboard-${d.key}:view`) && (
    d.key === 'executive' ? !user?.salesmanScoped && can('dashboard:view')
      : d.key === 'salesman' ? !!user?.salesmanScoped || can('sales-invoices:view')
        : can('warehouse-dashboard:view')));
  const wanted = deck ?? (user?.salesmanScoped ? 'salesman' : 'executive');
  const shown = openDecks.some(d => d.key === wanted) ? wanted : openDecks[0]?.key ?? 'executive';

  const openNewDoc = (tab: string) => {
    if (tab === currentTab) { setDocNonce(n => n + 1); return; }
    setCurrentTab(tab);
    setDocNonce(n => n + 1);
  };

  const handleQuickCreate = (type: string) => {
    if (type === 'sale-invoice') { setCurrentTab('sales-invoices'); setNewInvoiceNonce(n => n + 1); return; }
    if (type === 'detail-b-group') { setCurrentTab('detail-b-groups'); return; }
    // A challan is cut out of a bill, so this opens the dispatch board rather than a blank paper.
    if (type === 'sale-delivery') { setCurrentTab('delivery-challan'); return; }
    if (DOC_KINDS[type]) openNewDoc(`doc:${type}`);
  };

  return (
    <TenantProvider>
      <div className="app-shell min-h-screen">
        {/* Top Header */}
        <Header onQuickCreate={handleQuickCreate} onNavigate={setCurrentTab}
          onToggleSidebar={() => setSidebarCollapsed(c => !c)} />

        {/* Sidebar */}
        <Sidebar currentTab={currentTab} onSelectTab={selectTab}
          collapsed={sidebarCollapsed} onToggleCollapsed={() => setSidebarCollapsed(c => !c)} />
        {railOpen && narrow && (
          <div className="fixed inset-0 top-12 z-30 bg-slate-900/40" onClick={() => setSidebarCollapsed(true)} />
        )}

        {/* Main Content Area */}
        <main className={`pt-12 min-h-screen transition-[padding] duration-300 ease-out ${railPushes ? 'pl-60' : 'pl-0'}`}>
          <CompanyWorkspace tabKey={currentTab}>
            {denied ? <AccessDenied screen={denied} onHome={() => setCurrentTab('home')} /> : <>
            {currentTab === 'home' && <Home onNavigate={setCurrentTab} />}
            {currentTab === 'dashboard' && (openDecks.length === 0 ? (
              // Every desk unticked is a decision somebody made on the Roles screen, so this
              // says who to ask instead of leaving a blank page that reads as a broken build.
              <div className="nb-card px-4 py-8 text-center">
                <p className="text-sm font-bold text-gray-700">No dashboard desk is open to your role.</p>
                <p className="mt-1 text-xs text-gray-500">
                  An administrator ticks the desks this screen may show under Setup → User Roles →
                  Dashboard Tab.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {openDecks.length > 1 && (
                  <div className="nb-card px-3.5 py-2.5 flex flex-wrap items-center gap-x-3 gap-y-2">
                    <span className="text-[10px] font-black uppercase tracking-[0.14em] text-gray-500">
                      Role Dashboard Preview
                    </span>
                    <div className="seg-filter" role="group" aria-label="Preview a role's dashboard">
                      {openDecks.map(d => (
                        <button key={d.key} type="button" title={d.note}
                          aria-pressed={shown === d.key} className={shown === d.key ? 'is-on' : ''}
                          onClick={() => setDeck(d.key)}>
                          {d.label}
                        </button>
                      ))}
                    </div>
                    <span className="text-[11px] text-gray-500">
                      {DECKS.find(d => d.key === shown)?.note}
                    </span>
                  </div>
                )}
                {shown === 'salesman' ? (
                  <SalesmanDashboard onNavigate={setCurrentTab} onQuickCreate={handleQuickCreate} />
                ) : shown === 'warehouse' ? (
                  // The terminal's own location switcher moves this preview, not the tab — the
                  // keeper's real entry stays where the sidebar puts it. The desk ticks hide
                  // bands on this page only: the terminal the sidebar opens keeps them all.
                  <WarehouseDashboard deck warehouseId={previewWarehouse} onFolder={setPreviewWarehouse}
                    onNavigate={setCurrentTab} />
                ) : (
                  <Dashboard onNavigate={setCurrentTab} onQuickCreate={handleQuickCreate} />
                )}
              </div>
            ))}
            {currentTab === 'sales-invoices' && (
              <SaleInvoices openNewNonce={newInvoiceNonce} onConsumed={() => setNewInvoiceNonce(0)} />
            )}
            {/* The dispatch board and one warehouse's folder of it are the same screen: the tab
                carries the folder id so a gate's own book can be bookmarked. */}
            {(currentTab === 'delivery-challan' || currentTab.startsWith('delivery-challan:')) && (
              <DeliveryChallans
                key={currentTab}
                warehouseId={currentTab === 'delivery-challan' ? null : Number(currentTab.slice(17))}
                onFolder={id => setCurrentTab(id ? `delivery-challan:${id}` : 'delivery-challan')}
                onNavigate={setCurrentTab}
              />
            )}
            {/* One location's terminal, and the same terminal with another gate picked from
                its own switcher — the tab carries the id so a keeper can bookmark his building. */}
            {(currentTab === 'warehouse-dashboard' || currentTab.startsWith('warehouse-dashboard:')) && (
              <WarehouseDashboard
                key={currentTab}
                warehouseId={currentTab === 'warehouse-dashboard' ? null : Number(currentTab.slice(20))}
                onFolder={id => setCurrentTab(id ? `warehouse-dashboard:${id}` : 'warehouse-dashboard')}
                onNavigate={setCurrentTab}
              />
            )}
            {currentTab === 'detail-b-groups' && <DetailBGroupList />}
            {currentTab === 'master-groups' && <MasterGroupList />}
            {currentTab === 'branch-locations' && <BranchLocations />}
            {currentTab === 'uom' && <UnitsOfMeasurement />}
            {currentTab === 'customers' && <PartyPage kind="customers" />}
            {currentTab === 'vendors' && <PartyPage kind="vendors" />}
            {currentTab === 'products' && <ProductsPage />}
            {currentTab === 'sales-persons' && <SalesPersonsPage />}
            {currentTab === 'company-settings' && <CompanySettings onBack={() => setCurrentTab('dashboard')} />}
            {currentTab.startsWith('manufacturing-') && MFG_BY_TAB[currentTab] && (
              <ManufacturingDocs key={currentTab} spec={MFG_BY_TAB[currentTab]} />
            )}
            {currentTab === 'refer-earn' && <ReferAndEarn />}
            {currentTab.startsWith('cat:') && (
              <CategoryPage
                key={currentTab}
                type={currentTab.slice(4) as CategoryType}
                title={CATEGORY_TITLES[currentTab.slice(4) as CategoryType] ?? 'Masters'}
              />
            )}
            {currentTab === 'bank-accounts' && <BankAccounts />}
            {currentTab === 'item-master' && <ItemMaster />}
            {currentTab === 'stock-ledger' && <StockLedger onNavigate={setCurrentTab} />}
            {currentTab === 'adjustment-types' && <AdjustmentTypes />}
            {currentTab === 'scheduled-valuations' && <ScheduledValuations />}
            {currentTab === 'journal-entries' && <JournalEntries />}
            {currentTab === 'reports' && <Reports onNavigate={setCurrentTab} />}
            {currentTab === 'report:business-summary-report' && (
              <BusinessSummaryReport onNavigate={setCurrentTab} />
            )}
            {currentTab.startsWith('report:') && currentTab !== 'report:business-summary-report' && (
              <ReportViewer key={currentTab} reportKey={currentTab.slice(7)} onNavigate={setCurrentTab} />
            )}
            {currentTab === 'chart-of-accounts' && <ChartOfAccounts />}
            {currentTab === 'close-year' && <CloseYear />}
            {currentTab === 'pos-terminal' && <PosTerminal onNavigate={setCurrentTab} />}
            {currentTab === 'pos-counters' && <CheckoutCounters />}
            {currentTab === 'pos-barcode-templates' && <BarcodeTemplates />}
            {currentTab === 'pos-daily-summary' && <PosDailySummary onNavigate={setCurrentTab} />}
            {currentTab === 'pos-offline' && <PosOffline onNavigate={setCurrentTab} />}
            {currentTab.startsWith('doc:') && DOC_KINDS[currentTab.slice(4)] && (
              <DocWorkspace
                key={currentTab}
                kind={DOC_KINDS[currentTab.slice(4)]}
                openNewNonce={docNonce}
                onConsumed={() => setDocNonce(0)}
                onNavigate={setCurrentTab}
              />
            )}
            {currentTab === 'users' && <UsersPage />}
            {currentTab === 'roles' && <RolesPage />}
            {currentTab === 'branches' && <BranchesPage />}
            {currentTab === 'warehouses' && <WarehousesPage />}
            {currentTab === 'hr-employees' && <EmployeesPage />}
            {currentTab === 'hr-payheads' && <PayHeadsPage />}
            {currentTab === 'hr-salary-structure' && <SalaryStructurePage />}
            {currentTab === 'hr-attendance' && <AttendanceSheetPage />}
            {currentTab === 'hr-leave' && <LeavePage />}
            {currentTab === 'hr-loans' && <LoansPage />}
            {currentTab === 'hr-salary-sheet' && <SalarySheetPage />}
            {currentTab === 'subscription' && <SubscriptionPage />}
            {currentTab === 'weekly-routes' && <WeeklyRoutesPage />}
            {currentTab === 'my-profile' && <MyProfilePage />}
            {currentTab === 'change-password' && <MyProfilePage startOn="Change Password" />}
            {!hasScreen(currentTab) && (
              <ScreenNotFound address={window.location.pathname} onHome={() => setCurrentTab('home')} />
            )}
            </>}
          </CompanyWorkspace>
        </main>
      </div>
    </TenantProvider>
  );
};

// Every screen reads from the company that is currently open, so switching
// company has to throw the previous company's screens away and re-fetch.
const CompanyWorkspace: React.FC<{ tabKey: string; children: React.ReactNode }> = ({ tabKey, children }) => {
  const { tenantSlug } = useTenant();
  return <div key={`${tenantSlug}:${tabKey}`} className="p-5 lg:p-6 max-w-[88rem] mx-auto animate-[fadeUp_.4s_ease-out_backwards]">{children}</div>;
};

const Gate: React.FC = () => {
  const { user } = useAuth();
  if (!user) return <AuthScreen />;
  return <MainApp />;
};

export const App: React.FC = () => (
  <AuthProvider>
    <ThemeProvider>
      <Gate />
    </ThemeProvider>
  </AuthProvider>
);

export default App;
