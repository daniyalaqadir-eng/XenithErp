import React, { useState } from 'react';
import {
  ArrowLeft, Building2, CheckCircle2, ChevronRight, Eye, EyeOff, Gauge,
  Lock, Mail, Phone, ShieldCheck, Sparkles, Store, UserRound
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { authService } from '../../services/auth.service';

type View = 'login' | 'request' | 'reset';

const HIGHLIGHTS = [
  { icon: <Gauge className="w-4 h-4" />, title: 'Live business dashboard', text: 'Sales, cash and dues on one screen that refreshes itself.' },
  { icon: <Building2 className="w-4 h-4" />, title: 'Every branch in one place', text: 'Switch branch, keep each location on its own number series.' },
  { icon: <ShieldCheck className="w-4 h-4" />, title: 'Role based access', text: 'Give staff exactly the screens they need, and nothing more.' },
  { icon: <Store className="w-4 h-4" />, title: 'Billing to POS to plant', text: 'Invoices, counters, stock and job orders on the same books.' }
];

const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <label className="block text-[11px] font-bold uppercase tracking-wide text-gray-400 mb-1">{children}</label>
);

const Box: React.FC<{ children: React.ReactNode; invalid?: boolean }> = ({ children, invalid }) => (
  <div className={`flex items-center gap-2 rounded-lg border bg-white px-3 transition-all duration-200
    focus-within:border-[#2ec4b6] focus-within:ring-4 focus-within:ring-[#2ec4b6]/10
    ${invalid ? 'border-red-300' : 'border-gray-200'}`}>
    {children}
  </div>
);

const input = 'flex-1 py-2.5 text-sm bg-transparent outline-none placeholder:text-gray-300';

export const AuthScreen: React.FC = () => {
  const { login } = useAuth();
  const [view, setView] = useState<View>('login');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [company, setCompany] = useState('');
  const [needsCompany, setNeedsCompany] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  const go = (v: View) => { setView(v); setError(''); setInfo(''); };

  const run = async (e: React.FormEvent, fn: () => Promise<void>) => {
    e.preventDefault();
    setError(''); setInfo(''); setBusy(true);
    try { await fn(); } catch (err: any) { setError(err.message); }
    setBusy(false);
  };

  const handleLogin = (e: React.FormEvent) => run(e, async () => {
    try {
      await login(identifier, password, company.trim() || undefined);
    } catch (err: any) {
      // The server could not tell which firm this name belongs to, so it asks for the code
      // rather than guessing a book. The box appears only after that answer.
      if (err?.status === 409) setNeedsCompany(true);
      throw err;
    }
  });
  const handleRequest = (e: React.FormEvent) => run(e, async () => {
    const res = await authService.requestPassword(identifier);
    setInfo(res.message || `A reset code has been sent to ${identifier}.`);
    setView('reset');
  });
  const handleReset = (e: React.FormEvent) => run(e, async () => {
    await authService.resetPassword(identifier, code, newPassword);
    setInfo('Password reset successfully. Please sign in.');
    setPassword('');
    setView('login');
  });

  return (
    // The login screen wears the app's own skin: inside `.app-shell` every neutral, tint and
    // accent on this page is read from the theme, so a midnight sign-in is not a white page.
    <div className="app-shell min-h-screen w-full flex">
      {/* Brand panel */}
      <div className="hidden lg:flex relative w-[46%] max-w-[620px] shrink-0 overflow-hidden text-white login-brand">
        <div className="absolute inset-0 opacity-25 login-grid" />
        <span className="absolute -left-16 -top-16 w-72 h-72 rounded-full bg-[#2ec4b6]/20 blur-2xl animate-[float_11s_ease-in-out_infinite]" />
        <span className="absolute right-[-40px] top-40 w-56 h-56 rounded-full bg-[#1e88e5]/25 blur-2xl animate-[float_14s_ease-in-out_infinite_reverse]" />
        <span className="absolute left-20 bottom-[-60px] w-64 h-64 rounded-full bg-[#ff9f1c]/15 blur-2xl animate-[float_16s_ease-in-out_infinite]" />

        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          <div className="flex items-center gap-2 animate-[fadeUp_.6s_ease-out_backwards]">
            <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center shadow-lg">
              <i className="fa fa-chart-pie text-lg"></i>
            </div>
            <div className="leading-tight">
              <div className="text-lg font-extrabold tracking-wider">Xenith ERP</div>
              <div className="text-[10px] uppercase tracking-[.25em] text-white/90">Accounts · Inventory · POS</div>
            </div>
          </div>

          <div className="max-w-md">
            <h1 className="text-[34px] leading-[1.15] font-extrabold animate-[fadeUp_.7s_.08s_ease-out_backwards]">
              Your whole business, <span className="text-[#8ff5e6]">one smooth ledger.</span>
            </h1>
            <p className="mt-3 text-sm text-white/90 animate-[fadeUp_.7s_.16s_ease-out_backwards]">
              Trading, stock, banking, manufacturing and reporting that move together — no re-keying, no monthly spreadsheet fire drills.
            </p>

            <ul className="mt-7 space-y-3">
              {HIGHLIGHTS.map((h, i) => (
                <li key={h.title} className="flex items-start gap-3 animate-[fadeUp_.6s_ease-out_backwards]" style={{ animationDelay: `${0.2 + i * 0.09}s` }}>
                  <span className="mt-0.5 w-8 h-8 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0">
                    {h.icon}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">{h.title}</span>
                    <span className="block text-[11px] text-white/90">{h.text}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex items-center gap-6 text-[11px] text-white/90 animate-[fadeUp_.6s_.5s_ease-out_backwards]">
            <span><b className="text-white text-base block">117</b>ready-made reports</span>
            <span className="flex items-center gap-1"><Sparkles className="w-3.5 h-3.5" /> Urdu &amp; English screens</span>
          </div>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-8">
        <div className="w-full max-w-[400px]">
          <div className="lg:hidden flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-lg bg-[#2ec4b6] flex items-center justify-center text-white shadow-sm">
              <i className="fa fa-chart-pie"></i>
            </div>
            <div className="font-extrabold tracking-wider text-[#2ec4b6]">Xenith <span className="text-gray-500 text-xs tracking-widest">ERP</span></div>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl shadow-[0_18px_50px_-22px_rgba(15,40,60,.35)] px-7 py-7 animate-[popIn_.45s_ease-out_backwards]">
            <div key={view} className="animate-[fadeUp_.35s_ease-out_backwards]">
              {view === 'login' && (
                <>
                  <h2 className="text-xl font-extrabold text-gray-800">Hello!</h2>
                  <p className="text-xs text-gray-400 mt-1 mb-5">Log in with your username or email.</p>
                </>
              )}
              {view === 'request' && (
                <>
                  <h2 className="text-xl font-extrabold text-gray-800">Forgot password?</h2>
                  <p className="text-xs text-gray-400 mt-1 mb-5">Enter your email and we will hand you a reset code.</p>
                </>
              )}
              {view === 'reset' && (
                <>
                  <h2 className="text-xl font-extrabold text-gray-800">Set a new password</h2>
                  <p className="text-xs text-gray-400 mt-1 mb-5">Use the code we just generated for you.</p>
                </>
              )}

              {(error || info) && (
                <div className={`mb-3 text-xs font-semibold rounded-lg px-3 py-2 flex items-start gap-2 ${
                  error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
                  {info && <CheckCircle2 className="w-3.5 h-3.5 mt-px shrink-0" />}
                  <span>{error || info}</span>
                </div>
              )}

              {view === 'login' && (
                <form className="space-y-3" onSubmit={handleLogin}>
                  {/* Nothing here is filled in for you and nothing here names a real account.
                      This screen stands open at a counter: a browser offering to store the
                      owner's sign-in — or a grey hint spelling out his user name — hands the
                      whole book over to whoever is standing in front of it. */}
                  <div>
                    <Label>Username or Email</Label>
                    <Box invalid={!identifier && !!error}>
                      <UserRound className="w-4 h-4 text-gray-300" />
                      <input className={input} value={identifier} autoFocus autoComplete="off"
                        onChange={e => setIdentifier(e.target.value)} placeholder="your username or email" />
                    </Box>
                  </div>
                  <div>
                    <Label>Password</Label>
                    <Box invalid={!password && !!error}>
                      <Lock className="w-4 h-4 text-gray-300" />
                      <input className={input} type={show ? 'text' : 'password'} value={password} autoComplete="new-password"
                        onChange={e => setPassword(e.target.value)} placeholder="your password" />
                      <button type="button" onClick={() => setShow(s => !s)} aria-label="Toggle password"
                        className="text-gray-300 hover:text-gray-500 transition-colors">
                        {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </Box>
                  </div>
                  {needsCompany && (
                    <div>
                      <Label>Company code</Label>
                      <Box>
                        <Building2 className="w-4 h-4 text-gray-300" />
                        <input className={input} value={company} autoFocus autoComplete="off"
                          onChange={e => setCompany(e.target.value)} placeholder="your company code" />
                      </Box>
                      <p className="mt-1 text-[10px] text-gray-500">
                        This name signs in at more than one company here. The code is the name the vendor
                        gave your firm when he opened it, and it is shown on your bill.
                      </p>
                    </div>
                  )}
                  <div className="flex items-center justify-between text-[11px]">
                    <label className="flex items-center gap-1.5 text-gray-500 cursor-pointer">
                      <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} className="accent-[#2ec4b6]" />
                      Keep me signed in
                    </label>
                    <button type="button" onClick={() => go('request')} className="font-semibold text-[#1e88e5] hover:underline">
                      Forgot Password?
                    </button>
                  </div>
                  <button type="submit" disabled={busy || !identifier || !password}
                    className="login-cta w-full justify-center !py-2.5 text-sm">
                    {busy ? 'Signing in...' : 'SIGN IN'}
                    {!busy && <ChevronRight className="w-4 h-4" />}
                  </button>
                </form>
              )}

              {view === 'request' && (
                <form className="space-y-3" onSubmit={handleRequest}>
                  <div>
                    <Label>Email</Label>
                    <Box><Mail className="w-4 h-4 text-gray-300" />
                      <input className={input} type="email" value={identifier} autoComplete="off" onChange={e => setIdentifier(e.target.value)} placeholder="you@company.com" /></Box>
                  </div>
                  <button type="submit" disabled={busy || !identifier} className="login-cta w-full justify-center !py-2.5 text-sm">
                    {busy ? 'Working...' : 'GET RESET CODE'}
                  </button>
                  <button type="button" onClick={() => go('login')} className="w-full text-[11px] text-gray-500 hover:text-blue-600 inline-flex items-center justify-center gap-1">
                    <ArrowLeft className="w-3.5 h-3.5" /> Back to sign in
                  </button>
                </form>
              )}

              {view === 'reset' && (
                <form className="space-y-3" onSubmit={handleReset}>
                  <div>
                    <Label>Email</Label>
                    <Box><Mail className="w-4 h-4 text-gray-300" />
                      <input className={input} type="email" value={identifier} autoComplete="off" onChange={e => setIdentifier(e.target.value)} /></Box>
                  </div>
                  <div>
                    <Label>Reset Code</Label>
                    <Box><ShieldCheck className="w-4 h-4 text-gray-300" />
                      <input className={input} value={code} autoComplete="off" onChange={e => setCode(e.target.value)} placeholder="6-digit code" /></Box>
                  </div>
                  <div>
                    <Label>New Password</Label>
                    <Box><Lock className="w-4 h-4 text-gray-300" />
                      <input className={input} type="password" value={newPassword} autoComplete="new-password" onChange={e => setNewPassword(e.target.value)} /></Box>
                  </div>
                  <button type="submit" disabled={busy || !identifier || !code || !newPassword} className="login-cta w-full justify-center !py-2.5 text-sm">
                    {busy ? 'Resetting...' : 'RESET PASSWORD'}
                  </button>
                  <button type="button" onClick={() => go('login')} className="w-full text-[11px] text-gray-500 hover:text-blue-600 inline-flex items-center justify-center gap-1">
                    <ArrowLeft className="w-3.5 h-3.5" /> Back to sign in
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="mt-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-gray-400">
            <span className="flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-[#2ec4b6]" /> Support: +92 322 3805981
            </span>
            <span>&copy; {new Date().getFullYear()} Xenith ERP</span>
          </div>
        </div>
      </div>
    </div>
  );
};
