import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { DocAttachment, JournalEntry, JournalEntryLine, LedgerAccount, Party } from '../../types';
import {
  addJournalEntry, deleteJournalEntry, getJournalEntries, getJournalProposal,
  setJournalStatus, updateJournalEntry
} from '../../services/accounting.service';
import { getLedgerAccounts } from '../../services/accounts.service';
import { getParties } from '../../services/masters.service';
import { getEmployees } from '../../services/hr.service';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import { BookOpen, Check, Pencil, RefreshCw, Trash2, X } from 'lucide-react';
import {
  Area, AttachmentBox, DateWindow, DeleteConfirm, ExportPair, Field, FormFooter, IconAction,
  ListToolbar, NumCell, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { isoDay } from '../../utils/dateRange';
import { useScreenReload } from '../../utils/screenReload';

// Paisa chhupa kar gol nahi kiya jata: har jagah do decimal, screen par bhi, print par bhi,
// workbook me bhi, aur server ne bhi yehi round kiya hua number rakhna ha.
const round2 = roundMoney;
const money = (n: number) => round2(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

interface LineDraft {
  account: string;
  debit: number;
  credit: number;
  description: string;
  contact: string;
}

interface Paper {
  id: number | null;
  number: string;
  date: string;
  reference: string;
  memo: string;
  status: 'Draft' | 'Approved';
  lines: LineDraft[];
  attachments: DocAttachment[];
  raisedBy: string;
  approvedBy: string;
  approvedAt: string;
  // Woh tareekh jis din yeh paper book par tha. Apni jagah se hilna back-dating ha, wahin
  // para rehna nahi — is liye rule ko shuruati date se farq karna parta ha.
  storedDate: string;
}

const blankLine = (): LineDraft => ({ account: '', debit: 0, credit: 0, description: '', contact: '' });

const draftOf = (l: JournalEntryLine): LineDraft => ({
  account: l.account || '',
  debit: Number(l.debit) || 0,
  credit: Number(l.credit) || 0,
  description: l.description || '',
  contact: l.contact || ''
});

// Server bhi khaali line ko chhor deta ha, is liye "save hongi" gin-ti usi qaida se hoti ha.
const kept = (lines: LineDraft[]) => lines.filter(l => l.account.trim() || l.debit || l.credit);

// Approval ke rules alag likhe hain, kyun ke save ke buttons status baad me tay karte hain:
// "Save as Approved" ko usi waqt wohi rules dikhane parta ha jo server approve karte waqt
// lagayega, warna clerk kaam ki request haar man kar wapas aati ha.
const approvalProblems = (rows: LineDraft[], accounts: LedgerAccount[], debit: number, credit: number): string[] => {
  if (!rows.length) return [];
  const list: string[] = [];
  if (rows.length < 2) list.push('An entry needs at least two lines before it can be approved.');
  if (rows.some(l => !l.account)) list.push('Every line needs an account before the entry can be approved.');
  const grouped = [...new Set(rows.map(l => l.account).filter(n => {
    const acc = accounts.find(a => a.name === n);
    return acc && (acc.isGroup || acc.isActive === false);
  }))];
  if (grouped.length) {
    list.push(`${grouped.join(', ')} ${grouped.length === 1 ? 'is a group account' : 'are group accounts'}`
      + ' — post to one of their sub-accounts instead.');
  }
  if (debit <= 0) list.push('Enter at least one debit amount.');
  else if (debit !== credit) list.push(`Both sides must agree before approval — debit ${money(debit)}, credit ${money(credit)}.`);
  return list;
};

const accountsOf = (j: JournalEntry, side: 'debit' | 'credit') =>
  j.lines.filter(l => (side === 'debit' ? l.debit : l.credit) > 0).map(l => l.account).join(', ');

export const JournalEntries: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { user, can } = useAuth();
  // Is module me 'approve' naam ki koi permission nahi — approval edit ki ahmiyat se chalta ha.
  const mayWrite = can('journal-entries:add') || can('journal-entries:edit');
  const mayApprove = can('journal-entries:edit');
  const mayDelete = can('journal-entries:delete');

  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox apna text khud rakhta ha; clear-all par box khaali karne ka tareeqa usay
  // dobara mount karna ha.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'date', dir: 'desc' });
  const [loading, setLoading] = useState(true);
  // Paper register ki jagah le leta ha, jaise baaki modules me list se form khulta ha.
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]);
  const [contacts, setContacts] = useState<{ name: string; kind: string }[]>([]);
  const [dateFloor, setDateFloor] = useState('');
  const [canBackdate, setCanBackdate] = useState(true);
  const [paper, setPaper] = useState<Paper>({
    id: null, number: '', date: isoDay(), reference: '', memo: '', status: 'Draft',
    lines: [blankLine(), blankLine()], attachments: [], raisedBy: '', approvedBy: '', approvedAt: '',
    storedDate: ''
  });

  useEffect(() => {
    getLedgerAccounts(tenantSlug, branchId).then(r => setAccounts(r.data)).catch(() => setAccounts([]));
  }, [tenantSlug, branchId]);

  // Contacts sirf tab mangwate hain jab koi paper khulta ha — register inhein dekhta nahi.
  useEffect(() => {
    if (!open || contacts.length) return;
    Promise.all([
      getParties('customers', tenantSlug, branchId).catch((): { data: Party[] } => ({ data: [] })),
      getParties('vendors', tenantSlug, branchId).catch((): { data: Party[] } => ({ data: [] })),
      getEmployees(tenantSlug, branchId).catch(() => null)
    ]).then(([customers, vendors, hr]) => {
      const rows = [
        ...customers.data.map(p => ({ name: p.name, kind: 'Customer' })),
        ...vendors.data.map(p => ({ name: p.name, kind: 'Vendor' })),
        ...(hr?.data ?? []).filter(e => e.isActive !== false).map(e => ({ name: e.name, kind: 'Staff' }))
      ];
      const seen = new Set<string>();
      setContacts(rows.filter(r => {
        const key = (r.name || '').toLowerCase();
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      }));
    });
  }, [open, contacts.length, tenantSlug, branchId]);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await getJournalEntries(tenantSlug, branchId, search);
    setEntries(res.data); setLoading(false);
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  // Posting chart of accounts ki leaf accounts se hoti ha; group head par qalam nahi chalta.
  const postable = useMemo(() => accounts.filter(a => a.isActive !== false && !a.isGroup), [accounts]);

  // Perpurane entries me aise naam ho sakte hain jo aaj chart me nahi — unhein parhne ke
  // liye picker me wahi naam extra option ban kar aata ha, warna paper khaali nazar aata.
  const accountOptions = useMemo(() => {
    const named = new Set(postable.map(a => a.name));
    const strays = [...new Set(paper.lines.map(l => l.account).filter(n => n && !named.has(n)))];
    return [
      ...postable.map(a => ({ id: a.id, label: a.name, hint: a.code } as SelectOption)),
      ...strays.map((n, i) => ({ id: -1 - i, label: n, hint: 'Not in the chart of accounts' } as SelectOption))
    ];
  }, [postable, paper.lines]);

  const chartNames = useMemo(() => new Set(accounts.map(a => a.name)), [accounts]);
  const accountId = (name: string) => accountOptions.find(o => o.label.toLowerCase() === name.toLowerCase())?.id ?? null;
  const accountName = (id: number | null) => (id == null ? '' : accountOptions.find(o => o.id === id)?.label ?? '');
  const contactOptions = useMemo<SelectOption[]>(
    () => contacts.map((c, i) => ({ id: i + 1, label: c.name, hint: c.kind })), [contacts]);
  const contactId = (name: string) => {
    const i = contacts.findIndex(c => c.name.toLowerCase() === (name || '').toLowerCase());
    return i < 0 ? null : i + 1;
  };
  const contactName = (id: number | null) => (id == null ? '' : contacts[id - 1]?.name ?? '');

  const set = (patch: Partial<Paper>) => setPaper(p => ({ ...p, ...patch }));
  const setLine = (idx: number, patch: Partial<LineDraft>) =>
    setPaper(p => ({ ...p, lines: p.lines.map((l, i) => (i === idx ? { ...l, ...patch } : l)) }));
  const dropLine = (idx: number) => setPaper(p => ({ ...p, lines: p.lines.filter((_, i) => i !== idx) }));
  const addLine = () => setPaper(p => ({ ...p, lines: [...p.lines, blankLine()] }));

  const proposal = useCallback(async () => {
    const p = await getJournalProposal(tenantSlug, branchId);
    setDateFloor(p.dateFloor); setCanBackdate(p.canBackdate);
    return p.number;
  }, [tenantSlug, branchId]);

  const openNew = async () => {
    setError(''); setNotice('');
    const number = await proposal();
    setPaper({
      id: null, number, date: isoDay(), reference: '', memo: '', status: 'Draft',
      lines: [blankLine(), blankLine()], attachments: [],
      raisedBy: user?.name ?? '', approvedBy: '', approvedAt: '', storedDate: ''
    });
    setOpen(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openEntry = (j: JournalEntry) => {
    setError(''); setNotice('');
    setPaper({
      id: j.id, number: j.entryNumber, date: j.date, reference: j.reference || '', memo: j.memo || '',
      status: j.status, lines: j.lines.map(draftOf), attachments: j.attachments ?? [],
      raisedBy: j.createdByName || '', approvedBy: j.approvedByName || '', approvedAt: j.approvedAt || '',
      storedDate: j.date
    });
    setOpen(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closePaper = () => { setOpen(false); setError(''); };

  const rows = kept(paper.lines);
  const skipped = paper.lines.length - rows.length;
  const totalDebit = round2(rows.reduce((s, l) => s + l.debit, 0));
  const totalCredit = round2(rows.reduce((s, l) => s + l.credit, 0));
  const diff = round2(totalDebit - totalCredit);
  const backdated = !canBackdate && !!dateFloor && paper.date < dateFloor && paper.date !== paper.storedDate;

  // Wohi rules jo server lagata ha, yahan pehle se: draft adhura para sakta ha, lekin
  // approve hote hi poori, sidhi hui tasreeh banna parta ha.
  const baseProblems = useMemo(() => {
    const list: string[] = [];
    if (!accounts.length) list.push('The chart of accounts could not be read, so nothing can be posted to it.');
    if (!paper.date) list.push('The entry needs a date.');
    else if (backdated) {
      list.push(`${dateFloor} is already approved on the journal, so a new entry cannot be dated ${paper.date} — `
        + 'an administrator or the company owner has to sign it back that far.');
    }
    if (!rows.length) list.push('Write at least one line with an account on it.');
    const unknown = [...new Set(rows.map(l => l.account).filter(n => n && !chartNames.has(n)))];
    if (unknown.length) list.push(`Not in the chart of accounts: ${unknown.join(', ')}`);
    return list;
  }, [accounts, paper.date, rows, backdated, dateFloor, chartNames]);

  const problems = [...baseProblems, ...(paper.status === 'Approved' ? approvalProblems(rows, accounts, totalDebit, totalCredit) : [])];

  const canSave = mayWrite && !saving && problems.length === 0;
  // Khaali naye paper par cheekhna zaroori nahi: wahan bas yeh batana ha ke save kab khulega.
  const touched = rows.length > 0 || !!paper.reference.trim() || !!paper.memo.trim();

  const save = async (choice?: string) => {
    const raiseAnother = choice === 'New';
    const asStatus: 'Draft' | 'Approved' = choice === 'Draft' || choice === 'Approved' ? choice : paper.status;
    const blocked = [...baseProblems, ...(asStatus === 'Approved' ? approvalProblems(rows, accounts, totalDebit, totalCredit) : [])];
    if (blocked.length) { setError(blocked[0]); return; }
    setSaving(true); setError('');
    const body: Partial<JournalEntry> = {
      date: paper.date, memo: paper.memo, reference: paper.reference, status: asStatus,
      attachments: paper.attachments,
      lines: rows.map(l => ({ account: l.account, debit: l.debit, credit: l.credit, description: l.description, contact: l.contact }))
    };
    try {
      const saved = paper.id == null
        ? await addJournalEntry(tenantSlug, branchId, { ...body, entryNumber: paper.number })
        : await updateJournalEntry(tenantSlug, branchId, paper.id, body);
      await load();
      const label = asStatus === 'Approved' ? 'approved' : 'drafted';
      if (raiseAnother) {
        setNotice(`${saved.entryNumber} saved as a ${label} — PKR ${money(saved.totalDebit)} on the debit side. A fresh paper is open.`);
        const number = await proposal();
        setPaper({
          id: null, number, date: isoDay(), reference: '', memo: '', status: 'Draft',
          lines: [blankLine(), blankLine()], attachments: [],
          raisedBy: user?.name ?? '', approvedBy: '', approvedAt: '', storedDate: ''
        });
      } else {
        setOpen(false);
        setNotice(`${saved.entryNumber} saved as ${asStatus} — PKR ${money(saved.totalDebit)} debited, PKR ${money(saved.totalCredit)} credited.`);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally { setSaving(false); }
  };

  const changeStatus = async (j: JournalEntry, to: 'Draft' | 'Approved') => {
    setError(''); setNotice('');
    try {
      await setJournalStatus(tenantSlug, branchId, j.id, to);
      await load();
      setNotice(to === 'Approved'
        ? `${j.entryNumber} is approved — PKR ${money(j.totalDebit)} now stands in the ledgers, the trial balance and the party accounts.`
        : `${j.entryNumber} is back to Draft, so it no longer moves the ledgers or the reports.`);
    } catch (e) { setError((e as Error).message); }
  };

  const remove = async (j: JournalEntry) => {
    setConfirmId(null); setError(''); setNotice('');
    try {
      await deleteJournalEntry(tenantSlug, branchId, j.id);
      await load();
      setNotice(`${j.entryNumber} has been taken back off the book.`);
      if (open && paper.id === j.id) setOpen(false);
    } catch (e) { setError((e as Error).message); }
  };

  // Har chip usi set se gin-ti ha jo table me nazar aa raha ha — tile, line aur print ek hi
  // number bolein.
  const inScope = useMemo(() => entries.filter(j =>
    (!fromDate || j.date >= fromDate) && (!toDate || j.date <= toDate)), [entries, fromDate, toDate]);

  const visible = useMemo(() => {
    const list = status ? inScope.filter(j => j.status === status) : inScope;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [inScope, status, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const shown = useMemo(() => ({
    debit: round2(visible.reduce((s, j) => s + j.totalDebit, 0)),
    credit: round2(visible.reduce((s, j) => s + j.totalCredit, 0)),
    approved: round2(visible.filter(j => j.status === 'Approved').reduce((s, j) => s + j.totalDebit, 0)),
    drafts: visible.filter(j => j.status === 'Draft').length
  }), [visible]);
  const registerDiff = round2(shown.debit - shown.credit);

  const stats: RegisterStat[] = [
    {
      label: 'Entries',
      value: status ? `${visible.length} of ${inScope.length}` : String(inScope.length),
      title: 'Journal entries the search, the window and the status pill leave on screen'
    },
    { label: 'Amount', value: `PKR ${money(shown.debit)}`, title: 'The debit side of the rows on screen, added up as printed' },
    { label: 'Credit', value: `PKR ${money(shown.credit)}`, title: 'The credit side of the rows on screen, added up as printed' },
    {
      label: 'Approved and posted',
      value: `PKR ${money(shown.approved)}`,
      tone: shown.drafts ? 'warn' : 'ok',
      title: shown.drafts
        ? `Only Approved entries reach the ledgers and the reports. ${shown.drafts} draft${shown.drafts === 1 ? '' : 's'} on screen, PKR ${money(shown.debit - shown.approved)} still waiting`
        : 'Every entry on screen is Approved, so all of it stands in the ledgers'
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: inScope.length },
    { value: 'Draft', label: 'Draft', count: inScope.filter(j => j.status === 'Draft').length },
    { value: 'Approved', label: 'Approved', count: inScope.filter(j => j.status === 'Approved').length }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    status && `status ${status}`,
    (fromDate || toDate) && `dated ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus(''); setFromDate(''); setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const tieSentence = registerDiff
    ? `Both sides differ by PKR ${money(Math.abs(registerDiff))}`
    : 'Both sides tie, entry by entry';

  const columns: ExportColumn<JournalEntry>[] = [
    { label: 'Number', value: j => j.entryNumber },
    { label: 'Date', value: j => j.date },
    { label: 'Memo', value: j => j.memo || '-' },
    { label: 'Reference', value: j => j.reference || '-' },
    { label: 'Debit', value: j => money(j.totalDebit), align: 'right' },
    { label: 'Credit', value: j => money(j.totalCredit), align: 'right' },
    { label: 'Status', value: j => j.status },
    { label: 'Lines', value: j => String(j.lines.length), align: 'right' },
    { label: 'Accounts Debited', value: j => accountsOf(j, 'debit') || '-' },
    { label: 'Accounts Credited', value: j => accountsOf(j, 'credit') || '-' }
  ];

  // Ek entry ki lines hi uska poora haal bayan karti hain, is liye paper ka print aur
  // workbook lines ka hero, aur uska total bhi wahi jo screen par dikha.
  const lineColumns: ExportColumn<JournalEntryLine>[] = [
    { label: 'Account', value: l => l.account || '-' },
    { label: 'Description', value: l => l.description || '-' },
    { label: 'Contact', value: l => l.contact || '-' },
    { label: 'Debit', value: l => money(l.debit), align: 'right' },
    { label: 'Credit', value: l => money(l.credit), align: 'right' }
  ];
  const paperRows: JournalEntryLine[] = rows.map(l => ({
    account: l.account, debit: l.debit, credit: l.credit, description: l.description, contact: l.contact
  }));

  const subtitle = activeFilters.length ? activeFilters.join(' · ')
    : `Every journal entry on the book (${inScope.length})`;

  if (open) {
    return (
      <div className="space-y-4">
        <div className="nb-card p-0 overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3.5">
            <h2 className="page-title flex items-center gap-2">
              <BookOpen size={15} />
              Journal Entries - [{paper.number || 'NEW'}]
            </h2>
            <div className="flex flex-wrap items-center gap-2">
              {paper.raisedBy && <span className="text-[11px] text-gray-500">Raised by {paper.raisedBy}</span>}
              {paper.approvedBy && (
                <span className="text-[11px] text-[#25a195]">
                  Approved by {paper.approvedBy}{paper.approvedAt ? ` · ${paper.approvedAt}` : ''}
                </span>
              )}
              <span className={`px-3 py-1 rounded border text-[11px] font-bold uppercase tracking-wide ${
                paper.status === 'Approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-gray-100 text-gray-600 border-gray-300'}`}>
                {paper.status}
              </span>
            </div>
          </div>

          <div className="px-4 pb-3.5 -mt-1">
            <p className="text-xs text-gray-500">
              A journal entry is the book told by hand: pick the ledger accounts, write the reason on each line and
              say whose money it carries. A draft may sit half-keyed, but the day it is approved it needs two named
              accounts and both sides equal — that is the moment it starts moving the trial balance.
            </p>
          </div>
        </div>

        {(error || (problems.length > 0 && touched)) && (
          <div className="text-xs rounded px-3 py-2 border bg-red-50 border-red-100 text-red-600 space-y-0.5">
            {error && <p className="font-semibold">{error}</p>}
            {problems.map(p => <p key={p} className="font-semibold">{p}</p>)}
          </div>
        )}
        {!error && !touched && (
          <p className="text-[11px] text-gray-500 bg-gray-50 border border-gray-200 rounded px-3 py-2">
            Nothing is on the paper yet — save opens as soon as one line carries a ledger account.
          </p>
        )}
        {notice && !error && (
          <div className="text-xs font-semibold rounded px-3 py-2 flex items-center justify-between text-green-700 bg-green-50 border border-green-100">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice('')}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        {/* View-only role: the paper is open for reading, but nothing on it answers a click. */}
        <div className={`nb-card p-4 space-y-4 ${mayWrite ? '' : 'pointer-events-none opacity-70'}`}>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Field label="Entry Number" hint="counted by the register">
              <div className="flex items-center gap-1">
                <Text value={paper.number} readOnly placeholder="Numbered by the register"
                  className={`bg-gray-50 font-mono ${paper.id != null ? 'text-gray-500' : ''}`} />
                {paper.id == null && (
                  <IconAction title="Ask the register for the next free number" tone="default"
                    onClick={async () => set({ number: await proposal() })}>
                    <RefreshCw className="w-4 h-4" />
                  </IconAction>
                )}
              </div>
            </Field>

            <Field label="Date" required hint={backdated
              ? `${dateFloor} is already approved on the journal — an administrator or the company owner has to date a paper before that day.`
              : undefined}>
              <input type="date" className={`input-xenith ${backdated ? 'ring-1 ring-amber-400' : ''}`}
                value={paper.date} onChange={e => set({ date: e.target.value })} />
            </Field>

            <Field label="Reference" hint="the paper this entry stands for">
              <Text value={paper.reference} onChange={e => set({ reference: e.target.value })}
                placeholder="Voucher, cheque or bill no" />
            </Field>

            <Field label="Status" hint="approval is what posts it">
              <div className="input-xenith bg-gray-50 text-gray-600 flex items-center justify-between">
                {paper.status}
                <span className="text-[10px] text-gray-400 font-normal">use the save menu</span>
              </div>
            </Field>
          </div>

          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-gray-50 text-gray-500">
                <tr>
                  <th className="text-left px-2 py-2 w-[26%]">Account</th>
                  <th className="text-left px-2 py-2">Description</th>
                  <th className="text-right px-2 py-2 w-32">Debit</th>
                  <th className="text-right px-2 py-2 w-32">Credit</th>
                  <th className="text-left px-2 py-2 w-[20%]">Contact</th>
                  <th className="px-2 py-2 w-16 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {paper.lines.map((line, idx) => {
                  const stray = !!line.account && !chartNames.has(line.account);
                  return (
                    <tr key={idx} className="border-t border-gray-100 align-top">
                      <td className="px-2 py-1.5">
                        <SearchSelect options={accountOptions} value={accountId(line.account)}
                          invalid={stray} placeholder="Type to search account"
                          emptyMessage="No ledger account by that name"
                          onChange={id => setLine(idx, { account: accountName(id) })} />
                      </td>
                      <td className="px-2 py-1.5">
                        <Text value={line.description} onChange={e => setLine(idx, { description: e.target.value })}
                          placeholder="Why this line exists" />
                      </td>
                      <td className="px-2 py-1.5">
                        <NumCell value={line.debit} min={0} step="0.01"
                          onChange={e => setLine(idx, { debit: round2(Number(e.target.value)) })} />
                      </td>
                      <td className="px-2 py-1.5">
                        <NumCell value={line.credit} min={0} step="0.01"
                          onChange={e => setLine(idx, { credit: round2(Number(e.target.value)) })} />
                      </td>
                      <td className="px-2 py-1.5">
                        <SearchSelect options={contactOptions} value={contactId(line.contact)}
                          placeholder="Type to search contact"
                          emptyMessage="No customer, vendor or staff member by that name"
                          onChange={id => setLine(idx, { contact: contactName(id) })} />
                      </td>
                      <td className="px-2 py-1.5">
                        <div className="flex items-center justify-center gap-1">
                          <IconAction title="Key this line and open the next one" tone="success"
                            onClick={() => setPaper(p => {
                              const lines = [...p.lines];
                              const next = lines[idx + 1];
                              if (!next || kept([next]).length) lines.splice(idx + 1, 0, blankLine());
                              return { ...p, lines };
                            })}>
                            <Check className="w-4 h-4" />
                          </IconAction>
                          <IconAction title={paper.lines.length > 1 ? 'Delete this line' : 'The entry needs at least one line'}
                            tone="danger" disabled={paper.lines.length <= 1}
                            onClick={() => dropLine(idx)}>
                            <Trash2 className="w-4 h-4" />
                          </IconAction>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-gray-50">
                <tr className="border-t border-gray-200 font-bold">
                  <td className="px-3 py-2 text-gray-600" colSpan={2}>TOTAL (PKR)</td>
                  <td className="px-3 py-2 text-right tabular-nums text-green-600">{money(totalDebit)}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-red-500">{money(totalCredit)}</td>
                  <td className="px-3 py-2 text-right text-[11px] font-semibold" colSpan={2}>
                    <span className={diff === 0 ? 'text-[#25a195]' : 'text-amber-600'}>
                      {totalDebit === 0 && totalCredit === 0 ? 'Enter the amount on either side'
                        : diff === 0 ? 'Both sides tie'
                        : diff > 0 ? `Credit is short by PKR ${money(diff)}`
                        : `Debit is short by PKR ${money(-diff)}`}
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <button type="button" className="btn-xenith-outline" onClick={addLine}>
              <span className="font-semibold">+</span> Add a line
            </button>
            <span className="text-[11px] text-gray-500">
              {rows.length} line{rows.length === 1 ? '' : 's'} will be posted
              {skipped > 0 ? ` · ${skipped} blank row${skipped === 1 ? '' : 's'} left out` : ''}
            </span>
            <ExportPair title={`Journal Entry ${paper.number || 'draft'}`}
              subtitle={[paper.date, rows.length ? `${rows.length} line${rows.length === 1 ? '' : 's'} · PKR ${money(totalDebit)}` : 'No lines keyed yet',
                paper.memo || null].filter(Boolean).join('  ·  ')}
              filename={`journal-entry-${(paper.number || 'draft').toLowerCase()}`}
              columns={lineColumns} rows={paperRows}
              footer={footerRow(lineColumns.length, {
                0: `Total (${rows.length})`, 3: money(totalDebit), 4: money(totalCredit)
              })} />
          </div>

          <Field label="Memo" hint="what the whole paper is about">
            <Area rows={3} value={paper.memo} onChange={e => set({ memo: e.target.value })}
              placeholder="Rent for September booked against the store's deposit account" />
          </Field>

          <AttachmentBox items={paper.attachments} onChange={a => set({ attachments: a })} />
        </div>

        <FormFooter onSave={choice => save(choice)} onClose={closePaper} saving={saving} disabled={!canSave}
          saveLabel={saving ? 'Saving...'
            : paper.id == null ? (paper.status === 'Draft' ? 'SAVE DRAFT AND CLOSE' : 'SAVE AND CLOSE')
            : 'SAVE CHANGES'}
          statusOptions={[
            { label: 'Save as Draft', value: 'Draft' },
            { label: 'Save as Approved', value: 'Approved' },
            ...(paper.id == null ? [{ label: 'Save and raise another', value: 'New' }] : [])
          ]} />

        {!mayWrite && (
          <p className="text-[11px] text-gray-500">
            This role may read the journal but not write it, so every field above is open for reading only.
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Journal Entries</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Anything the ledgers have to be told by hand comes here: one paper, its lines, and the approval that
              moves them. A draft can sit unfinished; approving it is what puts the entry into the trial balance,
              the party accounts and every report. Vouchers, payroll and loan recoveries raise their own entries,
              which is why this register is where a figure that looks wrong gets traced back.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {mayWrite && <ListToolbar addLabel="ADD JOURNAL ENTRY" onAdd={openNew} />}
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by number, memo, reference, account or contact" onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={statusCounts} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Journal Entries" subtitle={subtitle} filename="journal-entries"
              columns={columns} rows={visible}
              footer={footerRow(columns.length, {
                0: `Total (${visible.length})`, 4: money(shown.debit), 5: money(shown.credit),
                6: registerDiff ? `Differ by ${money(Math.abs(registerDiff))}` : 'Both sides tie'
              })} />
          </span>
        </div>
      </div>

      {(error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Number" sortKey="entryNumber" sort={sort} onSort={onSort} />
                <SortHeader label="Date" sortKey="date" sort={sort} onSort={onSort} />
                <SortHeader label="Memo" sortKey="memo" sort={sort} onSort={onSort} />
                <SortHeader label="Reference" sortKey="reference" sort={sort} onSort={onSort} />
                <SortHeader label="Amount" sortKey="totalDebit" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th className="text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={7}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={7} noun="journal entries" filters={activeFilters} cleared={clearAll}
                  addLabel={entries.length || !mayWrite ? undefined : 'ADD JOURNAL ENTRY'} onAdd={openNew} />
              )}
              {!loading && visible.map(j => (
                <tr key={j.id}>
                  <td className="font-mono font-semibold text-blue-700 whitespace-nowrap">{j.entryNumber}</td>
                  <td className="whitespace-nowrap">{j.date}</td>
                  <td className="text-xs text-gray-600 max-w-[22rem]">
                    {j.memo || <span className="text-gray-300">-</span>}
                    <span className="block text-[10px] text-gray-400">
                      {j.lines.length} line{j.lines.length === 1 ? '' : 's'} ·{' '}
                      Dr {accountsOf(j, 'debit') || '—'} · Cr {accountsOf(j, 'credit') || '—'}
                    </span>
                  </td>
                  <td className="whitespace-nowrap">
                    {j.reference || <span className="text-gray-300">-</span>}
                    {j.createdByName && (
                      <span className="block text-[10px] text-gray-400">by {j.createdByName}</span>
                    )}
                  </td>
                  <td className="font-semibold text-gray-800 tabular-nums whitespace-nowrap">
                    PKR {money(j.totalDebit)}
                    {j.totalDebit !== j.totalCredit && (
                      <span className="block text-[10px] font-semibold text-amber-600">credit PKR {money(j.totalCredit)}</span>
                    )}
                  </td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      j.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {j.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      <IconAction title={mayWrite ? `Edit ${j.entryNumber}` : `Read ${j.entryNumber} and its lines`}
                        tone="primary" onClick={() => openEntry(j)}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>
                      {mayApprove && (j.status === 'Draft' ? (
                        <IconAction title="Approve — this puts the entry into the ledgers" tone="success"
                          onClick={() => changeStatus(j, 'Approved')}>
                          <Check className="w-4 h-4" />
                        </IconAction>
                      ) : (
                        <IconAction title="Take the approval back — the entry stops moving the ledgers" tone="danger"
                          onClick={() => changeStatus(j, 'Draft')}>
                          <RefreshCw className="w-4 h-4" />
                        </IconAction>
                      ))}
                      {mayDelete && (confirmId === j.id ? (
                        <DeleteConfirm onConfirm={() => remove(j)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${j.entryNumber} on the book`} />
                      ) : (
                        <IconAction title={j.status === 'Approved'
                            ? 'Approved entries stand in the ledgers — take the approval back first'
                            : 'Delete this entry'}
                          tone="danger" disabled={j.status === 'Approved'} onClick={() => setConfirmId(j.id)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  {/* Wahi adaad jo upar ke chips likhte hain, aur sheet aur workbook jis par
                      khatam hote hain. */}
                  <td colSpan={4} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.debit)}</td>
                  <td colSpan={2} className="text-[11px] text-gray-500">
                    {tieSentence}
                    {status ? ` · printed rows incl. ${status.toLowerCase()}` : ''}
                    {' '}· credit side PKR {money(shown.credit)}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default JournalEntries;
