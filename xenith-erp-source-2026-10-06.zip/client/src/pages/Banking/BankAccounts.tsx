import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Pencil, RefreshCw, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { BankAccount, LedgerAccount } from '../../types';
import { addBankAccount, deleteBankAccount, getBankAccounts, updateBankAccount } from '../../services/banking.service';
import { getLedgerAccounts } from '../../services/accounts.service';
import { isoDay } from '../../utils/dateRange';
import {
  Area, Check, ExportPair, Field, FormFooter, IconAction, ListToolbar, Pick, RegisterStat, SearchBox, SearchPick,
  SectionTitle, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const money = (n: number) => `PKR ${Number(n || 0).toLocaleString()}`;

const blank = (): Partial<BankAccount> => ({
  accountTitle: '', bankName: '', accountNumber: '', iban: '', branchCode: '',
  balance: 0, isActive: true, acceptsChequeBook: false, acceptsCreditCard: false,
  description: '', openingBalanceDate: isoDay()
});

export const BankAccounts: React.FC = () => {
  const { tenantSlug, branchId, allBranches, currency } = useTenant();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [ledger, setLedger] = useState<LedgerAccount[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [branchFilter, setBranchFilter] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'accountTitle', dir: 'asc' });
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState<Partial<BankAccount> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getBankAccounts(tenantSlug, branchId, 200, 0, 'accountTitle', 'asc', search);
      setAccounts(res.data ?? []);
      setNotice('');
    } catch (e) {
      setNotice((e as Error).message || 'Bank accounts are not available right now.');
    } finally {
      setLoading(false);
    }
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);
  useEffect(() => {
    getLedgerAccounts(tenantSlug, branchId)
      .then(r => setLedger((r.data ?? []).filter(a => !a.isGroup && a.type === 'Asset')))
      .catch(() => setLedger([]));
  }, [tenantSlug, branchId]);

  const toggleSort = (key: string) =>
    setSort(s => (s?.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));

  const visible = useMemo(() => {
    const rows = accounts.filter(a =>
      (!statusFilter || (statusFilter === 'active') === !!a.isActive) &&
      (!branchFilter || String(a.branchId) === branchFilter));
    if (!sort) return rows;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((x, y) => {
      const a = (x as any)[sort.key] ?? '', b = (y as any)[sort.key] ?? '';
      return (typeof a === 'number' && typeof b === 'number' ? a - b : String(a).localeCompare(String(b))) * dir;
    });
  }, [accounts, statusFilter, branchFilter, sort]);

  // One balance for the whole screen: the chip, the footer under the table and the footer of
  // the printed sheet and the workbook all read `shownTotal`, so none of them can quietly
  // start counting only the active ones the way the old caption did.
  const shownTotal = visible.reduce((s, a) => s + (Number(a.balance) || 0), 0);
  const activeCount = visible.filter(a => a.isActive).length;

  const stats: RegisterStat[] = [
    { label: 'Accounts', value: String(visible.length), title: 'Rows the search, the status and the branch leave on screen' },
    { label: 'Balance', value: money(shownTotal), tone: 'ok', title: 'Sum of every balance listed below, active and inactive alike' },
    ...(visible.length && activeCount !== visible.length
      ? [{ label: 'Inactive', value: visible.length - activeCount, tone: 'warn' as const, title: 'Inactive accounts still hold their balance but take no new paper' }]
      : [])
  ];

  const statusCounts = [
    { value: '', label: 'All', count: accounts.length },
    { value: 'active', label: 'Active', count: accounts.filter(a => a.isActive).length },
    { value: 'inactive', label: 'Inactive', count: accounts.filter(a => !a.isActive).length }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    statusFilter && `status ${statusFilter === 'active' ? 'Active' : 'Inactive'}`,
    branchFilter && `branch ${allBranches.find(b => String(b.id) === branchFilter)?.name ?? branchFilter}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatusFilter('');
    setBranchFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns = [
    { label: 'Account Title', value: (a: BankAccount) => a.accountTitle },
    { label: 'Bank Name', value: (a: BankAccount) => a.bankName },
    { label: 'Account Number', value: (a: BankAccount) => a.accountNumber },
    { label: 'IBAN', value: (a: BankAccount) => a.iban ?? '' },
    { label: 'Branch Name', value: (a: BankAccount) => a.branchName ?? '' },
    { label: 'Bank Branch Code', value: (a: BankAccount) => a.branchCode ?? '' },
    { label: 'Ledger Account', value: (a: BankAccount) => a.linkedAccountName ?? '' },
    { label: 'Balance', value: (a: BankAccount) => a.balance, align: 'right' as const },
    { label: 'Status', value: (a: BankAccount) => (a.isActive ? 'Active' : 'Inactive') }
  ];

  const save = async () => {
    if (!editing) return;
    if (!editing.accountTitle?.trim()) { setError('Account title is required'); return; }
    if (!editing.bankName?.trim()) { setError('Bank name is required'); return; }
    setSaving(true);
    setError('');
    try {
      if (editing.id) await updateBankAccount(tenantSlug, branchId, editing.id, editing);
      else await addBankAccount(tenantSlug, branchId, editing);
      setEditing(null);
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (a: BankAccount) => {
    if (!window.confirm(`Delete ${a.accountTitle}?`)) return;
    try {
      await deleteBankAccount(tenantSlug, branchId, a.id);
      load();
    } catch (e) {
      setNotice((e as Error).message);
    }
  };

  if (editing) {
    const set = (patch: Partial<BankAccount>) => setEditing(p => ({ ...(p || {}), ...patch }));
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => setEditing(null)} className="btn-xenith-outline">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Bank Accounts</span>
          </button>
          <span className="text-[11px] text-gray-500">{editing.id ? `EDIT · ${editing.accountTitle}` : 'NEW ACCOUNT'}</span>
        </div>

        <div className="nb-card p-0">
          <div className="px-4 py-3 border-b border-gray-100">
            <h2 className="page-title">{editing.id ? 'Edit Bank Account' : 'New Bank Account'}</h2>
            <p className="text-xs text-gray-500">Opening balance is the figure on the day the account was brought onto the books.</p>
          </div>

          {error && <p className="px-4 pt-3 text-xs text-red-600">{error}</p>}

          <div className="p-4 space-y-4">
            <div>
              <SectionTitle>Identification</SectionTitle>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Account Title" required>
                  <Text value={editing.accountTitle || ''} onChange={e => set({ accountTitle: e.target.value })} placeholder="e.g. HBL Current Account" />
                </Field>
                <Field label="Bank Name" required>
                  <Text value={editing.bankName || ''} onChange={e => set({ bankName: e.target.value })} placeholder="e.g. Habib Bank Limited" />
                </Field>
                <Field label="Account Number">
                  <Text value={editing.accountNumber || ''} onChange={e => set({ accountNumber: e.target.value })} />
                </Field>
                <Field label="IBAN">
                  <Text value={editing.iban || ''} onChange={e => set({ iban: e.target.value })} placeholder="PK00HBL0000000000000000" />
                </Field>
              </div>
            </div>

            <div>
              <SectionTitle>Branch</SectionTitle>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Branch Name" hint="The company branch this account is held for.">
                  <Pick value={String(editing.branchId ?? '')} onChange={e => {
                    const b = allBranches.find(x => String(x.id) === e.target.value);
                    set({ branchId: b?.id, branchName: b?.name });
                  }}>
                    <option value="">Select branch...</option>
                    {allBranches.map(b => <option key={b.id} value={String(b.id)}>{b.name}</option>)}
                  </Pick>
                </Field>
                <Field label="Bank Branch Code" hint="Printed on the cheque leaf.">
                  <Text value={editing.branchCode || ''} onChange={e => set({ branchCode: e.target.value })} placeholder="0044" />
                </Field>
              </div>
            </div>

            <div>
              <SectionTitle>Opening &amp; Ledger</SectionTitle>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label={`Opening Balance (${currency})`}>
                  <Text type="number" value={String(editing.balance ?? 0)} onChange={e => set({ balance: Number(e.target.value) })} />
                </Field>
                <Field label="Opening Balance Date">
                  <Text type="date" value={editing.openingBalanceDate || ''} onChange={e => set({ openingBalanceDate: e.target.value })} />
                </Field>
                <Field label="Ledger Account" hint="The account in the chart of accounts that carries this balance." className="md:col-span-2">
                  <SearchPick
                    options={ledger.map(a => ({ id: a.id, label: a.name, sub: `${a.code} · ${a.type}` }))}
                    valueId={editing.linkedAccountId ?? null}
                    valueLabel={editing.linkedAccountName}
                    onPick={o => set({ linkedAccountId: o?.id ?? 0, linkedAccountName: o?.label ?? '' })}
                  />
                </Field>
              </div>
            </div>

            <div>
              <SectionTitle>Facilities</SectionTitle>
              <div className="flex flex-wrap items-center gap-6">
                <Check checked={!!editing.acceptsChequeBook} onChange={v => set({ acceptsChequeBook: v })} label="Issue cheque book" />
                <Check checked={!!editing.acceptsCreditCard} onChange={v => set({ acceptsCreditCard: v })} label="Credit card account" />
                <Check checked={editing.isActive !== false} onChange={v => set({ isActive: v })} label="Active" />
              </div>
            </div>

            <Field label="Description">
              <Area rows={2} value={editing.description || ''} onChange={e => set({ description: e.target.value })} />
            </Field>
          </div>

          <FormFooter
            onSave={save}
            onClose={() => setEditing(null)}
            saving={saving}
            saveLabel={editing.id ? 'SAVE BANK ACCOUNT' : 'ADD BANK ACCOUNT'}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Bank Accounts</h2>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD BANK ACCOUNT" onAdd={() => { setError(''); setEditing(blank()); }}>
            <button type="button" onClick={load} className="btn-xenith-outline"><RefreshCw className="w-3.5 h-3.5" />Refresh</button>
          </ListToolbar>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by title, bank, account number or IBAN" onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter} counts={statusCounts} />
          {allBranches.length > 1 && (
            <span className="filter-plate">
              <Pick aria-label="Filter by branch" value={branchFilter} onChange={e => setBranchFilter(e.target.value)}>
                <option value="">Branch</option>
                {allBranches.map(b => <option key={b.id} value={String(b.id)}>{b.name}</option>)}
              </Pick>
              {branchFilter && (
                <button type="button" title="Show every branch" onClick={() => setBranchFilter('')}
                  className="text-gray-400 hover:text-gray-600">
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          )}
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Bank Accounts" filename="bank-accounts" columns={columns} rows={visible}
              footer={footerRow(columns.length, { 0: `Total (${visible.length})`, 7: money(shownTotal) })} />
          </span>
        </div>
      </div>

      {notice && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 flex items-start justify-between gap-3">
          <span>{notice}</span>
          <button type="button" className="text-red-400 hover:text-red-700 leading-none" onClick={() => setNotice('')} aria-label="Dismiss">×</button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
        <table className="xenith-table">
          <thead className="sticky top-0 z-10">
            <tr>
              <SortHeader label="Account Title" sortKey="accountTitle" sort={sort} onSort={toggleSort} />
              <SortHeader label="Bank Name" sortKey="bankName" sort={sort} onSort={toggleSort} />
              <SortHeader label="Account Number" sortKey="accountNumber" sort={sort} onSort={toggleSort} />
              <th>IBAN</th>
              <SortHeader label="Branch Name" sortKey="branchName" sort={sort} onSort={toggleSort} />
              <th>Bank Branch Code</th>
              <th>Ledger Account</th>
              <SortHeader label="Balance" sortKey="balance" sort={sort} onSort={toggleSort} />
              <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={toggleSort} />
              <th className="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                <td colSpan={10}>
                  <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                </td>
              </tr>
            ))}
            {!loading && !visible.length && (
              <TableEmpty colSpan={10} noun="bank accounts" filters={activeFilters} cleared={clearAll}
                addLabel={accounts.length ? undefined : 'ADD BANK ACCOUNT'} onAdd={() => { setError(''); setEditing(blank()); }} />
            )}
            {!loading && visible.map(a => (
              <tr key={a.id} className={a.isActive ? '' : 'opacity-60'}>
                <td className="font-semibold text-gray-800">{a.accountTitle}</td>
                <td>{a.bankName}</td>
                <td className="font-mono text-xs">{a.accountNumber}</td>
                <td className="font-mono text-xs text-gray-500">{a.iban || '—'}</td>
                <td>{a.branchName || '—'}</td>
                <td>{a.branchCode || '—'}</td>
                <td className="text-gray-600">{a.linkedAccountName || '—'}</td>
                <td className={`text-right tabular-nums font-semibold ${a.balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{money(a.balance)}</td>
                <td>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${a.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {a.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="text-center whitespace-nowrap">
                  <IconAction title={`Edit ${a.accountTitle}`} onClick={() => { setError(''); setEditing(a); }}><Pencil className="w-4 h-4" /></IconAction>
                  <IconAction title={`Delete ${a.accountTitle}`} tone="danger" onClick={() => remove(a)}><Trash2 className="w-4 h-4" /></IconAction>
                </td>
              </tr>
            ))}
          </tbody>
          {!!visible.length && !loading && (
            <tfoot>
              <tr className="bg-gray-50/80">
                {/* Ties to the "Balance" chip above and to the row the sheet and the workbook
                    close with — one figure, three places. */}
                <td colSpan={7} className="font-black text-gray-800">Total ({visible.length})</td>
                <td className="text-right tabular-nums font-black text-gray-800">{money(shownTotal)}</td>
                <td />
                <td />
              </tr>
            </tfoot>
          )}
        </table>
        </div>
      </div>
    </div>
  );
};

export default BankAccounts;
