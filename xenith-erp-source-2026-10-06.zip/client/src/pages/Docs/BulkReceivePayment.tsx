import React, { useEffect, useState } from 'react';
import { Check, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import { Check as Chk, Field, FormFooter, Pick, Text } from '../Masters/masterUi';
import { DocPaymentLine, Party } from '../../types';
import { saveBulkDoc } from '../../services/docs.service';
import { getParties } from '../../services/masters.service';
import { getBankAccounts } from '../../services/banking.service';
import { isoDay } from '../../utils/dateRange';

const CASH_ID = -1;
const money = (v: number) => (v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const num = (v: number) => (v ? String(v) : '');

let rowSeq = 1;

interface BulkRow {
  key: number;
  partyId: number | null;
  paymentMode: string;
  accountId: number | null;
  accountName: string;
  reference: string;
  bankName: string;
  instrumentNumber: string;
  instrumentDate: string;
  amount: number;
}

const blankRow = (): BulkRow => ({
  key: rowSeq++, partyId: null, paymentMode: 'Cash', accountId: null, accountName: '', reference: '',
  bankName: '', instrumentNumber: '', instrumentDate: '', amount: 0
});

export const BulkReceivePayment: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const { tenantSlug, branchId } = useTenant();
  const [customers, setCustomers] = useState<Party[]>([]);
  const [accounts, setAccounts] = useState<{ id: number; name: string }[]>([]);
  const [date, setDate] = useState(isoDay());
  const [autoSettlements, setAutoSettlements] = useState(false);
  const [comments, setComments] = useState('');
  const [rows, setRows] = useState<BulkRow[]>([blankRow()]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([getParties('customers', tenantSlug, branchId), getBankAccounts(tenantSlug, branchId)])
      .then(([cs, acs]) => {
        setCustomers(cs.data);
        setAccounts(acs.data.map(a => ({ id: a.id, name: a.accountTitle })));
      });
  }, [tenantSlug, branchId]);

  const partyOptions: SelectOption[] = customers.map(c => ({ id: c.id, label: c.name, hint: c.city }));
  const total = rows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
  const valid = rows.filter(r => r.partyId && Number(r.amount) > 0);

  const patch = (key: number, fields: Partial<BulkRow>) =>
    setRows(rs => rs.map(r => (r.key === key ? { ...r, ...fields } : r)));

  const save = async () => {
    if (!valid.length) return;
    setSaving(true);
    setError('');
    try {
      await saveBulkDoc('receivePayments', tenantSlug, branchId, {
        date,
        rows: valid.map(r => {
          const paymentLine: DocPaymentLine = {
            id: 0,
            paymentMode: r.paymentMode,
            accountId: r.accountId,
            accountName: r.accountId === CASH_ID ? 'Cash in Hand' : (accounts.find(a => a.id === r.accountId)?.name || r.accountName),
            reference: r.reference, bankName: r.bankName, instrumentNumber: r.instrumentNumber,
            instrumentDate: r.instrumentDate, documentNumber: '', amount: r.amount
          };
          return {
            partyId: r.partyId, date, comments, autoSettlements,
            accountAdjustments: false,
            paymentLines: [paymentLine]
          };
        })
      });
      onDone();
    } catch (e: any) {
      setError(e.message || 'Could not save bulk payments');
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4 pb-4">
      <div className="bg-white rounded border border-gray-200 px-4 py-3 flex items-center justify-between">
        <h2 className="page-title">Bulk Receive Payments</h2>
        <span className="px-3 py-1 rounded border text-[11px] font-bold uppercase tracking-wide bg-gray-100 text-gray-600 border-gray-300">
          Draft
        </span>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-600 text-xs rounded px-3 py-2">{error}</div>}

      <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <Field label="Date" required>
            <input type="date" className="input-xenith" value={date} onChange={e => setDate(e.target.value)} />
          </Field>
        </div>

        <Chk checked={autoSettlements} onChange={setAutoSettlements} label="Make auto settlements" />

        <div className="border border-gray-200 rounded overflow-x-auto">
          <table className="xenith-table">
            <thead>
              <tr>
                <th className="w-[22%]">Customer</th>
                <th className="w-[18%]">Account</th>
                <th className="w-[14%]">Reference</th>
                <th className="w-[12%]">Amount</th>
                <th className="w-[12%]">Bank Name</th>
                <th className="w-[12%]">Instrument No.</th>
                <th className="w-[10%]">Instrument Date</th>
                <th className="text-center w-[8%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.key}>
                  <td>
                    <SearchSelect options={partyOptions} value={r.partyId}
                      onChange={id => patch(r.key, { partyId: id })} placeholder="Type to search customer" />
                  </td>
                  <td>
                    <Pick value={r.accountId === null ? '' : String(r.accountId)}
                      onChange={e => patch(r.key, {
                        paymentMode: 'Cash',
                        accountId: e.target.value === '' ? null : Number(e.target.value)
                      })}>
                      <option value="">-Choose-</option>
                      <option value={CASH_ID}>Cash in Hand</option>
                      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </Pick>
                  </td>
                  <td><Text placeholder="Reference" value={r.reference} onChange={e => patch(r.key, { reference: e.target.value })} /></td>
                  <td>
                    <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0"
                      value={num(r.amount)} onChange={e => patch(r.key, { amount: Number(e.target.value) })} />
                  </td>
                  <td><Text placeholder="Bank Name" value={r.bankName} onChange={e => patch(r.key, { bankName: e.target.value })} /></td>
                  <td><Text placeholder="Instrument No." value={r.instrumentNumber} onChange={e => patch(r.key, { instrumentNumber: e.target.value })} /></td>
                  <td><input type="date" className="input-xenith" value={r.instrumentDate} onChange={e => patch(r.key, { instrumentDate: e.target.value })} /></td>
                  <td className="text-center whitespace-nowrap">
                    <button type="button" title="Add another row" onClick={() => setRows(rs => [...rs, blankRow()])}
                      className="text-gray-500 hover:text-emerald-600 px-1"><Check className="w-4 h-4" /></button>
                    <button type="button" title="Remove row"
                      onClick={() => setRows(rs => (rs.length === 1 ? [blankRow()] : rs.filter(x => x.key !== r.key)))}
                      className="text-gray-500 hover:text-red-600 px-1"><X className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded border border-gray-200 p-4">
          <textarea rows={4} placeholder="Comments" className="input-xenith resize-y"
            value={comments} onChange={e => setComments(e.target.value)} />
        </div>
        <div className="bg-white rounded border border-gray-200 p-4 flex items-center justify-between">
          <span className="text-xs text-gray-600">Total Amount (PKR)</span>
          <span className="card-title">{money(total)}</span>
        </div>
      </div>

      <div className="flex justify-end items-start gap-2">
        {valid.length === 0 && <span className="text-[11px] text-red-500 self-center mr-auto">Add at least one customer with an amount</span>}
        <FormFooter onSave={() => save()} onClose={onDone} saving={saving} disabled={!valid.length || saving}
          saveLabel="Save and Close" />
      </div>
    </div>
  );
};
