import { BizDoc } from '../../types';
import { DocSheet } from '../../utils/printDocument';

export type LineMode = 'none' | 'qty' | 'priced' | 'import';
export type AmountMode = 'lines' | 'payments' | 'allocations' | 'box';
// Who the paper stands across from. A voucher uses 'accounts': the Payee / Receiver is the head
// of the books the money crossed, since a customer or a vendor has Receive Payment and Make
// Payment of their own and money handed over the counter has only a head across it.
export type PartyMode = 'customers' | 'vendors' | 'accounts' | 'none';

export type ColKey =
  | 'number' | 'date' | 'party' | 'subject' | 'order' | 'source' | 'reference' | 'warehouse' | 'toWarehouse'
  | 'gatePass' | 'dispatch' | 'billed'
  | 'receiptDate' | 'dueDate' | 'gross' | 'net' | 'total' | 'unadjusted' | 'balance' | 'landed'
  | 'account' | 'toAccount' | 'status' | 'products' | 'quantity' | 'adjustmentType';

export interface DocKind {
  resource: string;
  prefix: string;
  title: string;
  party: PartyMode;
  partyLabel: string;
  addLabel: string;
  // A screen can point at the master that feeds it, e.g. adjustments offer their
  // "ADD ADJUSTMENT TYPE" button next to "ADD STOCK ADJUSTMENT".
  linkButton?: { label: string; tab: string };
  bulkLabel?: string;
  approveLabel?: string;
  secondDate?: { key: 'dueDate' | 'receiptDate'; label: string; required?: boolean };
  warehouse?: boolean;
  warehouseLabel?: string;
  // Beside a line's warehouse, show how much of that product actually stands there, and
  // mark the line when it asks for more. A sale promises goods, so this warns rather than
  // refuses — the load itself is verified later on the challan.
  stockColumn?: boolean;
  // The header names a second location: stock leaves the line's warehouse and lands
  // in this one.
  toWarehouse?: boolean;
  // The paper carries the manual Gate Pass number the load leaves the compound on. It is
  // typed once, on the bill, and every challan cut out of that bill repeats it — so a
  // challan shows it without offering to change it.
  gatePass?: 'type' | 'shown';
  // A register whose keeper works from folders: the list splits by warehouse so the staff of
  // one gate see the loads that leave their own gate.
  warehouseFolders?: boolean;
  adjustmentType?: boolean;
  lines: LineMode;
  amountFrom: AmountMode;
  shippingAddress?: boolean;
  totals?: boolean;
  subjectLabel?: string;
  paymentBoxLabel?: string;
  // Which way the tender table reads: a receipt asks for a reference, a payment-out
  // paper asks for the document number the tender settles.
  paymentLinesMode?: 'receive' | 'refund';
  accountAdjustments?: boolean;
  autoSettlements?: boolean;
  expenseBlock?: boolean;
  // An import invoice clears customs: the paper carries a currency and a rate, the
  // declaration the container was assessed on, the duty lines that assessment raised, and
  // the landed cost those two add up to. It switches on the whole customs side of the form.
  customs?: boolean;
  // What this register files beside a paper, in its own words: a bill files delivery
  // challans, an import invoice files payment vouchers for its charges and duties.
  filedWord?: { one: string; many: string; tail: string };
  // Count screens can fold repeated lines for the same product together and compare
  // the counted quantity against what the system holds.
  consolidateCompare?: boolean;
  // A voucher settles its whole entry in its party box, so that box holds the ledger head the
  // money crossed rather than a customer or a vendor. The side named here is the one offered
  // first; the head a payment reverses or a receipt hands back can legitimately sit on either
  // half of the chart, so nothing else is shut out — only the tills and bank accounts are,
  // since those are the other half of the entry, not the reason for it.
  headPicker?: 'Expense' | 'Income';
  // A cash voucher can only be paid in cash and a bank voucher only through an account,
  // so the tender box is locked to that one channel instead of offering three.
  voucherChannel?: 'Cash' | 'Bank';
  // Which paper this one is raised out of: a challan out of an invoice. It switches on the
  // PICK button, the line-level remaining quantities, and the cap the server enforces on
  // save.
  picksFrom?: { resource: string; label: string; takenWord: string; required: boolean;
    // False for a paper that only points back at its source — a sales return reverses an
    // invoice, it does not draw goods off it. The picker works the same; what stands down is
    // the "already taken" arithmetic and the wording that would call an unpicked form a
    // mistake.
    consumes?: boolean };
  // Show the parts already raised out of this paper — the A / B / C trail of a customer
  // who takes the goods in instalments. Only the bill at the head of that trail has
  // anything to show here.
  chainParts?: boolean;
  // How the printed sheet reads: the band across its top, the rows it spells out, the
  // columns over the lines and whose signature sits under it.
  sheet: DocSheet;
  // A second, different paper the same form prints: the gate pass a load leaves the
  // compound on. Only the bills that carry a gate pass number offer one.
  gateSheet?: DocSheet;
  columns: ColKey[];
}

export const money = (v: number) => (v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// The documents saved before a line carried its source name only that name on the header,
// and a hand-typed line names nothing at all, so a list cell reads both and falls back.
export const lineSources = (d: BizDoc) =>
  [...new Set((d.lines || []).map(l => l.sourceNumber).filter(Boolean))].join(', ');

// Sale-side tables: for a salesperson's own role the server forces these to Pending and
// refuses an approval, so the form hides the option rather than offering a lie.
export const SALE_SIDE_RESOURCES = ['saleInvoices', 'saleDeliveries', 'saleReturns', 'receivePayments'];

// The heading on a printed sheet is the words the add button already uses, minus the verb.
export const printLabelOf = (kind: DocKind) => kind.addLabel.replace(/^(ADD|START)\s+/i, '').toUpperCase();

// The shared link column names the paper behind the document — a challan reads "Against
// Sale Invoice". Every table asks this one function — including the hand-written invoice
// list — so a header cannot drift from another's.
export const sourceLabelOf = (kind: DocKind) =>
  kind.picksFrom ? `Against ${kind.picksFrom.label}` : COLUMN_LIB.source.label;

// A save answers with whatever the register filed beside the paper, and the screen says so
// out loud: approving a bill files one challan per warehouse it draws from, and striking the
// bill out takes back the drafts no keeper has opened yet. Nobody should have to go looking
// for work the software already raised.
export const filedNote = (filed?: BizDoc[], kind?: DocKind) => {
  if (!filed?.length) return '';
  const nums = filed.map(d => d.number).join(', ');
  const w = kind?.filedWord;
  if (w) return `Filed ${filed.length} ${filed.length === 1 ? w.one : w.many} for the money to be signed off: ${nums} — ${w.tail}`;
  return `Filed ${filed.length} delivery ${filed.length === 1 ? 'challan' : 'challans'} for the warehouse keeper${filed.length === 1 ? '' : 's'}: ${nums} — tick off what is loading and approve the paper.`;
};
export const removedNote = (gone?: BizDoc[], kind?: DocKind) => {
  if (!gone?.length) return '';
  const nums = gone.map(d => d.number).join(', ');
  const w = kind?.filedWord;
  if (w) return `Took back ${gone.length} untouched ${gone.length === 1 ? w.one : w.many} this paper had filed: ${nums}. A ${w.one} somebody had already approved is a record and stays on the register.`;
  return `Took back ${gone.length} untouched challan${gone.length === 1 ? '' : 's'} this bill had filed: ${nums}. A challan a keeper had already loaded is a record and stays on the register.`;
};

export const COLUMN_LIB: Record<ColKey, { label: string; sort: string; cell: (d: BizDoc) => string | number; right?: boolean }> = {
  number: { label: 'Number', sort: 'number', cell: d => d.number },
  date: { label: 'Date', sort: 'date', cell: d => d.date },
  party: { label: 'Customer', sort: 'partyName', cell: d => d.partyName || '—' },
  subject: { label: 'Subject', sort: 'subject', cell: d => d.subject || '—' },
  order: { label: 'Order', sort: 'orderNumber', cell: d => d.orderNumber || '—' },
  // The paper this document was actually raised out of, taken from its lines rather than a
  // typed header, so the column can never claim a link the lines do not carry.
  source: { label: 'Against', sort: 'sourceNumber', cell: d => d.sourceNumber || lineSources(d) || '—' },
  reference: { label: 'Reference', sort: 'reference', cell: d => d.reference || '—' },
  warehouse: {
    label: 'Warehouse',
    sort: 'warehouseName',
    // Each product line can sit in its own warehouse, so the list shows every location
    // the document touched instead of one header value.
    cell: d => {
      const names = [...new Set(d.lines.map(l => l.warehouseName).filter(Boolean))];
      return names.length ? names.join(', ') : (d.warehouseName && d.warehouseName !== 'Multiple warehouses' ? d.warehouseName : '—');
    }
  },
  toWarehouse: { label: 'To Warehouse', sort: 'toWarehouseName', cell: d => d.toWarehouseName || '—' },
  // The permit the load went out on, repeated on every challan of the consignment.
  gatePass: { label: 'Gate Pass', sort: 'gatePass', cell: d => d.gatePass || '—' },
  // How much of the consignment has physically left, counted on Approved paper alone.
  dispatch: { label: 'Dispatch', sort: 'status', cell: d => d.dispatchState || '—' },
  // A receipt's own answer: has its vendor's bill arrived. Counted from the approved
  // invoices raised out of this very paper, so it cannot disagree with the bill.
  billed: { label: 'Billed', sort: 'status', cell: d => d.billedState || '—' },
  adjustmentType: { label: 'Adjustment Type', sort: 'adjustmentTypeName', cell: d => d.adjustmentTypeName || '—' },
  products: { label: 'No. of Products', sort: 'number', cell: d => d.lines.filter(l => l.productId).length },
  quantity: { label: 'Total Qty', sort: 'number', cell: d => d.lines.reduce((s, l) => s + Number(l.quantity || 0), 0) },
  receiptDate: { label: 'Receipt Date', sort: 'receiptDate', cell: d => d.receiptDate || '—' },
  dueDate: { label: 'Due Date', sort: 'dueDate', cell: d => d.dueDate || '—' },
  gross: { label: 'Gross Amount', sort: 'gross', cell: d => money(d.gross), right: true },
  net: { label: 'Net Amount', sort: 'net', cell: d => money(d.net), right: true },
  total: { label: 'Total Amount', sort: 'net', cell: d => money(d.net), right: true },
  unadjusted: { label: 'Unadjusted Amount', sort: 'unadjusted', cell: d => money(d.unadjusted), right: true },
  balance: { label: 'Balance Amount', sort: 'balance', cell: d => money(d.balance), right: true },
  // The whole cost of an imported consignment: its goods in rupees plus every duty and
  // charge that rides onto it. Read from the landed figure the server computed on save, so
  // the register, the form and the printed sheet quote the same rupee amount.
  landed: { label: 'Landed Cost (PKR)', sort: 'net', cell: d => d.landed ? money(d.landed.landedTotal) : '—', right: true },
  account: { label: 'Account', sort: 'accountName', cell: d => d.accountName || '—' },
  toAccount: { label: 'To Account', sort: 'toAccountName', cell: d => d.toAccountName || '—' },
  status: { label: 'Status', sort: 'status', cell: d => d.status }
};

const customerColumns: ColKey[] = ['number', 'date', 'party', 'reference', 'total', 'unadjusted', 'status'];

// A voucher list reads off the one box the paper decides its entry with: the head of the books
// the money crossed, which the party column already carries.
const VOUCHER_COLUMNS: ColKey[] = ['number', 'date', 'party', 'reference', 'account', 'total', 'status'];

// ---- printed sheets -------------------------------------------------------------------
// Every form prints the same sheet with its own words on it, so each family is written once
// here and a kind only overrides what reads differently on its paper.

// A bill a customer signs for goods: tax on every line, the amount in words, and how much
// of it has actually arrived.
const SALE_GOODS: DocSheet = {
  band: 'COMMERCIAL VOUCHER',
  meta: ['date', 'paymentMode', 'dueDate'],
  party: 'Billed Customer Profile',
  partyFields: ['address'],
  detail: 'Dispatch & Representative',
  fields: ['warehouse', ['salesPerson', 'Sales Officer'], 'gatePass', 'reference'],
  items: 'priced',
  totals: 'goods',
  amountLabel: 'Amount Chargeable',
  flags: true,
  tenderLabel: 'Payments Received',
  signs: [['Prepared By', 'prepared'], ['Customer Signature & Stamp', 'party'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated official commercial sales bill · Goods once sold are subject to the company return policy.'
};

// The same sheet read the other way round: what the business bought and owes for.
const PURCHASE_GOODS: DocSheet = {
  ...SALE_GOODS,
  band: 'PURCHASE VOUCHER',
  party: 'Vendor Account Profile',
  partyFields: [],
  detail: 'Receipt & Reference',
  fields: ['reference', 'receiptDate', 'status', 'approvedBy'],
  flags: false,
  tenderLabel: 'Payments Made',
  signs: [['Prepared By', 'prepared'], ['Received By', 'company'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated official purchase bill · Booked to the vendor ledger named above.'
};

// Goods going out or coming in on a paper that carries no price at all.
const STOCK_NOTE: DocSheet = {
  band: 'STOCK VOUCHER',
  meta: ['date', 'status', 'reference'],
  detail: 'Stock Details',
  fields: ['warehouse', 'approvedBy'],
  items: 'qty',
  whereLabel: 'Warehouse',
  totals: 'none',
  signs: [['Prepared By', 'prepared'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated stock voucher · Quantities are posted to the warehouses named above.'
};

// The permit a load leaves the compound on. A guard checks boxes, not rupees, so this sheet
// carries no rate, no tax and no total — only what is going out, in whose name, and whose
// signature closes it at the gate. The bill fixes no warehouse (the challans cut from it do),
// so the paper names no warehouse either rather than printing a column of dashes.
const GATE_PASS: DocSheet = {
  band: 'GATE PASS',
  meta: ['gatePass', 'date', 'reference'],
  party: 'Goods Released To',
  partyFields: ['address'],
  detail: 'Gate Details',
  fields: ['gatePass', 'vehicle', 'driver', 'salesPerson', 'approvedBy', 'status'],
  items: 'qty',
  totals: 'none',
  signs: [
    ['Store Keeper (Released By)', 'approved'],
    ['Received By (Customer / Carrier)', 'hand'],
    ['Security Guard at Gate', 'hand']
  ],
  fine: 'Goods leave the premises only against this pass. Vehicle number, time out and the gate '
    + 'signature are filled in at the gate. The quantities above are what the store keeper hands over.'
};

// Money moving in or out by itself: no goods lines, only the tenders and what they clear.
const MONEY_VOUCHER: DocSheet = {
  band: 'ACCOUNTING VOUCHER',
  meta: ['date', 'paymentMode', 'amount'],
  party: 'Party Profile',
  detail: 'Settlement & Reference',
  fields: ['account', 'reference', 'status', 'approvedBy'],
  items: 'none',
  totals: 'amount',
  amountLabel: 'Amount',
  tenderLabel: 'Tenders',
  appliedLabel: 'Adjusted Against',
  signs: [['Prepared By', 'prepared'], ['Received By', 'party'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated official voucher · This entry posts to the party and account ledgers named above.'
};

// Money that leaves the till or the bank account against a ledger head, with no bill behind
// it. The head is the story of the paper and it stands where a payment sheet shows the party,
// so the paper carries the narration beside it rather than the head a second time.
const PAYMENT_VOUCHER: DocSheet = {
  ...MONEY_VOUCHER,
  detail: 'Payment Details',
  fields: ['account', 'narration', 'reference', 'status', 'approvedBy'],
  appliedLabel: undefined,
  signs: [['Prepared By', 'prepared'], ['Received By', 'hand'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated payment voucher · The amount is booked to the account head above and paid from the account named.'
};

// The same paper from the other side: money arriving that no invoice asked for.
const RECEIPT_VOUCHER: DocSheet = {
  ...MONEY_VOUCHER,
  detail: 'Receipt Details',
  fields: ['account', 'narration', 'reference', 'status', 'approvedBy'],
  tenderLabel: 'Tenders Received',
  appliedLabel: undefined,
  signs: [['Prepared By', 'prepared'], ['Received By', 'company'], ['Authorised Signature', 'approved']],
  fine: 'Computer generated receipt voucher · The amount is booked to the account head above and received in the account named.'
};

// A reversal of a sale: it names the paper it undoes and states the credit it leaves.
const CREDIT_NOTE: DocSheet = {
  band: 'SALES RETURN / CREDIT NOTE',
  meta: ['date', ['partyName', 'Customer Account'], 'status', 'linkedInvoice', 'settlement'],
  items: 'plain',
  whereLabel: 'Warehouse',
  totals: 'credit',
  amountLabel: 'Total Credit',
  tenderLabel: 'Refund Paid',
  appliedLabel: 'Adjusted Against',
  signs: [['Authorised Signature', 'company'], ['Customer Acknowledgment', 'party']],
  fine: 'Computer generated sales return and credit adjustment note · The credit is adjusted against the customer ledger.'
};

export const DOC_KINDS: Record<string, DocKind> = {
  'sale-invoice': {
    resource: 'saleInvoices', prefix: 'SI', title: 'Sale Invoices',
    party: 'customers', partyLabel: 'Customer', addLabel: 'ADD SALE INVOICE',
    approveLabel: 'APPROVE SELECTED INVOICES',
    // The bill says which gate each product is promised out of, so the challan that is cut
    // from it lands on the right folder and the stock leaves the right card.
    warehouse: true, stockColumn: true,
    gatePass: 'type',
    secondDate: { key: 'dueDate', label: 'Due Date', required: true },
    lines: 'priced', amountFrom: 'lines', totals: true, paymentBoxLabel: 'Received',
    chainParts: true,
    sheet: SALE_GOODS,
    gateSheet: GATE_PASS,
    // The register answers "has it gone yet" in the same words the challan uses, counted
    // from the approved challans against the bill — not from a status somebody typed.
    columns: ['number', 'date', 'party', 'reference', 'dueDate', 'net', 'balance', 'dispatch', 'status']
  },
  'sale-delivery': {
    resource: 'saleDeliveries', prefix: 'SD', title: 'Delivery Challans',
    party: 'customers', partyLabel: 'Customer', addLabel: 'ADD DELIVERY CHALLAN',
    warehouse: true, warehouseFolders: true, gatePass: 'shown', lines: 'qty', amountFrom: 'lines', shippingAddress: true,
    // The rule the owner asked for: goods do not leave against an idea. A challan is only
    // ever raised out of an approved invoice, so the link here is demanded, not offered.
    picksFrom: { resource: 'saleInvoices', label: 'Sale Invoice', takenWord: 'delivered', required: true },
    sheet: {
      ...STOCK_NOTE, band: 'DELIVERY CHALLAN',
      meta: ['date', ['against', 'Against Sale Invoice'], 'status'],
      party: 'Delivered To Customer', partyFields: ['address'],
      detail: 'Dispatch Details',
      fields: ['gatePass', 'vehicle', 'driver', 'warehouse', 'reference', 'approvedBy'],
      signs: [['Received By', 'party'], ['Authorised Signature', 'approved']],
      fine: 'Computer generated delivery challan · Goods stay the property of the company until the invoice is settled.'
    },
    // The permit is checked at the gate against the load that is standing there, so the
    // challan prints its own gate pass rather than sending the guard back to the bill.
    gateSheet: GATE_PASS,
    columns: ['number', 'date', 'party', 'source', 'gatePass', 'reference', 'warehouse', 'dispatch', 'status']
  },
  'sale-return': {
    resource: 'saleReturns', prefix: 'SR', title: 'Sales Returns',
    party: 'customers', partyLabel: 'Customer', addLabel: 'ADD SALES RETURN',
    approveLabel: 'APPROVE SELECTED RETURNS',
    lines: 'priced', amountFrom: 'lines', totals: true, paymentBoxLabel: 'Refund', autoSettlements: true,
    // The customer's own bills, so a return is raised off the invoice it reverses rather than
    // by retyping every item. Optional: a return with no bill behind it stays a general return.
    picksFrom: { resource: 'saleInvoices', label: 'Sale Invoice', takenWord: 'returned', required: false, consumes: false },
    sheet: CREDIT_NOTE,
    columns: ['number', 'date', 'reference', 'party', 'net', 'unadjusted', 'status']
  },
  'receive-payment': {
    resource: 'receivePayments', prefix: 'RM', title: 'Receive Payments',
    party: 'customers', partyLabel: 'Customer', addLabel: 'ADD RECEIVE PAYMENT', bulkLabel: 'ADD BULK RECEIVE PAYMENT',
    approveLabel: 'APPROVE SELECTED PAYMENTS',
    lines: 'none', amountFrom: 'payments', paymentLinesMode: 'receive', accountAdjustments: true, autoSettlements: true,
    sheet: {
      ...MONEY_VOUCHER, band: 'RECEIPT VOUCHER',
      party: 'Received From Customer',
      amountLabel: 'Amount Received', tenderLabel: 'Tenders Received', appliedLabel: 'Applied Against Invoices',
      signs: [['Prepared By', 'prepared'], ['Received By', 'company'], ['Authorised Signature', 'approved']]
    },
    columns: customerColumns
  },
  'good-receiving': {
    resource: 'goodReceivings', prefix: 'GR', title: 'Good Receivings',
    party: 'vendors', partyLabel: 'Vendor', addLabel: 'ADD GOOD RECEIVING',
    approveLabel: 'APPROVE SELECTED GOOD RECEIVINGS',
    warehouse: true, lines: 'qty', amountFrom: 'lines',
    sheet: {
      ...STOCK_NOTE, band: 'GOOD RECEIVING NOTE',
      party: 'Received From Vendor',
      detail: 'Store & Reference', fields: ['warehouse', ['order', 'Purchase Order'], 'approvedBy'],
      signs: [['Counted By', 'prepared'], ['Authorised Signature', 'approved']],
      fine: 'Computer generated goods receiving note · Stock counted here is added to the warehouses named above.'
    },
    columns: ['number', 'date', 'party', 'reference', 'warehouse', 'billed', 'status']
  },
  'purchase-bill': {
    resource: 'purchaseBills', prefix: 'PI', title: 'Purchase Invoices',
    party: 'vendors', partyLabel: 'Vendor', addLabel: 'ADD PURCHASE INVOICE',
    approveLabel: 'APPROVE SELECTED INVOICES',
    secondDate: { key: 'dueDate', label: 'Due Date', required: true },
    lines: 'priced', amountFrom: 'lines', totals: true, paymentBoxLabel: 'Payment',
    // The rule the owner asked for: a vendor's bill is the money half of goods the store has
    // already counted, so it is raised out of an approved Good Receiving — never typed in.
    picksFrom: { resource: 'goodReceivings', label: 'Good Receiving', takenWord: 'billed', required: true },
    sheet: PURCHASE_GOODS,
    columns: ['number', 'date', 'party', 'source', 'reference', 'dueDate', 'net', 'balance', 'status']
  },
  'import-invoice': {
    resource: 'importInvoices', prefix: 'II', title: 'Import Invoices',
    party: 'vendors', partyLabel: 'Vendor', addLabel: 'ADD IMPORT INVOICE',
    approveLabel: 'APPROVE SELECTED INVOICES',
    secondDate: { key: 'dueDate', label: 'Due Date', required: true },
    lines: 'import', amountFrom: 'lines', totals: true, expenseBlock: true, customs: true,
    // The goods an import charges for have to be counted into a warehouse first: the Good
    // Receiving is the paper that moves stock, so the exporter's bill is raised out of it and
    // cannot be billed into the air. A container billed before it lands is received on a dated
    // GR — and an import already typed without one stays editable.
    picksFrom: { resource: 'goodReceivings', label: 'Good Receiving', takenWord: 'billed', required: true },
    // What was bought, in the exporter's words — a consignment has no narration to type and
    // the goods the declaration describes are the line of the bill.
    subjectLabel: 'Goods Description',
    paymentBoxLabel: 'Payment',
    // The invoice does not pay its own freight bill or duty challan — it files the paper
    // that does, so the save has to say what it raised.
    filedWord: { one: 'payment voucher', many: 'payment vouchers',
      tail: 'approve each one when the money actually leaves the till or the bank.' },
    sheet: {
      ...PURCHASE_GOODS, band: 'IMPORT INVOICE',
      // A consignment is not received at a counter the way a local purchase is: its goods line
      // up at the port on the CD date, so the paper states who approved it rather than the day
      // a store keeper ticked it off. The due date stands where the purchase sheet puts it.
      meta: ['date', 'paymentMode', 'status'],
      subjectLabel: 'Goods Description',
      detail: 'Clearing & Reference', fields: ['reference', 'dueDate', 'approvedBy'],
      amountLabel: 'Amount Payable to Vendor',
      items: 'import', totals: 'import', customsBlock: true,
      fine: 'Computer generated import invoice · The landed cost is the goods at the rate on the declaration, plus the duty and charges that are a cost of them.'
    },
    columns: ['number', 'date', 'party', 'source', 'reference', 'dueDate', 'net', 'landed', 'balance', 'status']
  },
  'vendor-payment': {
    resource: 'vendorPayments', prefix: 'PM', title: 'Make Payments',
    party: 'vendors', partyLabel: 'Vendor', addLabel: 'ADD MAKE PAYMENT',
    approveLabel: 'APPROVE SELECTED PAYMENTS',
    lines: 'none', amountFrom: 'payments', paymentLinesMode: 'refund', accountAdjustments: true, autoSettlements: true,
    sheet: {
      ...MONEY_VOUCHER, band: 'PAYMENT VOUCHER',
      party: 'Paid To Vendor',
      amountLabel: 'Amount Paid', tenderLabel: 'Tenders Paid', appliedLabel: 'Applied Against Bills',
      signs: [['Prepared By', 'prepared'], ['Received By', 'party'], ['Authorised Signature', 'approved']]
    },
    columns: ['number', 'date', 'party', 'reference', 'total', 'unadjusted', 'status']
  },
  // ── vouchers ─────────────────────────────────────────────────────────────────
  // Four papers for the two directions money moves and the two pockets it moves from. One box
  // decides the whole entry: the head of the books the money is paid against or received
  // against, with the till or the named bank account as the other half. It never touches that
  // head's standing of its own accord beyond the amount on the paper, and a customer or a
  // vendor who owes or is owed a bill has Receive Payment / Make Payment for that.
  'cash-voucher': {
    resource: 'cashVouchers', prefix: 'CV', title: 'Cash Payment Vouchers',
    party: 'accounts', partyLabel: 'Paid To', addLabel: 'ADD CASH PAYMENT VOUCHER',
    approveLabel: 'APPROVE SELECTED VOUCHERS',
    headPicker: 'Expense', voucherChannel: 'Cash',
    lines: 'none', amountFrom: 'box', paymentBoxLabel: 'Paid',
    sheet: { ...PAYMENT_VOUCHER, band: 'CASH PAYMENT VOUCHER', party: 'Paid To', amountLabel: 'Amount Paid' },
    columns: VOUCHER_COLUMNS
  },
  'bank-voucher': {
    resource: 'bankVouchers', prefix: 'BV', title: 'Bank Payment Vouchers',
    party: 'accounts', partyLabel: 'Paid To', addLabel: 'ADD BANK PAYMENT VOUCHER',
    approveLabel: 'APPROVE SELECTED VOUCHERS',
    headPicker: 'Expense', voucherChannel: 'Bank',
    lines: 'none', amountFrom: 'box', paymentBoxLabel: 'Paid',
    sheet: { ...PAYMENT_VOUCHER, band: 'BANK PAYMENT VOUCHER', party: 'Paid To', amountLabel: 'Amount Paid' },
    columns: VOUCHER_COLUMNS
  },
  'cash-receipt-voucher': {
    resource: 'cashReceiptVouchers', prefix: 'CRV', title: 'Cash Receipt Vouchers',
    party: 'accounts', partyLabel: 'Received From', addLabel: 'ADD CASH RECEIPT VOUCHER',
    approveLabel: 'APPROVE SELECTED VOUCHERS',
    headPicker: 'Income', voucherChannel: 'Cash',
    lines: 'none', amountFrom: 'box', paymentBoxLabel: 'Received',
    sheet: { ...RECEIPT_VOUCHER, band: 'CASH RECEIPT VOUCHER', party: 'Received From', amountLabel: 'Amount Received' },
    columns: VOUCHER_COLUMNS
  },
  'bank-receipt-voucher': {
    resource: 'bankReceiptVouchers', prefix: 'BRV', title: 'Bank Receipt Vouchers',
    party: 'accounts', partyLabel: 'Received From', addLabel: 'ADD BANK RECEIPT VOUCHER',
    approveLabel: 'APPROVE SELECTED VOUCHERS',
    headPicker: 'Income', voucherChannel: 'Bank',
    lines: 'none', amountFrom: 'box', paymentBoxLabel: 'Received',
    sheet: { ...RECEIPT_VOUCHER, band: 'BANK RECEIPT VOUCHER', party: 'Received From', amountLabel: 'Amount Received' },
    columns: VOUCHER_COLUMNS
  },
  'stock-movement': {
    resource: 'stockMovements', prefix: 'SM', title: 'Stock Movements',
    party: 'none', partyLabel: 'Party', addLabel: 'ADD STOCK MOVEMENT',
    subjectLabel: 'Narration', warehouse: true, warehouseLabel: 'From Warehouse', toWarehouse: true,
    approveLabel: 'APPROVE SELECTED MOVEMENTS',
    lines: 'qty', amountFrom: 'lines',
    sheet: {
      ...STOCK_NOTE, band: 'STOCK MOVEMENT',
      detail: 'Movement Details', fields: ['warehouse', 'toWarehouse', 'approvedBy'],
      whereLabel: 'From Warehouse', subjectLabel: 'Narration',
      fine: 'Computer generated stock movement · Quantity leaves the warehouse above and lands in the destination.'
    },
    columns: ['number', 'date', 'reference', 'warehouse', 'toWarehouse', 'products', 'quantity', 'status']
  },
  'stock-adjustment': {
    resource: 'stockAdjustments', prefix: 'SA', title: 'Stock Adjustments',
    party: 'none', partyLabel: 'Party', addLabel: 'ADD STOCK ADJUSTMENT',
    linkButton: { label: 'ADD ADJUSTMENT TYPE', tab: 'adjustment-types' },
    approveLabel: 'APPROVE SELECTED ADJUSTMENTS',
    subjectLabel: 'Remarks', warehouse: true, warehouseLabel: 'Warehouse', adjustmentType: true,
    lines: 'qty', amountFrom: 'lines',
    sheet: {
      ...STOCK_NOTE, band: 'STOCK ADJUSTMENT SHEET',
      meta: ['date', 'adjustmentType', 'reference'],
      detail: 'Adjustment Details', fields: ['warehouse', 'status', 'approvedBy'],
      subjectLabel: 'Remarks',
      fine: 'Computer generated stock adjustment · The counted quantity replaces the system balance above.'
    },
    columns: ['number', 'date', 'adjustmentType', 'reference', 'warehouse', 'products', 'quantity', 'status']
  },
  'stock-audit': {
    resource: 'stockAudits', prefix: 'AU', title: 'Stock Audits',
    party: 'none', partyLabel: 'Party', addLabel: 'START AUDIT',
    approveLabel: 'APPROVE SELECTED AUDITS',
    subjectLabel: 'Narration', warehouse: true, warehouseLabel: 'Warehouse',
    lines: 'qty', amountFrom: 'lines', consolidateCompare: true,
    sheet: {
      ...STOCK_NOTE, band: 'STOCK AUDIT SHEET',
      detail: 'Audit Details', subjectLabel: 'Narration',
      signs: [['Counted By', 'prepared'], ['Audited By', 'approved'], ['Authorised Signature', 'company']],
      fine: 'Computer generated stock audit sheet · Counted quantities are compared against the system balance.'
    },
    columns: ['number', 'date', 'reference', 'warehouse', 'products', 'quantity', 'status']
  }
};

export const docKind = (key: string): DocKind => DOC_KINDS[key];

// Which open documents a payment screen can adjust against, per party type.
export const settlementSources = (party: PartyMode): { open: string; received: string } =>
  party === 'vendors' ? { open: 'purchaseBills', received: 'vendorPayments' }
    : { open: 'saleInvoices', received: 'receivePayments' };

export const settlementTitles = (party: PartyMode): { open: string; received: string } =>
  party === 'vendors' ? { open: 'Payables', received: 'Paid' }
    : { open: 'Receivables', received: 'Received' };
