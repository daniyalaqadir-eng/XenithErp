import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { ArrowLeft, Ban, CheckCircle2, FileText, Pencil, Printer, RotateCcw, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { BizDoc } from '../../types';
import { approveDocs, deleteDoc, getDoc, getDocs, setDocStatus } from '../../services/docs.service';
import {
  DateWindow, ExportPair, IconAction, ListToolbar, RegisterStat, SearchBox,
  SortHeader, SortState, StatStrip, StatusPills, TableEmpty
} from '../Masters/masterUi';
import { COLUMN_LIB, ColKey, DocKind, SALE_SIDE_RESOURCES, filedNote, money, printLabelOf, removedNote, sourceLabelOf } from './docKinds';
import { DocForm } from './DocForm';
import { BulkReceivePayment } from './BulkReceivePayment';
import { footerRow } from '../../utils/exportTable';
import { isoDay, monthStart } from '../../utils/dateRange';
import { printDocsWithLetterhead } from '../../utils/printWithLetterhead';
import { useScreenReload } from '../../utils/screenReload';

const statusClass: Record<string, string> = {
  Draft: 'bg-gray-50 text-gray-600 border-gray-200',
  Pending: 'bg-amber-50 text-amber-600 border-amber-200',
  Approved: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  Void: 'bg-red-50 text-red-600 border-red-200 line-through'
};

type View = 'list' | 'form' | 'bulk';

// How much of a consignment has left, in the same words the server counts it in. A bill
// still owing goods is amber, not red: nothing has gone wrong, the load is simply not out.
const dispatchClass: Record<string, string> = {
  'Fully Dispatched': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  'Partial Dispatched': 'bg-amber-50 text-amber-700 border-amber-200',
  'Not Dispatched': 'bg-gray-50 text-gray-500 border-gray-200'
};

const rd = roundMoney;

// Columns whose printed total means something. Amount columns keep two decimals because
// that is how the cell above them is written; quantities stay whole.
const SUMMABLE: Partial<Record<ColKey, (d: BizDoc) => number>> = {
  quantity: d => d.lines.reduce((s, l) => s + Number(l.quantity || 0), 0),
  gross: d => d.gross,
  net: d => d.net,
  total: d => d.net,
  unadjusted: d => d.unadjusted,
  balance: d => d.balance
};

// The states a paper can sit in, in the order a register lists them. The blank one is the
// whole register and wears no count: the number beside it would only repeat the records
// chip above it.
const STATUSES = ['', 'Draft', 'Pending', 'Approved', 'Void'];

// Which money column a register is about. The figure beside the title and the line at the
// foot of the table headline the first one the screen actually carries, so the two can
// never be adding up different columns.
const HEADLINE: ColKey[] = ['total', 'net', 'gross', 'balance', 'unadjusted'];

export const DocWorkspace: React.FC<{
  kind: DocKind;
  openNewNonce?: number;
  onConsumed?: () => void;
  // A screen can lead to the master that feeds it, e.g. adjustments to adjustment types.
  onNavigate?: (tab: string) => void;
}> = ({ kind, openNewNonce = 0, onConsumed, onNavigate }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { user } = useAuth();
  // An administrator approves a salesperson's sale paper and owns its booked history, so
  // those buttons would only fail — the server refuses them too.
  const approvalHeldByAdmin = !!user?.salesmanScoped && SALE_SIDE_RESOURCES.includes(kind.resource);
  const [notice, setNotice] = useState('');
  const [view, setView] = useState<View>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [rows, setRows] = useState<BizDoc[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  // A warehouse-wise register splits into folders: the staff of one gate work the loads
  // that leave their own gate. It is derived from the papers on the register rather than
  // from the warehouse master, so a folder is never offered that holds nothing.
  const [folder, setFolder] = useState('');
  const [fromDate, setFromDate] = useState(monthStart());
  const [toDate, setToDate] = useState(isoDay());
  const [selected, setSelected] = useState<number[]>([]);
  const [sort, setSort] = useState<SortState | null>(null);
  // The search box holds its own text, so the only way to empty it from the table's
  // "clear every filter" button is to mount a fresh one.
  const [searchEpoch, setSearchEpoch] = useState(0);
  // Only the newest request may paint the table, otherwise a slow response typed over
  // earlier can replace the results the user is already looking at.
  const requestId = useRef(0);

  // The status pills wear live counts, so the register is fetched whole and the state is
  // picked here: asking the server for one status would leave every other pill reading
  // zero, and a count a reader can see through is worse than no count at all.
  const refresh = useCallback(() => {
    const at = ++requestId.current;
    getDocs(kind.resource, tenantSlug, branchId, search, '').then(r => {
      if (at !== requestId.current) return;
      setRows(r.data);
      setSelected([]);
    }).catch(e => {
      // An empty register has to say why: silence reads as "this company has no papers".
      if (at === requestId.current) setNotice(`Could not read the register: ${(e as Error).message}`);
    });
  }, [kind, tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  useEffect(() => {
    if (openNewNonce > 0) { setEditId(null); setView('form'); onConsumed?.(); }
  }, [openNewNonce, onConsumed]);

  const onSort = (key: string) =>
    setSort(s => (s && s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));

  // A document type can rename a shared column: a pricing's second date reads "Valid
  // Upto", a stock movement's warehouse column reads "From". The header and the printed
  // sheet both ask this one function, so they can never drift apart.
  const colLabel = (c: ColKey) => {
    const second = kind.secondDate;
    return c === 'party' ? kind.partyLabel
      : (second && second.key === c) ? second.label
        : c === 'subject' && kind.subjectLabel ? kind.subjectLabel
          : c === 'warehouse' && kind.warehouseLabel ? kind.warehouseLabel
            : c === 'source' ? sourceLabelOf(kind)
              : COLUMN_LIB[c].label;
  };

  const exportCols = kind.columns.map(c => ({
    label: colLabel(c),
    value: COLUMN_LIB[c].cell,
    align: COLUMN_LIB[c].right ? 'right' as const : 'left' as const
  }));

  // Which folders a paper sits in: the header, and every location its lines draw from,
  // because a split load belongs to each gate that is carrying part of it.
  const foldersOf = (d: BizDoc) => [...new Set(
    [d.warehouseName, ...d.lines.map(l => l.warehouseName)]
      .map(v => String(v || '').trim())
      .filter(v => v && v !== 'Multiple warehouses')
  )];
  const foldered = !!kind.warehouseFolders;
  const inFolder = useMemo(
    () => foldered ? rows.filter(d => !folder || foldersOf(d).includes(folder)) : rows,
    [rows, folder, foldered]
  );

  // The chips carry live counts, so they are counted over the folder the reader is already
  // looking at — a number beside a folder is that folder's own, not the whole book's.
  const folders = useMemo(() => {
    if (!foldered) return [];
    const names = [...new Set(inFolder.flatMap(foldersOf))].sort();
    return names.map(name => ({
      name, count: rows.filter(d => foldersOf(d).includes(name)).length
    }));
  }, [foldered, inFolder, rows]);

  const byStatus = useMemo(() => {
    const c: Record<string, number> = {};
    inFolder.forEach(d => { c[d.status] = (c[d.status] ?? 0) + 1; });
    return c;
  }, [inFolder]);

  const matches = useMemo(
    () => inFolder.filter(d => !statusFilter || d.status === statusFilter),
    [inFolder, statusFilter]
  );

  const visible = useMemo(() => {
    let out = matches.filter(d =>
      (!fromDate || d.date >= fromDate) && (!toDate || d.date <= toDate));
    if (sort) {
      const lib = COLUMN_LIB[sort.key as ColKey];
      out = [...out].sort((a, b) => {
        const av = lib.cell(a), bv = lib.cell(b);
        const cmp = typeof av === 'number' && typeof bv === 'number'
          ? av - bv : String(av).localeCompare(String(bv));
        return sort.dir === 'asc' ? cmp : -cmp;
      });
    }
    return out;
  }, [matches, sort, fromDate, toDate]);

  // Print and export follow the tickbox: selected rows when there is a selection,
  // otherwise everything currently on screen.
  const exportRows = selected.length ? visible.filter(d => selected.includes(d.id)) : visible;

  const footerCells = () => {
    const out: Record<number, string> = {};
    kind.columns.forEach((c, i) => {
      const add = SUMMABLE[c];
      if (!add) return;
      const total = exportRows.reduce((s, d) => s + add(d), 0);
      out[i] = COLUMN_LIB[c].right ? money(rd(total)) : String(rd(total));
    });
    if (Object.keys(out).length) out[0] = selected.length ? `Total (${exportRows.length} selected)` : 'Total';
    return out;
  };

  const headline = kind.columns.find(c => HEADLINE.includes(c));
  const addTo = headline ? SUMMABLE[headline] : undefined;
  // The headline figure is the foot of the table read from above: the same rows, the same
  // column, so the chip beside the title and the total line can never disagree.
  const shownTotal = rd(addTo ? visible.reduce((s, d) => s + addTo(d), 0) : 0);
  const windowed = visible.length !== matches.length;

  const stats: RegisterStat[] = [
    {
      label: kind.title,
      value: windowed ? `${visible.length} of ${matches.length}` : String(matches.length),
      title: windowed
        ? 'The date window is holding the rest of them back'
        : 'Papers this register holds for the search above'
    },
    ...(headline && addTo ? [{
      label: colLabel(headline),
      value: `${currency} ${shownTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      title: `Added over the ${visible.length} paper(s) the table is showing — the same line the foot of the grid prints`,
      tone: 'ok' as const
    } as RegisterStat] : []),
    ...([['Approved', 'ok'], ['Draft', 'warn'], ['Pending', 'warn'], ['Void', 'bad']] as const)
      .filter(([state]) => byStatus[state])
      .map(([state, tone]) => ({
        label: state, value: byStatus[state], tone,
        title: `${byStatus[state]} of this register's papers sit in ${state}`
      } as RegisterStat))
  ];

  // Every filter still in place, named in the reader's own words, so an empty table can
  // say what emptied it.
  const activeFilters = [
    search && `search “${search}”`,
    folder && `folder ${folder}`,
    statusFilter && `status ${statusFilter}`,
    (fromDate || toDate) && `dates ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setFolder('');
    setStatusFilter('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const toggleAll = (checked: boolean) =>
    setSelected(checked ? visible.map(d => d.id) : []);

  // Approving from the selection bar or from one row's tick is the same call, and a bill
  // coming back approved files its challans either way — so both answers are read the same.
  const approveIds = (ids: number[]) => {
    if (!ids.length) return;
    setNotice('');
    approveDocs(kind.resource, tenantSlug, branchId, ids)
      .then(r => { refresh(); setNotice(filedNote(r.filedDocs, kind)); })
      .catch(e => setNotice((e as Error).message));
  };

  const approveSelected = () => approveIds(selected);

  const changeStatus = (d: BizDoc, status: 'Draft' | 'Approved' | 'Void') => {
    setNotice('');
    setDocStatus(kind.resource, tenantSlug, branchId, d.id, status)
      .then(one => { refresh(); setNotice(filedNote(one.filedDocs, kind)); })
      .catch(e => setNotice((e as Error).message));
  };

  const remove = (d: BizDoc) => {
    if (!window.confirm(`Delete ${d.number}?`)) return;
    setNotice('');
    deleteDoc(kind.resource, tenantSlug, branchId, d.id)
      .then(r => { refresh(); setNotice(removedNote(r.removedDocs, kind)); })
      .catch(e => setNotice((e as Error).message));
  };

  // Goods that have already left on a signed challan make a bill the record of that delivery,
  // so its Void and Delete buttons stand down and say why instead of waiting for the register
  // to refuse. Only the papers the server measures for dispatch answer this — a GRN or a
  // voucher carries no such field and keeps both buttons.
  const served = (d: BizDoc) => !!d.dispatchState && d.dispatchState !== 'Not Dispatched';

  // One row prints the document itself on the company letterhead; the selection bar prints
  // every ticked document, one per page. The design each sheet prints in is the template
  // the company saved for this paper in Settings, so pressing PRINT means printing.
  const printFail = (e: unknown) => setNotice(`Could not print: ${(e as Error).message}`);

  const printRow = (d: BizDoc) => getDoc(kind.resource, tenantSlug, branchId, d.id)
    .then(one => printDocsWithLetterhead([one], tenantSlug, branchId,
      { sheet: kind.sheet, label: printLabelOf(kind), currency }))
    .catch(printFail);

  const printRows = () => Promise.all(selected.map(id => getDoc(kind.resource, tenantSlug, branchId, id)))
    .then(list => printDocsWithLetterhead(list, tenantSlug, branchId,
      { sheet: kind.sheet, label: printLabelOf(kind), currency }))
    .catch(printFail);

  const openNew = () => { setEditId(null); setView('form'); };
  const openRow = (id: number) => { setEditId(id); setView('form'); };

  if (view === 'form' || (view === 'bulk' && kind.bulkLabel)) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <button onClick={() => { refresh(); setView('list'); }} className="btn-xenith-outline">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to {kind.title}</span>
          </button>
          {view === 'bulk' && <span className="text-[11px] text-gray-500">BULK RECEIVE PAYMENT</span>}
        </div>
        {view === 'bulk'
          ? <BulkReceivePayment onDone={() => { refresh(); setView('list'); }} />
          : <DocForm key={`${editId ?? 'new'}`} kind={kind} docId={editId}
              onDone={msg => { refresh(); setView('list'); if (msg) setNotice(msg); }} />}
      </div>
    );
  }

  const cells = footerCells();

  return (
    <div className="space-y-4">
      {/* The screen answers its own three questions in order: what this register is and
          what it holds, then the levers that narrow it, then the papers themselves. */}
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">{kind.title}</h2>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel={kind.addLabel} onAdd={openNew}>
            {kind.linkButton && onNavigate && (
              <button type="button" onClick={() => onNavigate(kind.linkButton!.tab)} className="btn-xenith-outline">
                <span className="font-semibold">+</span> {kind.linkButton.label}
              </button>
            )}
            {kind.bulkLabel && (
              <button type="button" onClick={() => setView('bulk')} className="btn-xenith-success">
                <span className="font-semibold">+</span> {kind.bulkLabel}
              </button>
            )}
          </ListToolbar>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch}
            placeholder={kind.gatePass ? 'Search by number, party, gate pass, reference or product' : 'Search by number, party, reference or product'}
            onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter}
            counts={STATUSES.map(s => ({
              value: s, label: s || 'All',
              count: s ? (byStatus[s] ?? 0) : inFolder.length
            }))} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={kind.title} filename={kind.resource} columns={exportCols} rows={exportRows}
              footer={footerRow(exportCols.length, cells)} landscape={exportCols.length > 6} />
          </span>
        </div>

        {/* Warehouse folders: the staff of one gate work the loads that leave their own
            gate. A paper sits in every folder whose warehouse it draws from, so a split
            load is waiting for each of the gates carrying part of it. */}
        {foldered && folders.length > 1 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/60">
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-500">Folders</span>
            {[{ name: '', count: inFolder.length }, ...folders].map(f => (
              <button key={f.name || '—'} type="button" onClick={() => setFolder(f.name)}
                title={f.name ? `Only the papers this warehouse is named on` : 'Every warehouse, whole register'}
                className={`px-2.5 py-1 rounded-full border text-[11px] font-bold transition-colors ${
                  folder === f.name
                    ? 'border-[#1e88e5] bg-[#1e88e5] text-white'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-[#1e88e5] hover:text-[#1e88e5]'
                }`}>
                {f.name || 'All warehouses'}
                <span className={`ml-1.5 tabular-nums ${folder === f.name ? 'text-blue-100' : 'text-gray-400'}`}>{f.count}</span>
              </button>
            ))}
          </div>
        )}

        {notice && (
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-t border-gray-100 bg-amber-50 text-[12px] font-semibold text-amber-800">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice('')}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        {/* A paper can only be approved or bulk-printed while the reader is holding one, so
            these controls wait for the tickbox instead of sitting greyed out all day. */}
        {selected.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/70">
            <span className="text-[11px] font-bold text-gray-600">
              {selected.length} of {visible.length} ticked
            </span>
            {kind.approveLabel && !approvalHeldByAdmin && (
              <button type="button" onClick={approveSelected} className="btn-xenith-primary">
                {kind.approveLabel}
              </button>
            )}
            <button type="button" onClick={printRows} className="btn-xenith-primary">
              <Printer className="w-3.5 h-3.5" />
              <span>Bulk Print / PDF</span>
            </button>
            <button type="button" onClick={() => setSelected([])} className="btn-xenith-outline">
              <X className="w-3.5 h-3.5" /> Clear selection
            </button>
            <span className="text-[11px] text-gray-500">Print and export both follow the tickbox.</span>
          </div>
        )}

        {approvalHeldByAdmin && rows.some(d => d.status === 'Pending') && (
          <div className="px-4 py-2.5 border-t border-gray-100 text-[12px] text-gray-500">
            {rows.filter(d => d.status === 'Pending').length} of your document(s) is waiting for an administrator to approve it.
          </div>
        )}
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-[3%] text-center">
                  <input type="checkbox" className="accent-[#1e88e5]"
                    checked={visible.length > 0 && selected.length === visible.length}
                    onChange={e => toggleAll(e.target.checked)} />
                </th>
                {kind.columns.map(c => (
                  <SortHeader key={c} sortKey={c} sort={sort} onSort={onSort} label={colLabel(c)} />
                ))}
                <th className="text-center w-[8%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {visible.map(d => (
                <tr key={d.id} className={d.status === 'Void' ? 'opacity-50' : ''}>
                  <td className="text-center">
                    <input type="checkbox" className="accent-[#1e88e5]" checked={selected.includes(d.id)}
                      onChange={e => setSelected(s => e.target.checked ? [...s, d.id] : s.filter(x => x !== d.id))} />
                  </td>
                  {kind.columns.map(c => {
                    const lib = COLUMN_LIB[c];
                    const cell = lib.cell(d);
                    if (c === 'number') {
                      return (
                        <td key={c} className="font-bold text-blue-600 whitespace-nowrap">
                          <button onClick={() => openRow(d.id)} className="flex items-center gap-1.5 hover:underline">
                            <FileText className="w-3.5 h-3.5 text-gray-400" />
                            <span>{cell}</span>
                          </button>
                        </td>
                      );
                    }
                    if (c === 'dispatch') {
                      return (
                        <td key={c} className="whitespace-nowrap">
                          {cell === '—' ? <span className="text-gray-400">—</span> : (
                            <span title="Counted from the approved challans against the bill behind this paper"
                              className={`px-2 py-0.5 rounded text-[11px] font-bold border ${dispatchClass[String(cell)] || 'bg-gray-50 text-gray-500 border-gray-200'}`}>
                              {cell}
                            </span>
                          )}
                        </td>
                      );
                    }
                    if (c === 'status') {
                      return (
                        <td key={c}>
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${statusClass[String(cell)]}`}>{cell}</span>
                        </td>
                      );
                    }
                    return <td key={c} className={lib.right ? 'text-right font-medium text-gray-800' : ''}>{cell}</td>;
                  })}
                  <td className="text-center whitespace-nowrap">
                    <div className="flex items-center justify-center">
                      <IconAction title={`Print ${d.number} or save as PDF`} onClick={() => printRow(d)}>
                        <Printer className="w-4 h-4" />
                      </IconAction>
                      <IconAction title={`Edit ${d.number}`} tone="primary" onClick={() => openRow(d.id)}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>
                      {kind.approveLabel && !approvalHeldByAdmin && d.status !== 'Approved' && d.status !== 'Void' && (
                        <IconAction title={`Approve ${d.number}`} tone="success"
                          onClick={() => approveIds([d.id])}>
                          <CheckCircle2 className="w-4 h-4" />
                        </IconAction>
                      )}
                      {/* Approved paper belongs to the administrator who booked it, and paper
                          whose goods have already gone out is the record of that delivery. */}
                      {!(approvalHeldByAdmin && d.status === 'Approved') && (d.status !== 'Void' ? (
                        served(d) ? (
                          <IconAction title={`${d.number} has goods delivered against its challans, so it cannot be voided — void that challan first, or cancel the sale with a Sales Return`} disabled>
                            <Ban className="w-4 h-4" />
                          </IconAction>
                        ) : (
                          <IconAction title={`Void ${d.number}`} tone="danger" onClick={() => changeStatus(d, 'Void')}>
                            <Ban className="w-4 h-4" />
                          </IconAction>
                        )
                      ) : (
                        <IconAction title={`Reopen ${d.number} as draft`} onClick={() => changeStatus(d, 'Draft')}>
                          <RotateCcw className="w-4 h-4" />
                        </IconAction>
                      ))}
                      {!(approvalHeldByAdmin && d.status === 'Approved') && (
                        served(d) ? (
                          <IconAction title={`${d.number} has goods delivered against its challans, so it cannot be deleted — the delivery would be left answering to nothing`} disabled>
                            <Trash2 className="w-4 h-4" />
                          </IconAction>
                        ) : (
                          <IconAction title={`Delete ${d.number}`} tone="danger" onClick={() => remove(d)}>
                            <Trash2 className="w-4 h-4" />
                          </IconAction>
                        )
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {visible.length === 0 && (
                <TableEmpty colSpan={kind.columns.length + 2} noun={kind.title.toLowerCase()}
                  filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : kind.addLabel} onAdd={openNew} />
              )}
            </tbody>
            {/* The register closes with the same figures its printed sheet and its workbook
                carry, so what the reader adds up here is what leaves the building. */}
            {!!visible.length && Object.keys(cells).length > 0 && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td />
                  {kind.columns.map((c, i) => (
                    <td key={c} className={`${COLUMN_LIB[c].right ? 'text-right' : ''} font-black text-gray-800 tabular-nums`}>
                      {cells[i] ?? ''}
                    </td>
                  ))}
                  <td className="text-center text-[10px] font-semibold text-gray-500">
                    {windowed ? `${visible.length} shown` : ''}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
