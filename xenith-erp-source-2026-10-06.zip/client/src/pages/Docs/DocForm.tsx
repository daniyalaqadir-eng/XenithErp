import React, { useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { ChevronDown, Layers, Plus, Printer, ScanLine, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import { AttachmentBox, Check as Chk, Field, FormFooter, Text, Area, Pick } from '../Masters/masterUi';
import { DocKind, SALE_SIDE_RESOURCES, settlementSources, settlementTitles, printLabelOf, filedNote } from './docKinds';
import { isoDay } from '../../utils/dateRange';
import {
  AdjustmentType, BankAccount, BizDoc, DocAllocation, DocAttachment, DocCustoms, DocExpense, DocLine,
  DocPaymentLine, DocStatus, ImportDuty, InventoryItem, LedgerAccount
} from '../../types';
import { printDocsWithLetterhead } from '../../utils/printWithLetterhead';
import { Paper } from '../../utils/printDocument';
import {
  ChainLine, ChainPart, PendingSource, getDoc, getDocChain, getDocProposedNumber, getDocs,
  getPendingSources, saveDoc, updateDoc
} from '../../services/docs.service';
import { getParties } from '../../services/masters.service';
import { getWarehouses } from '../../services/warehouses.service';
import { getAdjustmentTypes, getItems, getStockMap, StockMapRow } from '../../services/inventory.service';
import { getBankAccounts } from '../../services/banking.service';
import { getLedgerAccounts } from '../../services/accounts.service';

const CASH_ID = -1;
// Cash hides the bank columns, Bank requires a bank account, Combine asks for both
// sides and is stored as two tenders so the ledger stays split by account.
const PAYMENT_CHANNELS = ['Cash', 'Bank', 'Combine'] as const;
type Channel = typeof PAYMENT_CHANNELS[number];
const PAYMENT_MODES = ['Cash', 'Bank', 'Combine', 'Cheque', 'Online Transfer', 'IFSS / Easypaisa', 'Advance', 'Other'];
const instrumentBased = (mode: string) => ['Cheque', 'Online Transfer', 'IFSS / Easypaisa'].includes(mode);
const isCashMode = (mode: string) => mode === 'Cash';

const money = (v: number) => (v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const num = (v: number) => (v ? String(v) : '');
const r2 = roundMoney;

let keySeq = 1;
interface Line {
  key: number;
  productId: number | null;
  productName: string;
  sku: string;
  unit: string;
  quantity: number;
  price: number;
  discountType: 'Percent' | 'Amount';
  discountValue: number;
  percentage: number;
  expenses: number;
  warehouseId: number | null;
  warehouseName: string;
  // Which line of the parent paper this line was picked out of. The quantity still free on
  // it is asked from the server's pending list, never stored on the line.
  sourceNumber: string;
  sourceLineId: number | null;
}

const blankLine = (warehouseId: number | null = null, warehouseName = ''): Line => ({
  key: keySeq++, productId: null, productName: '', sku: '', unit: '',
  quantity: 0, price: 0, discountType: 'Percent', discountValue: 0, percentage: 0, expenses: 0,
  warehouseId, warehouseName,
  sourceNumber: '', sourceLineId: null
});

const blankPaymentLine = (paymentMode = 'Cash'): DocPaymentLine => ({
  id: keySeq++, paymentMode, accountId: CASH_ID, accountName: 'Cash in Hand', reference: '',
  bankName: '', instrumentNumber: '', instrumentDate: '', documentNumber: '', amount: 0
});

const blankExpense = (): DocExpense => ({ id: keySeq++, accountName: '', description: '', contact: '', amount: 0 });

// ── the customs side of an import invoice ──────────────────────────────────────
// A container clears on a declaration, and the declaration is what the books are built from:
// the goods bought at the rate on the header, freight and insurance added to reach the
// assessable value, a duty on each head of that value, and only the duties the books cannot
// claim back riding onto the cost of the goods. The same arithmetic runs on the server at
// save; this is the paper's own preview of it, so the figure seen before the save is the
// figure the register holds after it.
const IMPORT_CURRENCIES = ['PKR', 'USD', 'EUR', 'GBP', 'AED', 'CNY', 'SAR', 'JPY', 'INR'];
const PAID_VIA = ['Unsettled', 'Cash', 'Bank'] as const;

const blankCustoms = (): DocCustoms => ({
  currency: 'PKR', rate: 1,
  cdNumber: '', cdDate: '', lcNumber: '', blNumber: '',
  portOfDischarge: '', countryOfOrigin: '', agentName: '',
  assessableValue: 0, duties: []
});

// What a Pakistani customs assessment raises, at the rates it usually raises them at. A rate
// here is a starting point the clearing agent corrects, not a law the software enforces.
const STANDARD_DUTIES: Array<{ head: string; rate: number; treatment: ImportDuty['treatment']; accountName: string }> = [
  { head: 'Customs Duty', rate: 20, treatment: 'In cost', accountName: 'Customs Duty & Taxes' },
  { head: 'Additional Customs Duty', rate: 3, treatment: 'In cost', accountName: 'Customs Duty & Taxes' },
  { head: 'Regulatory Duty', rate: 0, treatment: 'In cost', accountName: 'Customs Duty & Taxes' },
  { head: 'Sales Tax on Imports', rate: 18, treatment: 'Recoverable', accountName: 'Sales Tax Input on Imports' },
  { head: 'Income Tax Withholding (s.153)', rate: 2, treatment: 'Recoverable', accountName: 'Advance Income Tax on Imports' }
];

const blankDuty = (): ImportDuty => ({
  id: keySeq++, head: '', rate: 0, amount: 0, treatment: 'In cost',
  accountId: null, accountName: '', challan: '', paidVia: 'Unsettled',
  paidAccountId: null, paidAccountName: ''
});

const standardDuties = (): ImportDuty[] => STANDARD_DUTIES.map(x => ({
  ...blankDuty(), head: x.head, rate: x.rate, treatment: x.treatment, accountName: x.accountName
}));

// The two charges customs counts into the assessable value, read by the same words the
// server reads them by so the preview cannot disagree with the saved figure.
const isFreightHead = (name: string) => /freight|transport|haulage|cartage/i.test(String(name || ''));
const isInsuranceHead = (name: string) => /insurance/i.test(String(name || ''));

// The rate on the header, read the way the server reads it: a blank or a nonsense rate is
// not an exchange rate of zero, it is rupees.
const importRateOf = (c: DocCustoms) => (Number(c.rate) > 0 ? Number(c.rate) : 1);

// A count sheet counts the same product more than once. Consolidating folds those
// lines together and then reads the total against the stock actually sitting at that
// location, so the counter sees the gap before the audit is approved.
interface CompareRow {
  productName: string;
  sku: string;
  warehouseName: string;
  counted: number;
  system: number;
  variance: number;
}
interface CompareResult { folded: number; rows: CompareRow[] }

const sumAllocated = (d: BizDoc) => r2((d.allocations || []).reduce((s, a) => s + Number(a.allocated), 0));

// Money rests in a pocket — the till, the petty cash box, a bank account — and a voucher has
// already named the pocket it left or entered. Booking the other side against a second pocket
// moves nothing, so the cash and bank branches of the chart are not offered as account heads.
const isMoneyPocket = (a: LedgerAccount) =>
  !!a.bankName || /cash|bank|awaiting deposit/i.test(`${a.name} ${a.parentName ?? ''}`);

// The heads a voucher may be booked against: every leaf of the chart but the pockets. The side
// the paper normally posts to is offered first, since a receipt is nearly always income and a
// payment nearly always a spend — but a deposit taken in and an advance paid out sit on the
// other half of the chart, and both are honest answers to the same question.
const headChoices = (list: LedgerAccount[], side?: 'Expense' | 'Income') => list
  .filter(a => a.isActive !== false && !a.isGroup && !isMoneyPocket(a))
  .sort((a, b) => (a.type === side ? 0 : 1) - (b.type === side ? 0 : 1))
  .map(a => ({ id: a.id, label: a.name, hint: `${a.code} · ${a.type}` }));

// The leaves of one named branch of the chart. A branch is looked up by the name it is known
// by rather than by a code a company could renumber, and a book that has been renamed still has
// to offer its charges somewhere — so an unmatched branch widens back to its whole side rather
// than leaving the clerk with an empty box and no head to choose.
const branchLeaves = (list: LedgerAccount[], branch: string, type: LedgerAccount['type']) => {
  const leaves = list.filter(h => h.isActive !== false && !h.isGroup && h.type === type);
  const hit = list.find(h => h.isGroup && h.name.toLowerCase() === branch.toLowerCase());
  if (!hit) return leaves;
  const under = leaves.filter(l => l.code.startsWith(`${hit.code}.`));
  return under.length ? under : leaves;
};

// The heads a charge, a duty or a payment is booked against are chosen, never typed: a name
// that the chart does not hold files a voucher against nothing.
//
// A row can carry the name of a head without carrying its id — which is how the five duties an
// import seeds itself with arrive, and how the server resolves them at save. The box answers to
// the name in that case, so a head the book holds is never called an unknown one on screen
// while the same book is being read.
const HeadPick: React.FC<{
  heads: LedgerAccount[]; id: number | null; name: string;
  onPick: (id: number | null, name: string) => void;
}> = ({ heads, id, name, onPick }) => {
  const byName = id === null && name
    ? heads.find(h => h.name.toLowerCase() === name.toLowerCase()) ?? null : null;
  const shown = id ?? byName?.id ?? null;
  const matched = shown !== null && heads.some(h => h.id === shown);
  return (
    <div>
      <Pick value={shown === null ? '' : String(shown)}
        onChange={e => {
          const hit = heads.find(h => h.id === Number(e.target.value));
          onPick(e.target.value === '' ? null : Number(e.target.value), hit?.name ?? '');
        }}>
        <option value="">-Choose-</option>
        {!matched && shown !== null && <option value={String(shown)}>{name || `Head ${shown}`} — not on this list</option>}
        {heads.map(h => <option key={h.id} value={h.id}>{h.code} · {h.name}</option>)}
      </Pick>
      {!!name && !matched && (
        <div className="text-[10px] leading-tight text-red-600">
          “{name}” is not a head of the book — choose one, or this amount files nothing.
        </div>
      )}
    </div>
  );
};

interface Draft {
  number: string;
  partyId: number | null;
  date: string;
  dueDate: string;
  receiptDate: string;
  reference: string;
  subject: string;
  comments: string;
  warehouseId: number | null;
  warehouseName: string;
  toWarehouseId: number | null;
  toWarehouseName: string;
  adjustmentTypeId: number | null;
  adjustmentTypeName: string;
  orderNumber: string;
  // The exit permit the load leaves the compound on. The bill holds it and the register
  // repeats it on every challan cut out of that bill.
  gatePass: string;
  vehicle: string;
  driver: string;
  shippingAddress: string;
  discountPercent: number;
  discount: number;
  tax: number;
  shippingCharges: number;
  roundOff: number;
  accountId: number | null;
  accountName: string;
  toAccountId: number | null;
  accountReference: string;
  paymentAmount: number;
  autoSettlements: boolean;
  accountAdjustments: boolean;
  paymentLines: DocPaymentLine[];
  allocations: DocAllocation[];
  receivedAllocations: DocAllocation[];
  expenseMethod: string;
  expenses: DocExpense[];
  // The declaration the goods cleared on, for the one paper that has one. Its duties and
  // assessable value are computed at save, so only what the clerk writes lives here.
  customs: DocCustoms;
  attachments: DocAttachment[];
}

const emptyDraft = (kind: DocKind): Draft => ({
  number: '', partyId: null, date: isoDay(), dueDate: '', receiptDate: '',
  reference: '', subject: '', comments: '', warehouseId: null, warehouseName: '',
  toWarehouseId: null, toWarehouseName: '', adjustmentTypeId: null, adjustmentTypeName: '',
  orderNumber: '', gatePass: '', vehicle: '', driver: '',
  shippingAddress: '', discountPercent: 0, discount: 0, tax: 0, shippingCharges: 0, roundOff: 0,
  accountId: null, accountName: '', toAccountId: null,
  accountReference: '', paymentAmount: 0, autoSettlements: false, accountAdjustments: false,
  paymentLines: [blankPaymentLine()], allocations: [], receivedAllocations: [],
  expenseMethod: 'Method 1', expenses: [blankExpense()],
  // An import opens with the five heads customs raises, all of them unsettled: the clerk
  // marks which were paid and from where, and it is that mark which files the voucher.
  customs: { ...blankCustoms(), duties: kind.customs ? standardDuties() : [] },
  attachments: []
});

const statusBadge: Record<DocStatus, string> = {
  Draft: 'bg-gray-100 text-gray-600 border-gray-300',
  Pending: 'bg-amber-50 text-amber-600 border-amber-200',
  Approved: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  Void: 'bg-red-50 text-red-600 border-red-200'
};

interface Props {
  kind: DocKind;
  docId: number | null;
  // The board already knows which bill the paper is being cut out of, so it hands the number
  // over rather than making the keeper hunt for it in the picker a second time.
  presetSource?: string | null;
  // Back to the register, with whatever the save filed beside this paper to say out loud.
  onDone: (notice?: string) => void;
}

export const DocForm: React.FC<Props> = ({ kind, docId, presetSource = null, onDone }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { user } = useAuth();
  // A salesperson's own sale paper is approved by an administrator, so the footer must
  // not offer a status the server would refuse anyway.
  const needsApproval = !!user?.salesmanScoped && SALE_SIDE_RESOURCES.includes(kind.resource);
  const [trail, setTrail] = useState({ raisedBy: '', approvedBy: '', approvedAt: '', salesPerson: '' });
  const [f, setF] = useState<Draft>(() => emptyDraft(kind));
  const [lines, setLines] = useState<Line[]>(() => (kind.lines === 'none' ? [] : [blankLine()]));
  const [status, setStatus] = useState<DocStatus>('Draft');
  const [sourcePart, setSourcePart] = useState<{ part: string; of: string } | null>(null);
  // The day back-dating is measured against and whether this person may go under it, both
  // read from the register itself so the warning on screen and the rule on the server
  // cannot drift apart. `storedDate` is the date this paper was saved with: moving an old
  // paper sideways under the floor is back-dating, leaving it where it is not.
  const [dateFloor, setDateFloor] = useState('');
  const [mayBackdate, setMayBackdate] = useState(true);
  const [storedDate, setStoredDate] = useState('');
  // A paper that was already on the book before its register began demanding a source names
  // no source and cannot be made to. It stays editable; only a new paper is held to the
  // link, which is the same grandfathering the back-date rule uses.
  const [legacyLink, setLegacyLink] = useState(false);
  // Who the paper stands across from. A sale or purchase document is offered its customer
  // or vendor book; a voucher's Payee or Receiver is the whole chart of accounts, since
  // rent, tax and deposits belong to neither of those two books.
  const [parties, setParties] = useState<{ id: number; name: string; hint: string }[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [accounts, setAccounts] = useState<{ id: number; name: string }[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [channel, setChannel] = useState<Channel>(kind.voucherChannel ?? 'Cash');
  const [boxCash, setBoxCash] = useState(0);
  const [boxBank, setBoxBank] = useState(0);
  const [warehouses, setWarehouses] = useState<{ id: number; name: string; inactive?: boolean }[]>([]);
  const [requireWarehouse, setRequireWarehouse] = useState(false);
  const [adjustmentTypes, setAdjustmentTypes] = useState<AdjustmentType[]>([]);
  const [comparison, setComparison] = useState<CompareResult | null>(null);
  const [receivables, setReceivables] = useState<DocAllocation[]>([]);
  const [received, setReceived] = useState<DocAllocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  // Left empty, the paper is the one the template in Settings sets — which is what the saved
  // design was chosen for. A size picked here is a one-off override for this print only.
  const [paper, setPaper] = useState<Paper | ''>('');
  const [quickMsg, setQuickMsg] = useState('');
  const [quickText, setQuickText] = useState('');
  // The account heads a voucher spends from or pays into, so Particulars can be chosen
  // from the chart of accounts instead of typed and guessed at.
  const [heads, setHeads] = useState<LedgerAccount[]>([]);

  const set = (patch: Partial<Draft>) => setF(prev => ({ ...prev, ...patch }));

  const tenderModes = PAYMENT_MODES;
  const newTender = () => blankPaymentLine('Cash');

  // The same product can sit in more than one warehouse, so a stock document asks for
  // a location on every product line instead of one answer for the whole document.
  const perLineWarehouse = !!kind.warehouse;
  const warehouseNameOf = (id: number | null) => warehouses.find(w => w.id === id)?.name ?? '';
  // New lines inherit the location already used on this document, so a multi-line
  // receipt only needs a warehouse chosen once unless the stock really splits.
  const lineWarehouseSeed = (ls: Line[]): Partial<Line> => {
    if (!perLineWarehouse) return {};
    const last = [...ls].reverse().find(l => l.warehouseId !== null);
    const id = last?.warehouseId ?? warehouses[0]?.id ?? null;
    return { warehouseId: id, warehouseName: last?.warehouseName ?? warehouseNameOf(id) };
  };

  // The gate a warehouse-wise register counts its numbers by: the location on the header,
  // or the first product line that names one — which is where a challan's warehouse really
  // sits when every line carries its own.
  const numberGateOf = (): number | null =>
    f.warehouseId ?? lines.find(l => l.warehouseId !== null)?.warehouseId ?? null;
  // The number this register last handed out for itself, and the gate it was handed out
  // for, so a fresh suggestion only ever replaces the register's own figure.
  const suggested = useRef('');
  const numberGate = useRef<number | null>(null);

  useEffect(() => {
    let live = true;
    Promise.all([
      // A paper that faces a customer or a vendor asks that one book for its party. A voucher
      // faces a head of the books rather than a person, so it asks the chart below instead and
      // neither name book here.
      kind.party === 'customers' ? getParties('customers', tenantSlug, branchId) : Promise.resolve(null),
      kind.party === 'vendors' ? getParties('vendors', tenantSlug, branchId) : Promise.resolve(null),
      getItems(tenantSlug, branchId),
      getBankAccounts(tenantSlug, branchId),
      getWarehouses(tenantSlug, branchId),
      kind.adjustmentType ? getAdjustmentTypes(tenantSlug, branchId) : Promise.resolve({ data: [] as AdjustmentType[], total: 0 }),
      // A voucher's party box is the chart of accounts, so the paper asks for it — and so
      // does an import invoice, which files each of its charges and duties against a head.
      (kind.headPicker || kind.customs)
        ? getLedgerAccounts(tenantSlug, branchId)
        : Promise.resolve({ data: [] as LedgerAccount[], total: 0 }),
      // Asked for an existing paper too: its number is not used, but the day back-dating is
      // measured against is, and only the register knows it.
      getDocProposedNumber(kind.resource, tenantSlug, branchId)
    ]).then(([cs, vs, its, acs, whs, types, coa, proposal]) => {
      if (!live) return;
      setParties([
        ...(cs?.data ?? []).map(p => ({ id: p.id, name: p.name, hint: p.city || '' })),
        ...(vs?.data ?? []).map(p => ({ id: p.id, name: p.name, hint: p.city || '' }))
      ]);
      setItems(its.data);
      setAccounts(acs.data.map(a => ({ id: a.id, name: a.accountTitle })));
      setBanks(acs.data.filter(a => a.isActive !== false));
      setAdjustmentTypes(types.data.filter(t => t.isActive));
      setHeads(coa.data);
      // Warehouses of the branch being worked on come first, but every location stays
      // selectable: one receipt can split the same product across branches.
      const here = whs.data.filter(w => w.branchId === branchId);
      const elsewhere = whs.data.filter(w => w.branchId !== branchId);
      const list = [...here, ...elsewhere].map(w => ({ id: w.id, name: w.name, inactive: w.isActive === false }));
      setWarehouses(list);
      // With a single location in reach there is no question to ask the user.
      if (kind.warehouse && list.length === 1) {
        setLines(ls => ls.map(l => (l.warehouseId === null ? { ...l, warehouseId: list[0].id, warehouseName: list[0].name } : l)));
      }
      setRequireWarehouse(whs.settings.enabled && whs.settings.requireWarehouseOnDocuments);
      setDateFloor(proposal.dateFloor);
      setMayBackdate(proposal.canBackdate);
      // A paper already on the book keeps the number it was given; only a new one is
      // offered the next in sequence. A warehouse-wise register counts each gate's own
      // book, so its challan is numbered only once the location is on the paper.
      if (docId === null) {
        suggested.current = proposal.number;
        if (!kind.warehouseFolders) set({ number: proposal.number });
        if (kind.voucherChannel === 'Cash') set({ accountId: CASH_ID, accountName: 'Cash in Hand' });
      }
      setLoading(false);
    })
      // A book whose lists could not be read is not a form: the clerk has to be told, and the
      // screen has to stop saying "Loading form..." forever.
      .catch((e: any) => { if (live) setError(e?.message || 'The lists behind this form could not be read'); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantSlug, branchId]);

  // Papers stored before a register asked for a gate carry lines with none on them. With a
  // single location in reach there is nothing to ask, so they are placed — including the
  // lines that arrive after the warehouses have been read.
  useEffect(() => {
    if (!perLineWarehouse || warehouses.length !== 1) return;
    const only = warehouses[0];
    setLines(ls => (ls.some(l => l.warehouseId === null)
      ? ls.map(l => (l.warehouseId === null ? { ...l, warehouseId: only.id, warehouseName: only.name } : l))
      : ls));
  }, [perLineWarehouse, warehouses, lines]);

  // A challan's number names the gate its load goes out of, and that is not known until a
  // warehouse is on the paper. When the location changes the register is asked again — but
  // only ever for the number it handed out itself, so a figure the person typed or re-took
  // with the + button stays where they left it.
  useEffect(() => {
    if (docId !== null || !kind.warehouseFolders) return;
    const gate = numberGateOf();
    if (gate === null || gate === numberGate.current) return;
    numberGate.current = gate;
    if (f.number && f.number !== suggested.current) return;
    let live = true;
    getDocProposedNumber(kind.resource, tenantSlug, branchId, gate)
      .then(p => { if (live) { suggested.current = p.number; set({ number: p.number }); } })
      .catch(() => { numberGate.current = null; });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind.warehouseFolders, docId, f.warehouseId, f.number, lines, tenantSlug, branchId]);

  useEffect(() => {
    if (docId === null) { setSourcePart(null); return; }
    let live = true;
    getDoc(kind.resource, tenantSlug, branchId, docId).then(d => {
      if (!live) return;
      setStatus(d.status);
      setStoredDate(d.date);
      setTrail({ raisedBy: d.createdByName || '', approvedBy: d.approvedByName || '', approvedAt: d.approvedAt || '', salesPerson: d.salesPersonName || '' });
      // Which of its parent's parts this paper is — A, then B, then C. Only the server
      // knows, because the letters follow the siblings' dates, and a new challan has no
      // place in that order until it is saved.
      setSourcePart(d.sourcePart ? { part: d.sourcePart, of: d.sourceNumber || '' } : null);
      setLegacyLink(!d.lines.some(l => l.sourceNumber));
      setF({
        number: d.number, partyId: d.partyId, date: d.date, dueDate: d.dueDate, receiptDate: d.receiptDate,
        reference: d.reference, subject: d.subject, comments: d.comments, warehouseId: d.warehouseId,
        warehouseName: d.warehouseName, toWarehouseId: d.toWarehouseId, toWarehouseName: d.toWarehouseName,
        adjustmentTypeId: d.adjustmentTypeId, adjustmentTypeName: d.adjustmentTypeName,
        orderNumber: d.orderNumber, gatePass: d.gatePass || '',
        vehicle: d.vehicle || '', driver: d.driver || '', shippingAddress: d.shippingAddress,
        discountPercent: d.discountPercent, discount: d.discount, tax: d.tax, shippingCharges: d.shippingCharges,
        roundOff: d.roundOff,
        // A cash register's pocket is fixed by the register, and its stored papers were
        // written with only the name on them, so the name is read back as the account.
        accountId: kind.voucherChannel === 'Cash' ? CASH_ID : d.accountId, accountName: d.accountName,
        toAccountId: d.toAccountId,
        accountReference: d.accountReference,
        paymentAmount: d.paymentAmount, autoSettlements: d.autoSettlements, accountAdjustments: d.accountAdjustments,
        paymentLines: d.paymentLines.length ? d.paymentLines : [blankPaymentLine()],
        allocations: d.allocations, receivedAllocations: d.receivedAllocations,
        expenseMethod: d.expenseMethod, expenses: d.expenses.length ? d.expenses : [blankExpense()],
        // A paper saved before the declaration existed opens with the heads customs raises,
        // every one of them unsettled — nothing here moves money until the clerk says it did.
        customs: d.customs
          ? { ...d.customs, duties: d.customs.duties.length || !kind.customs ? d.customs.duties : standardDuties() }
          : { ...blankCustoms(), duties: kind.customs ? standardDuties() : [] },
        attachments: d.attachments || []
      });
      setLines(d.lines.length ? d.lines.map(l => ({
        key: keySeq++, productId: l.productId, productName: l.productName, sku: l.sku, unit: l.unit,
        quantity: l.quantity, price: l.price, discountType: l.discountType, discountValue: l.discountValue,
        percentage: l.percentage, expenses: l.expenses,
        warehouseId: l.warehouseId ?? null, warehouseName: l.warehouseName ?? '',
        sourceNumber: l.sourceNumber ?? '', sourceLineId: l.sourceLineId ?? null
      })) : [blankLine()]);
      // Re-read how the stored payment was tendered so the mode shows the truth.
      if (kind.paymentBoxLabel) {
        const paid = d.paymentLines.filter(p => Number(p.amount) > 0);
        // A voucher's channel is decided by the register, so its whole amount belongs to
        // that one side. The others are read back from the tenders the paper stored.
        const total = r2(d.paymentAmount);
        const cash = kind.voucherChannel
          ? (kind.voucherChannel === 'Cash' ? total : 0)
          : paid.length
            ? paid.filter(p => isCashMode(p.paymentMode)).reduce((s, p) => s + Number(p.amount), 0)
            : (!d.accountName || d.accountName === 'Cash in Hand' ? d.paymentAmount : 0);
        const bank = kind.voucherChannel
          ? (kind.voucherChannel === 'Bank' ? total : 0)
          : paid.length
            ? paid.filter(p => !isCashMode(p.paymentMode)).reduce((s, p) => s + Number(p.amount), 0)
            : (cash ? 0 : d.paymentAmount);
        const mode: Channel = kind.voucherChannel ?? (cash > 0 && bank > 0 ? 'Combine' : bank > 0 ? 'Bank' : 'Cash');
        setChannel(mode);
        setBoxCash(r2(cash));
        setBoxBank(r2(bank));
        if (mode === 'Cash') set({ accountId: CASH_ID, accountName: 'Cash in Hand' });
      }
    }).catch((e: any) => {
      // A paper that could not be read must not open as an empty new form: the clerk would
      // then write a second one over the number that already exists.
      if (live) setError(e?.message || 'That paper could not be read from the register');
    });
    return () => { live = false; };
  }, [docId, kind, tenantSlug, branchId]);

  // What a product costs on this paper: a vendor-side document reads the purchase rate,
  // everything else the rate the item is sold at.
  const masterRateOf = (i: InventoryItem) =>
    kind.party === 'vendors' ? Number(i.purchasePrice) || 0 : Number(i.salePrice) || 0;

  // The rate a line starts at when the paper behind it names none: the product's own card,
  // which is the same figure a hand-typed line of this register would be given.
  const cardRateOf = (productId: number | null) => {
    const i = items.find(x => x.id === productId);
    return i ? masterRateOf(i) : 0;
  };

  // Open documents available for auto settlement against the selected party.
  useEffect(() => {
    if (!kind.autoSettlements || !f.partyId) {
      setReceivables([]);
      setReceived([]);
      return;
    }
    const sources = settlementSources(kind.party);
    const openAmount = (d: BizDoc) => d.balance;
    // A queue of clerks moving through parties is normal, so a settlement list that arrives
    // after the party has moved on is dropped rather than offered for the wrong account.
    let live = true;
    getDocs(sources.open, tenantSlug, branchId).then(res => {
      if (!live) return;
      setReceivables(res.data
        .filter(d => d.partyId === f.partyId && openAmount(d) > 0 && d.status !== 'Void')
        .map(d => ({
          id: d.id, description: d.number, date: d.date, dueDate: d.dueDate,
          totalAmount: d.net, adjustedAmount: r2(d.net - openAmount(d)), balanceAmount: openAmount(d), allocated: 0
        })));
    }).catch(() => { if (live) setReceivables([]); });
    getDocs(sources.received, tenantSlug, branchId).then(res => {
      if (!live) return;
      setReceived(res.data
        .filter(d => d.partyId === f.partyId && d.status === 'Approved' && d.net - sumAllocated(d) > 0)
        .map(d => ({
          id: d.id, description: d.number, date: d.date, dueDate: '',
          totalAmount: d.net, adjustedAmount: sumAllocated(d), balanceAmount: d.net - sumAllocated(d), allocated: 0
        })));
    }).catch(() => { if (live) setReceived([]); });
    return () => { live = false; };
  }, [f.partyId, kind.autoSettlements, tenantSlug, branchId]);

  // A voucher settles its whole entry in the box facing it: the head of the books the money
  // crossed is the party on the paper, and the till or the bank account named under the tender
  // is the other half. Its party box therefore reads the chart, not the two books of names.
  const headAsParty = kind.party === 'accounts';
  // The person a paper stands across from, in the word this register uses — a message that
  // says "customer" on a vendor's bill is the software not knowing its own book.
  const partyWord = kind.party === 'vendors' ? 'vendor' : 'customer';
  const partyOptions: SelectOption[] = headAsParty
    ? headChoices(heads, kind.headPicker)
    : parties.map(p => ({ id: p.id, label: p.name, hint: p.hint }));
  const productOptions: SelectOption[] = items.map(i => ({ id: i.id, label: i.name, hint: i.sku }));

  // ── The chain: the paper this document is raised out of ───────────────────────
  // A challan is not asked whether it comes out of an invoice, it is required to. The
  // lines arrive with the quantity the invoice still has left, so a customer who took
  // half the goods cannot be billed for the whole bill twice.
  const [pending, setPending] = useState<PendingSource[] | null>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [chain, setChain] = useState<{ parts: ChainPart[]; lines: ChainLine[] } | null>(null);

  // The answer is asked of this register, not of the parent's: the server hangs the waiting
  // paper under the child, since only the child knows what it may still take from it.
  useEffect(() => {
    if (!kind.picksFrom) return;
    let live = true;
    getPendingSources(kind.resource, tenantSlug, branchId, { except: docId })
      .then(list => { if (live) setPending(list); })
      .catch(() => { if (live) setPending([]); });
    return () => { live = false; };
  }, [kind.picksFrom, kind.resource, docId, tenantSlug, branchId]);

  // What has already been cut out of this paper — read back once it exists on the book.
  useEffect(() => {
    if (!kind.chainParts || docId === null) { setChain(null); return; }
    let live = true;
    getDocChain(kind.resource, tenantSlug, branchId, docId)
      .then(c => { if (live) setChain(c); })
      .catch(() => { if (live) setChain(null); });
    return () => { live = false; };
  }, [kind.chainParts, kind.resource, docId, tenantSlug, branchId]);

  // Sources of the customer being billed, so a picker never offers another party's paper.
  // null while the register is still being read — no claim is made about what is pending.
  const pendingForParty = !pending ? []
    : f.partyId === null ? pending : pending.filter(s => s.partyId === f.partyId);
  const pendingRead = pending !== null;

  const remainingOf = (sourceNumber: string, lineId: number | null) => {
    const line = pending?.find(s => s.number === sourceNumber)?.lines.find(l => l.id === lineId);
    return line ? line.remaining : Infinity;
  };
  const overCap = lines.filter(l => l.sourceNumber && Number(l.quantity) > remainingOf(l.sourceNumber, l.sourceLineId) + 0.001);
  const linkMissing = !!kind.picksFrom?.required && !legacyLink && !lines.some(l => l.sourceNumber);
  const sourcesNamed = [...new Set(lines.map(l => l.sourceNumber).filter(Boolean))].sort();
  // Named once so the wording below reads as one voice instead of a repeated optional.
  const pickFrom = kind.picksFrom;
  // Where the register demands a source, the goods are not something to type — they come off
  // the paper being billed against, in the quantity that paper still has left. The form says
  // so with the boxes it shows rather than offering a box whose contents the server refuses.
  // A paper that was saved before the rule keeps its typed lines: it has no source to name.
  const typedLines = !pickFrom?.required || legacyLink;
  // A pick never replaces what is already on the form: it adds to it. A line from the same
  // source line is topped up to the remaining quantity rather than duplicated.
  const applyPick = (src: PendingSource, lineIds: number[]) => {
    // The picker already hides another customer's paper; this keeps a stale list from
    // putting it on the form anyway.
    if (f.partyId !== null && src.partyId !== null && src.partyId !== f.partyId) {
      setError(`${src.number} belongs to ${src.partyName}, not to the ${partyWord} on this document.`);
      return;
    }
    setLines(ls => {
      const next = ls.map(l => ({ ...l }));
      for (const id of lineIds) {
        const sl = src.lines.find(x => x.id === id);
        if (!sl) continue;
        const mine = next.find(l => l.sourceNumber === src.number && l.sourceLineId === id);
        if (mine) { mine.quantity = sl.remaining; continue; }
        const filled: Partial<Line> = {
          productId: sl.productId, productName: sl.productName, sku: sl.sku, unit: sl.unit,
          quantity: sl.remaining,
          // A Good Receiving counts goods and never money, so a bill raised out of one opens
          // at the rate the product's own card carries — the very default typing the product
          // in by hand would give it — and the clerk writes the vendor's figure over it.
          price: Number(sl.price) || cardRateOf(sl.productId),
          discountType: sl.discountType === 'Amount' ? 'Amount' : 'Percent',
          discountValue: Number(sl.discountValue) || 0,
          sourceNumber: src.number, sourceLineId: id,
          // A picked line leaves from the bay its paper named, which on some registers is per line.
          ...(perLineWarehouse
            ? { warehouseId: sl.warehouseId ?? null, warehouseName: sl.warehouseName || '' }
            : {})
        };
        const blank = next.find(l => !l.productId && !l.sourceNumber);
        if (blank) Object.assign(blank, filled);
        else next.push({ ...blankLine(), ...filled } as Line);
      }
      return next;
    });
    const patch: Partial<Draft> = {};
    if (f.partyId === null && src.partyId !== null) { patch.partyId = src.partyId; }
    if (kind.shippingAddress && !f.shippingAddress) patch.shippingAddress = src.shippingAddress;
    if (Object.keys(patch).length) set(patch);
    setError('');
  };

  // One paper waiting for this customer leaves nothing to choose, so the form takes it
  // straight away instead of interrupting with the same question again. Each paper is
  // fetched at most once per form, and only where the link is demanded — otherwise the
  // PICK button stays the choice.
  const fetchedOf = useRef<number[]>([]);
  useEffect(() => {
    if (!pickFrom?.required || docId !== null) return;
    const waiting = pendingForParty.filter(s => !fetchedOf.current.includes(s.id)
      && s.lines.some(l => l.remaining > 0.001));
    if (waiting.length !== 1) return;
    fetchedOf.current = [...fetchedOf.current, waiting[0].id];
    applyPick(waiting[0], waiting[0].lines.filter(l => l.remaining > 0.001).map(l => l.id));
  }, [pickFrom, pendingForParty, docId]);

  // The dispatch board opened this paper for one particular bill, so that bill's own lines are
  // laid on the form as soon as the waiting register is read — still capped at what it has
  // left, because a preset is a shortcut, not a licence to over-deliver.
  const presetTaken = useRef(false);
  useEffect(() => {
    if (!presetSource || docId !== null || !pending || presetTaken.current) return;
    const src = pending.find(s => s.number === presetSource);
    if (!src) return;
    presetTaken.current = true;
    const left = src.lines.filter(l => l.remaining > 0.001).map(l => l.id);
    if (left.length) applyPick(src, left);
  }, [presetSource, pending, docId]);

  // Under every picked quantity: how much the parent paper still holds. The figure is the
  // one the server will refuse beyond, so the form never lets a quantity be typed that the
  // warehouse cannot honour.
  const linkHint = (l: Line) => {
    if (!kind.picksFrom || !l.sourceNumber) return null;
    const left = remainingOf(l.sourceNumber, l.sourceLineId);
    if (!Number.isFinite(left)) {
      return <div className="text-[10px] text-gray-400 text-right">Against {l.sourceNumber}</div>;
    }
    const over = Number(l.quantity) > left + 0.001;
    return (
      <div className={`text-[10px] leading-tight text-right ${over ? 'text-red-600 font-semibold' : 'text-gray-400'}`}>
        {over ? `Only ${left} left on ${l.sourceNumber}` : `${left} left on ${l.sourceNumber}`}
      </div>
    );
  };


  const perLine = useMemo(() => lines.map(l => {
    const grossAmount = kind.lines === 'none' || kind.lines === 'qty' ? 0 : r2(l.quantity * l.price);
    const discountAmount = grossAmount === 0 ? 0
      : (l.discountType === 'Percent' ? r2(grossAmount * l.discountValue / 100) : r2(l.discountValue));
    const amount = r2(grossAmount - discountAmount);
    return { grossAmount, discountAmount, amount, afterExpense: r2(amount - l.expenses) };
  }), [lines, kind.lines]);

  // A line is only on the paper if it names a product and carries quantity — the same test
  // the save uses. The totals read this mask, so a row whose quantity was typed before the
  // item was picked cannot make the screen show a bill that then gets stored smaller.
  const lineOk = useMemo(
    () => lines.map((l, i) => !!l.productId && l.quantity > 0 && (kind.lines === 'qty' || perLine[i].grossAmount > 0)),
    [lines, kind.lines, perLine]
  );

  const warehouseSummary = useMemo(
    () => [...new Set(lines.map(l => warehouseNameOf(l.warehouseId)).filter(Boolean))].join(', '),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [lines, warehouses]
  );

  const selectedType = adjustmentTypes.find(t => t.id === f.adjustmentTypeId) || null;

  const totals = useMemo(() => {
    const gross = r2(perLine.reduce((s, p, i) => s + (lineOk[i] ? p.grossAmount : 0), 0));
    const netOfLines = r2(perLine.reduce((s, p, i) => s + (lineOk[i] ? p.amount : 0), 0));
    const payments = r2(f.paymentLines.reduce((s, p) => s + Number(p.amount), 0));
    const allocated = r2([...f.allocations, ...f.receivedAllocations].reduce((s, a) => s + Number(a.allocated), 0));
    const totalExpenses = r2(f.expenses.reduce((s, e) => s + Number(e.amount), 0));
    const allocatedTo = r2(f.allocations.reduce((s, a) => s + Number(a.allocated), 0));
    // A consignment's bill carries no discount, tax, freight or rounding of its own — those are
    // the duty and charge lines below, each filing its own voucher. So the preview zeroes them
    // exactly as the save does, and the number on the paper is the number that gets stored.
    const beforeRound = r2(kind.customs ? netOfLines
      : netOfLines - f.discount + f.tax + f.shippingCharges);
    const foreign = r2(beforeRound + (kind.customs ? 0 : f.roundOff));
    const net = kind.amountFrom === 'allocations' ? allocatedTo
      : kind.amountFrom === 'payments' ? payments
        : kind.amountFrom === 'box' ? r2(f.paymentAmount)
          // An import's vendor is owed in their own currency and the books run in rupees, so
          // what lands on their account is that total bought at the rate on the header.
          : kind.customs ? r2(foreign * importRateOf(f.customs))
            : foreign;
    const balance = r2(net - (kind.amountFrom === 'payments' || kind.amountFrom === 'allocations' ? allocatedTo : f.paymentAmount));
    return { gross, netOfLines, payments, allocated, totalExpenses, net, beforeRound, unadjusted: r2(net - allocated), balance };
  }, [perLine, lineOk, f, kind]);

  // The landed cost the server works out at save, worked out here too so the clerk reads the
  // figure on the paper before filing it. Same order, same rounding, so the preview and the
  // register the paper lands in cannot disagree.
  const landed = useMemo(() => {
    if (!kind.customs) return null;
    const rate = importRateOf(f.customs);
    // Each line's rupee value is rounded before the sum, exactly as the stored line is.
    const pkrOf = (i: number) => r2(perLine[i].amount * rate);
    const goodsPkr = r2(lines.reduce((s, _l, i) => s + (lineOk[i] ? pkrOf(i) : 0), 0));
    const freight = r2(f.expenses.filter(e => isFreightHead(e.accountName)).reduce((s, e) => s + Number(e.amount), 0));
    const insurance = r2(f.expenses.filter(e => isInsuranceHead(e.accountName)).reduce((s, e) => s + Number(e.amount), 0));
    const assessable = r2(goodsPkr + freight + insurance);
    const duties = f.customs.duties.map(x => ({ ...x, amount: r2(assessable * Number(x.rate) / 100) }));
    const dutyInCost = r2(duties.filter(x => x.treatment === 'In cost').reduce((s, x) => s + x.amount, 0));
    const dutyRecoverable = r2(duties.filter(x => x.treatment === 'Recoverable').reduce((s, x) => s + x.amount, 0));
    // Method 1 pushes the duties and charges onto the goods; Method 2 leaves them on their
    // own heads, so nothing is distributed and each item keeps its invoice cost.
    const pool = f.expenseMethod === 'Method 2' ? 0 : r2(dutyInCost + totals.totalExpenses);
    const typed = r2(lines.reduce((s, l, i) => s + (lineOk[i] ? Number(l.percentage) : 0), 0));
    const rows = lines.map((l, i) => {
      const value = lineOk[i] ? pkrOf(i) : 0;
      // Shares left unset divide the charges by the value of each line, which is what an
      // import clerk expects; shares that are set are taken exactly as written.
      const share = typed > 0 ? Number(l.percentage) : (goodsPkr ? value / goodsPkr * 100 : 0);
      const charges = r2(pool * share / 100);
      const landedAmount = r2(value + charges);
      const qty = Math.abs(Number(l.quantity) || 0);
      return { share: r2(share), charges, landedAmount, perUnit: qty ? r2(landedAmount / qty) : 0 };
    });
    const qtyTotal = r2(lines.reduce((s, l) => s + Math.abs(Number(l.quantity) || 0), 0));
    const landedTotal = r2(goodsPkr + pool);
    // What has not been paid yet, on either side of the paper. These are the amounts that
    // file no voucher, and the clerk needs to see them named before approving.
    const chargesUnsettled = r2(f.expenses.filter(e => e.paidVia !== 'Cash' && e.paidVia !== 'Bank').reduce((s, e) => s + Number(e.amount), 0));
    const dutyUnsettled = r2(duties.filter(x => x.treatment === 'In cost' && x.paidVia !== 'Cash' && x.paidVia !== 'Bank').reduce((s, x) => s + x.amount, 0));
    return {
      rate, currency: f.customs.currency, goodsPkr, freight, insurance, assessable, duties,
      dutyInCost, dutyRecoverable, pool, byKey: new Map(lines.map((l, i) => [l.key, rows[i]])),
      shareTotal: r2(rows.reduce((s, x) => s + x.share, 0)), landedTotal, chargesUnsettled, dutyUnsettled,
      perUnit: qtyTotal ? r2(landedTotal / qtyTotal) : 0
    };
  }, [kind.customs, lines, perLine, f.expenses, f.customs, f.expenseMethod, totals.totalExpenses]);

  // What the paper's money is written in. The vendor is billed in their own currency and the
  // books below the header are always rupees, so every amount column says which it is.
  const importing = !!kind.customs;
  const invoiceCurrency = landed?.currency ?? 'PKR';
  // The method the charges divide by is the one decision on this paper that the server takes
  // back once the goods have been costed with it, so the box closes here for the same reason.
  const methodLocked = importing && status === 'Approved';
  // Shares left blank are not a mistake: the charges then divide by the value of each line,
  // and the footer says so rather than showing a red figure nobody typed.
  const sharesByValue = importing && r2(lines.reduce((s, l) => s + Number(l.percentage), 0)) <= 0;

  const patchLine = (key: number, patch: Partial<Line>) =>
    setLines(ls => ls.map(l => (l.key === key ? { ...l, ...patch } : l)));

  const selectProduct = (key: number, productId: number | null) => {
    const cur = lines.find(l => l.key === key);
    // A picked line whose product is retyped no longer mirrors the parent's line, so the
    // thread back to it is dropped rather than left pointing at the wrong item.
    const unlink = cur?.sourceNumber && cur.productId !== productId
      ? { sourceNumber: '', sourceLineId: null as number | null } : {};
    const item = items.find(i => i.id === productId);
    if (!item) { patchLine(key, { productId: null, productName: '', sku: '', unit: '', ...unlink }); return; }
    patchLine(key, {
      productId: item.id, productName: item.name, sku: item.sku, unit: item.unit,
      price: masterRateOf(item), ...unlink
    });
  };

  // A new line joins the bottom of the table, carrying the warehouse the last line stood in —
  // a bill drawn from one location should not ask for it again on every row.
  const appendLine = () => setLines(ls => [...ls, { ...blankLine(), ...lineWarehouseSeed(ls) }]);
  const removeLine = (key: number) => setLines(ls => (ls.length === 1 ? [blankLine()] : ls.filter(l => l.key !== key)));

  // Stock on hand at each location, read by the count screens that compare against it and by
  // the warehouse column that warns a bill is promising more than the gate holds.
  const [stockMap, setStockMap] = useState<StockMapRow[]>([]);
  useEffect(() => {
    if (!kind.consolidateCompare && !kind.stockColumn) return;
    let live = true;
    // The column is a warning, not a gate: a stock read that fails leaves the counts blank
    // rather than refusing the paper.
    getStockMap(tenantSlug, branchId)
      .then(r => { if (live) setStockMap(r.data); })
      .catch(() => { if (live) setStockMap([]); });
    return () => { live = false; };
  }, [kind.consolidateCompare, kind.stockColumn, tenantSlug, branchId]);

  const consolidateAndCompare = () => {
    const grouped = new Map<string, Line>();
    let folded = 0;
    lines.filter(l => l.productId).forEach(l => {
      const key = `${l.productId}|${l.warehouseId ?? 0}`;
      const kept = grouped.get(key);
      if (kept) { kept.quantity = r2(kept.quantity + l.quantity); folded += 1; }
      else grouped.set(key, { ...l });
    });
    const merged = [...grouped.values()];
    if (merged.length) setLines(merged);
    setComparison({
      folded,
      rows: merged.map(l => {
        const here = stockMap.find(s => s.sku === l.sku && s.warehouseName === l.warehouseName);
        const system = here ? here.qty : (items.find(i => i.id === l.productId)?.stockQty ?? 0);
        return {
          productName: l.productName, sku: l.sku,
          warehouseName: l.warehouseName || 'Any warehouse',
          counted: Number(l.quantity) || 0, system, variance: r2((Number(l.quantity) || 0) - system)
        };
      })
    });
  };

  const patchPayment = (id: number, fields: Partial<DocPaymentLine>) =>
    set({ paymentLines: f.paymentLines.map(p => (p.id === id ? { ...p, ...fields } : p)) });

  const patchExpense = (id: number, fields: Partial<DocExpense>) =>
    set({ expenses: f.expenses.map(x => (x.id === id ? { ...x, ...fields } : x)) });

  const setCustoms = (patch: Partial<DocCustoms>) => set({ customs: { ...f.customs, ...patch } });
  const patchDuty = (id: number, fields: Partial<ImportDuty>) =>
    set({ customs: { ...f.customs, duties: f.customs.duties.map(x => (x.id === id ? { ...x, ...fields } : x)) } });

  const onChargeVia = (id: number, via: string) => patchExpense(id, via === 'Bank'
    ? { paidVia: 'Bank' }
    : { paidVia: via as DocExpense['paidVia'], paidAccountId: null, paidAccountName: '' });
  const onDutyVia = (id: number, via: string) => patchDuty(id, via === 'Bank'
    ? { paidVia: 'Bank' }
    : { paidVia: via as ImportDuty['paidVia'], paidAccountId: null, paidAccountName: '' });

  const bankAccount = (id: number | null) => banks.find(b => b.id === id) || null;
  const selectedBank = bankAccount(f.accountId);
  // A purely cash payment has no bank details to record, so those columns disappear.
  const bankColumns = f.paymentLines.some(p => !isCashMode(p.paymentMode));

  // Switching a tender to Combine turns that one row into a cash row and a bank row,
  // which is what the two sides of the payment actually are.
  const onTenderMode = (p: DocPaymentLine, mode: string) => {
    if (mode === 'Combine') {
      const first = banks[0] || null;
      set({
        paymentLines: f.paymentLines.flatMap(x => x.id === p.id ? [
          { ...x, paymentMode: 'Cash', accountId: CASH_ID, accountName: 'Cash in Hand', bankName: '', instrumentNumber: '', instrumentDate: '', amount: 0 },
          { ...x, id: keySeq++, paymentMode: 'Bank', accountId: first?.id ?? null, accountName: first?.accountTitle ?? '', bankName: first?.bankName ?? '', amount: x.amount }
        ] : [x])
      });
      return;
    }
    if (mode === 'Cash') {
      patchPayment(p.id, { paymentMode: 'Cash', accountId: CASH_ID, accountName: 'Cash in Hand', bankName: '', instrumentNumber: '', instrumentDate: '' });
      return;
    }
    if (mode === 'Bank') {
      const b = f.accountId && f.accountId !== CASH_ID ? bankAccount(f.accountId) : banks[0] || null;
      patchPayment(p.id, { paymentMode: 'Bank', accountId: b?.id ?? null, accountName: b?.accountTitle ?? '', bankName: b?.bankName ?? '' });
      return;
    }
    patchPayment(p.id, { paymentMode: mode });
  };

  const setBox = (cash: number, bank: number) => {
    // Money put into a pocket cannot be negative: a minus here would book a receipt that
    // runs the till or the bank account the other way round.
    const c = Math.max(0, r2(Number(cash) || 0));
    const b = Math.max(0, r2(Number(bank) || 0));
    setBoxCash(c);
    setBoxBank(b);
    set({ paymentAmount: r2(c + b) });
  };

  const onChannel = (c: Channel) => {
    const total = r2(boxCash + boxBank);
    setChannel(c);
    if (c === 'Cash') {
      setBox(total, 0);
      set({ accountId: CASH_ID, accountName: 'Cash in Hand' });
    } else if (c === 'Bank') {
      setBox(0, total);
      if (f.accountId === null || f.accountId === CASH_ID) {
        const b = banks[0] || null;
        set({ accountId: b?.id ?? null, accountName: b?.accountTitle ?? '' });
      }
    } else {
      const b = f.accountId === null || f.accountId === CASH_ID ? banks[0] || null : selectedBank;
      set({ accountId: b?.id ?? null, accountName: b?.accountTitle ?? '' });
    }
  };

  const patchAllocation = (which: 'allocations' | 'receivedAllocations', id: number, allocated: number) => {
    const list0 = f[which];
    let list = list0;
    if (!list0.some(a => a.id === id)) {
      const seed = (which === 'allocations' ? receivables : received).find(a => a.id === id);
      if (!seed) return;
      list = [...list0, seed];
    }
    // An allocation is a share of one open paper, so it lives between nothing and that
    // paper's balance: a negative settled money the party never paid, and a figure over the
    // balance left the receipt owing the difference back.
    const cap = list.find(a => a.id === id)?.balanceAmount;
    const v = r2(Math.max(0, Math.min(Number(allocated) || 0, cap ?? Infinity)));
    set(which === 'allocations'
      ? { allocations: list.map(a => (a.id === id ? { ...a, allocated: v } : a)) }
      : { receivedAllocations: list.map(a => (a.id === id ? { ...a, allocated: v } : a)) });
  };

  // The two boxes are the same discount seen two ways, so each is clamped inside the bill:
  // a negative one made the customer owed more than the goods, and one over the bill made
  // the paper total below zero.
  const onDiscountPercent = (p: number) => {
    const pct = Math.max(0, Math.min(100, Number(p) || 0));
    set({ discountPercent: pct, discount: r2(totals.netOfLines * pct / 100) });
  };
  const onDiscountAmount = (a: number) => {
    const amt = Math.min(totals.netOfLines, Math.max(0, Number(a) || 0));
    set({ discount: r2(amt), discountPercent: totals.netOfLines ? r2(amt / totals.netOfLines * 100) : 0 });
  };

  const findProduct = (t: string) =>
    items.find(i => i.sku.toLowerCase() === t || (i as any).code?.toLowerCase() === t) ||
    items.find(i => i.name.toLowerCase().includes(t) || i.sku.toLowerCase().includes(t));

  const priceOf = (i: InventoryItem) => masterRateOf(i);

  // A scanned product fills the first empty line, otherwise it adds one, so repeated
  // scans of the same SKU in the same warehouse stack up instead of being refused.
  const placeProduct = (hit: InventoryItem, ls: Line[]): Line[] => {
    const next = ls.map(l => ({ ...l }));
    const wh = lineWarehouseSeed(next);
    const priced = {
      productId: hit.id, productName: hit.name, sku: hit.sku, unit: hit.unit,
      price: masterRateOf(hit)
    };
    const blank = next.find(l => !l.productId);
    if (blank) {
      Object.assign(blank, priced, { quantity: (Number(blank.quantity) || 0) + 1, ...wh });
      return next;
    }
    return [...next, { ...blankLine(), ...priced, quantity: 1, ...wh }];
  };

  const quickAdd = () => {
    const tokens = quickText.split(/[\n,;]+/).map(t => t.trim().toLowerCase()).filter(Boolean);
    if (!tokens.length) { setShowQuickAdd(false); return; }
    const hits = tokens.map(findProduct).filter(Boolean) as InventoryItem[];
    if (hits.length) setLines(ls => hits.reduce((acc, h) => placeProduct(h, acc), ls));
    setQuickText('');
    setQuickMsg(hits.length
      ? `Added ${hits.length} product${hits.length > 1 ? 's' : ''}: ${hits.map(h => h.name).join(', ')}`
      : `No product matched “${tokens.join(', ')}”`);
  };

  const quickCandidates = useMemo(() => {
    const t = quickText.trim().toLowerCase();
    if (!t) return [];
    return items.filter(i => i.name.toLowerCase().includes(t) || i.sku.toLowerCase().includes(t)).slice(0, 6);
  }, [items, quickText]);

  // An import invoice's charges are the costs of bringing the goods in, and the chart keeps
  // those on one branch. A clerk who has to find "Freight & Transportation" has to be able to
  // see it: offering the whole expense side buries it under salaries, rent and staff loans,
  // and a charge that lands on one of those is no longer a cost of the consignment.
  const expenseHeads = useMemo(() => branchLeaves(heads, 'Landed Costs', 'Expense'), [heads]);
  // A duty is either a cost of the goods or an advance the books claim back, so its head comes
  // from the two branches that hold those answers and from nowhere else.
  const dutyHeads = useMemo(() => [
    ...branchLeaves(heads, 'Customs and Regulatory Duties', 'Expense'),
    ...branchLeaves(heads, 'Customs and FBR Advances', 'Asset')
  ], [heads]);
  // The pockets a settled charge or duty can have left. The till is decided by the mark itself
  // — a cash charge goes out of Cash in Hand — so this list is the bank side only.
  const bankHeads = useMemo(() => heads
    .filter(h => h.isActive !== false && !h.isGroup && h.type === 'Asset' && /bank|current|savings/i.test(h.name)),
  [heads]);
  // A bank voucher is money moving out of, or into, one named account. Left blank, the
  // ledger would have to guess, and guessing puts the money in the till instead of the bank.
  const pocketOk = kind.voucherChannel !== 'Bank' || (f.accountId !== null && f.accountId !== CASH_ID);
  // A voucher for nothing posts nothing, so its paper waits for an amount.
  const amountOk = kind.amountFrom !== 'box' || r2(f.paymentAmount) > 0;

  // Every party, including a voucher's head of the books, has to be a record on a book.
  const validParty = kind.party === 'none' || f.partyId !== null;
  const validLines = lines.filter((l, i) => l.productId && l.quantity > 0 && (kind.lines === 'qty' || perLine[i].grossAmount > 0));
  const needsWarehouse = !!kind.warehouse && requireWarehouse;
  const unplaced = needsWarehouse && perLineWarehouse
    ? validLines.filter(l => l.warehouseId === null).length
    : 0;
  const warehouseOk = !needsWarehouse || (perLineWarehouse ? unplaced === 0 : f.warehouseId !== null);
  // A transfer that never says where the stock lands, or an adjustment with no reason
  // chosen against it, cannot be posted.
  const destinationOk = !kind.toWarehouse || f.toWarehouseId !== null;
  const typeOk = !kind.adjustmentType || f.adjustmentTypeId !== null;
  // Back-dating is the server's rule, mirrored here so the date is argued about while it is
  // being typed rather than after Save is pressed: nothing may be dated under the newest
  // Approved paper of this register unless an administrator or the owner is writing it, and
  // an old paper left on its own date is not being moved at all.
  const backdated = !mayBackdate && !!dateFloor && f.date < dateFloor && f.date !== storedDate;
  // Nothing is saved over the quantity the parent paper still holds, and a challan is not
  // written at all until the bill behind it is named on it.
  const canSave = validParty && (kind.lines === 'none' || validLines.length > 0)
    && warehouseOk && destinationOk && typeOk && pocketOk && amountOk && !saving && !backdated
    && overCap.length === 0 && !linkMissing;

  const accountTitle = (id: number | null) =>
    id === null ? '' : (accounts.find(a => a.id === id)?.name || (id === CASH_ID ? 'Cash in Hand' : ''));


  // A combined receipt is stored as two tenders so the ledger and the cash/bank
  // split in reports stay honest.
  const isBox = !!kind.paymentBoxLabel;
  const boxTenders = (): DocPaymentLine[] => {
    if (channel !== 'Combine') return [];
    const out: DocPaymentLine[] = [];
    if (boxCash > 0) out.push({ ...blankPaymentLine(), id: 1, amount: boxCash, reference: f.accountReference });
    if (boxBank > 0) {
      const b = selectedBank;
      out.push({ ...blankPaymentLine(), id: 2, paymentMode: 'Bank', accountId: f.accountId,
        accountName: f.accountName, bankName: b?.bankName ?? '', reference: f.accountReference, amount: boxBank });
    }
    return out;
  };
  const tenders = () => (isBox ? boxTenders() : f.paymentLines.filter(p => Number(p.amount) > 0));

  const doSave = async (nextStatus?: string) => {
    if (!canSave) return;
    // What the book has confirmed about this paper so far. The chip below flips to the chosen
    // status to show the intent, and a refused save hands this number back: a paper the
    // register turned down is still Draft or Pending, and a chip that kept reading APPROVED
    // after a refusal would be a lie on the screen.
    const confirmed = status;
    setSaving(true);
    setError('');
    if (nextStatus && nextStatus !== status) setStatus(nextStatus as DocStatus);
    const body: Partial<BizDoc> = {
      number: f.number, partyId: f.partyId,
      // Only the id is sent: the server reads the party's name off the book it lives on, so a
      // name changed there is never left stale on the papers behind it.
      date: f.date, dueDate: f.dueDate, receiptDate: f.receiptDate,
      reference: f.reference, subject: f.subject, comments: f.comments,
      status: (nextStatus as DocStatus) || status,
      warehouseId: perLineWarehouse ? null : f.warehouseId,
      warehouseName: perLineWarehouse ? '' : (warehouses.find(w => w.id === f.warehouseId)?.name || ''),
      toWarehouseId: kind.toWarehouse ? f.toWarehouseId : null,
      toWarehouseName: kind.toWarehouse ? f.toWarehouseName : '',
      adjustmentTypeId: kind.adjustmentType ? f.adjustmentTypeId : null,
      adjustmentTypeName: kind.adjustmentType ? f.adjustmentTypeName : '',
      orderNumber: f.orderNumber, gatePass: f.gatePass.trim(),
      vehicle: f.vehicle.trim(), driver: f.driver.trim(), shippingAddress: f.shippingAddress,
      // The header names every paper this document was cut out of; the server derives the
      // same list from the lines, so the two can never disagree.
      sourceNumber: kind.picksFrom ? sourcesNamed.join(', ') : undefined,
      lines: validLines.map(l => ({
        id: 0, productId: l.productId, productName: l.productName, sku: l.sku, unit: l.unit,
        quantity: l.quantity, price: l.price, discountType: l.discountType, discountValue: l.discountValue,
        grossAmount: 0, discountAmount: 0, amount: 0, percentage: l.percentage, expenses: l.expenses,
        netValueAfterExpense: 0,
        warehouseId: perLineWarehouse ? l.warehouseId : null,
        warehouseName: perLineWarehouse ? (warehouseNameOf(l.warehouseId)) : '',
        sourceNumber: l.sourceNumber || undefined,
        sourceLineId: l.sourceLineId ?? undefined
      })) as any,
      discountPercent: f.discountPercent, discount: f.discount, tax: f.tax,
      shippingCharges: f.shippingCharges, roundOff: f.roundOff,
      accountId: f.accountId,
      accountName: f.accountId === null ? '' : (accountTitle(f.accountId) || f.accountName || 'Cash in Hand'),
      toAccountId: f.toAccountId,
      toAccountName: f.toAccountId === null ? '' : (accountTitle(f.toAccountId) || 'Cash in Hand'),
      accountReference: f.accountReference, paymentAmount: f.paymentAmount,
      autoSettlements: f.autoSettlements, accountAdjustments: f.accountAdjustments,
      paymentLines: tenders(),
      allocations: f.allocations.filter(a => Number(a.allocated) > 0),
      receivedAllocations: f.receivedAllocations.filter(a => Number(a.allocated) > 0),
      expenseMethod: f.expenseMethod,
      expenses: f.expenses.filter(e => Number(e.amount) > 0 || e.accountName),
      // The declaration travels whole. The server recomputes the assessable value, each duty
      // amount and every line's landed share from it, so a head with no name on it files
      // nothing and is left off rather than sent as an empty row.
      customs: kind.customs
        ? { ...f.customs, duties: f.customs.duties.filter(x => x.head.trim()) }
        : undefined,
      attachments: f.attachments
    };
    try {
      const saved = docId === null
        ? await saveDoc(kind.resource, tenantSlug, branchId, body)
        : await updateDoc(kind.resource, tenantSlug, branchId, docId, body);
      // The server has the last word on status: a salesperson's save comes back Pending.
      setStatus(saved.status);
      setTrail({ raisedBy: saved.createdByName || '', approvedBy: saved.approvedByName || '', approvedAt: saved.approvedAt || '', salesPerson: saved.salesPersonName || '' });
      // Approving a bill files the papers its own detail asks for — a sale its challans per
      // warehouse, an import a voucher per settled charge and duty — and the register says so
      // instead of leaving the keeper to discover the work.
      onDone(filedNote(saved.filedDocs, kind));
    } catch (e: any) {
      setStatus(confirmed);
      setError(e.message || 'Could not save record');
    } finally {
      // The button is freed whichever way the write went: a saved form is on its way out of
      // the screen, and a refused one has to be editable again.
      setSaving(false);
    }
  };

  // The printed sheet follows what the form holds, so a draft can be checked on paper
  // before it is saved. `perLine` is aligned with `lines`, so each line carries its own
  // computed money by key.
  const lineMoney = useMemo(() => new Map(lines.map((l, i) => [l.key, perLine[i]])), [lines, perLine]);

  const printableDoc = (): BizDoc => ({
    id: docId ?? 0,
    number: f.number,
    partyId: f.partyId,
    partyName: partyOptions.find(o => o.id === f.partyId)?.label ?? '',
    date: f.date, dueDate: f.dueDate, receiptDate: f.receiptDate,
    reference: f.reference, subject: f.subject, comments: f.comments, status,
    // Who raised, who approved and who sold it are on the register even though the form
    // offers no box for them — a printed paper that signs itself with "N/A" is a lie.
    createdByName: trail.raisedBy, approvedByName: trail.approvedBy, salesPersonName: trail.salesPerson,
    warehouseId: f.warehouseId,
    warehouseName: perLineWarehouse ? warehouseSummary : f.warehouseName,
    orderNumber: f.orderNumber, gatePass: f.gatePass,
    vehicle: f.vehicle, driver: f.driver, shippingAddress: f.shippingAddress,
    lines: validLines.map(l => {
      const m = lineMoney.get(l.key);
      const ln = landed?.byKey.get(l.key);
      return {
        id: 0, productId: l.productId, productName: l.productName, sku: l.sku, unit: l.unit,
        quantity: l.quantity, price: l.price, discountType: l.discountType, discountValue: l.discountValue,
        grossAmount: m?.grossAmount ?? 0, discountAmount: m?.discountAmount ?? 0, amount: m?.amount ?? 0,
        // The share and the charges printed are the ones the landed cost worked out, not what
        // the box still holds from before the duties were written in.
        percentage: ln?.share ?? l.percentage, expenses: ln?.charges ?? l.expenses,
        netValueAfterExpense: m?.afterExpense ?? 0,
        ...(ln ? {
          amountPkr: r2((m?.amount ?? 0) * (landed?.rate ?? 1)), landedCharges: ln.charges,
          landedAmount: ln.landedAmount, landedCostPerUnit: ln.perUnit
        } : {}),
        warehouseId: l.warehouseId, warehouseName: l.warehouseName
      };
    }),
    gross: totals.gross, discountPercent: f.discountPercent, discount: f.discount, tax: f.tax,
    shippingCharges: f.shippingCharges, roundOff: f.roundOff, net: totals.net,
    accountId: f.accountId,
    accountName: f.accountId === null ? '' : (accountTitle(f.accountId) || f.accountName || 'Cash in Hand'),
    accountReference: f.accountReference,
    toAccountId: f.toAccountId,
    toAccountName: f.toAccountId === null ? '' : (accountTitle(f.toAccountId) || 'Cash in Hand'),
    toWarehouseId: f.toWarehouseId, toWarehouseName: f.toWarehouseName,
    adjustmentTypeId: f.adjustmentTypeId, adjustmentTypeName: f.adjustmentTypeName,
    paymentAmount: f.paymentAmount,
    autoSettlements: f.autoSettlements, accountAdjustments: f.accountAdjustments,
    paymentLines: tenders(),
    allocations: f.allocations.filter(a => Number(a.allocated) > 0),
    receivedAllocations: f.receivedAllocations.filter(a => Number(a.allocated) > 0),
    expenseMethod: f.expenseMethod,
    expenses: f.expenses.filter(e => Number(e.amount) > 0 || e.accountName),
    totalExpenses: totals.totalExpenses,
    // A printed declaration carries the figures the form is showing, so a draft can be read
    // on paper against the same numbers the clerk typed.
    customs: kind.customs
      ? { ...f.customs, assessableValue: landed?.assessable ?? 0, duties: landed?.duties ?? [] }
      : undefined,
    landed: landed ? {
      method: f.expenseMethod, goodsPkr: landed.goodsPkr, dutyInCost: landed.dutyInCost,
      dutyRecoverable: landed.dutyRecoverable, charges: totals.totalExpenses,
      chargesUnsettled: landed.chargesUnsettled, landedTotal: landed.landedTotal,
      perUnit: landed.perUnit, shareTotal: landed.shareTotal
    } : undefined,
    unadjusted: totals.unadjusted, balance: totals.balance,
    attachments: f.attachments
  });

  // The sheet prints in whatever template the company set for this paper in Settings, so
  // the button means printing rather than opening a designer first.
  const printNow = () => printDocsWithLetterhead([printableDoc()], tenantSlug, branchId, {
    sheet: kind.sheet, label: printLabelOf(kind), currency, paper: paper || undefined
  });

  // The same consignment read by a guard: quantities, no rupees. The customer carries this
  // out of the office and the store hands over what it lists.
  const printGatePass = () => printDocsWithLetterhead([printableDoc()], tenantSlug, branchId, {
    sheet: kind.gateSheet, label: 'GATE PASS', currency, paper: paper || undefined
  });

  if (loading) return <div className="text-xs text-gray-500 p-6">Loading form...</div>;

  // The one thing a line's own button does is take it back off the paper. Adding a line is not
  // asked here — a tick beside a row read as a tick, not as "another line" — it is the one
  // honest button under each table, where the reference papers put theirs.
  const lineAction = (key: number) => (
    <td className="text-center whitespace-nowrap">
      <button type="button" title="Delete line" onClick={() => removeLine(key)}
        className="text-gray-400 hover:text-red-600 px-1">
        <Trash2 className="w-4 h-4" />
      </button>
    </td>
  );

  const appendRow = (label: string, onClick: () => void) => (
    <div className="px-3 py-2 bg-gray-50 border-t border-gray-200">
      <button type="button" onClick={onClick} className="btn-xenith-outline !px-2 !py-1 text-[11px]">
        <Plus className="w-3.5 h-3.5" /><span>{label}</span>
      </button>
    </div>
  );

  // Only a paper whose lines are typed offers an empty row: on one picked off another paper a
  // blank line would be a line with nothing on it, and the server would refuse it.
  const appendRowStrip = typedLines && appendRow('APPEND ITEM ROW', appendLine);

  // The goods box: a search when a line may be typed, the goods themselves when they were
  // picked off another paper and are only here to be billed or delivered.
  const productCell = (l: Line) => (
    <td>
      {typedLines ? (
        <SearchSelect options={productOptions} value={l.productId}
          onChange={id => selectProduct(l.key, id)} placeholder="Type to search product" />
      ) : (
        <div className="py-1 text-gray-800">
          {l.productName || '—'}
          {!!l.sku && <span className="block text-[10px] text-gray-400">{l.sku}</span>}
        </div>
      )}
    </td>
  );

  const lineWarehouseCell = (l: Line) => (
    <td>
      <Pick value={l.warehouseId === null ? '' : String(l.warehouseId)}
        onChange={e => {
          const id = e.target.value === '' ? null : Number(e.target.value);
          patchLine(l.key, { warehouseId: id, warehouseName: warehouseNameOf(id) });
        }}>
        <option value="">{needsWarehouse ? 'Select warehouse' : 'Default'}</option>
        {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}{w.inactive ? ' (inactive)' : ''}</option>)}
      </Pick>
    </td>
  );

  // What actually stands at the gate this line names. A draft only promises goods, so a
  // shortage is shown in red and the draft still saves; it is the approval the register
  // refuses, because signing off is the moment the stock card would go below zero.
  const stockAt = (l: Line) => {
    const place = l.warehouseName || f.warehouseName || '';
    const rows = stockMap.filter(s => s.sku === l.sku && (!place || s.warehouseName === place));
    if (rows.length) return { place, qty: r2(rows.reduce((s, r) => s + Number(r.qty), 0)) };
    // A product that has never been received anywhere has no warehouse card to read, so the
    // answer is nothing. The item master's own figure only counts when it is the same goods —
    // an id that carries a different code belongs to neither book and is shown as empty.
    const card = items.find(i => i.id === l.productId);
    return { place, qty: card && card.sku === l.sku ? r2(card.stockQty ?? 0) : 0 };
  };

  const stockCell = (l: Line) => {
    if (!l.productId) return <td className="text-right text-gray-300">—</td>;
    const { place, qty } = stockAt(l);
    const short = r2(Number(l.quantity) - qty);
    return (
      <td className="text-right">
        <span className={`font-bold tabular-nums ${short > 0 ? 'text-red-600' : 'text-gray-700'}`}>
          {qty.toLocaleString(undefined, { maximumFractionDigits: 2 })} {l.unit || 'PCS'}
        </span>
        {short > 0 && (
          <em className="not-italic block text-[10px] text-red-600 leading-tight">
            Short {short.toLocaleString(undefined, { maximumFractionDigits: 2 })} {place ? `at ${place}` : 'in stock'}
          </em>
        )}
      </td>
    );
  };

  return (
    <>
    <div className="space-y-4 pb-4">
      <div className="bg-white rounded border border-gray-200 px-4 py-3 flex items-center justify-between">
        <h2 className="page-title">{kind.title} - [{f.number || 'NEW'}]</h2>
        <div className="flex items-center gap-2">
          {trail.raisedBy && <span className="text-[11px] text-gray-500">Raised by {trail.raisedBy}</span>}
          {trail.approvedBy && (
            <span className="text-[11px] text-[#25a195]">Approved by {trail.approvedBy}{trail.approvedAt ? ` · ${trail.approvedAt}` : ''}</span>
          )}
          <span className={`px-3 py-1 rounded border text-[11px] font-bold uppercase tracking-wide ${statusBadge[status]}`}>
            {status === 'Pending' && needsApproval ? 'Awaiting approval' : status}
          </span>
        </div>
      </div>

      {needsApproval && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 text-[11.5px] rounded px-3 py-2">
          You can raise and edit this document, but only an administrator can approve it. Until then it does not
          reach the ledger, the stock or the customer&rsquo;s balance.
        </div>
      )}

      {error && <div className="bg-red-50 border border-red-200 text-red-600 text-xs rounded px-3 py-2">{error}</div>}

      {/* Header fields */}
      <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
        {/* The three numbers a challan is read by, in the order a keeper asks for them:
            the bill it is cut out of, its own number, and the gate permit the load leaves
            the compound on. The bill and the permit are already written, so they are shown
            here rather than typed again. */}
        {kind.gatePass === 'shown' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-1">
            {[
              ['Sale Invoice No', sourcesNamed.length ? sourcesNamed.join(', ') : 'Pick the invoice below'],
              ['Sale Delivery No', f.number || 'Numbered once its warehouse is chosen'],
              ['Gate Pass No', f.gatePass || 'None written on the invoice yet']
            ].map(([label, value]) => (
              <div key={label} className="rounded border border-gray-200 bg-gray-50 px-3 py-2">
                <div className="text-[10px] uppercase tracking-wide text-gray-500">{label}</div>
                <div className={`text-[13px] font-bold break-words ${value.startsWith('Pick') || value.startsWith('None') || value.startsWith('Numbered') ? 'text-gray-400 font-normal' : 'text-gray-800'}`}>
                  {value}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {kind.party !== 'none' && (
            <Field label={kind.partyLabel} required
              hint={headAsParty
                ? kind.voucherChannel === 'Bank'
                  ? 'the head of the books the money crossed — the bank account named below is the other half'
                  : 'the head of the books the money crossed — Cash in Hand is the other half'
                : undefined}>
              <SearchSelect options={partyOptions} value={f.partyId}
                onChange={id => {
                  const head = partyOptions.find(o => o.id === id)?.label ?? '';
                  set(headAsParty ? { partyId: id, subject: head } : { partyId: id });
                }}
                placeholder={`Type to search ${headAsParty ? 'account heads' : kind.partyLabel.toLowerCase()}`}
                invalid={!validParty} />
            </Field>
          )}

          <Field label="Number" required
            hint={kind.warehouseFolders && !f.number
              ? 'Each warehouse keeps its own book of challans — the number appears when the goods have a warehouse to leave from.'
              : undefined}>
            <div className="flex gap-1">
              <Text value={f.number} onChange={e => set({ number: e.target.value })} />
              <button type="button"
                title={kind.warehouseFolders && numberGateOf() === null
                  ? 'Choose the warehouse first — this register numbers each gate separately'
                  : 'Get next number'}
                disabled={kind.warehouseFolders && numberGateOf() === null}
                onClick={() => getDocProposedNumber(kind.resource, tenantSlug, branchId, numberGateOf())
                  .then(p => { suggested.current = p.number; set({ number: p.number }); })
                  .catch((e: any) => setError(e?.message || 'The register would not hand out a number'))}
                className="btn-xenith-success !px-2 rounded disabled:opacity-40 disabled:cursor-not-allowed">
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </Field>

          <Field label="Date" required
            hint={backdated
              ? `${dateFloor} is already approved in this register — an administrator or the company owner has to date a paper before that day.`
              : undefined}>
            <input type="date" className={`input-xenith ${backdated ? 'ring-1 ring-amber-400' : ''}`}
              value={f.date} onChange={e => set({ date: e.target.value })} />
          </Field>

          {kind.secondDate && (
            <Field label={kind.secondDate.label} required={!!kind.secondDate.required}>
              <input type="date" className="input-xenith"
                value={kind.secondDate.key === 'dueDate' ? f.dueDate : f.receiptDate}
                onChange={e => set(kind.secondDate!.key === 'dueDate' ? { dueDate: e.target.value } : { receiptDate: e.target.value })} />
            </Field>
          )}

          <Field label="Reference">
            <Text placeholder="Reference" value={f.reference} onChange={e => set({ reference: e.target.value })} />
          </Field>
        </div>

        {/* A voucher has no subject to name apart from the head it already picked across the
            counter, so its paper goes straight from the party to the tender. */}
        {!headAsParty && (<>
          {kind.gatePass && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Field label={kind.subjectLabel || 'Subject'}>
                <Text placeholder={kind.subjectLabel || 'Subject'} value={f.subject} onChange={e => set({ subject: e.target.value })} />
              </Field>

              {/* The bill grants the exit permit and its challans repeat it, so the number is
                  written once here and every load cut out of this paper carries it. */}
              {kind.gatePass === 'type' && (
                <Field label="Gate Pass No"
                  hint="the permit the goods leave the compound on — every delivery raised out of this bill carries it">
                  <Text placeholder="e.g. GP-7788" value={f.gatePass} onChange={e => set({ gatePass: e.target.value })} />
                </Field>
              )}

              {/* What carries the load and who is at the wheel are the load's own business: a
                  bill may go out in two vans on two days, so the challan answers for itself and
                  the watchman checks these two lines before the gate opens. */}
              <Field label="Vehicle / Transport"
                hint={kind.gatePass === 'type'
                  ? 'what the goods leave on — a challan raised from this bill starts with it and may name its own'
                  : "this load's own vehicle — the bill's is filled in to start with"}>
                <Text placeholder="e.g. Bolero LD-12-3456, or Counter Delivery" value={f.vehicle} onChange={e => set({ vehicle: e.target.value })} />
              </Field>
              <Field label="Driver / Handover"
                hint="who is taking the goods out, or the person handing them over at the counter">
                <Text placeholder="e.g. Imran (van), or Direct Handover" value={f.driver} onChange={e => set({ driver: e.target.value })} />
              </Field>
            </div>
          )}

          {!kind.gatePass && (
            <div className="md:w-1/2">
              <Field label={kind.subjectLabel || 'Subject'}>
                <Text placeholder={kind.subjectLabel || 'Subject'} value={f.subject} onChange={e => set({ subject: e.target.value })} />
              </Field>
            </div>
          )}
        </>)}

        {(kind.adjustmentType || kind.toWarehouse) && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {kind.adjustmentType && (
              <Field label="Adjustment Type" required
                hint={selectedType ? `(${selectedType.direction === 'Add' ? 'increases' : 'decreases'} stock)` : undefined}>
                <Pick value={f.adjustmentTypeId === null ? '' : String(f.adjustmentTypeId)}
                  onChange={e => {
                    const id = e.target.value === '' ? null : Number(e.target.value);
                    set({ adjustmentTypeId: id, adjustmentTypeName: adjustmentTypes.find(t => t.id === id)?.name ?? '' });
                  }}>
                  <option value="">-Choose-</option>
                  {adjustmentTypes.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </Pick>
              </Field>
            )}
            {kind.toWarehouse && (
              <Field label="To Warehouse" required hint="(where the stock lands)">
                <Pick value={f.toWarehouseId === null ? '' : String(f.toWarehouseId)}
                  onChange={e => {
                    const id = e.target.value === '' ? null : Number(e.target.value);
                    set({ toWarehouseId: id, toWarehouseName: warehouseNameOf(id) });
                  }}>
                  <option value="">-Choose-</option>
                  {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}{w.inactive ? ' (inactive)' : ''}</option>)}
                </Pick>
              </Field>
            )}
            {selectedType && selectedType.description && (
              <p className="self-center text-[11px] text-gray-500">{selectedType.description}</p>
            )}
          </div>
        )}

        {kind.picksFrom && (() => {
          const from = kind.picksFrom!;
          // A paper that was on the book before the register demanded a source is a record,
          // not a mistake: it is stated plainly in the same voice as the rest, without the
          // red that means "this save will be refused".
          const legacy = legacyLink && !sourcesNamed.length;
          return (
            <div className={`border rounded px-3 py-2 text-[11px] flex flex-wrap items-center gap-x-4 gap-y-1.5 ${
              overCap.length || linkMissing ? 'border-red-300 bg-red-50'
                : sourcesNamed.length ? 'border-emerald-200 bg-emerald-50' : 'border-gray-200 bg-gray-50'}`}>
              <span className={`font-semibold ${overCap.length || linkMissing ? 'text-red-700' : sourcesNamed.length ? 'text-emerald-800' : 'text-gray-600'}`}>
                {sourcesNamed.length
                  ? `RAISED AGAINST ${sourcesNamed.join(', ').toUpperCase()}`
                  : legacy
                    ? `NO ${from.label.toUpperCase()} NAMED — this paper was raised before ${printLabelOf(kind).toLowerCase()}s began being cut out of one, so it stands as it was saved`
                    : from.required
                      ? `NOTHING LINKED — ${printLabelOf(kind)} IS ONLY RAISED OUT OF AN APPROVED ${from.label.toUpperCase()}`
                      : from.consumes === false
                        // Nothing is missing here: a return that names no bill is the general
                        // kind, which is why the sentence reads as a statement, not a warning.
                        ? `GENERAL ${printLabelOf(kind).toUpperCase()} — NO ${from.label.toUpperCase()} NAMED, THE LINES WERE TYPED IN`
                        : `NOT TAKEN FROM A ${from.label.toUpperCase()} — THE LINES WERE TYPED IN`}
              </span>
              {sourcePart && (
                <span className="font-semibold text-emerald-700">
                  PART {sourcePart.part.toUpperCase()} OF {sourcePart.of.toUpperCase()}
                </span>
              )}
              {overCap.length > 0 && (
                <span className="w-full text-red-700">
                  {overCap.map(l => `${l.productName || 'a line'}: ${remainingOf(l.sourceNumber, l.sourceLineId)} ${l.unit || 'units'} left on ${l.sourceNumber}`).join(' · ')}
                  {' '}— reduce the quantity or the server will refuse the save.
                </span>
              )}
              {pendingForParty.length > 0 && (
                <button type="button" onClick={() => setShowPicker(true)} className="btn-xenith-primary ml-auto">
                  <Layers className="w-3.5 h-3.5" />
                  <span>PICK {from.label.toUpperCase()}{pendingForParty.length > 1 ? 'S' : ''} ({pendingForParty.length})</span>
                </button>
              )}
              {pendingForParty.length === 0 && pendingRead && (
                <span className="text-gray-500 ml-auto">
                  No approved {from.label.toLowerCase()} is pending{f.partyId === null ? '' : ` for this ${partyWord}`}.
                </span>
              )}
            </div>
          );
        })()}

        {kind.lines !== 'none' && (
          <div className="flex justify-end flex-wrap gap-2">
            {kind.consolidateCompare && (
              <button type="button" onClick={consolidateAndCompare} className="btn-xenith-primary">
                <span className="font-semibold">⇄</span>
                <span>Consolidate &amp; Compare</span>
              </button>
            )}
            {typedLines && (
              <button type="button" onClick={() => { setShowQuickAdd(true); setQuickMsg(''); }} className="btn-xenith-success">
                <ScanLine className="w-3.5 h-3.5" />
                <span>Quickly Add Products / Scan</span>
              </button>
            )}
          </div>
        )}

        {kind.lines === 'qty' && (
          <div className="border border-gray-200 rounded overflow-hidden">
            <table className="xenith-table">
              <thead>
                <tr>
                  <th className="w-[45%]">Product</th>
                  {perLineWarehouse && <th className="w-[30%]">{kind.warehouseLabel || 'Warehouse'}</th>}
                  <th className="text-right w-[15%]">Quantity</th>
                  <th className="text-center w-[10%]">Action</th>
                </tr>
              </thead>
              <tbody>
                {lines.map(l => (
                  <tr key={l.key}>
                    {productCell(l)}
                    {perLineWarehouse && lineWarehouseCell(l)}
                    <td>
                      <input type="number" min="0" className="input-xenith text-right" placeholder="0"
                        value={num(l.quantity)} onChange={e => patchLine(l.key, { quantity: Number(e.target.value) })} />
                      {linkHint(l)}
                    </td>
                    {lineAction(l.key)}
                  </tr>
                ))}
              </tbody>
            </table>
            {appendRowStrip}
            {perLineWarehouse && (
              <div className="px-3 py-2 bg-gray-50 border-t border-gray-200 text-[11px] text-gray-600 flex flex-wrap gap-x-5 gap-y-1">
                <span>NO OF PRODUCTS: <b className="text-gray-800">{lines.filter(l => l.productId).length}</b></span>
                <span>TOTAL QTY: <b className="text-gray-800">{r2(lines.reduce((s, l) => s + Number(l.quantity), 0))}</b></span>
                <span>WAREHOUSES USED: <b className="text-gray-800">{warehouseSummary || '—'}</b></span>
                {kind.toWarehouse && (
                  <span>MOVING TO: <b className="text-gray-800">{f.toWarehouseName || '—'}</b></span>
                )}
                {needsWarehouse && unplaced > 0 && (
                  <span className="text-red-600 font-semibold">{unplaced} line{unplaced > 1 ? 's' : ''} still need{unplaced > 1 ? '' : 's'} a warehouse</span>
                )}
              </div>
            )}
            {comparison && (
              <div className="border-t border-gray-200">
                <div className="px-3 py-2 bg-gray-50 text-[11px] text-gray-600 flex flex-wrap gap-x-5 gap-y-1">
                  <span className="font-semibold text-gray-700">COUNTED AGAINST SYSTEM STOCK</span>
                  <span>LINES MERGED: <b className="text-gray-800">{comparison.folded}</b></span>
                  <span>AGREEING: <b className="text-emerald-700">{comparison.rows.filter(r => !r.variance).length}</b></span>
                  <span>WITH VARIANCE: <b className="text-red-600">{comparison.rows.filter(r => r.variance).length}</b></span>
                </div>
                <table className="xenith-table">
                  <thead>
                    <tr>
                      <th>Product</th>
                      <th>Warehouse</th>
                      <th className="text-right">Counted</th>
                      <th className="text-right">System</th>
                      <th className="text-right">Variance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparison.rows.map((r, i) => (
                      <tr key={`${r.sku}-${r.warehouseName}-${i}`}>
                        <td className="font-medium text-gray-800">{r.productName} <em className="not-italic text-gray-400">· {r.sku}</em></td>
                        <td className="text-xs text-gray-500">{r.warehouseName}</td>
                        <td className="text-right font-semibold">{r.counted}</td>
                        <td className="text-right">{r.system}</td>
                        <td className={`text-right font-bold ${r.variance === 0 ? 'text-emerald-600' : r.variance > 0 ? 'text-blue-600' : 'text-red-600'}`}>
                          {r.variance > 0 ? `+${r.variance}` : r.variance}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {(kind.lines === 'priced' || kind.lines === 'import') && (
          <div className="border border-gray-200 rounded overflow-hidden">
            <table className="xenith-table">
              <thead>
                <tr>
                  <th className={perLineWarehouse ? (kind.stockColumn ? 'w-[18%]' : 'w-[20%]') : 'w-[26%]'}>Product</th>
                  {perLineWarehouse && <th className="w-[16%]">Warehouse</th>}
                  {kind.stockColumn && (
                    <th className="text-right w-[11%]" title="How much of this product actually stands in the warehouse the line names. A warning only — the bill still saves.">Stock in Warehouse</th>
                  )}
                  <th className="text-right w-[9%]">Quantity</th>
                  <th className="text-right w-[12%]">Price{importing ? ` (${invoiceCurrency})` : ''}</th>
                  <th className={`text-right ${kind.stockColumn ? 'w-[11%]' : 'w-[14%]'}`}>Disc.</th>
                  <th className="text-right w-[12%]">Amount{importing ? ` (${invoiceCurrency})` : ''}</th>
                  {kind.lines === 'import' && (
                    <>
                      <th className="text-right w-[9%]">Share %</th>
                      <th className="text-right w-[11%]" title="Its share of the duties and charges of the consignment, worked out on the paper.">Charges (PKR)</th>
                      <th className="text-right w-[12%]" title="The rupee value of the goods plus the charges pushed onto it.">Landed Value</th>
                      <th className="text-right w-[12%]" title="What one unit of this product actually cost, landed in the warehouse.">Landed / Unit</th>
                    </>
                  )}
                  <th className="text-center w-[8%]">Action</th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={l.key}>
                    {productCell(l)}
                    {perLineWarehouse && lineWarehouseCell(l)}
                    {kind.stockColumn && stockCell(l)}
                    <td>
                      <input type="number" min="0" className="input-xenith text-right" placeholder="0"
                        value={num(l.quantity)} onChange={e => patchLine(l.key, { quantity: Math.max(0, Number(e.target.value) || 0) })} />
                      {linkHint(l)}
                    </td>
                    <td>
                      <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0"
                        value={num(l.price)} onChange={e => patchLine(l.key, { price: Math.max(0, Number(e.target.value) || 0) })} />
                    </td>
                    <td>
                      <div className="flex gap-1">
                        {/* A discount is a share of the line: a negative made the line worth more
                            than its gross and more than 100 made it worth less than nothing, and
                            either figure would be sent and posted as a sum nobody agreed to. */}
                        <input type="number" min="0" max={l.discountType === 'Percent' ? 100 : undefined} step="0.01" className="input-xenith text-right" placeholder="0"
                          value={num(l.discountValue)}
                          onChange={e => patchLine(l.key, {
                            discountValue: Math.max(0,
                              l.discountType === 'Percent' ? Math.min(100, Number(e.target.value) || 0) : (Number(e.target.value) || 0))
                          })} />
                        <button type="button" title="Toggle discount type"
                          onClick={() => patchLine(l.key, { discountType: l.discountType === 'Percent' ? 'Amount' : 'Percent' })}
                          className="input-xenith !w-10 flex items-center justify-center gap-0.5 text-gray-500">
                          <span>{l.discountType === 'Percent' ? '%' : '₨'}</span>
                          <ChevronDown className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </td>
                    <td className="text-right font-bold text-gray-800">{money(perLine[i].amount)}</td>
                    {kind.lines === 'import' && (
                      <>
                        <td>
                          <input type="number" step="0.01" className="input-xenith text-right" placeholder="0"
                            value={num(l.percentage)} onChange={e => patchLine(l.key, { percentage: Number(e.target.value) })} />
                        </td>
                        {/* The charges on a line are its share of the consignment's duties and
                            charges, not a figure to be typed — the paper works them out. */}
                        <td className="text-right text-gray-700 tabular-nums">{money(landed?.byKey.get(l.key)?.charges ?? 0)}</td>
                        <td className="text-right font-bold text-gray-800 tabular-nums">{money(landed?.byKey.get(l.key)?.landedAmount ?? 0)}</td>
                        <td className="text-right text-gray-700 tabular-nums">{money(landed?.byKey.get(l.key)?.perUnit ?? 0)}</td>
                      </>
                    )}
                    {lineAction(l.key)}
                  </tr>
                ))}
              </tbody>
            </table>
            {appendRowStrip}
            {kind.lines === 'import' && (
              <div className="flex flex-wrap gap-x-6 gap-y-1 px-3 py-2 bg-gray-50 border-t border-gray-200 text-[11px] text-gray-600">
                <span>NO OF PRODUCTS: <b className="text-gray-800">{lines.filter(l => l.productId).length}</b></span>
                {/* Shares that do not add to the whole leave a part of the charges with no
                    line to sit on, and the paper says so instead of hiding it. */}
                <span>TOTAL SHARE:{' '}
                  <b className={Math.abs((landed?.shareTotal ?? 0) - 100) < 0.01 ? 'text-gray-800' : 'text-red-600'}>
                    {(landed?.shareTotal ?? 0).toFixed(2)}%
                  </b>
                  {sharesByValue && <span className="text-gray-500"> (unset — divided by the value of each line)</span>}
                </span>
                <span>TOTAL VALUE: <b className="text-gray-800">{money(totals.gross)} {invoiceCurrency}</b></span>
                <span>TOTAL BASE VALUE: <b className="text-gray-800">{money(landed?.goodsPkr ?? 0)} PKR</b></span>
                <span>TOTAL LANDED VALUE: <b className="text-gray-800">{money(landed?.landedTotal ?? 0)} PKR</b></span>
                <span>LANDED COST PER UNIT: <b className="text-gray-800">{money(landed?.perUnit ?? 0)} PKR</b></span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* What has already been cut out of this paper */}
      {chain && (chain.parts.length > 0 || chain.lines.length > 0) && (
        <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <h3 className="text-xs font-bold text-gray-700">
              ALREADY CUT OUT OF THIS {printLabelOf(kind)}
            </h3>
            <span className="text-[11px] text-gray-500">
              {chain.parts.length
                ? `${chain.parts.length} part${chain.parts.length > 1 ? 's' : ''} — ${chain.parts.map(p => `${p.part} (${p.number})`).join(', ')}`
                : 'Nothing has been taken from it yet.'}
            </span>
          </div>

          {chain.parts.length > 0 && (
            <div className="border border-gray-200 rounded overflow-y-auto max-h-56">
              <table className="xenith-table">
                <thead>
                  <tr>
                    <th className="w-[6%]">Part</th>
                    <th className="w-[18%]">Document</th>
                    <th className="w-[12%]">Date</th>
                    <th className="w-[14%]">Status</th>
                    <th>Lines</th>
                    <th className="w-[16%]">Warehouse</th>
                    <th className="w-[14%]">Approved By</th>
                  </tr>
                </thead>
                <tbody>
                  {chain.parts.map(p => (
                    <tr key={`${p.resource}-${p.id}`}>
                      <td className="font-bold text-blue-700">{p.part}</td>
                      <td className="font-medium text-gray-800">{p.number}</td>
                      <td>{p.date}</td>
                      <td>
                        <span className={p.status === 'Approved' ? 'text-emerald-700 font-semibold'
                          : p.status === 'Void' ? 'text-red-600 line-through' : 'text-amber-600 font-semibold'}>
                          {p.status}
                        </span>
                      </td>
                      <td>{p.summary || p.lines.map(l => `${l.quantity} ${l.unit}`).join(' + ')}</td>
                      <td className="text-gray-500">{p.warehouseName || '—'}</td>
                      <td className="text-gray-500">{p.approvedByName || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {chain.lines.length > 0 && (
            <div className="border border-gray-200 rounded overflow-hidden">
              <table className="xenith-table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th className="text-right w-[14%]">On This Paper</th>
                    <th className="text-right w-[14%]">Already Out</th>
                    <th className="text-right w-[14%]">Still Left</th>
                  </tr>
                </thead>
                <tbody>
                  {chain.lines.map(l => (
                    <tr key={l.id}>
                      <td className="font-medium text-gray-800">
                        {l.productName} <em className="not-italic text-gray-400">· {l.sku}</em>
                      </td>
                      <td className="text-right">{money(l.qty)} {l.unit}</td>
                      <td className="text-right text-emerald-700">{money(l.taken)} {l.unit}</td>
                      <td className={`text-right font-semibold ${l.remaining > 0.001 ? 'text-amber-600' : 'text-gray-400'}`}>
                        {money(l.remaining)} {l.unit}{l.remaining <= 0.001 ? ' · complete' : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Shipping address + comments */}
      <div className={`grid gap-4 ${kind.shippingAddress ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        {kind.shippingAddress && (
          <div className="bg-white rounded border border-gray-200 p-4">
            <Field label="Shipping Address">
              <Area rows={4} placeholder="Shipping address" value={f.shippingAddress}
                onChange={e => set({ shippingAddress: e.target.value })} />
            </Field>
          </div>
        )}
        <div className="bg-white rounded border border-gray-200 p-4 space-y-4">
          <Area rows={kind.shippingAddress ? 4 : 3} placeholder="Comments" value={f.comments}
            onChange={e => set({ comments: e.target.value })} />
          <AttachmentBox items={f.attachments} onChange={attachments => set({ attachments })} />
        </div>
      </div>

      {/* Payment lines (receive payment / refund) */}
      {kind.paymentLinesMode && (
        <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
          <table className="xenith-table">
            <thead>
              <tr>
                <th className="w-[16%]">Payment Mode</th>
                <th className="w-[20%]">Account</th>
                {kind.paymentLinesMode === 'refund'
                  ? <th className="w-[22%]">Document No.</th>
                  : <th className="w-[16%]">Reference</th>}
                {bankColumns && <th className="w-[16%]">Bank Name</th>}
                {bankColumns && <th className="w-[14%]">Instrument No.</th>}
                {bankColumns && <th className="w-[12%]">Instrument Date</th>}
                <th className="text-right w-[12%]">Amount</th>
                <th className="text-center w-[8%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {f.paymentLines.map(p => {
                const cashLine = isCashMode(p.paymentMode);
                const byInstrument = instrumentBased(p.paymentMode);
                return (
                  <tr key={p.id}>
                    <td>
                      <Pick value={p.paymentMode} onChange={e => onTenderMode(p, e.target.value)}>
                        {tenderModes.map(m => <option key={m} value={m}>{m}</option>)}
                      </Pick>
                    </td>
                    <td>
                      {cashLine ? (
                        <input type="text" readOnly className="input-xenith bg-gray-50" value="Cash in Hand" />
                      ) : (
                        <Pick value={p.accountId === null || p.accountId === CASH_ID ? '' : String(p.accountId)}
                          onChange={e => {
                            const b = bankAccount(e.target.value === '' ? null : Number(e.target.value));
                            patchPayment(p.id, {
                              accountId: b?.id ?? null, accountName: b?.accountTitle ?? '', bankName: b?.bankName ?? p.bankName
                            });
                          }}>
                          <option value="">-Choose-</option>
                          {banks.map(b => <option key={b.id} value={b.id}>{b.accountTitle}</option>)}
                        </Pick>
                      )}
                    </td>
                    {kind.paymentLinesMode === 'refund' ? (
                      <td><Text placeholder="Document No." value={p.documentNumber} onChange={e => patchPayment(p.id, { documentNumber: e.target.value })} /></td>
                    ) : (
                      <td><Text placeholder="Reference" value={p.reference} onChange={e => patchPayment(p.id, { reference: e.target.value })} /></td>
                    )}
                    {bankColumns && (
                      <td>
                        {bankAccount(p.accountId)?.bankName || (
                          <Text placeholder="Bank" disabled={!byInstrument} value={p.bankName} onChange={e => patchPayment(p.id, { bankName: e.target.value })} />
                        )}
                      </td>
                    )}
                    {bankColumns && <td><Text placeholder="Instrument No." disabled={!byInstrument} value={p.instrumentNumber} onChange={e => patchPayment(p.id, { instrumentNumber: e.target.value })} /></td>}
                    {bankColumns && <td><input type="date" disabled={!byInstrument} className="input-xenith" value={p.instrumentDate} onChange={e => patchPayment(p.id, { instrumentDate: e.target.value })} /></td>}
                    <td><input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0" value={num(p.amount)} onChange={e => patchPayment(p.id, { amount: Number(e.target.value) })} /></td>
                    <td className="text-center whitespace-nowrap">
                      <button type="button" title="Delete line"
                        onClick={() => set({ paymentLines: f.paymentLines.length === 1 ? [newTender()] : f.paymentLines.filter(x => x.id !== p.id) })}
                        className="text-gray-400 hover:text-red-600 px-1"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {appendRow('ADD PAYMENT LINE', () => set({ paymentLines: [...f.paymentLines, newTender()] }))}
          {kind.accountAdjustments && (
            <Chk checked={f.accountAdjustments} onChange={v => set({ accountAdjustments: v })}
              label="Account Adjustments (Optional) (e.g. WHT, Rebate, etc)" />
          )}
          <div className="max-w-sm">
            <Field label="Total Amount (PKR)">
              <input type="text" readOnly className="input-xenith text-right bg-gray-50 font-bold" value={money(totals.payments)} />
            </Field>
          </div>
        </div>
      )}

      {/* The declaration the container cleared on, and every duty that assessment raised */}
      {importing && landed && (
        <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <h3 className="text-xs font-bold text-gray-700">CUSTOMS DECLARATION &amp; LANDED COST</h3>
            <span className="text-[11px] text-gray-500">
              The goods are billed in {invoiceCurrency}; the books below run in PKR at the rate written here.
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <Field label="Currency" required>
              <Pick value={f.customs.currency}
                onChange={e => setCustoms({ currency: e.target.value, rate: e.target.value === 'PKR' ? 1 : f.customs.rate })}>
                {IMPORT_CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
              </Pick>
            </Field>
            <Field label={`Rate (PKR per ${f.customs.currency})`}>
              <input type="number" min="0" step="0.0001" className="input-xenith text-right disabled:bg-gray-50"
                placeholder="1" disabled={f.customs.currency === 'PKR'}
                value={num(f.customs.rate)} onChange={e => setCustoms({ rate: Number(e.target.value) })} />
            </Field>
            <Field label="Clearing Agent"><Text placeholder="Clearing agent" value={f.customs.agentName}
              onChange={e => setCustoms({ agentName: e.target.value })} /></Field>
            <Field label="CD Number"><Text placeholder="Customs declaration no." value={f.customs.cdNumber}
              onChange={e => setCustoms({ cdNumber: e.target.value })} /></Field>
            <Field label="CD Date"><input type="date" className="input-xenith" value={f.customs.cdDate}
              onChange={e => setCustoms({ cdDate: e.target.value })} /></Field>
            <Field label="LC / TT Number"><Text placeholder="Letter of credit" value={f.customs.lcNumber}
              onChange={e => setCustoms({ lcNumber: e.target.value })} /></Field>
            <Field label="Bill of Lading / AWB"><Text placeholder="B/L or airway bill" value={f.customs.blNumber}
              onChange={e => setCustoms({ blNumber: e.target.value })} /></Field>
            <Field label="Port of Discharge"><Text placeholder="Cleared at" value={f.customs.portOfDischarge}
              onChange={e => setCustoms({ portOfDischarge: e.target.value })} /></Field>
            <Field label="Country of Origin"><Text placeholder="Made in" value={f.customs.countryOfOrigin}
              onChange={e => setCustoms({ countryOfOrigin: e.target.value })} /></Field>
          </div>

          {/* The assessment is the goods in rupees with freight and insurance added to them,
              and every duty is a rate on that value — read from the same arithmetic that
              prices the lines below. */}
          <div className="flex flex-wrap gap-x-6 gap-y-1 rounded bg-gray-50 border border-gray-200 px-3 py-2 text-[11px] text-gray-600">
            <span>Goods Value: <b className="text-gray-800">{money(landed.goodsPkr)} PKR</b></span>
            <span>+ Freight: <b className="text-gray-800">{money(landed.freight)} PKR</b></span>
            <span>+ Insurance: <b className="text-gray-800">{money(landed.insurance)} PKR</b></span>
            <span>Assessable Value: <b className="text-gray-900">{money(landed.assessable)} PKR</b></span>
            <span>Duties into cost: <b className="text-gray-800">{money(landed.dutyInCost)} PKR</b></span>
            <span>Duties claimable back: <b className="text-gray-800">{money(landed.dutyRecoverable)} PKR</b></span>
          </div>

          <datalist id="duty-heads">{STANDARD_DUTIES.map(d => <option key={d.head} value={d.head} />)}</datalist>
          <table className="xenith-table">
            <thead>
              <tr>
                <th className="w-[18%]">Duty Head</th>
                <th className="text-right w-[7%]">Rate %</th>
                <th className="text-right w-[11%]">Amount (PKR)</th>
                <th className="w-[11%]">Treatment</th>
                <th className="w-[17%]">Booked To</th>
                <th className="w-[12%]">Challan No.</th>
                <th className="w-[9%]">Paid Via</th>
                <th className="w-[14%]">Paid From</th>
                <th className="text-center w-[6%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {f.customs.duties.map((x, i) => (
                <tr key={x.id}>
                  <td><Text placeholder="Duty head" list="duty-heads" value={x.head}
                    onChange={e => patchDuty(x.id, { head: e.target.value })} /></td>
                  <td><input type="number" step="0.01" className="input-xenith text-right" placeholder="0"
                    value={num(x.rate)} onChange={e => patchDuty(x.id, { rate: Number(e.target.value) })} /></td>
                  <td className="text-right font-bold text-gray-800 tabular-nums">{money(landed.duties[i]?.amount ?? 0)}</td>
                  <td>
                    <Pick value={x.treatment} onChange={e => patchDuty(x.id, { treatment: e.target.value as ImportDuty['treatment'] })}>
                      <option value="In cost">In cost</option>
                      <option value="Recoverable">Recoverable</option>
                    </Pick>
                  </td>
                  <td><HeadPick heads={dutyHeads} id={x.accountId} name={x.accountName}
                    onPick={(id, name) => patchDuty(x.id, { accountId: id, accountName: name })} /></td>
                  <td><Text placeholder="Challan / TRN" value={x.challan}
                    onChange={e => patchDuty(x.id, { challan: e.target.value })} /></td>
                  <td>
                    <Pick value={x.paidVia ?? 'Unsettled'} onChange={e => onDutyVia(x.id, e.target.value)}>
                      {PAID_VIA.map(v => <option key={v} value={v}>{v}</option>)}
                    </Pick>
                  </td>
                  <td>{x.paidVia === 'Bank' ? (
                    <HeadPick heads={bankHeads} id={x.paidAccountId} name={x.paidAccountName}
                      onPick={(id, name) => patchDuty(x.id, { paidAccountId: id, paidAccountName: name })} />
                  ) : x.paidVia === 'Cash' ? (
                    <div className="text-[11px] text-gray-600 pt-1.5">Cash in Hand</div>
                  ) : <span className="text-[11px] text-gray-400">— not paid yet —</span>}</td>
                  <td className="text-center">
                    <button type="button" title="Take this duty off the declaration"
                      onClick={() => setCustoms({ duties: f.customs.duties.filter(y => y.id !== x.id) })}
                      className="text-gray-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex flex-wrap items-center gap-3">
            <button type="button" className="btn-xenith-outline !px-2"
              onClick={() => setCustoms({ duties: [...f.customs.duties, blankDuty()] })}>
              <Plus className="w-3.5 h-3.5" /><span>ADD DUTY LINE</span>
            </button>
            <button type="button" className="btn-xenith-outline !px-2" title="Put the five heads a Pakistani assessment raises back on the paper"
              onClick={() => setCustoms({ duties: standardDuties() })}>
              <Layers className="w-3.5 h-3.5" /><span>RESET TO STANDARD DUTIES</span>
            </button>
          </div>
          <p className="text-[11px] text-gray-500 leading-relaxed">
            A duty marked <b>In cost</b> rides onto the cost of the goods{f.expenseMethod === 'Method 1' ? '' : ' only under Method 1'}; a
            duty marked <b>Recoverable</b> is an advance the books claim back, so it never files a payment voucher — its challan
            prints on the invoice and a Journal Entries paper moves the money against it.{' '}
            {(landed.dutyUnsettled > 0 || landed.chargesUnsettled > 0) && (
              <span className="text-amber-600 font-semibold">
                {money(landed.chargesUnsettled + landed.dutyUnsettled)} PKR of this consignment is still marked unsettled and will file no voucher.
              </span>
            )}
          </p>
        </div>
      )}

      {/* The documents the consignment was cleared with: every charge, the head it belongs
          to, and whether it had been paid when the invoice was approved */}
      {kind.expenseBlock && (
        <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Charges of the Consignment" className="w-72">
              {/* The method decides what the stock is worth, so it is chosen before the paper is
                  approved and not after: the server refuses the change once the lines have been
                  costed and the goods sold out of them. */}
              <Pick value={f.expenseMethod} disabled={methodLocked}
                onChange={e => set({ expenseMethod: e.target.value })}>
                <option value="Method 1">Method 1 — into the cost of the goods</option>
                <option value="Method 2">Method 2 — left on their own heads</option>
              </Pick>
            </Field>
            {methodLocked && (
              <span className="text-[11px] text-gray-500 pb-2">
                Approved paper — its lines are already costed, so the method is fixed.
              </span>
            )}
            <span className="ml-auto text-xs text-gray-600">Total Expense Cost: <b className="text-gray-900">{money(totals.totalExpenses)} PKR</b></span>
          </div>
          <p className="text-[11px] text-gray-500">
            {f.expenseMethod === 'Method 1'
              ? 'Method 1 — the duties and every charge here are pushed onto the goods, so each product line carries its share as landed cost.'
              : 'Method 2 — the duties and charges stay on their own heads: each product keeps its invoice value, and the landed cost below is the goods alone.'}
          </p>
          {/* Who the charge is paid to. A carrier, a port trust or an agent is usually not a
              vendor of the firm, so the name is typed and the registers already on the book
              are offered below it — never a list a real payee would be missing from. */}
          <datalist id="charge-contacts">
            {parties.map(p => <option key={`p${p.id}`} value={p.name} />)}
            {accounts.map(a => <option key={`c${a.id}`} value={a.name} />)}
          </datalist>
          <table className="xenith-table">
            <thead>
              <tr>
                <th className="w-[18%]">Account</th>
                <th className="w-[20%]">Description</th>
                <th className="w-[14%]">Contact</th>
                <th className="text-right w-[10%]">Amount (PKR)</th>
                <th className="w-[10%]">Paid Via</th>
                <th className="w-[16%]">Paid From</th>
                <th className="text-center w-[12%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {f.expenses.map(e => (
                <tr key={e.id}>
                  <td><HeadPick heads={expenseHeads} id={e.accountId ?? null} name={e.accountName}
                    onPick={(id, name) => patchExpense(e.id, { accountId: id, accountName: name })} /></td>
                  <td><Text placeholder="Description" value={e.description}
                    onChange={ev => patchExpense(e.id, { description: ev.target.value })} /></td>
                  <td><Text placeholder="Paid to" list="charge-contacts" value={e.contact}
                    onChange={ev => patchExpense(e.id, { contact: ev.target.value })} /></td>
                  <td><input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0" value={num(e.amount)}
                    onChange={ev => patchExpense(e.id, { amount: Number(ev.target.value) })} /></td>
                  <td>
                    <Pick value={e.paidVia ?? 'Unsettled'} onChange={ev => onChargeVia(e.id, ev.target.value)}>
                      {PAID_VIA.map(v => <option key={v} value={v}>{v}</option>)}
                    </Pick>
                  </td>
                  <td>{e.paidVia === 'Bank' ? (
                    <HeadPick heads={bankHeads} id={e.paidAccountId ?? null} name={e.paidAccountName ?? ''}
                      onPick={(id, name) => patchExpense(e.id, { paidAccountId: id, paidAccountName: name })} />
                  ) : e.paidVia === 'Cash' ? (
                    <div className="text-[11px] text-gray-600 pt-1.5">Cash in Hand</div>
                  ) : <span className="text-[11px] text-gray-400">— not paid yet —</span>}</td>
                  <td className="text-center whitespace-nowrap">
                    <button type="button" title="Take this charge off the paper"
                      onClick={() => set({ expenses: f.expenses.length === 1 ? [blankExpense()] : f.expenses.filter(x => x.id !== e.id) })}
                      className="text-gray-400 hover:text-red-600 px-1"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {appendRow('ADD CHARGE LINE', () => set({ expenses: [...f.expenses, blankExpense()] }))}
        </div>
      )}

      {/* Auto settlements */}
      {kind.autoSettlements && (
        <div className="bg-white rounded border border-gray-200 p-4 space-y-3">
          <Chk checked={f.autoSettlements} onChange={v => set({ autoSettlements: v })} label="Make auto settlements" />
          <AllocationTable title={settlementTitles(kind.party).open} rows={f.autoSettlements ? receivables : []}
            empty={f.autoSettlements
              ? `Nothing open against ${parties.find(p => p.id === f.partyId)?.name || 'this party'} — there is no paper here for this payment to settle.`
              : 'Auto settlements are off. Tick the box above to list the open papers against this party.'}
            selected={f.allocations} onAllocate={(id, v) => patchAllocation('allocations', id, v)} />
        </div>
      )}

      {/* Totals */}
      {(kind.totals || kind.paymentBoxLabel) && (
        <div className="bg-white rounded border border-gray-200 p-4">
          {kind.amountFrom === 'lines' && (<>
          <TotalRow label={importing ? `Gross Value of the Goods (${invoiceCurrency})` : 'Gross'}>{money(totals.gross)}</TotalRow>
          {!importing && (<>
          <TotalRow label="Discount">
            <div className="flex gap-1">
              <div className="relative flex-1">
                <input type="number" min="0" step="0.01" className="input-xenith text-right pr-6" placeholder="0"
                  value={num(f.discountPercent)} onChange={e => onDiscountPercent(Number(e.target.value))} />
                <span className="absolute right-2 top-1.5 text-[10px] text-gray-400">%</span>
              </div>
              <input type="number" min="0" step="0.01" className="input-xenith text-right flex-1" placeholder="0"
                  value={num(f.discount)} onChange={e => onDiscountAmount(Number(e.target.value))} />
            </div>
          </TotalRow>
          <TotalRow label="Tax">
            <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0.00"
              value={num(f.tax)} onChange={e => set({ tax: r2(Math.max(0, Number(e.target.value) || 0)) })} />
          </TotalRow>
          <TotalRow label="Shipping Charges">
            <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0"
              value={num(f.shippingCharges)} onChange={e => set({ shippingCharges: r2(Math.max(0, Number(e.target.value) || 0)) })} />
          </TotalRow>
          <TotalRow label="Round Off">
            <div className="flex gap-1">
              <input type="number" step="0.01" className="input-xenith text-right" placeholder="0"
                value={num(f.roundOff)} onChange={e => set({ roundOff: r2(Number(e.target.value) || 0) })} />
              {/* The button rounds the bill before its own rounding, so pressing it again — or
                  twice in quick succession — settles on the same rupee instead of reading the
                  rounded total back and cancelling the first press out. */}
              <button type="button" title="Auto round to nearest rupee" className="btn-xenith-outline !px-2"
                onClick={() => set({ roundOff: r2(Math.round(totals.beforeRound) - totals.beforeRound) })}>
                <span>≈</span>
              </button>
            </div>
          </TotalRow>
          </>)}
          </>)}
          {/* A consignment has no room for these four. Each of them would move what the vendor is
              owed without moving the goods, the assessment or the landed cost one step behind it,
              and the bill would then owe a sum its own declaration cannot account for. What the
              container cost beyond its goods is already written where it belongs: the agent's fee
              and the freight on the charges table, the duty on the declaration, and the discount
              a trader gives on the line it was given on. */}
          {importing && (
            <p className="text-[11px] leading-relaxed text-gray-500">
              The vendor is owed the goods at the rate on the declaration — nothing is added to that
              here. Discount belongs on the line it was given on, freight, insurance and the agent's
              fee on the charges below, and every duty on the declaration; each of those files its
              own voucher.
            </p>
          )}
          {kind.expenseBlock && <TotalRow label="Total Expenses">{money(totals.totalExpenses)}</TotalRow>}
          {/* The landed cost in the same order the server works it out, so the figure on the
              totals card is the figure the register holds after the save. */}
          {landed && (<>
            <TotalRow label={`Goods Value (PKR · ${money(landed.rate)} per ${landed.currency})`}>{money(landed.goodsPkr)}</TotalRow>
            <TotalRow label="Assessable Value">{money(landed.assessable)}</TotalRow>
            <TotalRow label="Duties into cost">{money(landed.dutyInCost)}</TotalRow>
            <TotalRow label="Duties claimable back">{money(landed.dutyRecoverable)}</TotalRow>
            <TotalRow label="Landed Cost (PKR)">{money(landed.landedTotal)}</TotalRow>
            <TotalRow label="Landed per Unit">{money(landed.perUnit)}</TotalRow>
          </>)}
          {/* A voucher's net is the amount typed below it, so the card does not say it twice. */}
          {kind.amountFrom !== 'box' && (<>
            <div className="border-t border-gray-200 my-2"></div>
            <TotalRow label="">
              <div className="text-right card-title">
                {importing ? `Amount Payable to the Vendor (PKR) ${money(totals.net)}` : `Net (PKR) ${money(totals.net)}`}
              </div>
            </TotalRow>
          </>)}

          {kind.paymentBoxLabel && (
            <div className="mt-3 space-y-2">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <Field label="Payment Mode" required>
                  {/* The register decides the pocket: a cash voucher has no bank answer. */}
                  {kind.voucherChannel ? (
                    <input type="text" readOnly className="input-xenith bg-gray-50" value={kind.voucherChannel} />
                  ) : (
                    <Pick value={channel} onChange={e => onChannel(e.target.value as Channel)}>
                      {PAYMENT_CHANNELS.map(c => <option key={c} value={c}>{c}</option>)}
                    </Pick>
                  )}
                </Field>
                {channel !== 'Cash' && (
                  <Field label="Bank Account" required>
                    <Pick value={f.accountId === null || f.accountId === CASH_ID ? '' : String(f.accountId)}
                      onChange={e => set({
                        accountId: e.target.value === '' ? null : Number(e.target.value),
                        accountName: e.target.value === '' ? '' : (bankAccount(Number(e.target.value))?.accountTitle ?? '')
                      })}>
                      <option value="">-Choose-</option>
                      {banks.map(b => <option key={b.id} value={b.id}>{b.accountTitle}</option>)}
                    </Pick>
                  </Field>
                )}
                <Field label="Reference">
                  <Text placeholder="Reference" value={f.accountReference}
                    onChange={e => set({ accountReference: e.target.value })} />
                </Field>
              </div>
              {channel !== 'Cash' && (
                <p className="text-[11px] text-gray-500">
                  {selectedBank
                    ? [selectedBank.bankName, selectedBank.branchCode && `Branch Code ${selectedBank.branchCode}`,
                      selectedBank.accountNumber && `A/C ${selectedBank.accountNumber}`,
                      selectedBank.iban && `IBAN ${selectedBank.iban}`].filter(Boolean).join(' · ')
                    : 'Select the bank account that receives this amount.'}
                </p>
              )}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {channel !== 'Bank' && (
                  <Field label={channel === 'Combine' ? `${kind.paymentBoxLabel} in Cash (PKR)` : `${kind.paymentBoxLabel} (PKR)`}>
                    <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0"
                      value={num(boxCash)} onChange={e => setBox(Number(e.target.value), channel === 'Combine' ? boxBank : 0)} />
                  </Field>
                )}
                {channel !== 'Cash' && (
                  <Field label={channel === 'Combine' ? `${kind.paymentBoxLabel} in Bank (PKR)` : `${kind.paymentBoxLabel} (PKR)`}>
                    <input type="number" min="0" step="0.01" className="input-xenith text-right" placeholder="0"
                      disabled={f.accountId === null || f.accountId === CASH_ID} value={num(boxBank)}
                      onChange={e => setBox(channel === 'Combine' ? boxCash : 0, Number(e.target.value))} />
                  </Field>
                )}
              </div>
              {channel === 'Combine' && (
                <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded px-3 py-1.5">
                  <span className="text-xs text-gray-600">Total {kind.paymentBoxLabel.toLowerCase()} (PKR)</span>
                  <span className="text-xs font-bold text-gray-900">{money(r2(boxCash + boxBank))}</span>
                </div>
              )}
            </div>
          )}

          {kind.amountFrom !== 'box' && (
            <div className="border-t border-gray-200 mt-3 pt-2 flex items-center justify-between">
              <span className="text-xs text-gray-600">Balance (PKR)</span>
              <span className={`font-bold text-sm ${totals.balance > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                {money(totals.balance)}
              </span>
            </div>
          )}
        </div>
      )}

      <div className="flex justify-end items-start gap-2">
        <div className="mr-auto self-center text-[11px] text-red-500 space-y-0.5 text-right">
          {!validParty && <div>{headAsParty ? 'Choose the account head the money crossed' : `${kind.partyLabel} selection is required`}</div>}
          {!pocketOk && <div>Choose the bank account the money moves through</div>}
          {!amountOk && <div>Enter the amount, a voucher for nothing posts nothing</div>}
          {!destinationOk && <div>Choose the warehouse the stock is moving into</div>}
          {!typeOk && <div>Choose an adjustment type, it decides which way stock moves</div>}
          {needsWarehouse && unplaced > 0 && <div>{unplaced} line(s) still need a warehouse</div>}
          {linkMissing && <div>Nothing is linked to a {pickFrom?.label.toLowerCase()} yet — pick it so the quantities are known</div>}
          {overCap.length > 0 && <div>{overCap.length} line(s) ask for more than the linked paper still holds</div>}
        </div>
        {/* The size the template in Settings was saved with is the size the paper prints on;
            this box only ever overrides it for the print in front of it. An 80 mm counter slip
            is not offered here because none of these sheets is written to fit one — a bill with
            a declaration on it needs a page, and the roll belongs to the counter's own receipt. */}
        <select className="input-xenith !w-44 self-center" value={paper} onChange={e => setPaper(e.target.value as Paper | '')}
          title="Paper for this print — left on the template's own size unless you choose here">
          <option value="">Paper: as the template</option>
          <option value="A4">Paper: A4 sheet</option>
          <option value="A5">Paper: A5 half page</option>
        </select>
        <button type="button" onClick={printNow} disabled={!canSave} className="btn-xenith-outline"
          title="Print this document or save it as a PDF, in the template set for it under Settings">
          <Printer className="w-3.5 h-3.5" />
          <span>PRINT / SAVE PDF</span>
        </button>
        {kind.gateSheet && (
          <button type="button" onClick={printGatePass} disabled={!canSave} className="btn-xenith-outline"
            title="Print or save the gate pass — the quantities the customer carries out and the gate checks against the store">
            <Printer className="w-3.5 h-3.5" />
            <span>GATE PASS / CHALLAN</span>
          </button>
        )}
        <FormFooter onSave={doSave} onClose={onDone} saving={saving}
          disabled={!canSave} statusOptions={[
            { label: 'Save as Draft', value: 'Draft' },
            { label: 'Save as Pending', value: 'Pending' },
            // An administrator approves a salesperson's paper, so the choice is theirs.
            ...(needsApproval ? [] : [{ label: 'Save and Approve', value: 'Approved' }])
          ]} />
      </div>


      {showPicker && kind.picksFrom && (
        <SourcePicker
          label={kind.picksFrom.label} takenWord={kind.picksFrom.takenWord} partyWord={partyWord}
          sources={pendingForParty} partyId={f.partyId} currency={currency}
          onPick={applyPick}
          onClose={() => setShowPicker(false)}
        />
      )}

      {showQuickAdd && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-lg border border-gray-200 text-xs">
            <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center font-bold text-gray-800">
              <span>Quickly Add Products / Scan</span>
              <button onClick={() => setShowQuickAdd(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className="p-4 space-y-2">
              <p className="text-gray-600">Enter SKU, barcode, product code or name to search.</p>
              <input autoFocus className="input-xenith !rounded-none !border-0 !border-b-2 !border-[#2ec4b6] focus:!ring-0"
                placeholder="Start typing or scan..."
                value={quickText} onChange={e => setQuickText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); quickAdd(); } }} />
              {quickCandidates.length > 0 && (
                <div className="border border-gray-200 rounded divide-y divide-gray-100 max-h-44 overflow-y-auto">
                  {quickCandidates.map(c => (
                    <button type="button" key={c.id}
                      onClick={() => { setLines(ls => placeProduct(c, ls)); setQuickText(''); setQuickMsg(`Added: ${c.name}`); }}
                      className="w-full flex items-center justify-between gap-3 px-2.5 py-1.5 hover:bg-emerald-50 text-left">
                      <span className="truncate">
                        <b className="text-gray-800">{c.name}</b>
                        <em className="not-italic text-gray-400"> · {c.sku}</em>
                      </span>
                      <span className="text-gray-500 whitespace-nowrap">{money(priceOf(c))} / {c.unit}</span>
                    </button>
                  ))}
                </div>
              )}
              <p className="text-gray-400">Please scan barcode.</p>
              <p className="text-gray-400">Please type product SKU, product code or product name and press enter.</p>
              {quickMsg && (
                <p className={`font-semibold ${quickMsg.startsWith('Added') ? 'text-emerald-600' : 'text-red-600'}`}>{quickMsg}</p>
              )}
            </div>
            <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between gap-2">
              <span className="text-[11px] text-gray-500">{lines.filter(l => l.productId).length} product line(s) on this document</span>
              <div className="flex gap-2">
                <button onClick={() => { quickAdd(); setShowQuickAdd(false); }} className="btn-xenith-success">Add Matched Products</button>
                <button onClick={() => setShowQuickAdd(false)} className="btn-xenith-outline">Done</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
    </>
  );
};

const TotalRow: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="flex items-center justify-between gap-3 py-1">
    <span className="text-xs text-gray-600">{label}</span>
    {/* A typed field reaches the right edge of the card, so a figure that is only shown has to
        stand under it — otherwise "Gross" sits a hand's width left of the boxes below it. */}
    <div className="flex-1 max-w-[240px] text-right">{children}</div>
  </div>
);

// True when nothing on the paper has anything left to take.
const fullyTaken = (s: PendingSource) => s.lines.every(l => l.remaining <= 0.001);

// The waiting paper, line by line: what the bill held, what has already been dispatched out
// of it, and what is left to take. Every box starts ticked at the remaining quantity, so a
// full pick is one click and a half pick is a few unticks.
//
// One document carries one customer, so when the form has not chosen a party yet the picker
// locks onto the first paper's — another party's bill stays off the list rather than being
// picked onto a bill the server would refuse.
const SourcePicker: React.FC<{
  label: string;
  takenWord: string;
  partyWord: string;
  sources: PendingSource[];
  partyId: number | null;
  currency: string;
  onPick: (src: PendingSource, lineIds: number[]) => void;
  onClose: () => void;
}> = ({ label, takenWord, partyWord, sources, partyId, currency, onPick, onClose }) => {
  const lock = partyId ?? sources[0]?.partyId ?? null;
  const mine = sources.filter(s => lock === null || s.partyId === lock);
  const held = sources.length - mine.length;
  // A Good Receiving counts goods and never money, so its lines carry no rate: printing a
  // column of 0.00 over a bill would read as the price rather than as the absence of one.
  const rates = sources.some(s => s.lines.some(l => Number(l.price) > 0));
  const [sel, setSel] = useState<Record<number, number[]>>(() => Object.fromEntries(
    mine.map(s => [s.id, s.lines.filter(l => l.remaining > 0.001).map(l => l.id)])));
  const idsOf = (id: number) => sel[id] || [];
  const toggle = (id: number, lineId: number) => setSel(m => {
    const cur = m[id] || [];
    return { ...m, [id]: cur.includes(lineId) ? cur.filter(x => x !== lineId) : [...cur, lineId] };
  });
  const toggleAll = (s: PendingSource) => setSel(m => ({
    ...m, [s.id]: (m[s.id] || []).length ? [] : s.lines.filter(l => l.remaining > 0.001).map(l => l.id)
  }));
  const linesFor = (s: PendingSource) => s.lines.filter(l => idsOf(s.id).includes(l.id));
  const pickedLines = mine.reduce((n, s) => n + idsOf(s.id).length, 0);
  const pickedValue = mine.reduce((v, s) =>
    v + linesFor(s).reduce((x, l) => x + l.remaining * l.price, 0), 0);
  const applyAll = () => {
    mine.forEach(s => { if (idsOf(s.id).length) onPick(s, idsOf(s.id)); });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl border border-gray-200 text-xs max-h-[88vh] overflow-y-auto">
        <div className="sticky top-0 z-10 px-4 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center gap-3">
          <span className="font-bold text-gray-800 uppercase">Pick {label}s — tick what this document should take</span>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>

        <div className="p-4 space-y-3">
          {held > 0 && (
            <p className="text-[11px] text-gray-500">
              {held} waiting {label.toLowerCase()}{held > 1 ? 's belong' : ' belongs'} to another {partyWord} — one
              document bills one {partyWord}, so change the {partyWord} above to pick from those instead.
            </p>
          )}
          {mine.map(s => {
            const picked = linesFor(s);
            const value = picked.reduce((x, l) => x + l.remaining * l.price, 0);
            return (
              <div key={s.id} className="border border-gray-200 rounded overflow-hidden">
                <div className="px-3 py-2 bg-gray-50 border-b border-gray-200 flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
                  <span className="font-bold text-gray-800">
                    {s.number} <em className="not-italic font-normal text-gray-500">· {s.date} · {s.partyName}</em>
                  </span>
                  <span className="text-gray-600">
                    {picked.length}/{s.lines.length} line(s){rates ? ` · ${money(value)} ${currency}` : ''}
                    {s.sourceNumber && <em className="not-italic text-gray-400"> · from {s.sourceNumber}</em>}
                  </span>
                  <button type="button" onClick={() => toggleAll(s)}
                    className="text-[11px] text-blue-600 hover:underline">
                    {(idsOf(s.id).length ? 'CLEAR' : 'ALL') + ' THIS ' + label.toUpperCase()}
                  </button>
                </div>
                <table className="xenith-table">
                  <thead>
                    <tr>
                      <th className="w-[5%]"></th>
                      <th>Product</th>
                      <th className="text-right w-[11%]">On Paper</th>
                      <th className="text-right w-[13%]">Already {takenWord}</th>
                      <th className="text-right w-[10%]">Left</th>
                      {rates && <th className="text-right w-[12%]">Rate</th>}
                      {s.warehouseName && <th className="w-[16%]">Warehouse</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {s.lines.map(l => {
                      const done = l.remaining <= 0.001;
                      return (
                        <tr key={l.id} className={done ? 'text-gray-400' : ''}>
                          <td className="text-center">
                            <input type="checkbox" disabled={done} checked={idsOf(s.id).includes(l.id)}
                              onChange={() => toggle(s.id, l.id)} className="accent-[#1e88e5]" />
                          </td>
                          <td className={done ? '' : 'font-medium text-gray-800'}>
                            {l.productName} <em className="not-italic text-gray-400">· {l.sku}</em>
                          </td>
                          <td className="text-right">{money(l.qty)} {l.unit}</td>
                          <td className="text-right text-blue-700">{money(l.taken)} {l.unit}</td>
                          <td className={`text-right font-bold ${done ? '' : 'text-amber-600'}`}>{money(l.remaining)} {l.unit}</td>
                          {rates && <td className="text-right">{money(l.price)}</td>}
                          {s.warehouseName && <td className="text-gray-500">{l.warehouseName || s.warehouseName}</td>}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {fullyTaken(s) && (
                  <p className="px-3 py-1.5 bg-gray-50 border-t border-gray-200 text-[11px] text-gray-500">
                    This {label.toLowerCase()} is already fully {takenWord}.
                  </p>
                )}
              </div>
            );
          })}
        </div>

        <div className="sticky bottom-0 z-10 px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between gap-2">
          <span className="text-[11px] text-gray-600">
            {pickedLines} line(s) selected ·{' '}
            {rates
              ? <>{money(pickedValue)} {currency} will come across with the quantity still left.</>
              : <>the quantity still left comes across, and the rate is what {partyWord === 'vendor' ? 'the vendor has billed' : 'the paper says'}.</>}
          </span>
          <div className="flex gap-2">
            <button onClick={onClose} className="btn-xenith-outline">Done</button>
            <button onClick={applyAll} disabled={!pickedLines} className="btn-xenith-primary">
              <Layers className="w-3.5 h-3.5" />
              <span>PICK SELECTED</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const AllocationTable: React.FC<{
  title: string;
  rows: DocAllocation[];
  // An empty settle-list says which of its two causes it is, instead of printing a colour and
  // leaving the reader to guess whether the party owes nothing or the box is simply off.
  empty: string;
  selected: DocAllocation[];
  onAllocate: (id: number, v: number) => void;
}> = ({ title, rows, empty, selected, onAllocate }) => (
  <div>
    <h3 className="text-xs font-bold text-gray-700 mb-2">{title}</h3>
    <div className="border border-gray-200 rounded overflow-hidden">
      <table className="xenith-table">
        <thead>
          <tr>
            <th className="w-[4%]"></th>
            <th>Description</th>
            <th>Date</th>
            <th>Due Date</th>
            <th className="text-right">Total Amount</th>
            <th className="text-right">Adjusted Amount</th>
            <th className="text-right">Balance Amount</th>
            <th className="text-right w-[12%]">Allocate</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(a => (
            <tr key={a.id}>
              <td className="text-center">
                <input type="checkbox" checked={(selected.find(s => s.id === a.id)?.allocated || 0) > 0}
                  onChange={e => onAllocate(a.id, e.target.checked ? a.balanceAmount : 0)} className="accent-[#1e88e5]" />
              </td>
              <td className="font-medium text-gray-800">{a.description}</td>
              <td>{a.date}</td>
              <td>{a.dueDate || '—'}</td>
              <td className="text-right">{money(a.totalAmount)}</td>
              <td className="text-right text-emerald-600">{money(a.adjustedAmount)}</td>
              <td className="text-right text-amber-600">{money(a.balanceAmount)}</td>
              <td>
                <input type="number" min="0" step="0.01" max={a.balanceAmount} className="input-xenith text-right" placeholder="0"
                  value={num(selected.find(s => s.id === a.id)?.allocated || 0)}
                  onChange={e => onAllocate(a.id, Math.min(Number(e.target.value), a.balanceAmount))} />
              </td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={8} className="text-center text-gray-500 py-5">{empty}</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
);
