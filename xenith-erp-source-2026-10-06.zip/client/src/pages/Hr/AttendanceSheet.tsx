import React, { useMemo, useState } from 'react';
import { CalendarCheck, Check, Eraser, Save, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { AttendanceRow, getAttendance, HrMark, monthNamed, putAttendance } from '../../services/hr.service';
import {
  ExportPair, IconAction, Pick, RegisterStat, SearchBox, StatStrip, TableEmpty
} from '../Masters/masterUi';
import { useHub } from '../Setup/useHub';
import { isoDay } from '../../utils/dateRange';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAY_LETTER = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

// The order a cell walks through when it is clicked, ending back on a blank day.
const CYCLE: (HrMark | '')[] = ['', 'Present', 'Absent', 'Half Day', 'Leave', 'Off', 'Holiday', 'On Duty'];

const CELL: Record<HrMark, { short: string; cls: string }> = {
  Present: { short: 'P', cls: 'bg-teal-100 text-[#1b7a70] border-teal-300' },
  Absent: { short: 'A', cls: 'bg-red-100 text-red-700 border-red-300' },
  'Half Day': { short: '½', cls: 'bg-amber-100 text-amber-700 border-amber-300' },
  Leave: { short: 'L', cls: 'bg-blue-100 text-blue-700 border-blue-300' },
  Off: { short: 'O', cls: 'bg-gray-200 text-gray-500 border-gray-300' },
  Holiday: { short: 'H', cls: 'bg-purple-100 text-purple-700 border-purple-300' },
  'On Duty': { short: 'D', cls: 'bg-cyan-100 text-cyan-700 border-cyan-300' }
};

const daysIn = (month: string) => {
  const [y, m] = month.split('-').map(Number);
  return new Date(y, m, 0).getDate();
};
const dowOf = (month: string, day: number) => DAY_LETTER[new Date(`${month}-${String(day).padStart(2, '0')}T00:00:00Z`).getUTCDay()];

// A half day is counted in this register, so a total keeps the fraction rather than
// rounding it out of the Deduct column it adds up.
const dayCount = (n: number) => String(Math.round(Number(n || 0) * 10) / 10);

interface Patch {
  days: Record<string, HrMark | ''>;
  overtimeHours: number;
  lateDays: number;
  note: string;
}

export const AttendanceSheetPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const [month, setMonth] = useState(() => isoDay().slice(0, 7));
  const hub = useHub(() => getAttendance(tenantSlug, branchId, month), [tenantSlug, branchId, month]);
  useScreenReload(hub.reload);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [patches, setPatches] = useState<Record<number, Patch>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [warning, setWarning] = useState('');

  const editable = can('hr-attendance:edit');
  const rows = hub.value?.data ?? [];
  const total = hub.value ? daysIn(hub.value.month) : daysIn(month);
  const dayNos = Array.from({ length: total }, (_, i) => i + 1);

  const finalDays = (r: AttendanceRow) => {
    const p = patches[r.employeeId];
    if (!p) return r.days;
    const out: Record<string, HrMark> = {};
    Object.entries({ ...r.days, ...p.days }).forEach(([d, m]) => { if (m) out[d] = m as HrMark; });
    return out;
  };

  const tallyOf = (r: AttendanceRow) => {
    const d = finalDays(r);
    const counts: Record<string, number> = {};
    Object.values(d).forEach(m => { counts[m] = (counts[m] || 0) + 1; });
    const unpaid = (counts.Absent || 0) + (counts['Half Day'] || 0) * 0.5 + r.unpaidLeave;
    return { counts, marked: Object.keys(d).length, unpaid };
  };

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => !q || `${r.code} ${r.name} ${r.department} ${r.designation}`.toLowerCase().includes(q));
  }, [rows, search]);

  // The chips, the line under the grid and the printed sheet all come from this one set of
  // sums, so a month being typed in cannot show two different answers on one screen.
  const shown = useMemo(() => {
    const t = visible.map(tallyOf);
    return {
      marked: t.reduce((s, x) => s + x.marked, 0),
      present: t.reduce((s, x) => s + (x.counts.Present || 0), 0),
      absent: t.reduce((s, x) => s + (x.counts.Absent || 0), 0),
      halfDay: t.reduce((s, x) => s + (x.counts['Half Day'] || 0), 0),
      leave: t.reduce((s, x) => s + (x.counts.Leave || 0), 0),
      unpaid: t.reduce((s, x) => s + x.unpaid, 0),
      overtime: visible.reduce((s, r) => s + (patches[r.employeeId]?.overtimeHours ?? r.overtimeHours), 0),
      late: visible.reduce((s, r) => s + (patches[r.employeeId]?.lateDays ?? r.lateDays), 0)
    };
  }, [visible, patches]);

  const stats: RegisterStat[] = [
    {
      label: 'Staff',
      value: visible.length === rows.length ? String(rows.length) : `${visible.length} of ${rows.length}`,
      title: `Members of staff on the ${hub.value?.monthLabel ?? month} grid that the search leaves standing`
    },
    {
      label: 'Marked days',
      value: dayCount(shown.marked),
      title: `Days carrying a letter of any sort, out of ${rows.length} staff × ${total} days in the month`
    },
    { label: 'Present', value: dayCount(shown.present), tone: shown.present ? 'ok' : undefined, title: 'The P column added up as the grid prints it' },
    {
      label: 'Absent',
      value: dayCount(shown.absent),
      tone: shown.absent ? 'warn' : undefined,
      title: `${shown.halfDay} half day(s) are marked alongside them and cost half a day each`
    },
    { label: 'On leave', value: dayCount(shown.leave), title: 'Leave marked on the grid — approved applications write themselves onto these cells' },
    {
      label: 'Days off pay',
      value: dayCount(shown.unpaid),
      tone: shown.unpaid ? 'bad' : undefined,
      title: 'The Deduct column added up: absent days, half of each half day and unpaid leave the register holds'
    }
  ];

  const patchOf = (r: AttendanceRow): Patch =>
    patches[r.employeeId] ?? { days: {}, overtimeHours: r.overtimeHours, lateDays: r.lateDays, note: r.note };

  const setCell = (r: AttendanceRow, day: number) => {
    if (!editable) return;
    setPatches(p => {
      const cur = p[r.employeeId] ?? patchOf(r);
      const key = String(day);
      const next = CYCLE[(CYCLE.indexOf((cur.days[key] ?? r.days[key] ?? '') as any) + 1) % CYCLE.length];
      return { ...p, [r.employeeId]: { ...cur, days: { ...cur.days, [key]: next } } };
    });
    setError(''); setNotice('');
  };

  const fillWeeklyOff = (only?: AttendanceRow) => {
    if (!editable) return;
    const targets = only ? [only] : visible;
    setPatches(p => {
      const out = { ...p };
      targets.forEach(r => {
        const cur = out[r.employeeId] ?? patchOf(r);
        const offAt = WEEK.indexOf(r.weeklyOff || hub.value?.weeklyOff || 'Sunday');
        const days = { ...cur.days };
        dayNos.forEach(d => {
          const key = String(d);
          if (!days[key]) days[key] = new Date(`${month}-${key.padStart(2, '0')}T00:00:00Z`).getUTCDay() === offAt ? 'Off' : days[key];
        });
        out[r.employeeId] = { ...cur, days };
      });
      return out;
    });
    setNotice(`${only ? only.name : `${targets.length} employees`} — ${only?.weeklyOff ?? hub.value?.weeklyOff ?? 'weekly off'}s marked Off.`);
  };

  const markAllPresent = () => {
    if (!editable) return;
    setPatches(p => {
      const out = { ...p };
      visible.forEach(r => {
        const cur = out[r.employeeId] ?? patchOf(r);
        const days = { ...cur.days };
        dayNos.forEach(d => { if (!days[String(d)]) days[String(d)] = 'Present'; });
        out[r.employeeId] = { ...cur, days };
      });
      return out;
    });
    setNotice(`${visible.length} employee rows filled with Present on the blank days — clear the days nobody worked.`);
  };

  const clearRow = (r: AttendanceRow) => {
    if (!editable) return;
    setPatches(p => ({ ...p, [r.employeeId]: { days: Object.fromEntries(dayNos.map(d => [String(d), ''])), overtimeHours: 0, lateDays: 0, note: '' } }));
    setNotice(`${r.name}'s month cleared — save the row to drop the record.`);
  };

  const bodyOf = (r: AttendanceRow) => {
    const p = patchOf(r);
    const days: Record<string, HrMark> = {};
    Object.entries({ ...r.days, ...p.days }).forEach(([d, m]) => { if (m) days[d] = m as HrMark; });
    return { employeeId: r.employeeId, days, overtimeHours: p.overtimeHours, lateDays: p.lateDays, note: p.note };
  };

  const save = async (only?: AttendanceRow) => {
    const list = only ? [only] : visible.filter(r => patches[r.employeeId]);
    if (!list.length) { setError('Nothing has been changed on this month.'); return; }
    setSaving(true); setError(''); setNotice(''); setWarning('');
    try {
      const res = await putAttendance(tenantSlug, branchId, month, list.map(bodyOf));
      setPatches({});
      setNotice(`${res.data.length} employee${res.data.length === 1 ? '' : 's'} saved for ${hub.value?.monthLabel ?? month}.`);
      setWarning(res.warning || '');
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const dirty = Object.keys(patches).length;

  // The sheet prints the grid the desk just marked, letters and all, so the paper can be
  // signed against the same month the screen shows.
  const columns: ExportColumn<AttendanceRow>[] = [
    { label: 'Employee #', value: r => r.code },
    { label: 'Name', value: r => r.name },
    { label: 'Department', value: r => r.department || '-' },
    { label: 'Weekly off', value: r => r.weeklyOff || hub.value?.weeklyOff || '-' },
    ...dayNos.map(d => ({
      label: `${d}`,
      value: (r: AttendanceRow) => {
        const m = finalDays(r)[String(d)];
        return m ? CELL[m].short : '';
      }
    })),
    { label: 'P', value: r => String(tallyOf(r).counts.Present || 0), align: 'right' as const },
    { label: 'A', value: r => String(tallyOf(r).counts.Absent || 0), align: 'right' as const },
    { label: '½', value: r => String(tallyOf(r).counts['Half Day'] || 0), align: 'right' as const },
    { label: 'L', value: r => String(tallyOf(r).counts.Leave || 0), align: 'right' as const },
    { label: 'Deduct days', value: r => dayCount(tallyOf(r).unpaid), align: 'right' as const },
    { label: 'OT hrs', value: r => String(patches[r.employeeId]?.overtimeHours ?? r.overtimeHours), align: 'right' as const },
    { label: 'Late days', value: r => String(patches[r.employeeId]?.lateDays ?? r.lateDays), align: 'right' as const },
    { label: 'Note', value: r => r.note || '' }
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];
  const clearAll = () => { if (search) { setSearch(''); setSearchEpoch(n => n + 1); } };

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title flex items-center gap-2">
              <CalendarCheck className="w-4 h-4" /> Attendance
            </h2>
            <p className="text-xs text-gray-500 mt-0.5 max-w-3xl">
              Click a day to walk it through Present, Absent, Half Day, Leave, Off, Holiday and On Duty. Payroll reads
              this sheet for the days it should take off basic pay — Absent costs a whole day, Half Day half, and a paid
              Leave or On Duty costs nothing.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            <button type="button" onClick={markAllPresent} disabled={!editable} className="btn-xenith-outline disabled:opacity-50">
              <Check className="w-3.5 h-3.5" /> Fill blank days Present
            </button>
            <button type="button" onClick={() => fillWeeklyOff()} disabled={!editable} className="btn-xenith-outline disabled:opacity-50">
              Mark weekly offs Off
            </button>
            <button type="button" onClick={() => save()} disabled={saving || !editable || !dirty}
              className="btn-xenith-success disabled:opacity-50">
              <Save className="w-3.5 h-3.5" /> {saving ? 'Saving...' : `Save ${dirty || ''} changed`}
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <Pick className="w-44" value={month} onChange={e => { setMonth(e.target.value); setPatches({}); setError(''); setNotice(''); }}>
            {(hub.value?.months ?? [month]).map(m => <option key={m} value={m}>{monthNamed(m)}</option>)}
          </Pick>
          <SearchBox key={searchEpoch} placeholder="Search by staff #, name, department or role" onSearch={setSearch} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={`Attendance Sheet — ${hub.value?.monthLabel ?? monthNamed(month)}`}
              subtitle={`${visible.length} employee row(s), ${total} days${activeFilters.length ? ` · ${activeFilters.join(' · ')}` : ''}`}
              filename={`attendance-${month}`} columns={columns} rows={visible} landscape
              footer={footerRow(columns.length, {
                0: `Total (${visible.length})`,
                [4 + total]: dayCount(shown.present), [5 + total]: dayCount(shown.absent),
                [6 + total]: dayCount(shown.halfDay), [7 + total]: dayCount(shown.leave),
                [8 + total]: dayCount(shown.unpaid), [9 + total]: dayCount(shown.overtime),
                [10 + total]: dayCount(shown.late)
              })} />
          </span>
        </div>
      </div>

      {(error || hub.error || notice || warning) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || hub.error ? 'text-red-600 bg-red-50 border border-red-100'
            : warning ? 'text-amber-700 bg-amber-50 border border-amber-100'
              : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || hub.error || warning || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); setWarning(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {!editable && (
        <div className="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-100 rounded px-3 py-2">
          Attendance is read-only for your role — the month can be viewed and printed, not marked.
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-center gap-1.5 px-4 py-2 border-b border-gray-100 text-[10px] font-bold uppercase">
          {(Object.keys(CELL) as HrMark[]).map(m => (
            <span key={m} className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border ${CELL[m].cls}`}>
              {CELL[m].short} {m}
            </span>
          ))}
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-dashed border-gray-300 text-gray-400">
            blank &amp; unmarked day
          </span>
          <span className="ml-auto text-[10px] font-semibold normal-case text-gray-500">
            {hub.value?.monthLabel ?? monthNamed(month)} · {total} days
          </span>
        </div>
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table text-[11px]">
            <thead className="sticky top-0 z-20">
              <tr>
                <th className="sticky left-0 z-30 bg-gray-50 min-w-[190px]">Employee</th>
                {dayNos.map(d => (
                  <th key={d} className="p-0 min-w-[26px]">
                    <span className="block leading-tight py-1">
                      <span className="block font-semibold">{d}</span>
                      <span className="block text-[9px] text-gray-400 font-normal">{dowOf(month, d)}</span>
                    </span>
                  </th>
                ))}
                <th className="min-w-[46px]">P</th>
                <th className="min-w-[46px]">A</th>
                <th className="min-w-[46px]">½</th>
                <th className="min-w-[46px]">L</th>
                <th className="min-w-[60px]">Deduct days</th>
                <th className="min-w-[62px]">OT hrs</th>
                <th className="min-w-[58px]">Late</th>
                <th className="min-w-[150px]">Note</th>
                <th className="w-20">Row</th>
              </tr>
            </thead>
            <tbody>
              {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={total + 10}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!hub.loading && !visible.length && (
                <TableEmpty colSpan={total + 10} noun="staff rows" filters={activeFilters} cleared={clearAll} />
              )}
              {!hub.loading && visible.map(r => {
                const p = patchOf(r);
                const t = tallyOf(r);
                const changed = !!patches[r.employeeId];
                return (
                  <tr key={r.employeeId} className={changed ? 'bg-blue-50/40' : ''}>
                    <td className="sticky left-0 z-10 bg-white min-w-[190px] text-left">
                      <span className="block font-semibold">{r.name}</span>
                      <span className="block text-[10px] text-gray-400">{r.code} · {r.department} · off {r.weeklyOff}</span>
                    </td>
                    {dayNos.map(d => {
                      const mark = (p.days[String(d)] ?? r.days[String(d)] ?? '') as HrMark | '';
                      return (
                        <td key={d} className="p-0 text-center">
                          <button type="button" title={`${r.name} — ${d} ${monthNamed(month)}: ${mark || 'unmarked'}`}
                            onClick={() => setCell(r, d)} disabled={!editable}
                            className={`w-[24px] h-[24px] mx-auto block rounded border text-[10px] font-bold transition-colors ${
                              mark ? CELL[mark].cls : 'border-transparent hover:bg-gray-100'} ${
                              !editable ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
                            {mark ? CELL[mark].short : ''}
                          </button>
                        </td>
                      );
                    })}
                    <td className="text-right tabular-nums">{t.counts.Present || 0}</td>
                    <td className={`text-right tabular-nums ${t.counts.Absent ? 'text-red-600 font-semibold' : ''}`}>{t.counts.Absent || 0}</td>
                    <td className="text-right tabular-nums">{t.counts['Half Day'] || 0}</td>
                    <td className="text-right tabular-nums">{t.counts.Leave || 0}</td>
                    <td className={`text-right font-semibold tabular-nums ${t.unpaid ? 'text-amber-600' : 'text-gray-400'}`}>{t.unpaid}</td>
                    <td className="p-0">
                      <input type="number" min={0} value={p.overtimeHours ? String(p.overtimeHours) : ''} placeholder="0"
                        disabled={!editable} onChange={e => setPatches(s => ({ ...s, [r.employeeId]: { ...p, overtimeHours: Math.max(0, Number(e.target.value)) } }))}
                        className="w-full h-[24px] px-1 text-right border-0 bg-transparent focus:bg-blue-50 focus:outline-none" />
                    </td>
                    <td className="p-0">
                      <input type="number" min={0} value={p.lateDays ? String(p.lateDays) : ''} placeholder="0"
                        disabled={!editable} onChange={e => setPatches(s => ({ ...s, [r.employeeId]: { ...p, lateDays: Math.max(0, Number(e.target.value)) } }))}
                        className="w-full h-[24px] px-1 text-right border-0 bg-transparent focus:bg-blue-50 focus:outline-none" />
                    </td>
                    <td className="p-0">
                      <input value={p.note} disabled={!editable} placeholder={r.filled ? '' : 'not marked yet'}
                        onChange={e => setPatches(s => ({ ...s, [r.employeeId]: { ...p, note: e.target.value } }))}
                        className="w-full h-[24px] px-1 border-0 bg-transparent focus:bg-blue-50 focus:outline-none text-left" />
                    </td>
                    <td>
                      <div className="flex items-center gap-1 justify-end">
                        <IconAction title="Clear this month" tone="muted" disabled={!editable} onClick={() => clearRow(r)}><Eraser className="w-4 h-4" /></IconAction>
                        <IconAction title="Save this row" tone="success" disabled={!editable || !changed} onClick={() => save(r)}><Save className="w-4 h-4" /></IconAction>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {!!visible.length && !hub.loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td colSpan={total + 1} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.present)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.absent)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.halfDay)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.leave)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.unpaid)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.overtime)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{dayCount(shown.late)}</td>
                  <td colSpan={2} className="text-[11px] text-gray-500">
                    {dirty ? `${dirty} row(s) changed but not saved yet` : 'Every row on the page is saved'}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default AttendanceSheetPage;
