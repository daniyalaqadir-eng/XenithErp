import React, { useMemo, useState } from 'react';
import { CalendarDays, Check, MailX, Pencil, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { isoDay } from '../../utils/dateRange';
import {
  decideLeave, deleteLeave, deleteLeaveType, getLeave, LeaveApplication, LeaveBalanceRow,
  LeaveStatus, LeaveType, saveLeave, saveLeaveType, updateLeave, updateLeaveType
} from '../../services/hr.service';
import {
  Area, Check as CheckBox, DateWindow, DeleteConfirm, ExportPair, Field, FormFooter, IconAction, ListToolbar,
  NumCell, Pick, RegisterStat, SearchBox, SearchPick, SortHeader, SortState, StatStrip,
  StatusPills, TabStrip, TableEmpty, Text
} from '../Masters/masterUi';
import { useHub } from '../Setup/useHub';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const TABS = ['Applications', 'Balances', 'Leave Types'];

const blankApp = (): Partial<LeaveApplication> => ({
  employeeId: 0, leaveTypeId: 0, from: isoDay(),
  to: isoDay(), halfDay: false, reason: '', addressOnLeave: ''
});

const blankType = (): Partial<LeaveType> => ({
  name: '', code: '', daysPerYear: 12, carryForward: 0, paid: true, requiresProof: false,
  isActive: true, description: ''
});

const STATUS_TONE: Record<string, string> = {
  Applied: 'bg-amber-50 text-amber-700', Approved: 'bg-teal-50 text-[#25a195]',
  Rejected: 'bg-red-50 text-red-600', Cancelled: 'bg-gray-100 text-gray-500'
};

// A half day is a real figure on this register, so totals keep the fraction instead of
// rounding it away from the Days column it adds up.
const days = (n: number) => String(Math.round(Number(n || 0) * 10) / 10);

type Balance = { employeeId: number; code: string; name: string; department: string; rows: LeaveBalanceRow[] };

export const LeavePage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const hub = useHub(() => getLeave(tenantSlug, branchId), [tenantSlug, branchId]);
  useScreenReload(hub.reload);
  const [tab, setTab] = useState(TABS[0]);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState('');
  const [typeState, setTypeState] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'from', dir: 'desc' });
  const [draft, setDraft] = useState<Partial<LeaveApplication> | null>(null);
  const [typeDraft, setTypeDraft] = useState<Partial<LeaveType> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const editable = can('hr-leave:edit');
  const rows = hub.value?.data ?? [];
  const types = hub.value?.types ?? [];
  const employees = hub.value?.employees ?? [];
  const allBalances = hub.value?.balances ?? [];

  // Everything but the status pill: a pill writes its own count, so that count is taken
  // over the applications the search and the date window still leave standing.
  const inWindow = useMemo(() => rows.filter(a =>
    (!fromDate || a.from >= fromDate) && (!toDate || a.from <= toDate) &&
    (!search.trim() || `${a.number} ${a.employeeName} ${a.employeeCode} ${a.leaveTypeName} ${a.reason}`
      .toLowerCase().includes(search.trim().toLowerCase()))),
  [rows, fromDate, toDate, search]);

  const visible = useMemo(() => {
    const list = status ? inWindow.filter(a => a.status === status) : inWindow;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((x: any, y: any) => {
      const av = x[sort.key], bv = y[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [inWindow, status, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  // Each column added up as it prints, so a chip can never disagree with the line under
  // the table or with the sheet and the workbook.
  const shown = useMemo(() => ({
    days: visible.reduce((s, a) => s + a.days, 0),
    waiting: visible.filter(a => a.status === 'Applied').length,
    waitingDays: visible.filter(a => a.status === 'Applied').reduce((s, a) => s + a.days, 0),
    unpaid: visible.filter(a => !a.paid).reduce((s, a) => s + a.days, 0)
  }), [visible]);

  const statusCounts = [
    { value: '', label: 'All', count: inWindow.length },
    ...(hub.value?.statuses ?? []).map(s => ({ value: s, label: s, count: inWindow.filter(a => a.status === s).length }))
  ];

  const balances = useMemo(() => allBalances.filter(b =>
    !search.trim() || `${b.code} ${b.name} ${b.department}`.toLowerCase().includes(search.trim().toLowerCase())),
  [allBalances, search]);

  // The type columns come from the rows actually on screen, so the header can never print
  // a kind a row below it has no cell for.
  const typeCols = useMemo(() => {
    const out: { leaveTypeId: number; name: string; entitled: number; used: number; pending: number; remaining: number }[] = [];
    for (const b of balances) for (const r of b.rows) {
      let col = out.find(x => x.leaveTypeId === r.leaveTypeId);
      if (!col) { col = { leaveTypeId: r.leaveTypeId, name: r.name, entitled: 0, used: 0, pending: 0, remaining: 0 }; out.push(col); }
      col.entitled += r.entitled; col.used += r.used; col.pending += r.pending; col.remaining += r.remaining;
    }
    return out;
  }, [balances]);

  const balanceTotals = useMemo(() => ({
    entitled: typeCols.reduce((s, c) => s + c.entitled, 0),
    used: typeCols.reduce((s, c) => s + c.used, 0),
    waiting: typeCols.reduce((s, c) => s + c.pending, 0),
    remaining: typeCols.reduce((s, c) => s + c.remaining, 0)
  }), [typeCols]);

  // One sheet column per leave kind the page prints, so the workbook cannot carry a type
  // the screen has no row for.
  const balanceColumns: ExportColumn<Balance>[] = useMemo(() => [
    { label: 'Employee #', value: b => b.code },
    { label: 'Name', value: b => b.name },
    { label: 'Department', value: b => b.department || '-' },
    ...typeCols.map(c => ({
      label: c.name, align: 'right' as const,
      value: (b: Balance) => {
        const r = b.rows.find(x => x.leaveTypeId === c.leaveTypeId);
        if (!r) return '-';
        return `${r.remaining} left of ${r.entitled}${r.used ? `, used ${r.used}` : ''}${r.pending ? `, ${r.pending} waiting` : ''}`;
      }
    })),
    { label: 'Total left', value: (b: Balance) => days(b.rows.reduce((s, r) => s + r.remaining, 0)), align: 'right' }
  ], [typeCols]);

  const balanceFooter = useMemo(() => {
    const cells: Record<number, string> = { 0: `Total (${balances.length})` };
    typeCols.forEach((c, i) => { cells[3 + i] = days(c.remaining); });
    cells[3 + typeCols.length] = days(balanceTotals.remaining);
    return footerRow(balanceColumns.length, cells);
  }, [balanceColumns, typeCols, balances.length, balanceTotals.remaining]);

  const typesScoped = useMemo(() => types.filter(t =>
    !search.trim() || `${t.code} ${t.name} ${t.description}`.toLowerCase().includes(search.trim().toLowerCase())),
  [types, search]);

  const typesVisible = useMemo(() => typeState
    ? typesScoped.filter(t => (typeState === 'Active') === t.isActive) : typesScoped,
  [typesScoped, typeState]);

  const typeTotals = useMemo(() => ({
    perYear: typesVisible.reduce((s, t) => s + t.daysPerYear, 0),
    carry: typesVisible.reduce((s, t) => s + (t.carryForward || 0), 0),
    applied: typesVisible.reduce((s, t) => s + (t.applied || 0), 0),
    stopped: typesScoped.filter(t => !t.isActive).length
  }), [typesVisible, typesScoped]);

  const typeStateCounts = [
    { value: '', label: 'All', count: typesScoped.length },
    { value: 'Active', label: 'Active', count: typesScoped.filter(t => t.isActive).length },
    { value: 'Stopped', label: 'Stopped', count: typesScoped.filter(t => !t.isActive).length }
  ];

  // The register keeps a kind a member of staff has already been approved against, so the
  // delete only offers itself for kinds nothing has settled on yet.
  const approvedType = new Set(rows.filter(a => a.status === 'Approved').map(a => a.leaveTypeId));

  const stats: RegisterStat[] = tab === 'Applications' ? [
    {
      label: 'Applications',
      value: status ? `${visible.length} of ${inWindow.length}` : String(inWindow.length),
      title: 'Requests the search, the window and the status pill leave on screen'
    },
    { label: 'Days asked', value: days(shown.days), title: 'The Days column added up exactly as printed — working days, weekly offs already taken out by the register' },
    {
      label: 'Waiting on a decision',
      value: String(shown.waiting),
      tone: shown.waiting ? 'warn' : undefined,
      title: shown.waiting ? `${days(shown.waitingDays)} day(s) of leave sit in Applied and cannot reach the attendance sheet until someone decides` : 'Nothing is left undecided'
    },
    {
      label: 'Unpaid days',
      value: days(shown.unpaid),
      tone: shown.unpaid ? 'warn' : undefined,
      title: 'Of the days above, these come out of pay the same way an absence does'
    }
  ] : tab === 'Balances' ? [
    {
      label: 'Staff',
      value: balances.length === allBalances.length ? String(balances.length) : `${balances.length} of ${allBalances.length}`,
      title: 'Members of staff the search leaves on the page'
    },
    { label: 'Entitled', value: days(balanceTotals.entitled), title: `For the ${hub.value?.year ?? ''} year, across ${typeCols.length} leave type(s) and the rows shown` },
    { label: 'Used', value: days(balanceTotals.used), tone: 'ok', title: 'Approved applications only — the Used figures under each type' },
    {
      label: 'Remaining',
      value: days(balanceTotals.remaining),
      tone: balanceTotals.remaining ? 'ok' : 'bad',
      title: balanceTotals.waiting ? `Total left column added up. ${days(balanceTotals.waiting)} day(s) more are still waiting on a decision` : 'Total left column added up'
    }
  ] : [
    {
      label: 'Leave types',
      value: typeState ? `${typesVisible.length} of ${typesScoped.length}` : String(typesScoped.length),
      title: 'Kinds the search and the status pill leave on screen'
    },
    { label: 'Days a year', value: days(typeTotals.perYear), title: 'The Days / Year column added up as printed' },
    { label: 'Carry forward', value: days(typeTotals.carry), title: 'Days these kinds let an employee push into next year' },
    {
      label: 'Applications',
      value: String(typeTotals.applied),
      title: 'Requests already booked against these kinds'
    },
    ...(typeTotals.stopped ? [{
      label: 'Stopped', value: String(typeTotals.stopped), tone: 'warn' as const,
      title: 'Hidden from new applications but kept for the records already using them'
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    tab === 'Applications' && status && `status ${status}`,
    tab === 'Applications' && (fromDate || toDate) && `from ${fromDate || 'the beginning'} → ${toDate || 'today'}`,
    tab === 'Leave Types' && typeState && `type ${typeState.toLowerCase()}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    setTypeState('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const appColumns: ExportColumn<LeaveApplication>[] = [
    { label: 'Application #', value: a => a.number },
    { label: 'Employee', value: a => `${a.employeeCode} - ${a.employeeName}` },
    { label: 'Department', value: a => a.department || '-' },
    { label: 'Leave Type', value: a => a.leaveTypeName },
    { label: 'Paid', value: a => a.paid ? 'Yes' : 'No' },
    { label: 'From', value: a => a.from },
    { label: 'To', value: a => a.to },
    { label: 'Days', value: a => days(a.days), align: 'right' },
    { label: 'Applied On', value: a => a.appliedOn },
    { label: 'Status', value: a => a.status },
    { label: 'Decided On', value: a => a.decidedOn || '-' },
    { label: 'Decided By', value: a => a.decidedBy || '-' },
    { label: 'Reason', value: a => a.reason || '-' }
  ];

  const typeColumns: ExportColumn<LeaveType>[] = [
    { label: 'Code', value: t => t.code || '-' },
    { label: 'Leave Type', value: t => t.name },
    { label: 'Days / Year', value: t => days(t.daysPerYear), align: 'right' },
    { label: 'Carry Forward', value: t => days(t.carryForward || 0), align: 'right' },
    { label: 'Pay', value: t => t.paid ? 'Paid' : 'Unpaid' },
    { label: 'Proof', value: t => t.requiresProof ? 'Required' : '-' },
    { label: 'Applications', value: t => String(t.applied || 0), align: 'right' },
    { label: 'Status', value: t => t.isActive ? 'Active' : 'Stopped' }
  ];

  // The span the desk typed, before the register takes the employee's own weekly off out
  // of it — that deduction needs the staff record, so it is the server's arithmetic.
  const spanDays = useMemo(() => {
    if (!draft?.from || !draft.to || draft.to < draft.from) return null;
    if (draft.halfDay) return 0.5;
    const a = new Date(`${draft.from}T00:00:00Z`);
    const b = new Date(`${draft.to}T00:00:00Z`);
    return Math.round((b.getTime() - a.getTime()) / 86400000) + 1;
  }, [draft]);

  const submit = async (close = true) => {
    if (!draft) return;
    if (!draft.employeeId) { setError('Choose the employee'); return; }
    if (!draft.leaveTypeId) { setError('Choose the kind of leave'); return; }
    setSaving(true); setError(''); setNotice('');
    try {
      if (draft.id) {
        await updateLeave(tenantSlug, branchId, draft.id, draft);
        setNotice(`${draft.number} has been amended.`);
      } else {
        const created = await saveLeave(tenantSlug, branchId, draft);
        setNotice(`${created.number} — ${created.employeeName} has applied for ${created.days} day(s) of ${created.leaveTypeName}.`);
      }
      hub.reload();
      if (close) setDraft(null);
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const decide = async (a: LeaveApplication, next: LeaveStatus) => {
    setError(''); setNotice('');
    try {
      const out = await decideLeave(tenantSlug, branchId, a.id, next);
      setNotice(`${out.number} ${next.toLowerCase()} for ${out.employeeName} (${out.days} day(s)).`);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  const remove = async (a: LeaveApplication) => {
    setError(''); setNotice(''); setConfirmId(null);
    try {
      await deleteLeave(tenantSlug, branchId, a.id);
      setNotice(`${a.number} has been deleted.`);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
  };

  const submitType = async () => {
    if (!typeDraft) return;
    if (!String(typeDraft.name ?? '').trim()) { setError('Leave type name is required'); return; }
    setSaving(true); setError(''); setNotice('');
    try {
      if (typeDraft.id) await updateLeaveType(tenantSlug, branchId, typeDraft.id, typeDraft);
      else await saveLeaveType(tenantSlug, branchId, typeDraft);
      setNotice(`${typeDraft.name} saved.`);
      setTypeDraft(null);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const removeType = async (t: LeaveType) => {
    setError(''); setNotice(''); setConfirmId(null);
    try {
      await deleteLeaveType(tenantSlug, branchId, t.id);
      setNotice(`${t.name} has been deleted.`);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
  };

  const set = (patch: Partial<LeaveApplication>) => setDraft(d => (d ? { ...d, ...patch } : d));
  const setType = (patch: Partial<LeaveType>) => setTypeDraft(d => (d ? { ...d, ...patch } : d));

  const subtitle = activeFilters.length
    ? activeFilters.join(' · ')
    : tab === 'Applications' ? 'Every leave application on the book'
    : tab === 'Leave Types' ? `Every leave kind${hub.value?.year ? ` for ${hub.value.year}` : ''}`
    : `What is still left of each kind for ${hub.value?.year ?? 'the year'} on the staff book`;

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title flex items-center gap-2">
              <CalendarDays className="w-4 h-4" /> Leave
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {tab === 'Applications' && (
                <>Approving an application writes the leave onto the attendance sheet for those dates, so the payroll
                  desk never enters the same days twice. Paid leave costs nothing on the payslip; an unpaid kind is
                  taken out of pay the same way an absence is.</>
              )}
              {tab === 'Balances' && (
                <>Entitlement is set per leave type for the <span className="font-semibold">{hub.value?.year ?? 'this'}</span>
                  {' '}year; used counts approved applications only, and waiting shows what still needs a decision.
                  Remaining is what may still be approved before the desk has to say no.</>
              )}
              {tab === 'Leave Types' && (
                <>A type decides how many days a person gets in a year and whether those days are paid. Whatever is
                  defined here is what an application can be filed against.</>
              )}
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {tab !== 'Balances' && (
            <ListToolbar addLabel={tab === 'Applications' ? 'NEW APPLICATION' : 'ADD LEAVE TYPE'}
              onAdd={() => {
                setError(''); setNotice('');
                if (tab === 'Applications') setDraft({ ...blankApp(), leaveTypeId: types[0]?.id ?? 0 });
                else setTypeDraft(blankType());
              }} />
          )}
        </div>

        <div className="px-4 pt-1 pb-3 border-t border-gray-100">
          <TabStrip tabs={TABS} active={tab} onChange={t => { setTab(t); setError(''); setNotice(''); }} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch}
            placeholder={tab === 'Applications' ? 'Search by application #, staff, kind or reason'
              : tab === 'Balances' ? 'Search staff by code, name or department'
              : 'Search leave types by code, name or description'}
            onSearch={setSearch} />
          {tab === 'Applications' && <StatusPills value={status} onChange={setStatus} counts={statusCounts} />}
          {tab === 'Leave Types' && <StatusPills value={typeState} onChange={setTypeState} counts={typeStateCounts} />}
          {tab === 'Applications' && (
            <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          )}
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            {tab === 'Applications' && (
              <ExportPair title="Leave Applications" subtitle={subtitle} filename="leave-applications"
                columns={appColumns} rows={visible} landscape
                footer={footerRow(appColumns.length, {
                  0: `Total (${visible.length})`, 7: days(shown.days)
                })} />
            )}
            {tab === 'Balances' && (
              <ExportPair title="Leave Balances" subtitle={subtitle} filename="leave-balances"
                columns={balanceColumns} rows={balances} landscape footer={balanceFooter} />
            )}
            {tab === 'Leave Types' && (
              <ExportPair title="Leave Types" subtitle={subtitle} filename="leave-types"
                columns={typeColumns} rows={typesVisible}
                footer={footerRow(typeColumns.length, {
                  0: `Total (${typesVisible.length})`, 2: days(typeTotals.perYear),
                  3: days(typeTotals.carry), 6: String(typeTotals.applied)
                })} />
            )}
          </span>
        </div>
      </div>

      {(error || hub.error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || hub.error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {draft && (
        <div className="p-3 bg-gray-50 border border-gray-200 rounded">
          <h3 className="card-title mb-3">
            {draft.id ? `Edit Application - [${draft.number}]` : 'Record Leave Application'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Field label="Employee" required className="lg:col-span-2">
              <SearchPick
                options={employees.map(e => ({ id: e.id, label: e.name, sub: e.code }))}
                valueId={draft.employeeId || null}
                valueLabel={draft.employeeName || rows.find(r => r.id === draft.id)?.employeeName}
                onPick={o => set({ employeeId: o?.id ?? 0, employeeName: o?.label ?? '' })}
                placeholder="Search staff by name or code..." />
            </Field>
            <Field label="Kind of Leave" required>
              <Pick value={String(draft.leaveTypeId ?? '')} onChange={e => set({ leaveTypeId: Number(e.target.value) })}>
                <option value="">Choose...</option>
                {types.filter(t => t.isActive).map(t => (
                  <option key={t.id} value={t.id}>{t.name} ({t.paid ? 'paid' : 'unpaid'})</option>
                ))}
              </Pick>
            </Field>
            <Field label="Half Day" hint="Tick for a single half day on the first date.">
              <CheckBox checked={!!draft.halfDay} onChange={v => set({ halfDay: v })} label="Only half a day" />
            </Field>
            <Field label="From" required>
              <Text type="date" value={draft.from ?? ''} onChange={e => set({ from: e.target.value })} />
            </Field>
            <Field label="To" required>
              <Text type="date" value={draft.to ?? ''} onChange={e => set({ to: e.target.value })} disabled={!!draft.halfDay} />
            </Field>
            <Field label="Days in Range" hint="Working days are settled by the register, which knows the weekly off.">
              <Text value={spanDays === null ? '—' : String(spanDays)} readOnly />
            </Field>
            <Field label="Address While Away">
              <Text value={draft.addressOnLeave ?? ''} onChange={e => set({ addressOnLeave: e.target.value })} />
            </Field>
            <Field label="Reason" className="lg:col-span-4">
              <Area rows={2} value={draft.reason ?? ''} onChange={e => set({ reason: e.target.value })}
                placeholder="What the leave is for — the manager sees this when deciding." />
            </Field>
          </div>
          <FormFooter onSave={() => submit()} onClose={() => setDraft(null)} saving={saving}
            disabled={!editable} saveLabel={draft.id ? 'SAVE' : 'RECORD APPLICATION'} />
        </div>
      )}

      {typeDraft && (
        <div className="p-3 bg-gray-50 border border-gray-200 rounded">
          <h3 className="card-title mb-3">{typeDraft.id ? `Edit Leave Type - [${typeDraft.name}]` : 'Create Leave Type'}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Field label="Name" required>
              <Text value={typeDraft.name ?? ''} onChange={e => setType({ name: e.target.value })} placeholder="e.g. Casual Leave" disabled={!editable} />
            </Field>
            <Field label="Code">
              <Text value={typeDraft.code ?? ''} onChange={e => setType({ code: e.target.value.toUpperCase().slice(0, 4) })} placeholder="CL" disabled={!editable} />
            </Field>
            <Field label="Days a Year" required>
              <NumCell value={typeDraft.daysPerYear ?? 0} onChange={e => setType({ daysPerYear: Number(e.target.value) })} disabled={!editable} />
            </Field>
            <Field label="Carry Forward" hint="Days an employee may push into next year.">
              <NumCell value={typeDraft.carryForward ?? 0} onChange={e => setType({ carryForward: Number(e.target.value) })} disabled={!editable} />
            </Field>
            <Field label="Description" className="lg:col-span-4">
              <Area rows={2} value={typeDraft.description ?? ''} onChange={e => setType({ description: e.target.value })} disabled={!editable} />
            </Field>
            <div className="flex items-end gap-4 lg:col-span-4">
              <CheckBox checked={typeDraft.paid !== false} onChange={v => setType({ paid: v })} label="On full pay" disabled={!editable} />
              <CheckBox checked={!!typeDraft.requiresProof} onChange={v => setType({ requiresProof: v })} label="Needs a medical or proof" disabled={!editable} />
              <CheckBox checked={typeDraft.isActive !== false} onChange={v => setType({ isActive: v })} label="Active" disabled={!editable} />
            </div>
          </div>
          <FormFooter onSave={submitType} onClose={() => setTypeDraft(null)} saving={saving}
            disabled={!editable || !String(typeDraft.name ?? '').trim()} saveLabel={typeDraft.id ? 'SAVE' : 'ADD TYPE'} />
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          {tab === 'Applications' && (
            <table className="xenith-table">
              <thead className="sticky top-0 z-10">
                <tr>
                  <SortHeader label="App #" sortKey="number" sort={sort} onSort={onSort} />
                  <SortHeader label="Employee" sortKey="employeeName" sort={sort} onSort={onSort} />
                  <SortHeader label="Department" sortKey="department" sort={sort} onSort={onSort} />
                  <SortHeader label="Leave Type" sortKey="leaveTypeName" sort={sort} onSort={onSort} />
                  <SortHeader label="From" sortKey="from" sort={sort} onSort={onSort} />
                  <SortHeader label="To" sortKey="to" sort={sort} onSort={onSort} />
                  <SortHeader label="Days" sortKey="days" sort={sort} onSort={onSort} />
                  <SortHeader label="Applied" sortKey="appliedOn" sort={sort} onSort={onSort} />
                  <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                  <th>Decision</th>
                  <th className="w-32">Action</th>
                </tr>
              </thead>
              <tbody>
                {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={11}>
                      <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                    </td>
                  </tr>
                ))}
                {!hub.loading && !visible.length && (
                  <TableEmpty colSpan={11} noun="leave applications" filters={activeFilters} cleared={clearAll}
                    addLabel={rows.length ? undefined : 'NEW APPLICATION'}
                    onAdd={() => { setDraft({ ...blankApp(), leaveTypeId: types[0]?.id ?? 0 }); setError(''); setNotice(''); }} />
                )}
                {!hub.loading && visible.map(a => (
                  <tr key={a.id}>
                    <td className="font-medium">{a.number}</td>
                    <td>
                      <span className="block font-medium">{a.employeeName}</span>
                      <span className="block text-[10px] text-gray-400">{a.employeeCode}</span>
                    </td>
                    <td>{a.department || <span className="text-gray-300">-</span>}</td>
                    <td>
                      <span className="flex items-center gap-1.5">
                        {a.leaveTypeName}
                        {!a.paid && <span className="text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">Unpaid</span>}
                      </span>
                    </td>
                    <td>{a.from}</td>
                    <td>{a.halfDay ? '-' : a.to}</td>
                    <td className="text-right font-semibold tabular-nums">{a.days}</td>
                    <td>{a.appliedOn}</td>
                    <td>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${STATUS_TONE[a.status] ?? 'bg-gray-100 text-gray-500'}`}>
                        {a.status}
                      </span>
                    </td>
                    <td>
                      {a.decidedOn ? (
                        <span className="block text-[10px] text-gray-500">{a.decidedOn} · {a.decidedBy}</span>
                      ) : <span className="text-gray-300">-</span>}
                      {a.decisionNote && <span className="block text-[10px] text-gray-400 italic">{a.decisionNote}</span>}
                    </td>
                    <td>
                      <div className="flex items-center gap-1 justify-end">
                        {a.status === 'Applied' && editable && (
                          <>
                            <IconAction title="Approve this leave" tone="success" onClick={() => decide(a, 'Approved')}><Check className="w-4 h-4" /></IconAction>
                            <IconAction title="Reject this leave" tone="danger" onClick={() => decide(a, 'Rejected')}><MailX className="w-4 h-4" /></IconAction>
                          </>
                        )}
                        {a.status === 'Applied' && !editable && <span className="text-[10px] text-gray-300">waiting</span>}
                        {a.status === 'Approved' && (
                          <button type="button" disabled={!editable} onClick={() => decide(a, 'Cancelled')}
                            className="text-[10px] font-bold text-gray-500 border border-gray-200 rounded px-2 py-1 hover:bg-gray-50 disabled:opacity-40">
                            Cancel
                          </button>
                        )}
                        <IconAction title="Edit application" tone="primary" disabled={!editable || a.status === 'Approved'}
                          onClick={() => { setDraft({ ...a }); setError(''); setNotice(''); }}><Pencil className="w-4 h-4" /></IconAction>
                        {confirmId === a.id ? (
                          <DeleteConfirm onConfirm={() => remove(a)} onCancel={() => setConfirmId(null)}
                            keepLabel={`Keep ${a.number} · ${a.employeeName}`} />
                        ) : (
                          <IconAction title="Delete application" tone="danger" disabled={!editable || a.status === 'Approved'}
                            onClick={() => setConfirmId(a.id)}><Trash2 className="w-4 h-4" /></IconAction>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              {!!visible.length && !hub.loading && (
                <tfoot>
                  <tr className="bg-gray-50/80">
                    <td colSpan={6} className="font-black text-gray-800">Total ({visible.length})</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{days(shown.days)}</td>
                    <td colSpan={4} className="text-[11px] text-gray-500">
                      {shown.waiting ? `${shown.waiting} still awaiting a decision` : 'Every application on this page has been decided'}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          )}

          {tab === 'Balances' && (
            <table className="xenith-table">
              <thead className="sticky top-0 z-10">
                <tr>
                  <th>Employee #</th>
                  <th>Name</th>
                  <th>Department</th>
                  {typeCols.map(c => <th key={c.leaveTypeId}>{c.name}</th>)}
                  <th className="text-right">Total left</th>
                </tr>
              </thead>
              <tbody>
                {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={4 + typeCols.length}>
                      <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                    </td>
                  </tr>
                ))}
                {!hub.loading && !balances.length && (
                  <TableEmpty colSpan={4 + typeCols.length} noun="staff balances" filters={activeFilters} cleared={clearAll} />
                )}
                {!hub.loading && balances.map(b => (
                  <tr key={b.employeeId}>
                    <td className="font-medium">{b.code}</td>
                    <td>{b.name}</td>
                    <td>{b.department}</td>
                    {typeCols.map(c => {
                      const r = b.rows.find(x => x.leaveTypeId === c.leaveTypeId);
                      return (
                        <td key={c.leaveTypeId}>
                          {r ? (
                            <span className="flex items-center justify-between gap-2 whitespace-nowrap">
                              <span className={`tabular-nums ${r.remaining <= 0 ? 'font-bold text-red-600' : r.remaining <= 2 ? 'font-semibold text-amber-600' : 'font-semibold text-[#25a195]'}`}>
                                {r.remaining}
                              </span>
                              <span className="text-[10px] text-gray-400">
                                of {r.entitled} · used {r.used}{r.pending ? ` · ${r.pending} waiting` : ''}
                              </span>
                            </span>
                          ) : <span className="text-gray-300">-</span>}
                        </td>
                      );
                    })}
                    <td className="text-right font-bold tabular-nums">{b.rows.reduce((s, r) => s + r.remaining, 0)}</td>
                  </tr>
                ))}
              </tbody>
              {!!balances.length && !hub.loading && (
                <tfoot>
                  <tr className="bg-gray-50/80">
                    <td colSpan={3} className="font-black text-gray-800">Total ({balances.length})</td>
                    {typeCols.map(c => (
                      <td key={c.leaveTypeId} className="text-right tabular-nums font-black text-gray-800">
                        {c.remaining}
                        <span className="block text-[10px] font-normal text-gray-500">of {c.entitled} · used {c.used}</span>
                      </td>
                    ))}
                    <td className="text-right tabular-nums font-black text-gray-800">{days(balanceTotals.remaining)}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          )}

          {tab === 'Leave Types' && (
            <table className="xenith-table">
              <thead className="sticky top-0 z-10">
                <tr>
                  <th>Code</th><th>Leave Type</th>
                  <th className="text-right">Days / Year</th>
                  <th className="text-right">Carry Forward</th>
                  <th>Pay</th><th>Proof</th>
                  <th className="text-right">Applications</th><th>Status</th><th className="w-24">Action</th>
                </tr>
              </thead>
              <tbody>
                {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={9}>
                      <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                    </td>
                  </tr>
                ))}
                {!hub.loading && !typesVisible.length && (
                  <TableEmpty colSpan={9} noun="leave types" filters={activeFilters} cleared={clearAll}
                    addLabel={types.length ? undefined : 'ADD LEAVE TYPE'}
                    onAdd={() => { setTypeDraft(blankType()); setError(''); setNotice(''); }} />
                )}
                {!hub.loading && typesVisible.map(t => (
                  <tr key={t.id}>
                    <td className="font-medium">{t.code}</td>
                    <td>
                      <span className="block font-medium">{t.name}</span>
                      {t.description && <span className="block text-[10px] text-gray-400">{t.description}</span>}
                    </td>
                    <td className="text-right tabular-nums">{t.daysPerYear}</td>
                    <td className="text-right tabular-nums">{t.carryForward || <span className="text-gray-300">-</span>}</td>
                    <td>{t.paid ? 'Paid' : <span className="text-amber-600 font-semibold">Unpaid</span>}</td>
                    <td>{t.requiresProof ? 'Required' : <span className="text-gray-300">-</span>}</td>
                    <td className="text-right tabular-nums">{t.applied}</td>
                    <td>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${t.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                        {t.isActive ? 'Active' : 'Stopped'}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center gap-1 justify-end">
                        <IconAction title="Edit leave type" tone="primary" disabled={!editable}
                          onClick={() => { setTypeDraft({ ...t }); setError(''); setNotice(''); }}><Pencil className="w-4 h-4" /></IconAction>
                        {confirmId === t.id ? (
                          <DeleteConfirm onConfirm={() => removeType(t)} onCancel={() => setConfirmId(null)}
                            keepLabel={`Keep ${t.name}`} />
                        ) : (
                          <IconAction title={approvedType.has(t.id) ? 'Has approved leave on record — switch it off instead' : 'Delete leave type'}
                            tone="danger" disabled={!editable || approvedType.has(t.id)} onClick={() => setConfirmId(t.id)}><Trash2 className="w-4 h-4" /></IconAction>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              {!!typesVisible.length && !hub.loading && (
                <tfoot>
                  <tr className="bg-gray-50/80">
                    <td colSpan={2} className="font-black text-gray-800">Total ({typesVisible.length})</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{days(typeTotals.perYear)}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{days(typeTotals.carry)}</td>
                    <td colSpan={3} className="text-[11px] text-gray-500">
                      {typeTotals.stopped ? `${typeTotals.stopped} stopped kind(s) still listed for the records using them` : 'Every kind here is open for new applications'}
                    </td>
                    <td className="text-right tabular-nums font-black text-gray-800">{typeTotals.applied}</td>
                    <td colSpan={2}></td>
                  </tr>
                </tfoot>
              )}
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeavePage;
