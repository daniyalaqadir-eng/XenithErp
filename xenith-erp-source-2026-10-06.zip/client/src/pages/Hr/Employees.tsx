import React, { useMemo, useState } from 'react';
import { Pencil, Trash2, X, FileText } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { isoDay } from '../../utils/dateRange';
import {
  deleteEmployee, Employee, EmployeeLoan, getEmployees, getPayslips, PayslipRow,
  saveEmployee, updateEmployee
} from '../../services/hr.service';
import {
  Area, Check, DeleteConfirm, ExportPair, Field, FormFooter, IconAction, ListToolbar, NumCell, Pick,
  RegisterStat, SearchBox, SearchPick, SortHeader, SortState, StatStrip, StatusPills,
  TabStrip, TableEmpty, Text
} from '../Masters/masterUi';
import { useHub } from '../Setup/useHub';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const money = (n: number) => Number(n || 0).toLocaleString();

const TABS = ['General', 'Job & Paying', 'Bank Account', 'Service Record'];

const blank = (branchId: number): Partial<Employee> => ({
  name: '', fatherName: '', cnic: '', gender: 'Male', phone: '', email: '', address: '', city: '',
  departmentId: null, designationId: null, grade: 'G-3', branchId, employmentType: 'Permanent',
  status: 'Active', joiningDate: isoDay(), confirmationDate: '',
  exitDate: '', exitReason: '', basicSalary: 0, bankName: '', bankAccount: '', weeklyOff: 'Sunday',
  userId: null, notes: '', isActive: true
});

const STATUS_TONE: Record<string, string> = {
  Active: 'bg-teal-50 text-[#25a195]', 'On Leave': 'bg-amber-50 text-amber-700',
  'Notice Period': 'bg-orange-50 text-orange-700', Resigned: 'bg-gray-100 text-gray-500',
  Terminated: 'bg-red-50 text-red-600'
};

export const EmployeesPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const hub = useHub(() => getEmployees(tenantSlug, branchId), [tenantSlug, branchId]);
  useScreenReload(hub.reload);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [dept, setDept] = useState('');
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [tab, setTab] = useState(TABS[0]);
  const [draft, setDraft] = useState<Partial<Employee> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [slips, setSlips] = useState<{ employee: Employee; rows: PayslipRow[] } | null>(null);
  const [slipError, setSlipError] = useState('');

  const rows = hub.value?.data ?? [];
  const editable = can('hr-employees:edit');

  // Everything but the status pill. A pill writes a number on itself, so that number has
  // to be counted over the rows the search and the department already left standing —
  // otherwise clicking it would promise a staff the pill never held.
  const scoped = useMemo(() => rows.filter(e =>
    (!dept || e.departmentName === dept) &&
    (!search.trim() || `${e.code} ${e.name} ${e.cnic} ${e.phone} ${e.city} ${e.designationName}`
      .toLowerCase().includes(search.trim().toLowerCase()))),
  [rows, search, dept]);

  const visible = useMemo(() => {
    const list = status ? scoped.filter(e => e.status === status) : scoped;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [scoped, status, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  // One set of figures for the whole screen: the chips, the line under the table and the
  // footers of the printed sheet and the workbook all add up these same rows.
  const totals = useMemo(() => ({
    basic: visible.reduce((s, e) => s + e.basicSalary, 0),
    gross: visible.reduce((s, e) => s + e.gross, 0),
    net: visible.reduce((s, e) => s + e.net, 0),
    advances: visible.reduce((s, e) => s + e.loanBalance, 0)
  }), [visible]);

  const activeCount = visible.filter(e => e.status === 'Active').length;

  const stats: RegisterStat[] = [
    {
      label: 'Staff',
      value: status ? `${visible.length} of ${scoped.length}` : String(scoped.length),
      title: 'People the search and the department leave on the register'
    },
    { label: 'Active', value: activeCount, tone: 'ok', title: `Of the ${visible.length} listed below. A person in notice or past exit still carries their pay scheme` },
    { label: 'Gross', value: `PKR ${money(totals.gross)}`, title: 'Basic plus the agreed allowances of every row below, per month' },
    { label: 'Net payable', value: `PKR ${money(totals.net)}`, tone: 'ok', title: 'Gross less the deductions on each scheme. The Net column added up exactly' },
    {
      label: 'Advances out',
      value: `PKR ${money(totals.advances)}`,
      tone: totals.advances ? 'warn' : undefined,
      title: 'Still to be recovered out of future salary for the staff listed below'
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: scoped.length },
    ...(hub.value?.statuses ?? []).map(s => ({ value: s, label: s, count: scoped.filter(e => e.status === s).length }))
  ];

  const activeFilters = [
    search && `search “${search}”`,
    dept && `department ${dept}`,
    status && `status ${status}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setDept('');
    setStatus('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<Employee>[] = [
    { label: 'Employee #', value: e => e.code },
    { label: 'Name', value: e => e.name },
    { label: 'Father Name', value: e => e.fatherName || '-' },
    { label: 'CNIC', value: e => e.cnic || '-' },
    { label: 'Department', value: e => e.departmentName },
    { label: 'Designation', value: e => e.designationName },
    { label: 'Grade', value: e => e.grade || '-' },
    { label: 'Type', value: e => e.employmentType },
    { label: 'Joined', value: e => e.joiningDate },
    { label: 'Basic', value: e => money(e.basicSalary), align: 'right' },
    { label: 'Gross', value: e => money(e.gross), align: 'right' },
    { label: 'Net', value: e => money(e.net), align: 'right' },
    { label: 'Advances', value: e => money(e.loanBalance), align: 'right' },
    { label: 'Status', value: e => e.status }
  ];

  const submit = async (close = true) => {
    if (!draft) return;
    if (!String(draft.name ?? '').trim()) { setError('Employee name is required'); return; }
    setSaving(true); setError(''); setNotice('');
    try {
      if (draft.id) {
        await updateEmployee(tenantSlug, branchId, draft.id, draft);
        setNotice(`${draft.name} has been updated.`);
      } else {
        const created = await saveEmployee(tenantSlug, branchId, draft);
        setNotice(`${created.code} — ${created.name} has been added to the staff register.`);
      }
      hub.reload();
      if (close) setDraft(null);
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const remove = async (e: Employee) => {
    setError(''); setNotice(''); setConfirmId(null);
    try {
      await deleteEmployee(tenantSlug, branchId, e.id);
      setNotice(`${e.name} has been removed from the register.`);
      hub.reload();
    } catch (err) { setError((err as Error).message); }
  };

  const openSlips = async (e: Employee) => {
    setSlipError(''); setSlips({ employee: e, rows: [] });
    try {
      const r = await getPayslips(tenantSlug, branchId, e.id);
      setSlips({ employee: e, rows: r.data });
    } catch (err) { setSlipError((err as Error).message); setSlips(null); }
  };

  const set = (patch: Partial<Employee>) => setDraft(d => (d ? { ...d, ...patch } : d));
  const depts = hub.value?.departments ?? [];
  const desigs = hub.value?.designations ?? [];

  const subtitle = activeFilters.length ? activeFilters.join(' · ') : 'Everyone on the staff register';

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Employees</h2>
            <p className="text-xs text-gray-500 mt-0.5">The staff register: who the company pays, on what scheme, and what is still owed out of their salary.</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD EMPLOYEE"
            onAdd={() => { setDraft(blank(branchId)); setTab(TABS[0]); setError(''); setNotice(''); }} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by employee #, name, CNIC, phone, city or designation" onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={statusCounts} />
          {depts.length > 1 && (
            <span className="filter-plate">
              <Pick aria-label="Filter by department" value={dept} onChange={e => setDept(e.target.value)}>
                <option value="">Department</option>
                {depts.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
              </Pick>
              {dept && (
                <button type="button" title="Show every department" onClick={() => setDept('')}
                  className="text-gray-400 hover:text-gray-600">
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          )}
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Employees" subtitle={subtitle} filename="employees" columns={columns}
              rows={visible} landscape
              footer={footerRow(columns.length, {
                0: `Total (${visible.length})`, 9: money(totals.basic), 10: money(totals.gross),
                11: money(totals.net), 12: money(totals.advances)
              })} />
          </span>
        </div>
      </div>

      {(error || hub.error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || hub.error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

        {draft && (
          <div className="p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-2">
              <h3 className="card-title">
                {draft.id ? `Edit Employee - [${draft.code || ''}] ${draft.name || 'untitled'}` : 'Create Employee'}
              </h3>
              <span className="text-[11px] text-gray-400">Staff records only — an employee does not get a login of their own.</span>
            </div>
            <TabStrip tabs={TABS} active={tab} onChange={setTab} />

            {tab === 'General' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
                <Field label="Employee Name" required>
                  <Text value={draft.name ?? ''} onChange={e => set({ name: e.target.value })} placeholder="e.g. Shahid Mehmood" />
                </Field>
                <Field label="Father Name"><Text value={draft.fatherName ?? ''} onChange={e => set({ fatherName: e.target.value })} /></Field>
                <Field label="CNIC" hint="42101-1234567-1">
                  <Text value={draft.cnic ?? ''} onChange={e => set({ cnic: e.target.value })} />
                </Field>
                <Field label="Gender">
                  <Pick value={draft.gender ?? 'Male'} onChange={e => set({ gender: e.target.value as Employee['gender'] })}>
                    {['Male', 'Female', 'Other'].map(g => <option key={g}>{g}</option>)}
                  </Pick>
                </Field>
                <Field label="Mobile"><Text value={draft.phone ?? ''} onChange={e => set({ phone: e.target.value })} /></Field>
                <Field label="Email"><Text type="email" value={draft.email ?? ''} onChange={e => set({ email: e.target.value })} /></Field>
                <Field label="City"><Text value={draft.city ?? ''} onChange={e => set({ city: e.target.value })} /></Field>
                <Field label="Address" className="lg:col-span-2"><Text value={draft.address ?? ''} onChange={e => set({ address: e.target.value })} /></Field>
              </div>
            )}

            {tab === 'Job & Paying' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
                <Field label="Department">
                  <Pick value={String(draft.departmentId ?? '')} onChange={e => set({ departmentId: Number(e.target.value) || null })}>
                    <option value="">Unassigned</option>
                    {depts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </Pick>
                </Field>
                <Field label="Designation">
                  <Pick value={String(draft.designationId ?? '')} onChange={e => set({ designationId: Number(e.target.value) || null })}>
                    <option value="">Unassigned</option>
                    {desigs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </Pick>
                </Field>
                <Field label="Grade">
                  <Pick value={draft.grade ?? ''} onChange={e => set({ grade: e.target.value })}>
                    {(hub.value?.grades ?? []).map(g => <option key={g}>{g}</option>)}
                  </Pick>
                </Field>
                <Field label="Branch">
                  <Pick value={String(draft.branchId ?? '')} onChange={e => set({ branchId: Number(e.target.value) })}>
                    {(hub.value?.branches ?? []).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </Pick>
                </Field>
                <Field label="Employment Type">
                  <Pick value={draft.employmentType ?? 'Permanent'} onChange={e => set({ employmentType: e.target.value })}>
                    {(hub.value?.employmentTypes ?? []).map(t => <option key={t}>{t}</option>)}
                  </Pick>
                </Field>
                <Field label="Weekly Off">
                  <Pick value={draft.weeklyOff ?? 'Sunday'} onChange={e => set({ weeklyOff: e.target.value })}>
                    {(hub.value?.weeklyOffs ?? []).map(d => <option key={d}>{d}</option>)}
                  </Pick>
                </Field>
                <Field label="Basic Salary" hint="the scheme is built on this">
                  <NumCell value={draft.basicSalary ?? 0} min={0}
                    onChange={e => set({ basicSalary: Number(e.target.value) || 0 })} />
                </Field>
                <div className="sm:col-span-2 lg:col-span-2 flex items-end">
                  {draft.id ? (
                    <p className="text-[11px] text-gray-500">
                      On the current scheme: gross <b>PKR {money(draft.gross ?? 0)}</b>, withheld{' '}
                      <b>PKR {money(draft.withheld ?? 0)}</b>, net <b>PKR {money(draft.net ?? 0)}</b>.
                      Allowances are agreed on the Salary Structure screen.
                    </p>
                  ) : (
                    <p className="text-[11px] text-gray-400">
                      Save the record, then open Salary Structure to agree the allowances and deductions.
                    </p>
                  )}
                </div>
              </div>
            )}

            {tab === 'Bank Account' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
                <Field label="Bank"><Text value={draft.bankName ?? ''} onChange={e => set({ bankName: e.target.value })} placeholder="e.g. HBL" /></Field>
                <Field label="Account Number / IBAN"><Text value={draft.bankAccount ?? ''} onChange={e => set({ bankAccount: e.target.value })} /></Field>
                <Field label="Application User" hint="optional, for the audit trail only">
                  <SearchPick
                    options={(hub.value?.users ?? []).map(u => ({ id: u.id, label: u.name, sub: u.username }))}
                    valueId={draft.userId ?? null}
                    onPick={opt => set({ userId: opt ? opt.id : null })}
                    placeholder="Link an existing user..."
                  />
                </Field>
                <p className="text-[11px] text-gray-400 sm:col-span-2 lg:col-span-3">
                  Salaries go out through one account chosen on the salary sheet, so this is where the
                  money lands — not where it leaves from.
                </p>
              </div>
            )}

            {tab === 'Service Record' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
                <Field label="Status">
                  <Pick value={draft.status ?? 'Active'} onChange={e => set({ status: e.target.value })}>
                    {(hub.value?.statuses ?? []).map(s => <option key={s}>{s}</option>)}
                  </Pick>
                </Field>
                <Field label="Joining Date" required>
                  <Text type="date" value={draft.joiningDate ?? ''} onChange={e => set({ joiningDate: e.target.value })} />
                </Field>
                <Field label="Confirmation Date">
                  <Text type="date" value={draft.confirmationDate ?? ''} onChange={e => set({ confirmationDate: e.target.value })} />
                </Field>
                {(draft.status === 'Resigned' || draft.status === 'Terminated') && (
                  <>
                    <Field label="Exit Date"><Text type="date" value={draft.exitDate ?? ''} onChange={e => set({ exitDate: e.target.value })} /></Field>
                    <Field label="Exit Reason" className="lg:col-span-2">
                      <Text value={draft.exitReason ?? ''} onChange={e => set({ exitReason: e.target.value })} />
                    </Field>
                  </>
                )}
                <Field label="Employee Code" hint="blank lets the register number it">
                  <Text value={draft.code ?? ''} onChange={e => set({ code: e.target.value.toUpperCase() })} placeholder="EMP-011" />
                </Field>
                <Field label="Notes" className="sm:col-span-2 lg:col-span-3">
                  <Area rows={2} value={draft.notes ?? ''} onChange={e => set({ notes: e.target.value })} />
                </Field>
                <div className="lg:col-span-3"><Check checked={draft.isActive !== false} onChange={v => set({ isActive: v })} label="On the staff register" /></div>
              </div>
            )}

            <FormFooter onSave={() => submit(true)} onClose={() => setDraft(null)} saving={saving}
              saveLabel={draft.id ? 'SAVE' : 'CREATE EMPLOYEE'} />
          </div>
        )}

        {slips && (
          <div className="p-3 bg-white border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-2">
              <h3 className="card-title">Payslips — {slips.employee.name} ({slips.employee.code})</h3>
              <button type="button" onClick={() => setSlips(null)}><X className="w-4 h-4 text-gray-400" /></button>
            </div>
            {slipError && <p className="text-xs text-red-600">{slipError}</p>}
            {slips.rows.length === 0 && <p className="text-xs text-gray-400 py-3">No month has been paid to this employee yet.</p>}
            {slips.rows.length > 0 && (
              <div className="overflow-x-auto">
                <table className="xenith-table">
                  <thead>
                    <tr>
                      <th>Salary Sheet</th><th>Month</th><th>Basic</th><th>Earnings</th><th>Absence</th>
                      <th>Gross</th><th>Deductions</th><th>Net Pay</th><th>Days Unpaid</th><th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {slips.rows.map(r => (
                      <tr key={`${r.number}-${r.employeeId}`}>
                        <td className="font-medium">{r.number}</td>
                        <td>{r.monthLabel}</td>
                        <td className="text-right">{money(r.basic)}</td>
                        <td className="text-right">{money(r.earnings.reduce((s, i) => s + i.amount, 0) - r.basic)}</td>
                        <td className="text-right">{r.absence ? `(${money(r.absence)})` : '-'}</td>
                        <td className="text-right font-semibold">{money(r.gross)}</td>
                        <td className="text-right">{r.totalDeductions ? `(${money(r.totalDeductions)})` : '-'}</td>
                        <td className="text-right font-bold text-[#25a195]">{money(r.net)}</td>
                        <td className="text-right">{r.unpaidDays || '-'}</td>
                        <td><span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${r.paid ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                          {r.paid ? 'Paid' : r.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {slips.rows.length > 0 && (
              <div className="mt-2 text-[11px] text-gray-500">
                Each slip is built from the pay heads below — the first row of {slips.rows[0].number} for{' '}
                {slips.rows[0].employeeName}: {slips.rows[0].earnings.map(i => `${i.name} ${money(i.amount)}`).join(' · ')}
                {slips.rows[0].deductions.length > 0 && ` — less ${slips.rows[0].deductions.map(i => `${i.name} ${money(i.amount)}`).join(' · ')}`}
              </div>
            )}
          </div>
        )}

        <div className="nb-card p-0 overflow-hidden">
          <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Employee #" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Department" sortKey="departmentName" sort={sort} onSort={onSort} />
                <SortHeader label="Designation" sortKey="designationName" sort={sort} onSort={onSort} />
                <SortHeader label="Grade" sortKey="grade" sort={sort} onSort={onSort} />
                <SortHeader label="Joined" sortKey="joiningDate" sort={sort} onSort={onSort} />
                <SortHeader label="Basic" sortKey="basicSalary" sort={sort} onSort={onSort} />
                <SortHeader label="Gross" sortKey="gross" sort={sort} onSort={onSort} />
                <SortHeader label="Net" sortKey="net" sort={sort} onSort={onSort} />
                <SortHeader label="Advances" sortKey="loanBalance" sort={sort} onSort={onSort} />
                <SortHeader label="This Month" sortKey="marks" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {hub.loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={13}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!hub.loading && !visible.length && (
                <TableEmpty colSpan={13} noun="staff records" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'ADD EMPLOYEE'}
                  onAdd={() => { setDraft(blank(branchId)); setTab(TABS[0]); setError(''); setNotice(''); }} />
              )}
              {!hub.loading && visible.map(e => (
                <tr key={e.id}>
                  <td className="font-medium">{e.code}</td>
                  <td>
                    <span className="font-medium">{e.name}</span>
                    {e.pendingLeave > 0 && (
                      <span className="ml-1.5 text-[10px] font-bold uppercase bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded"
                        title={`${e.pendingLeave} leave application(s) awaiting a decision`}>
                        {e.pendingLeave} leave pending</span>
                    )}
                  </td>
                  <td>{e.departmentName}</td>
                  <td>{e.designationName}</td>
                  <td>{e.grade || '-'}</td>
                  <td>{e.joiningDate}</td>
                  <td className="text-right">{money(e.basicSalary)}</td>
                  <td className="text-right">{money(e.gross)}</td>
                  <td className="text-right font-semibold">{money(e.net)}</td>
                  <td className={e.loanBalance ? 'text-right text-amber-700 font-semibold' : 'text-right text-gray-300'}>
                    {e.loanBalance ? money(e.loanBalance) : '-'}</td>
                  <td className="whitespace-nowrap">
                    <span className={e.marks.filled ? 'text-gray-600' : 'text-gray-300'}>
                      {e.marks.filled
                        ? `${e.marks.counts.Present}P · ${e.marks.counts.Absent}A · ${e.marks.counts.Leave}L`
                        : 'not marked'}
                    </span>
                    {e.marks.unpaidDays > 0 && <span className="ml-1 text-[10px] font-bold text-red-500">{e.marks.unpaidDays}d cut</span>}
                  </td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${STATUS_TONE[e.status] ?? 'bg-gray-100 text-gray-500'}`}>
                      {e.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Payslips" onClick={() => openSlips(e)}><FileText className="w-4 h-4" /></IconAction>
                      {editable && <IconAction title="Edit employee" tone="primary"
                        onClick={() => { setDraft({ ...e }); setTab(TABS[0]); setError(''); setNotice(''); }}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>}
                      {editable && (confirmId === e.id ? (
                        <DeleteConfirm onConfirm={() => remove(e)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${e.name} on the staff roll`} />
                      ) : (
                        <IconAction title="Delete employee" tone="danger" onClick={() => setConfirmId(e.id)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !hub.loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  {/* The same four figures the chips above write and the sheet and the workbook
                      close with — one measurement, four places. */}
                  <td colSpan={6} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(totals.basic)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(totals.gross)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(totals.net)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(totals.advances)}</td>
                  <td colSpan={3} className="text-[11px] text-gray-500">
                    Gross is the pay scheme of every row listed; advances are what salary has still to recover.
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default EmployeesPage;
