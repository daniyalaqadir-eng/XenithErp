import React, { useMemo, useState } from 'react';
import { Pencil, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { isoDay } from '../../utils/dateRange';
import {
  deleteLoan, EmployeeLoan, getLoans, monthNamed, saveLoan, updateLoan
} from '../../services/hr.service';
import {
  Area, Check, DateWindow, DeleteConfirm, ExportPair, Field, FormFooter, IconAction, ListToolbar, NumCell, Pick,
  RegisterStat, SearchBox, SearchPick, SortHeader, SortState, StatStrip, StatusPills,
  TableEmpty, Text
} from '../Masters/masterUi';
import { useHub } from '../Setup/useHub';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const money = (n: number) => Math.round(Number(n || 0)).toLocaleString();

const blank = (months: string[]): Partial<EmployeeLoan> => ({
  employeeId: 0, kind: 'Loan', purpose: '', sanctionedOn: isoDay(),
  amount: 0, installments: 12, installmentAmount: 0, startMonth: months[0] ?? isoDay().slice(0, 7),
  accountId: null, remarks: '', status: 'Active'
});

const STATUS_TONE: Record<string, string> = {
  Active: 'bg-teal-50 text-[#25a195]', Closed: 'bg-gray-100 text-gray-500', Cancelled: 'bg-red-50 text-red-600'
};

export const LoansPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const hub = useHub(() => getLoans(tenantSlug, branchId), [tenantSlug, branchId]);
  useScreenReload(hub.reload);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'sanctionedOn', dir: 'desc' });
  const [draft, setDraft] = useState<Partial<EmployeeLoan> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const editable = can('hr-loans:edit');
  const rows = hub.value?.data ?? [];
  const months = hub.value?.months ?? [];

  // Everything but the status pill: a pill writes its own count, so that count is taken
  // over the records the search and the date window still leave standing.
  const inWindow = useMemo(() => rows.filter(l =>
    (!fromDate || l.sanctionedOn >= fromDate) && (!toDate || l.sanctionedOn <= toDate) &&
    (!search.trim() || `${l.number} ${l.employeeName} ${l.employeeCode} ${l.purpose} ${l.kind}`
      .toLowerCase().includes(search.trim().toLowerCase()))),
  [rows, fromDate, toDate, search]);

  const visible = useMemo(() => {
    const list = status ? inWindow.filter(l => l.status === status) : inWindow;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [inWindow, status, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  // Each column added up as it is printed, so a chip can never disagree with the line
  // under the table or with the sheet and the workbook.
  const shown = useMemo(() => ({
    amount: visible.reduce((s, l) => s + l.amount, 0),
    recovered: visible.reduce((s, l) => s + l.deducted, 0),
    balance: visible.reduce((s, l) => s + l.balance, 0)
  }), [visible]);
  const holders = new Set(visible.filter(l => l.balance > 0).map(l => l.employeeId)).size;

  const stats: RegisterStat[] = [
    {
      label: 'Records',
      value: status ? `${visible.length} of ${inWindow.length}` : String(inWindow.length),
      title: 'Sanctions the search, the window and the status pill leave on screen'
    },
    { label: 'Sanctioned', value: `PKR ${money(shown.amount)}`, title: 'The Amount column added up exactly as printed' },
    { label: 'Recovered', value: `PKR ${money(shown.recovered)}`, tone: 'ok', title: 'Already cut from payslips — the Recovered column added up' },
    {
      label: 'Still outstanding',
      value: `PKR ${money(shown.balance)}`,
      tone: shown.balance ? 'warn' : undefined,
      title: `The Balance column added up. ${holders} member${holders === 1 ? '' : 's'} of staff still hold${holders === 1 ? 's' : ''} money against it`
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: inWindow.length },
    ...(hub.value?.statuses ?? []).map(s => ({ value: s, label: s, count: inWindow.filter(l => l.status === s).length }))
  ];

  const activeFilters = [
    search && `search “${search}”`,
    status && `status ${status}`,
    (fromDate || toDate) && `sanctioned ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<EmployeeLoan>[] = [
    { label: 'Voucher #', value: l => l.number },
    { label: 'Employee', value: l => `${l.employeeCode} - ${l.employeeName}` },
    { label: 'Department', value: l => l.department || '-' },
    { label: 'Kind', value: l => l.kind },
    { label: 'Purpose', value: l => l.purpose || '-' },
    { label: 'Sanctioned On', value: l => l.sanctionedOn },
    { label: 'Amount', value: l => money(l.amount), align: 'right' },
    { label: 'Installment', value: l => money(l.installmentAmount), align: 'right' },
    { label: 'Months', value: l => String(l.installments), align: 'right' },
    { label: 'Recovered', value: l => `${l.installmentsPaid} of ${l.installments}`, align: 'right' },
    { label: 'Recovered PKR', value: l => money(l.deducted), align: 'right' },
    { label: 'Balance', value: l => money(l.balance), align: 'right' },
    { label: 'Status', value: l => l.status },
    { label: 'Journal', value: l => l.journalNumber || '-' }
  ];

  const perMonth = draft && Number(draft.installments) > 0
    ? Math.round((Number(draft.amount) || 0) / Number(draft.installments)) : 0;

  const submit = async () => {
    if (!draft) return;
    if (!draft.employeeId) { setError('Choose the employee'); return; }
    if (!draft.id && !(Number(draft.amount) > 0)) { setError('Enter the amount sanctioned'); return; }
    setSaving(true); setError(''); setNotice('');
    try {
      if (draft.id) {
        const out = await updateLoan(tenantSlug, branchId, draft.id, draft);
        setNotice(`${out.number} has been updated — ${money(out.balance)} still owed.`);
      } else {
        const created = await saveLoan(tenantSlug, branchId, draft);
        setNotice(`${created.number} — ${money(created.amount)} sanctioned to ${created.employeeName}, ${money(created.installmentAmount)} a month from ${created.startMonth}.`);
      }
      hub.reload();
      setDraft(null);
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const remove = async (l: EmployeeLoan) => {
    setError(''); setNotice(''); setConfirmId(null);
    try {
      await deleteLoan(tenantSlug, branchId, l.id);
      setNotice(`${l.number} has been deleted and its issuing journal taken back.`);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
  };

  const setStatusOf = async (l: EmployeeLoan, next: EmployeeLoan['status']) => {
    setError(''); setNotice('');
    try {
      const out = await updateLoan(tenantSlug, branchId, l.id, { status: next });
      setNotice(`${out.number} is ${out.status.toLowerCase()}.`);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
  };

  const set = (patch: Partial<EmployeeLoan>) => setDraft(d => (d ? { ...d, ...patch } : d));
  const subtitle = activeFilters.length ? activeFilters.join(' · ') : 'Every loan and advance on the staff book';

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Staff Loans &amp; Advances</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Money handed to a member of staff is an advance the ledger has to remember. Sanctioning one posts it out
              of the bank or cash account into <span className="font-semibold">Staff Loans &amp; Advances</span>; each
              payslip then recovers the installment until the balance closes.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="SANCTION LOAN / ADVANCE"
            onAdd={() => { setDraft(blank(months)); setError(''); setNotice(''); }} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by voucher #, staff, purpose or kind" onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={statusCounts} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Staff Loans and Advances" subtitle={subtitle} filename="staff-loans"
              columns={columns} rows={visible} landscape
              footer={footerRow(columns.length, {
                0: `Total (${visible.length})`, 6: money(shown.amount),
                10: money(shown.recovered), 11: money(shown.balance)
              })} />
          </span>
        </div>
      </div>

      {(error || hub.error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || hub.error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

        {draft && (
          <div className="p-3 bg-gray-50 border border-gray-200 rounded">
            <h3 className="card-title mb-3">
              {draft.id ? `Edit ${draft.number} - ${draft.employeeName}` : 'Sanction a Loan or Advance'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Field label="Employee" required className="lg:col-span-2">
                <SearchPick
                  options={(hub.value?.employees ?? []).map(e => ({ id: e.id, label: e.name, sub: e.code }))}
                  valueId={draft.employeeId || null}
                  valueLabel={draft.employeeName}
                  onPick={o => set({ employeeId: o?.id ?? 0, employeeName: o?.label ?? '' })}
                  placeholder="Search staff by name or code..." />
              </Field>
              <Field label="Kind" required hint="An Advance is recovered as one sum; a Loan runs on installments.">
                <Pick value={draft.kind ?? 'Loan'} onChange={e => set({ kind: e.target.value })} disabled={!editable}>
                  {(hub.value?.kinds ?? ['Loan', 'Advance', 'Interest Free Loan']).map(k => <option key={k} value={k}>{k}</option>)}
                </Pick>
              </Field>
              <Field label="Sanctioned On" required>
                <Text type="date" value={draft.sanctionedOn ?? ''} onChange={e => set({ sanctionedOn: e.target.value })} disabled={!editable} />
              </Field>
              <Field label="Amount (PKR)" required>
                <NumCell value={draft.amount ?? 0} onChange={e => set({ amount: Number(e.target.value) })} disabled={!editable || !!draft.id} />
              </Field>
              <Field label="Recovered Over (months)" required>
                <NumCell value={draft.installments ?? 1} onChange={e => set({ installments: Math.max(1, Number(e.target.value)) })}
                  disabled={!editable || !!draft.id} />
              </Field>
              <Field label="Installment (PKR)" hint={draft.id ? 'May not exceed the balance still owed.' : `Leave 0 to split the amount across the months (${money(perMonth)}).`}>
                <NumCell value={draft.installmentAmount ?? 0} onChange={e => set({ installmentAmount: Number(e.target.value) })} disabled={!editable} />
              </Field>
              <Field label="Recovery Starts" required hint="The payroll month the first installment is cut from.">
                <Pick value={draft.startMonth ?? ''} onChange={e => set({ startMonth: e.target.value })} disabled={!editable}>
                  {months.map(m => <option key={m} value={m}>{monthNamed(m)}</option>)}
                </Pick>
              </Field>
              <Field label="Paid Out Of" hint="Handing the money over is posted against this account.">
                <Pick value={String(draft.accountId ?? '')} onChange={e => set({ accountId: Number(e.target.value) || null })} disabled={!editable}>
                  <option value="">Cash in Hand</option>
                  {(hub.value?.accounts ?? []).filter(a => !/loan|salary|wage/i.test(a.name)).map(a => (
                    <option key={a.id} value={a.id}>{a.code} - {a.name}</option>
                  ))}
                </Pick>
              </Field>
              <Field label="Purpose" className="lg:col-span-2">
                <Text value={draft.purpose ?? ''} onChange={e => set({ purpose: e.target.value })} placeholder="e.g. Medical, marriage, festival advance" disabled={!editable} />
              </Field>
              <Field label="Remarks" className="lg:col-span-4">
                <Area rows={2} value={draft.remarks ?? ''} onChange={e => set({ remarks: e.target.value })} disabled={!editable} />
              </Field>
              {!!draft.id && draft.status !== 'Cancelled' && (
                <div className="flex items-end gap-4 lg:col-span-4">
                  <Check checked={draft.status === 'Active'} onChange={v => set({ status: v ? 'Active' : 'Closed' })}
                    label="Still being recovered" disabled={!editable || (draft.balance ?? 0) <= 0} />
                  <span className="text-[11px] text-gray-400">
                    {money(draft.deducted ?? 0)} already cut from pay · {money(draft.balance ?? 0)} left ·
                    {' '}{draft.left ?? 0} installment{draft.left === 1 ? '' : 's'} to run
                  </span>
                </div>
              )}
            </div>
            <FormFooter onSave={submit} onClose={() => setDraft(null)} saving={saving} disabled={!editable}
              saveLabel={draft.id ? 'SAVE' : 'SANCTION AND POST'} />
          </div>
        )}

        <div className="nb-card p-0 overflow-hidden">
          <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Voucher #" sortKey="number" sort={sort} onSort={onSort} />
                <SortHeader label="Employee" sortKey="employeeName" sort={sort} onSort={onSort} />
                <SortHeader label="Kind" sortKey="kind" sort={sort} onSort={onSort} />
                <SortHeader label="Sanctioned On" sortKey="sanctionedOn" sort={sort} onSort={onSort} />
                <SortHeader label="Amount" sortKey="amount" sort={sort} onSort={onSort} />
                <SortHeader label="Installment" sortKey="installmentAmount" sort={sort} onSort={onSort} />
                <th>Recovery</th>
                <SortHeader label="Recovered" sortKey="deducted" sort={sort} onSort={onSort} />
                <SortHeader label="Balance" sortKey="balance" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th>Journal</th>
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={12}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!hub.loading && !visible.length && (
                <TableEmpty colSpan={12} noun="loan and advance records" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'SANCTION LOAN / ADVANCE'}
                  onAdd={() => { setDraft(blank(months)); setError(''); setNotice(''); }} />
              )}
              {!hub.loading && visible.map(l => (
                <tr key={l.id}>
                  <td className="font-medium">{l.number}</td>
                  <td>
                    <span className="block font-medium">{l.employeeName}</span>
                    <span className="block text-[10px] text-gray-400">{l.employeeCode} · {l.department || '—'}</span>
                    {l.purpose && <span className="block text-[10px] text-gray-400 italic">{l.purpose}</span>}
                  </td>
                  <td>{l.kind}</td>
                  <td>{l.sanctionedOn}</td>
                  <td className="text-right">{money(l.amount)}</td>
                  <td className="text-right">
                    {money(l.installmentAmount)}
                    <span className="block text-[10px] text-gray-400">from {l.startMonth}</span>
                  </td>
                  <td>
                    <div className="w-24 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-[#2ec4b6]"
                        style={{ width: `${Math.min(100, Math.round((l.installmentsPaid / Math.max(1, l.installments)) * 100))}%` }} />
                    </div>
                    <span className="text-[10px] text-gray-400">{l.installmentsPaid} of {l.installments} months</span>
                  </td>
                  <td className="text-right text-[#25a195]">{money(l.deducted)}</td>
                  <td className={`text-right font-semibold ${l.balance > 0 ? 'text-amber-600' : 'text-gray-400'}`}>{money(l.balance)}</td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${STATUS_TONE[l.status]}`}>{l.status}</span>
                  </td>
                  <td>{l.journalNumber || <span className="text-gray-300">-</span>}</td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      <IconAction title="Edit this record" tone="primary" disabled={!editable}
                        onClick={() => { setDraft({ ...l }); setError(''); setNotice(''); }}><Pencil className="w-4 h-4" /></IconAction>
                      {l.status === 'Active' && l.deducted === 0 && editable && (
                        <button type="button" onClick={() => setStatusOf(l, 'Cancelled')} title="Cancel and take the issuing journal back"
                          className="text-[10px] font-bold text-gray-500 border border-gray-200 rounded px-2 py-1 hover:bg-gray-50">
                          Cancel
                        </button>
                      )}
                      {confirmId === l.id ? (
                        // The row's own Cancel button cancels the loan, so the delete arm says
                        // plainly which of the two it means.
                        <DeleteConfirm onConfirm={() => remove(l)} onCancel={() => setConfirmId(null)}
                          confirmLabel="Delete" keepLabel={`Keep ${l.number} · ${l.employeeName}`} />
                      ) : (
                        <IconAction title={l.deducted > 0 ? 'Has recoveries booked — cancel it instead' : 'Delete record'}
                          tone="danger" disabled={!editable || l.deducted > 0} onClick={() => setConfirmId(l.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !hub.loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  {/* The same three figures the chips above write, and the sheet and the workbook close with. */}
                  <td colSpan={4} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.amount)}</td>
                  <td colSpan={2} className="text-[11px] text-gray-500">
                    Every row as printed{status ? `, incl. ${status.toLowerCase()}` : ''}
                  </td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.recovered)}</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.balance)}</td>
                  <td colSpan={3} className="text-[11px] text-gray-500">
                    {holders ? `${holders} on the staff book still hold money` : 'Nothing owed against these records'}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default LoansPage;
