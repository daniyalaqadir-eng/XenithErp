import React, { useMemo, useState } from 'react';
import { isoDay } from '../../utils/dateRange';
import {
  Banknote, Check, ChevronDown, ClipboardList, FileSpreadsheet, Play, Settings2,
  Trash2, Undo2, X
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import {
  approveSheet, createSheet, deleteSheet, getSheet, getSheets, HrSettings, monthNamed, PayItem,
  PayrollLine, previewSheet, SalarySheetHead, SalarySheetView, paySheet, saveHrSettings,
  SheetStatus, unapproveSheet, updateSheet
} from '../../services/hr.service';
import {
  Area, Check as CheckBox, DeleteConfirm, ExportPair, Field, IconAction, NumCell, Pick,
  RegisterStat, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { useHub } from '../Setup/useHub';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const money = (n: number) => Math.round(Number(n || 0)).toLocaleString();
const thisMonth = () => isoDay().slice(0, 7);
// A half day is a real figure on payroll, so days keep the fraction instead of rounding it away.
const dayFig = (n: number) => String(Math.round(Number(n || 0) * 10) / 10);
const addUp = (lines: PayrollLine[], f: (l: PayrollLine) => number) => lines.reduce((s, l) => s + f(l), 0);

const SHEET_TONE: Record<string, string> = {
  Draft: 'bg-gray-100 text-gray-600', Approved: 'bg-blue-50 text-[#1e88e5]', Paid: 'bg-teal-50 text-[#25a195]'
};

// A payslip line prints its own heads, so the sheet columns are built from whatever the
// month actually carries rather than from a fixed set.
const itemsOf = (lines: PayrollLine[], kind: 'earnings' | 'extraEarnings' | 'deductions' | 'extraDeductions') => {
  const map: Record<string, number> = {};
  lines.forEach(l => l[kind].forEach(i => { map[i.name] = (map[i.name] || 0) + i.amount; }));
  return Object.entries(map).sort((a, b) => b[1] - a[1]);
};

export const SalarySheetPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const hub = useHub(() => getSheets(tenantSlug, branchId), [tenantSlug, branchId]);
  useScreenReload(hub.reload);
  const [month, setMonth] = useState(thisMonth());
  const [opts, setOpts] = useState({ deductForAbsence: true, recoverLoans: true });
  const [preview, setPreview] = useState<Awaited<ReturnType<typeof previewSheet>>['data'] | null>(null);
  const [prepared, setPrepared] = useState(false);
  const [detail, setDetail] = useState<SalarySheetView | null>(null);
  const [adjusting, setAdjusting] = useState<number | null>(null);
  const [adjust, setAdjust] = useState<{ extraEarnings: PayItem[]; extraDeductions: PayItem[]; remarks: string }>({
    extraEarnings: [], extraDeductions: [], remarks: ''
  });
  const [pay, setPay] = useState<{ open: boolean; payThrough: string; accountId: string; date: string }>({
    open: false, payThrough: 'Bank Transfer', accountId: '', date: isoDay()
  });
  const [settings, setSettings] = useState<HrSettings | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState<SheetStatus | ''>('');
  const [sort, setSort] = useState<SortState | null>({ key: 'month', dir: 'desc' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const editable = can('hr-salary-sheet:edit');
  const sheets = hub.value?.data ?? [];
  const heads = hub.value?.heads ?? [];
  const accounts = hub.value?.accounts ?? [];
  const flags = settings ?? hub.value?.settings ?? null;

  // Everything but the status pill: a pill writes its own count, so that count is taken
  // over the sheets the search still leaves standing.
  const inScope = useMemo(() => sheets.filter(s =>
    !search.trim() || `${s.number} ${s.monthLabel} ${s.status} ${s.payThrough} ${s.accountName} ${s.journalNumber}`
      .toLowerCase().includes(search.trim().toLowerCase())), [sheets, search]);

  const visible = useMemo(() => {
    const list = status ? inScope.filter(s => s.status === status) : inScope;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [inScope, status, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  // Each column added up as it is printed, so a chip can never disagree with the line under
  // the table, the sheet or the workbook.
  const shown = useMemo(() => ({
    employees: visible.reduce((s, x) => s + x.employees, 0),
    gross: visible.reduce((s, x) => s + x.gross, 0),
    deductions: visible.reduce((s, x) => s + x.deductions, 0),
    netPayable: visible.reduce((s, x) => s + x.netPayable, 0),
    unpaidDays: visible.reduce((s, x) => s + x.unpaidDays, 0)
  }), [visible]);

  const stats: RegisterStat[] = [
    {
      label: 'Sheets',
      value: status ? `${visible.length} of ${inScope.length}` : String(inScope.length),
      title: 'Salary sheets the search and the status pill leave on screen'
    },
    { label: 'Staff paid', value: String(shown.employees), title: 'The Staff column added up as printed' },
    { label: 'Gross', value: `PKR ${money(shown.gross)}`, title: 'The Gross column added up as printed' },
    {
      label: 'Withheld',
      value: `PKR ${money(shown.deductions)}`,
      tone: shown.deductions ? 'warn' : undefined,
      title: 'Deductions sitting against the staff book — the Withheld column added up'
    },
    {
      label: 'Net Payable',
      value: `PKR ${money(shown.netPayable)}`,
      tone: 'ok',
      title: 'What the sheets still hand to staff — the Net Payable column added up'
    },
    {
      label: 'Days not worked',
      value: dayFig(shown.unpaidDays),
      title: 'Absences and half days the pay was cut for — the Unpaid Days column added up'
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: inScope.length },
    ...(['Draft', 'Approved', 'Paid'] as SheetStatus[]).map(s => ({
      value: s, label: s, count: inScope.filter(x => x.status === s).length
    }))
  ];

  const activeFilters = [
    search && `search “${search}”`,
    status && `status ${status}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const run = async () => {
    setBusy(true); setError(''); setNotice(''); setPreview(null);
    try {
      const res = await previewSheet(tenantSlug, branchId, month, { deduct: opts.deductForAbsence, recover: opts.recoverLoans });
      setPrepared(true);
      setPreview(res.data);
      if (res.settings) setSettings(res.settings);
      if (!res.data.lines.length) setError('No employee is on the payroll — add staff and a salary scheme first.');
    } catch (e) { setError((e as Error).message); }
    setBusy(false);
  };

  const create = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const s = await createSheet(tenantSlug, branchId, {
        month, deductForAbsence: opts.deductForAbsence, recoverLoans: opts.recoverLoans,
        payThrough: flags?.paySalaryThrough, accountId: null, notes: ''
      });
      setNotice(`${s.number} has been raised for ${s.monthLabel} — ${s.employees} employee(s), PKR ${money(s.netPayable)} payable.`);
      setPreview(null); setPrepared(false);
      hub.reload();
      setDetail(s);
    } catch (e) { setError((e as Error).message); }
    setBusy(false);
  };

  const open = async (head: SalarySheetHead) => {
    setError(''); setNotice(''); setAdjusting(null);
    try { setDetail(await getSheet(tenantSlug, branchId, head.id)); }
    catch (e) { setError((e as Error).message); }
  };

  const act = async (fn: () => Promise<SalarySheetView>, message: (out: SalarySheetView) => string) => {
    setBusy(true); setError(''); setNotice('');
    try {
      const out = await fn();
      setDetail(out);
      setNotice(message(out));
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setBusy(false);
  };

  const approve = (s: SalarySheetView) => act(
    () => approveSheet(tenantSlug, branchId, s.id),
    out => `${out.number} approved — journal ${out.journalNumber} posted for PKR ${money(out.netPayable)} payable.`);

  const unapprove = (s: SalarySheetView) => act(
    () => unapproveSheet(tenantSlug, branchId, s.id),
    out => `${out.number} is a draft again and ${out.journalNumber || 'its journal'} has been reversed.`);

  const payOut = (s: SalarySheetView) => act(
    () => paySheet(tenantSlug, branchId, s.id, {
      payThrough: pay.payThrough, accountId: Number(pay.accountId) || undefined,
      accountName: accounts.find(a => a.id === Number(pay.accountId))?.name, date: pay.date
    }),
    out => `${out.number} paid PKR ${money(out.netPayable)} via ${out.accountName} — payment journal ${out.paymentJournalNumber}.`);

  const removeSheet = async (s: SalarySheetHead) => {
    setError(''); setNotice(''); setConfirmId(null);
    try {
      await deleteSheet(tenantSlug, branchId, s.id);
      setNotice(`${s.number} has been deleted.`);
      if (detail?.id === s.id) { setDetail(null); setPreview(null); }
      hub.reload();
    } catch (e) { setError((e as Error).message); }
  };

  const startAdjust = (l: PayrollLine) => {
    setAdjusting(l.employeeId);
    setAdjust({
      extraEarnings: l.extraEarnings.map(i => ({ ...i })),
      extraDeductions: l.extraDeductions.map(i => ({ ...i })),
      remarks: l.remarks
    });
  };

  const addItem = (kind: 'extraEarnings' | 'extraDeductions', headId: number) => {
    const head = heads.find(h => h.id === headId);
    if (!head) return;
    setAdjust(a => ({ ...a, [kind]: [...a[kind], { headId: head.id, name: head.name, amount: 0 }] }));
  };

  const saveAdjust = async (s: SalarySheetView, employeeId: number) => {
    await act(() => updateSheet(tenantSlug, branchId, s.id, {
      lines: [{ employeeId, extraEarnings: adjust.extraEarnings, extraDeductions: adjust.extraDeductions, remarks: adjust.remarks }]
    }), () => 'The additions are on the payslip and the sheet totals have been re-cut.');
    setAdjusting(null);
  };

  const saveFlags = async (next: HrSettings) => {
    setSettings(next); setError(''); setNotice('');
    try {
      const saved = await saveHrSettings(tenantSlug, branchId, next);
      setSettings(saved);
      hub.reload();
      setNotice('Payroll settings saved.');
    } catch (e) { setError((e as Error).message); }
  };

  const lineColumns = (lines: PayrollLine[]): ExportColumn<PayrollLine>[] => {
    const earn = itemsOf(lines, 'earnings').map(([name]) => name);
    const ded = itemsOf(lines, 'deductions').map(([name]) => name);
    return [
      { label: 'Employee #', value: l => l.employeeCode },
      { label: 'Name', value: l => l.employeeName },
      { label: 'Department', value: l => l.department },
      { label: 'Designation', value: l => l.designation || '-' },
      { label: 'Basic', value: l => money(l.basic), align: 'right' },
      ...earn.map(n => ({ label: n, value: (l: PayrollLine) => money(l.earnings.find(i => i.name === n)?.amount ?? 0), align: 'right' as const })),
      ...ded.map(n => ({ label: n, value: (l: PayrollLine) => money(l.deductions.find(i => i.name === n)?.amount ?? 0), align: 'right' as const })),
      { label: 'Absence Deduction', value: l => money(l.absence), align: 'right' },
      { label: 'Other Additions', value: l => money(l.extraEarnings.reduce((s, i) => s + i.amount, 0)), align: 'right' },
      { label: 'Other Deductions', value: l => money(l.extraDeductions.reduce((s, i) => s + i.amount, 0)), align: 'right' },
      { label: 'Gross', value: l => money(l.gross), align: 'right' },
      { label: 'Total Deductions', value: l => money(l.totalDeductions), align: 'right' },
      { label: 'Net Pay', value: l => money(l.net), align: 'right' },
      { label: 'Payable Days', value: l => String(l.payableDays), align: 'right' },
      { label: 'Present', value: l => String(l.present), align: 'right' },
      { label: 'Absent', value: l => String(l.absent), align: 'right' },
      { label: 'Unpaid Days', value: l => String(l.unpaidDays), align: 'right' },
      { label: 'Loan Recovery', value: l => money(l.recoveries.reduce((s, r) => s + r.amount, 0)), align: 'right' },
      { label: 'Paid', value: l => l.paid ? 'Yes' : 'No' },
      { label: 'Remarks', value: l => l.remarks || '-' }
    ];
  };

  const totalRow = (cols: ExportColumn<PayrollLine>[], lines: PayrollLine[]) => {
    const cells: Record<number, string> = { 0: 'Total' };
    const idx = (label: string) => cols.findIndex(c => c.label === label);
    const sum = (f: (l: PayrollLine) => number) => money(lines.reduce((s, l) => s + f(l), 0));
    const put = (label: string, v: string) => { const i = idx(label); if (i >= 0) cells[i] = v; };
    put('Basic', sum(l => l.basic));
    put('Gross', sum(l => l.gross));
    put('Total Deductions', sum(l => l.totalDeductions));
    put('Net Pay', sum(l => l.net));
    put('Absence Deduction', sum(l => l.absence));
    return footerRow(cols.length, cells);
  };

  const lines = detail?.lines ?? preview?.lines ?? [];
  const cols = lineColumns(lines);
  const draftMode = !!detail && detail.status === 'Draft' && editable;

  const sheetColumns: ExportColumn<SalarySheetHead>[] = [
    { label: 'Sheet #', value: s => s.number },
    { label: 'Month', value: s => s.monthLabel },
    { label: 'Staff', value: s => String(s.employees), align: 'right' },
    { label: 'Gross', value: s => money(s.gross), align: 'right' },
    { label: 'Withheld', value: s => money(s.deductions), align: 'right' },
    { label: 'Net Payable', value: s => money(s.netPayable), align: 'right' },
    { label: 'Unpaid Days', value: s => String(s.unpaidDays), align: 'right' },
    { label: 'Pay Through', value: s => s.payThrough },
    { label: 'Paid Account', value: s => s.accountName || '-' },
    { label: 'Accrual JE', value: s => s.journalNumber || '-' },
    { label: 'Payment JE', value: s => s.paymentJournalNumber || '-' },
    { label: 'Status', value: s => s.status }
  ];

  const subtitle = activeFilters.length ? activeFilters.join(' · ')
    : `Every salary sheet on the payroll register (${inScope.length})`;

  // The two preview panels add back to the run's own figures, so their footers are summed
  // from the rows they print rather than read off the headline.
  const deptSum = (f: (d: { staff: number; gross: number; net: number }) => number) =>
    (preview?.byDepartment ?? []).reduce((s, d) => s + f(d), 0);
  const headSum = (kind: string) =>
    (preview?.byHead ?? []).filter(h => h.kind === kind).reduce((s, h) => s + h.amount, 0);

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Salary Sheet</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Running a month lays every payslip on one paper — basic against the salary heads, pay cut for the days
              not worked, loan installments recovered. Approving the sheet posts what is payable into the ledger;
              paying it out moves the money from the bank or cash account.
            </p>
            {!detail && <div className="mt-2"><StatStrip stats={stats} /></div>}
          </div>
        </div>

        <div className="nb-plate mx-4">
          <div className="flex flex-wrap items-end gap-2">
            <Field label="Payroll Month" className="w-40">
              <Pick value={month} onChange={e => { setMonth(e.target.value); setPrepared(false); setPreview(null); }}>
                {(hub.value?.months ?? [month]).map(m => <option key={m} value={m}>{monthNamed(m)}</option>)}
              </Pick>
            </Field>
            <div className="flex items-end gap-4 pb-1.5">
              <CheckBox checked={opts.deductForAbsence} onChange={v => setOpts(o => ({ ...o, deductForAbsence: v }))}
                label="Cut pay for absent days" />
              <CheckBox checked={opts.recoverLoans} onChange={v => setOpts(o => ({ ...o, recoverLoans: v }))}
                label="Recover loan installments" />
            </div>
            <button type="button" onClick={run} disabled={busy} className="btn-xenith-outline disabled:opacity-50">
              <Play className="w-3.5 h-3.5" /> Run the month
            </button>
            {prepared && !detail && (
              <button type="button" onClick={create} disabled={busy || !editable || !preview?.lines.length}
                className="btn-xenith-success disabled:opacity-50">
                <ClipboardList className="w-3.5 h-3.5" /> Raise Salary Sheet
              </button>
            )}
            <button type="button" onClick={() => setShowSettings(s => !s)}
              className="ml-auto inline-flex items-center gap-1 text-[11px] font-semibold text-gray-500 hover:text-blue-600">
              <Settings2 className="w-3.5 h-3.5" /> Payroll Settings
              <ChevronDown className={`w-3 h-3 transition-transform ${showSettings ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {showSettings && flags && (
            <div className="mt-3 pt-3 border-t border-gray-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Field label="Pay Days in a Month" hint="Gross pay is divided by this to get the rate of a day.">
                <NumCell value={flags.payDaysInMonth} min={20} max={31} onChange={e => saveFlags({ ...flags, payDaysInMonth: Number(e.target.value) })} disabled={!editable} />
              </Field>
              <Field label="Weekly Off">
                <Pick value={flags.weeklyOff} onChange={e => saveFlags({ ...flags, weeklyOff: e.target.value })} disabled={!editable}>
                  {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(d => <option key={d} value={d}>{d}</option>)}
                </Pick>
              </Field>
              <Field label="Salary Goes Out By">
                <Pick value={flags.paySalaryThrough} onChange={e => saveFlags({ ...flags, paySalaryThrough: e.target.value })} disabled={!editable}>
                  {(hub.value?.payThrough ?? ['Bank Transfer', 'Cheque', 'Cash']).map(p => <option key={p} value={p}>{p}</option>)}
                </Pick>
              </Field>
              <Field label="Default Paying Account" hint="Offered on the sheet when nothing else is chosen.">
                <Pick value={flags.defaultPayAccountName} onChange={e => saveFlags({ ...flags, defaultPayAccountName: e.target.value })} disabled={!editable}>
                  {accounts.map(a => <option key={a.id} value={a.name}>{a.name}</option>)}
                </Pick>
              </Field>
              <div className="flex items-end gap-4 lg:col-span-4">
                <CheckBox checked={flags.deductForAbsence} onChange={v => saveFlags({ ...flags, deductForAbsence: v })}
                  label="Cut pay for absent days by default" disabled={!editable} />
                <CheckBox checked={flags.recoverLoans} onChange={v => saveFlags({ ...flags, recoverLoans: v })}
                  label="Recover staff loans by default" disabled={!editable} />
              </div>
            </div>
          )}
        </div>

        {!detail && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
            <SearchBox key={searchEpoch} placeholder="Search by sheet #, month, paying account or journal" onSearch={setSearch} />
            <StatusPills value={status} onChange={v => setStatus(v as SheetStatus | '')} counts={statusCounts} />
            <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
              <ExportPair title="Salary Sheets" subtitle={subtitle} filename="salary-sheets"
                columns={sheetColumns} rows={visible} landscape
                footer={footerRow(sheetColumns.length, {
                  0: `Total (${visible.length})`,
                  2: String(shown.employees),
                  3: money(shown.gross),
                  4: money(shown.deductions),
                  5: money(shown.netPayable)
                })} />
            </span>
          </div>
        )}
      </div>

      {(error || hub.error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || hub.error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        {detail ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-gray-50 border-b border-gray-100">
              <span className="flex items-center gap-2">
                <button type="button" onClick={() => { setDetail(null); setAdjusting(null); }}
                  className="text-[11px] font-bold text-blue-600 hover:underline">All sheets</button>
                <span className="text-gray-300">/</span>
                <h3 className="card-title">{detail.number} — {detail.monthLabel}</h3>
                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${SHEET_TONE[detail.status]}`}>{detail.status}</span>
              </span>
              <span className="flex items-center gap-2">
                {detail.status === 'Draft' && (
                  <button type="button" disabled={busy || !editable} onClick={() => approve(detail)}
                    className="btn-xenith-success disabled:opacity-50"><Check className="w-3.5 h-3.5" /> Approve and Post</button>
                )}
                {detail.status === 'Approved' && (
                  <>
                    <button type="button" disabled={busy || !editable} onClick={() => setPay(p => ({ ...p, open: !p.open, payThrough: detail.payThrough, accountId: String(detail.accountId ?? '') }))}
                      className="btn-xenith-success disabled:opacity-50"><Banknote className="w-3.5 h-3.5" /> Pay Out</button>
                    <button type="button" disabled={busy || !editable} onClick={() => unapprove(detail)}
                      className="btn-xenith-outline disabled:opacity-50"><Undo2 className="w-3.5 h-3.5" /> Un-approve</button>
                  </>
                )}
                <button type="button" onClick={() => { setDetail(null); setAdjusting(null); }} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Close
                </button>
              </span>
            </div>

            {pay.open && detail.status === 'Approved' && (
              <div className="px-4 py-3 border-b border-gray-100 bg-blue-50/40 flex flex-wrap items-end gap-2">
                <Field label="Pay Through" className="w-40">
                  <Pick value={pay.payThrough} onChange={e => setPay(p => ({ ...p, payThrough: e.target.value }))}>
                    {(hub.value?.payThrough ?? ['Bank Transfer', 'Cheque', 'Cash']).map(x => <option key={x} value={x}>{x}</option>)}
                  </Pick>
                </Field>
                <Field label="From Account" required className="w-64">
                  <Pick value={pay.accountId} onChange={e => setPay(p => ({ ...p, accountId: e.target.value }))}>
                    <option value="">Choose the bank or cash account...</option>
                    {accounts.filter(a => !/payable|loan|wage|salary/i.test(a.name)).map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}
                  </Pick>
                </Field>
                <Field label="Payment Date" className="w-44">
                  <Text type="date" value={pay.date} onChange={e => setPay(p => ({ ...p, date: e.target.value }))} />
                </Field>
                <button type="button" onClick={() => payOut(detail)} disabled={busy || !pay.accountId}
                  className="btn-xenith-success disabled:opacity-50">
                  <Banknote className="w-3.5 h-3.5" /> Post Payment of PKR {money(detail.netPayable)}
                </button>
                <button type="button" onClick={() => setPay(p => ({ ...p, open: false }))} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Cancel
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-b border-gray-100">
              {/* The paper's own totals, and the same figures the sheet and the workbook close with. */}
              <StatStrip stats={[
                { label: 'Staff', value: String(detail.employees), title: 'Payslip lines raised on this sheet' },
                { label: 'Gross', value: `PKR ${money(detail.gross)}`, title: 'Gross of every line, added up as printed' },
                {
                  label: 'Withheld', value: `PKR ${money(detail.deductions)}`,
                  tone: detail.deductions ? 'warn' : undefined,
                  title: 'Deductions, loan recoveries and absence cuts taken out of pay'
                },
                { label: 'Net Payable', value: `PKR ${money(detail.netPayable)}`, tone: 'ok', title: 'The Net Pay column added up' },
                { label: 'Days not worked', value: String(detail.unpaidDays), title: 'Absences and half days the pay was cut for' }
              ]} />
              <span className="ml-auto">
                <ExportPair title={`Salary Sheet ${detail.number} — ${detail.monthLabel}`}
                  subtitle={`${detail.employees} payslip line(s) · PKR ${money(detail.netPayable)} payable`}
                  filename={`salary-sheet-${detail.month}`}
                  columns={cols} rows={detail.lines} landscape footer={totalRow(cols, detail.lines)} />
              </span>
            </div>

            <div className="flex flex-wrap gap-x-3 gap-y-1 px-4 py-2.5 border-b border-gray-100 text-[10px] text-gray-500">
              <span>Pays through <span className="font-semibold text-gray-700">{detail.payThrough}</span></span>
              {detail.accountName && <span>From <span className="font-semibold text-gray-700">{detail.accountName}</span></span>}
              <span>Absence cut <span className="font-semibold text-gray-700">{detail.deductForAbsence ? 'on' : 'off'}</span></span>
              <span>Loan recovery <span className="font-semibold text-gray-700">{detail.recoverLoans ? 'on' : 'off'}</span></span>
              <span>Accrual journal <span className="font-semibold text-gray-700">{detail.journalNumber || 'not posted'}</span></span>
              <span>Payment journal <span className="font-semibold text-gray-700">{detail.paymentJournalNumber || (detail.status === 'Paid' ? 'none' : 'not yet paid')}</span></span>
              <span>Raised {detail.createdOn}{detail.approvedOn ? ` · approved ${detail.approvedOn}` : ''}{detail.paidOn ? ` · paid ${detail.paidOn}` : ''}</span>
            </div>

            <div className="overflow-auto max-h-[64vh] app-scroll">
              <table className="xenith-table">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <th>Employee #</th><th>Name</th><th>Department</th>
                    <th className="text-right">Basic</th>
                    <th className="text-right">Earnings</th>
                    <th className="text-right">Deductions</th>
                    <th className="text-right">Absence</th>
                    <th className="text-right">Net Pay</th>
                    <th className="text-right">Days P/A/L</th>
                    <th>Recoveries</th>
                    <th>Paid</th>
                    <th className="w-24">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.lines.map(l => (
                    <React.Fragment key={l.employeeId}>
                      <tr className={adjusting === l.employeeId ? 'bg-blue-50/60' : ''}>
                        <td className="font-medium">{l.employeeCode}</td>
                        <td>
                          <span className="block font-medium">{l.employeeName}</span>
                          <span className="block text-[10px] text-gray-400">{l.designation || '—'} · {l.grade}</span>
                        </td>
                        <td>{l.department}</td>
                        <td className="text-right">{money(l.basic)}</td>
                        <td className="text-right">
                          {money(l.gross + l.absence - l.basic)}
                          <span className="block text-[10px] text-gray-400">
                            {l.earnings.filter(i => i.headId).map(i => `${i.name} ${money(i.amount)}`).join(' · ') || 'no heads'}
                          </span>
                        </td>
                        <td className="text-right text-amber-600">
                          {money(l.totalDeductions)}
                          <span className="block text-[10px] text-gray-400">
                            {l.deductions.map(i => `${i.name} ${money(i.amount)}`).join(' · ') || 'none'}
                          </span>
                        </td>
                        <td className="text-right">{l.absence ? money(l.absence) : <span className="text-gray-300">-</span>}</td>
                        <td className="text-right font-bold text-[#25a195]">{money(l.net)}</td>
                        <td className="text-right whitespace-nowrap">
                          {l.present}<span className="text-gray-300"> / </span>
                          <span className={l.absent ? 'text-red-600 font-semibold' : ''}>{l.absent}</span>
                          <span className="text-gray-300"> / </span>{l.leaves}
                          <span className="block text-[10px] text-gray-400">of {l.payableDays} days</span>
                        </td>
                        <td>
                          {l.recoveries.length ? (
                            <span className="block text-[10px]">{l.recoveries.map(r => `${r.number} ${money(r.amount)}`).join(' · ')}</span>
                          ) : <span className="text-gray-300">-</span>}
                          {l.extraEarnings.length + l.extraDeductions.length > 0 && (
                            <span className="block text-[10px] text-gray-400 italic">
                              {[...l.extraEarnings, ...l.extraDeductions].map(i => `${i.name} ${money(i.amount)}`).join(' · ')}
                            </span>
                          )}
                          {l.remarks && <span className="block text-[10px] text-gray-400">{l.remarks}</span>}
                        </td>
                        <td>{l.paid ? <span className="text-[10px] font-bold uppercase text-[#25a195] bg-teal-50 px-1.5 py-0.5 rounded">Paid</span> : <span className="text-gray-300">-</span>}</td>
                        <td>
                          <div className="flex items-center gap-1 justify-end">
                            <IconAction title="Add or deduct on this payslip" tone="primary" disabled={!draftMode}
                              onClick={() => (adjusting === l.employeeId ? setAdjusting(null) : startAdjust(l))}>
                              <Settings2 className="w-4 h-4" />
                            </IconAction>
                          </div>
                        </td>
                      </tr>
                      {adjusting === l.employeeId && draftMode && (
                        <tr>
                          <td colSpan={12} className="bg-gray-50 p-3">
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
                              <div>
                                <span className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Manual Additions</span>
                                {adjust.extraEarnings.map((i, n) => (
                                  <div key={n} className="flex items-center gap-1 mb-1">
                                    <span className="flex-1 text-xs">{i.name}</span>
                                    <NumCell className="w-24" value={i.amount}
                                      onChange={e => setAdjust(a => ({ ...a, extraEarnings: a.extraEarnings.map((x, j) => j === n ? { ...x, amount: Number(e.target.value) } : x) }))} />
                                    <IconAction title="Remove" tone="danger" onClick={() => setAdjust(a => ({ ...a, extraEarnings: a.extraEarnings.filter((_, j) => j !== n) }))}>
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </IconAction>
                                  </div>
                                ))}
                                <Pick className="w-full" value="" onChange={e => { addItem('extraEarnings', Number(e.target.value)); e.target.value = ''; }}>
                                  <option value="">+ add an earning head...</option>
                                  {heads.filter(h => h.kind === 'Earning').map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
                                </Pick>
                              </div>
                              <div>
                                <span className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Manual Deductions</span>
                                {adjust.extraDeductions.map((i, n) => (
                                  <div key={n} className="flex items-center gap-1 mb-1">
                                    <span className="flex-1 text-xs">{i.name}</span>
                                    <NumCell className="w-24" value={i.amount}
                                      onChange={e => setAdjust(a => ({ ...a, extraDeductions: a.extraDeductions.map((x, j) => j === n ? { ...x, amount: Number(e.target.value) } : x) }))} />
                                    <IconAction title="Remove" tone="danger" onClick={() => setAdjust(a => ({ ...a, extraDeductions: a.extraDeductions.filter((_, j) => j !== n) }))}>
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </IconAction>
                                  </div>
                                ))}
                                <Pick className="w-full" value="" onChange={e => { addItem('extraDeductions', Number(e.target.value)); e.target.value = ''; }}>
                                  <option value="">+ add a deduction head...</option>
                                  {heads.filter(h => h.kind === 'Deduction').map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
                                </Pick>
                              </div>
                              <div>
                                <span className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Remarks on the Slip</span>
                                <Area rows={2} value={adjust.remarks} onChange={e => setAdjust(a => ({ ...a, remarks: e.target.value }))} />
                                <div className="flex items-center gap-2 mt-2">
                                  <button type="button" onClick={() => saveAdjust(detail, l.employeeId)} disabled={busy}
                                    className="btn-xenith-success disabled:opacity-50">Save Line</button>
                                  <button type="button" onClick={() => setAdjusting(null)} className="btn-xenith-warning">
                                    <X className="w-3.5 h-3.5" /> Discard
                                  </button>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50/80">
                    {/* Each figure sits under the column it adds up, and the Net is the same
                        PKR the chips above and the printed sheet close with. */}
                    <td colSpan={3} className="font-black text-gray-800">Sheet Total — {detail.employees} employee(s)</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{money(addUp(detail.lines, l => l.basic))}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{money(addUp(detail.lines, l => l.gross + l.absence - l.basic))}</td>
                    <td className="text-right tabular-nums font-black text-amber-600">{money(detail.deductions)}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{money(addUp(detail.lines, l => l.absence))}</td>
                    <td className="text-right tabular-nums font-black text-[#25a195]">{money(detail.netPayable)}</td>
                    <td colSpan={4} className="text-[11px] text-gray-500">
                      Gross {money(detail.gross)} less {money(detail.deductions)} withheld ·
                      {' '}{dayFig(detail.unpaidDays)} day(s) not worked
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {detail.notes && <p className="px-4 py-2.5 text-[11px] text-gray-500 border-t border-gray-100">{detail.notes}</p>}
            {!editable && detail.status === 'Draft' && (
              <p className="px-4 py-2.5 text-[11px] font-semibold text-amber-600 border-t border-gray-100">
                Your role may view sheets but not approve or pay them.
              </p>
            )}
          </>
        ) : (
          <div className="overflow-auto max-h-[64vh] app-scroll">
            <table className="xenith-table">
              <thead className="sticky top-0 z-10">
                <tr>
                  <SortHeader label="Sheet #" sortKey="number" sort={sort} onSort={onSort} />
                  <SortHeader label="Month" sortKey="month" sort={sort} onSort={onSort} />
                  <SortHeader label="Staff" sortKey="employees" sort={sort} onSort={onSort} />
                  <SortHeader label="Gross" sortKey="gross" sort={sort} onSort={onSort} />
                  <SortHeader label="Withheld" sortKey="deductions" sort={sort} onSort={onSort} />
                  <SortHeader label="Net Payable" sortKey="netPayable" sort={sort} onSort={onSort} />
                  <SortHeader label="Unpaid Days" sortKey="unpaidDays" sort={sort} onSort={onSort} />
                  <th>Pay Through</th>
                  <th>Journals</th>
                  <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                  <th className="w-32">Action</th>
                </tr>
              </thead>
              <tbody>
                {hub.loading && Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={11}>
                      <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                    </td>
                  </tr>
                ))}
                {!hub.loading && !visible.length && (
                  <TableEmpty colSpan={11} noun="salary sheets" filters={activeFilters} cleared={clearAll}
                    addLabel={sheets.length ? undefined : (preview?.lines.length ? 'RAISE THE SHEET' : 'RUN THE SELECTED MONTH')}
                    onAdd={() => (preview?.lines.length ? create() : run())} />
                )}
                {!hub.loading && visible.map(s => (
                  <tr key={s.id}>
                    <td className="font-medium">{s.number}</td>
                    <td>{s.monthLabel}</td>
                    <td className="text-right">{s.employees}</td>
                    <td className="text-right">{money(s.gross)}</td>
                    <td className="text-right text-amber-600">{money(s.deductions)}</td>
                    <td className="text-right font-bold text-[#25a195]">{money(s.netPayable)}</td>
                    <td className="text-right">{dayFig(s.unpaidDays)}</td>
                    <td>
                      {s.payThrough}
                      {s.accountName && <span className="block text-[10px] text-gray-400">{s.accountName}</span>}
                    </td>
                    <td className="text-[10px]">
                      {s.journalNumber || <span className="text-gray-300">not posted</span>}
                      {s.paymentJournalNumber && <span className="block text-gray-400">payment {s.paymentJournalNumber}</span>}
                    </td>
                    <td>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${SHEET_TONE[s.status]}`}>{s.status}</span>
                    </td>
                    <td>
                      <div className="flex items-center gap-1 justify-end">
                        <IconAction title={s.status === 'Draft' ? 'Open and approve the sheet' : 'Open the sheet'}
                          tone="primary" onClick={() => open(s)}><FileSpreadsheet className="w-4 h-4" /></IconAction>
                        {confirmId === s.id ? (
                          <DeleteConfirm onConfirm={() => removeSheet(s)} onCancel={() => setConfirmId(null)}
                            keepLabel={`Keep ${s.number} · ${s.monthLabel} on the payroll`} />
                        ) : (
                          <IconAction title={s.status !== 'Draft' ? 'Un-approve before deleting' : 'Delete the draft sheet'}
                            tone="danger" disabled={!editable || s.status !== 'Draft'} onClick={() => setConfirmId(s.id)}><Trash2 className="w-4 h-4" /></IconAction>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              {!!visible.length && !hub.loading && (
                <tfoot>
                  <tr className="bg-gray-50/80">
                    {/* The same five figures the chips above write, and the sheet and the workbook close with. */}
                    <td colSpan={2} className="font-black text-gray-800">Total ({visible.length})</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{shown.employees}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{money(shown.gross)}</td>
                    <td className="text-right tabular-nums font-black text-amber-600">{money(shown.deductions)}</td>
                    <td className="text-right tabular-nums font-black text-[#25a195]">{money(shown.netPayable)}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{dayFig(shown.unpaidDays)}</td>
                    <td colSpan={4} className="text-[11px] text-gray-500">
                      {status ? `Every sheet as printed, incl. ${status.toLowerCase()}` : 'Withheld is what the payslips keep back; Net Payable is what staff are handed'}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
      </div>

      {!detail && lines.length > 0 && preview && (
        <div className="nb-card p-0 overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
            <div className="min-w-0">
              <h2 className="page-title">Preview — {preview.monthLabel}</h2>
              <p className="text-xs text-gray-500 mt-0.5">
                {preview.lines.length} payslip line(s) read off the staff book for this month. Nothing is written to
                the ledger until the sheet is raised.
              </p>
              {/* The run's own figures sit here rather than beside the register chips, so the
                  two sets can never be read as one. */}
              <div className="mt-2">
                <StatStrip stats={[
                  { label: 'Staff on the run', value: String(preview.employees), title: `Payslip lines read for ${preview.monthLabel}` },
                  { label: 'Gross', value: `PKR ${money(preview.gross)}`, title: 'Gross of every line about to be raised, added up' },
                  {
                    label: 'Withheld', value: `PKR ${money(preview.deductions)}`,
                    tone: preview.deductions ? 'warn' : undefined,
                    title: 'Provident fund, tax and recoveries the payslips keep back'
                  },
                  { label: 'Net Payable', value: `PKR ${money(preview.netPayable)}`, tone: 'ok', title: 'What the sheet will hand to staff' },
                  { label: 'Days not worked', value: dayFig(preview.unpaidDays), title: 'Absences and half days the pay is cut for' }
                ]} />
              </div>
              {preview.unmarked.length > 0 && (
                <div className="mt-2 text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-100 rounded px-2.5 py-2">
                  {preview.unmarked.length} employee(s) have no attendance marked for {preview.monthLabel}: {preview.unmarked.slice(0, 8).join(', ')}
                  {preview.unmarked.length > 8 ? ', …' : ''}. Nothing will be deducted for absence on those lines.
                </div>
              )}
            </div>
            <ExportPair title={`Salary Sheet ${preview.monthLabel}`}
              subtitle={`${preview.employees} payslip line(s) · PKR ${money(preview.netPayable)} payable`}
              filename={`payroll-${preview.month}`}
              columns={cols} rows={preview.lines} landscape footer={totalRow(cols, preview.lines)} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 px-4 pb-4">
            <div className="overflow-x-auto border border-gray-200 rounded">
              <table className="xenith-table">
                <thead><tr><th>Department</th><th className="text-right">Staff</th><th className="text-right">Gross</th><th className="text-right">Net</th></tr></thead>
                <tbody>
                  {preview.byDepartment.map(d => (
                    <tr key={d.department}>
                      <td>{d.department}</td>
                      <td className="text-right">{d.staff}</td>
                      <td className="text-right">{money(d.gross)}</td>
                      <td className="text-right font-semibold text-[#25a195]">{money(d.net)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50/80">
                    {/* Adds back to the same Staff, Gross and Net the run above reports. */}
                    <td className="font-black text-gray-800">Total ({preview.byDepartment.length})</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{deptSum(d => d.staff)}</td>
                    <td className="text-right tabular-nums font-black text-gray-800">{money(deptSum(d => d.gross))}</td>
                    <td className="text-right tabular-nums font-black text-[#25a195]">{money(deptSum(d => d.net))}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <div className="overflow-x-auto border border-gray-200 rounded">
              <table className="xenith-table">
                <thead><tr><th>Salary Head</th><th>Type</th><th className="text-right">Amount</th></tr></thead>
                <tbody>
                  {preview.byHead.map(h => (
                    <tr key={`${h.kind}-${h.head}`}>
                      <td>{h.head}</td>
                      <td>{h.kind}</td>
                      <td className={`text-right ${h.kind === 'Deduction' ? 'text-amber-600' : ''}`}>{money(h.amount)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50/80">
                    <td className="font-black text-gray-800">Total ({preview.byHead.length})</td>
                    <td className="text-[11px] text-gray-500">
                      Earnings {money(headSum('Earning'))} less {money(headSum('Deduction'))} kept back
                    </td>
                    <td className="text-right tabular-nums font-black text-[#25a195]">{money(headSum('Earning') - headSum('Deduction'))}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalarySheetPage;
