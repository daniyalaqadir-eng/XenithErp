import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import {
  BusinessSummary, SummarySection, getBusinessSummary
} from '../../services/reports.service';
import { ExportColumn, esc, printSheet } from '../../utils/exportTable';
import { ExcelMenuButton, PrintMenuButton } from '../../components/print/PrintTemplateModal';
import { PrintPrefs } from '../../utils/printDesigns';
import { ArrowLeft, ChevronDown, ChevronRight, Download, Printer, RefreshCw, XCircle } from 'lucide-react';
import { useScreenReload } from '../../utils/screenReload';

interface Props { onNavigate: (tab: string) => void }

const money = (v: number, decimals: boolean) =>
  (v ?? 0).toLocaleString(undefined, { minimumFractionDigits: decimals ? 2 : 0, maximumFractionDigits: decimals ? 2 : 0 });

const dmy = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '');

// Rupee notes the closing cash balance works out to, largest first. The printed summary
// carries this so whoever counts the drawer can tick the physical cash against the books.
const DENOMS = [5000, 1000, 500, 100, 50, 20, 10];
const noteSplit = (amount: number) => {
  let rest = Math.max(0, Math.round(amount));
  const notes = DENOMS.map(denom => {
    const count = Math.floor(rest / denom);
    rest -= count * denom;
    return { denom, count };
  });
  return { notes, coins: rest };
};

const dayStart = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
};
const today = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};

// A section only earns its own ledger table when something moved through it, apart from
// Cash in Hand and Undeposited Funds, which are read every period whether or not they moved.
const ALWAYS_LEDGER = ['cash', 'undeposited'];

// The printed sheet is a statement, not a screen: cover line, date window, tiles in three
// columns, summary panels and hairline-ruled tables that survive a page break.
const PRINT_CSS = `
  body{margin:18px 22px;font-size:11px}
  .cover{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
  .cover .co,.cover .ti{font-size:19px;font-weight:700;color:#111}
  .dates{text-align:right;font-weight:700;color:#111;margin:12px 0 18px;line-height:1.7}
  .grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:10px}
  .tile{border:1px solid #cbd5e1;padding:5px 7px;display:flex;align-items:center;justify-content:space-between;gap:8px;break-inside:avoid}
  .tile b{background:#cfe3f7;color:#1b3a5c;font-size:11px;font-weight:700;padding:2px 8px;border-radius:3px}
  .tile span{font-weight:700;color:#334155;white-space:nowrap}
  .box{border:1px solid #cbd5e1;padding:8px 10px;break-inside:avoid}
  .box h3{font-size:12px;font-weight:700;color:#111;margin:0 0 6px}
  .kv{display:flex;justify-content:space-between;gap:8px;border-bottom:1px solid #eef2f7;padding:3px 0}
  .kv b{color:#111;white-space:nowrap}
  .noact{color:#e63946;font-weight:700;padding:4px 0}
  .denom{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 10px}
  .denom i{font-style:normal;display:flex;justify-content:space-between;gap:6px;border-bottom:1px solid #eef2f7;padding:2px 0}
  .denom b{color:#111}
  .st{font-size:12px;font-weight:700;color:#111;margin:16px 0 5px}
  .det table{width:100%;border-collapse:collapse}
  .det th,.det td{border:1px solid #e5e7eb;padding:5px 7px;font-size:11px;text-align:left}
  .det th{background:#f3f4f6;color:#111;font-weight:700;text-transform:none;letter-spacing:0}
  .det td.r,.det th.r{text-align:right}
  .det tr:nth-child(even) td{background:#fff}
  .det tr.hd td{font-weight:700;color:#111;background:#f8fafc}
`;

const SummaryCard: React.FC<{ section: SummarySection; decimals: boolean }> = ({ section, decimals }) => (
  <div className="card-xenith p-4 flex-1">
    <h3 className="card-title mb-2">{section.label} - Summary</h3>
    <div className="space-y-1.5 text-xs">
      <Line label="Opening" value={money(section.opening, decimals)} />
      {section.rows.length ? (
        <>
          <Line label="Money in" value={money(section.inflow, decimals)} tone="text-emerald-600" />
          <Line label="Money out" value={money(section.outflow, decimals)} tone="text-rose-600" />
        </>
      ) : (
        <p className="text-[11px] font-semibold text-[#e63946] py-1">There is no activity</p>
      )}
      <Line label="Closing" value={money(section.closing, decimals)} strong />
    </div>
  </div>
);

const Line: React.FC<{ label: string; value: string; tone?: string; strong?: boolean }> = ({
  label, value, tone = '', strong
}) => (
  <div className="flex flex-wrap items-center justify-between gap-x-2 border-b border-gray-100 pb-1 last:border-0">
    <span className={`${strong ? 'font-black text-gray-800' : 'text-gray-500'} font-semibold`}>{label}</span>
    <span className={`tabular-nums ml-auto ${strong ? 'font-black text-gray-900' : 'font-bold text-gray-700'} ${tone}`}>
      PKR {value}
    </span>
  </div>
);

const CashDetailCard: React.FC<{ balance: number }> = ({ balance }) => {
  const { notes, coins } = noteSplit(balance);
  return (
    <div className="card-xenith p-4 flex-1">
      <h3 className="card-title mb-2">Cash Detail</h3>
      <div className="grid grid-cols-2 gap-x-4 text-[11px]">
        {notes.map(n => (
          <div key={n.denom} className="flex items-center justify-between gap-2 border-b border-gray-100 py-1">
            <span className="font-bold text-gray-600">{n.denom.toLocaleString()} x</span>
            <span className="tabular-nums font-black text-gray-800">{n.count}</span>
          </div>
        ))}
        <div className="flex items-center justify-between gap-2 border-b border-gray-100 py-1">
          <span className="font-bold text-gray-600">Coins</span>
          <span className="tabular-nums font-black text-gray-800">{coins}</span>
        </div>
      </div>
      <p className="mt-2 text-[10px] text-gray-400">
        {balance > 0 ? 'The note split the closing balance works out to.' : 'Nothing is left in the drawer to count.'}
      </p>
    </div>
  );
};

const Tile: React.FC<{
  label: string; count: number; amount: number; decimals: boolean;
  open: boolean; onToggle: () => void;
  items: { date: string; number: string; party: string; status: string; amount: number }[];
}> = ({ label, count, amount, decimals, open, onToggle, items }) => (
  <div className="min-w-0">
    <button type="button" onClick={onToggle} aria-expanded={open}
      className="w-full flex items-center gap-2 rounded border border-blue-200/70 bg-blue-50 hover:bg-blue-100 px-3 py-2 text-left transition-colors">
      {open
        ? <ChevronDown className="w-3.5 h-3.5 text-[#1e88e5] shrink-0" />
        : <ChevronRight className="w-3.5 h-3.5 text-[#1e88e5] shrink-0" />}
      <span className="min-w-0 flex-1 truncate text-xs font-bold text-gray-700" title={label}>{label}</span>
      <span className="col-num text-[11px] text-gray-400">{count || '—'}</span>
      <span className="col-num text-xs font-black text-gray-800">{count ? money(amount, decimals) : '—'}</span>
    </button>
    {open && (
      <div className="mt-1 rounded border border-gray-200 divide-y divide-gray-100 overflow-hidden">
        {items.length ? items.map(it => (
          <div key={it.number} className="flex flex-wrap items-center gap-x-2 gap-y-0.5 px-3 py-1.5 text-[11px] bg-white">
            <span className="font-mono text-gray-500 shrink-0">{it.number}</span>
            <span className="min-w-0 flex-1 truncate text-gray-700 font-semibold" title={it.party}>{it.party}</span>
            <span className="text-gray-400 shrink-0">{it.date}</span>
            <span className="col-num font-bold text-gray-800">{money(it.amount, decimals)}</span>
          </div>
        )) : (
          <p className="px-3 py-2 text-[11px] text-gray-400 bg-white">Nothing was booked under this head in the period.</p>
        )}
      </div>
    )}
  </div>
);

export const BusinessSummaryReport: React.FC<Props> = ({ onNavigate }) => {
  const { tenantSlug, branchId, tenantName } = useTenant();
  const { can } = useAuth();
  const [from, setFrom] = useState(dayStart());
  const [to, setTo] = useState(today());
  const [query, setQuery] = useState({ from: dayStart(), to: today() });
  const [share, setShare] = useState(false);
  const [decimals, setDecimals] = useState(false);
  const [data, setData] = useState<BusinessSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openTile, setOpenTile] = useState<string>('');

  const load = useCallback(() => {
    setLoading(true); setError('');
    getBusinessSummary(tenantSlug, branchId, query.from, query.to)
      .then(setData)
      .catch(e => setError(String(e)))
      .finally(() => setLoading(false));
  }, [tenantSlug, branchId, query]);

  useEffect(load, [load]);
  useScreenReload(load);

  const period = `From ${query.from} to ${query.to}`;

  const ledgerSections = useMemo(
    () => (data?.sections ?? []).filter(s => ALWAYS_LEDGER.includes(s.key) || s.rows.length > 0),
    [data]
  );

  const cashSection = data?.sections.find(s => s.key === 'cash') ?? null;

  const journalTotals = useMemo(() => (data?.journals ?? []).reduce(
    (t, j) => ({ debit: t.debit + j.debit, credit: t.credit + j.credit }), { debit: 0, credit: 0 }), [data]);

  // "Show share" reads each posting's slice of the money that moved through the section,
  // so a single customer or invoice can be seen against the period's turnover.
  const shareOf = (s: SummarySection, r: { debit: number; credit: number }) => {
    const moved = s.rows.reduce((n, x) => n + Math.abs(x.debit - x.credit), 0);
    return moved ? `${(Math.abs(r.debit - r.credit) / moved * 100).toFixed(1)}%` : '—';
  };

  const printReport = (design?: PrintPrefs) => {
    if (!data) return;
    const pm = (v: number) => money(v, true);
    const sumBox = (s: SummarySection) => `<div class="box"><h3>${esc(s.label)} - Summary</h3>
      <div class="kv"><span>Opening</span><b>PKR ${pm(s.opening)}</b></div>
      ${s.rows.length
        ? `<div class="kv"><span>Money in</span><b>PKR ${pm(s.inflow)}</b></div>
           <div class="kv"><span>Money out</span><b>PKR ${pm(s.outflow)}</b></div>`
        : '<div class="noact">There is no activity</div>'}
      <div class="kv"><span>Closing</span><b>PKR ${pm(s.closing)}</b></div></div>`;

    const { notes, coins } = noteSplit(cashSection?.closing ?? 0);
    const cashBox = `<div class="box"><h3>Cash Detail</h3><div class="denom">${
      [...notes.map(n => ({ label: `${n.denom.toLocaleString()} x`, value: n.count })), { label: 'Coins', value: coins }]
        .map(n => `<i><span>${n.label}</span><b>${n.value}</b></i>`).join('')
    }</div></div>`;

    const grid = (head: { label: string; right?: boolean }[], rows: string[][], empty: string, foot?: string[]) =>
      `<div class="det"><table><thead><tr>${
        head.map(h => `<th${h.right ? ' class="r"' : ''}>${esc(h.label)}</th>`).join('')
      }</tr></thead><tbody>${
        rows.length
          ? rows.map(r => `<tr>${r.map((c, i) => `<td${head[i]?.right ? ' class="r"' : ''}>${esc(c)}</td>`).join('')}</tr>`).join('')
          : `<tr><td colspan="${head.length}" class="noact">${esc(empty)}</td></tr>`
      }${
        foot ? `<tr class="hd">${foot.map((c, i) => `<td${head[i]?.right ? ' class="r"' : ''}>${esc(c)}</td>`).join('')}</tr>` : ''
      }</tbody></table></div>`;

    const ledgerHead = [
      { label: 'Description' }, { label: 'Account' }, { label: 'Contact Name' },
      { label: 'Debit', right: true }, { label: 'Credit', right: true }, { label: 'Balance (PKR)', right: true }
    ];

    printSheet({
      title: 'Business Summary Report',
      headerHtml: `<div class="cover"><div class="co">${esc(tenantName)}</div><div class="ti">Business Summary Report</div></div>
        <div class="dates"><div>From Date: ${dmy(query.from)}</div><div>To Date: ${dmy(query.to)}</div></div>`,
      css: PRINT_CSS, pager: true, design, company: { name: tenantName },
      footRight: 'Powered By: app.xenitherp.com',
      bodyHtml: `
        <div class="grid3">${data.tiles.map(t =>
          `<div class="tile"><b>${esc(t.label)}</b><span>${t.count ? `${t.count} · ${pm(t.amount)}` : '—'}</span></div>`).join('')
        }</div>
        <div class="grid3">${cashSection ? `${sumBox(cashSection)}${cashBox}` : ''}</div>
        <div class="grid3">${data.sections.filter(s => s.key !== 'cash').map(sumBox).join('')}</div>
        ${ledgerSections.map(s => `<div class="st">${esc(s.label)} - Detail</div>${
          grid(ledgerHead, [
            ['Opening', s.accounts.join(', '), '—', '—', '—', pm(s.opening)],
            ...s.rows.map(r => [r.description, r.account, r.contact || '—', r.debit ? pm(r.debit) : '—', r.credit ? pm(r.credit) : '—', pm(r.balance)]),
            ['Closing', '', '—', s.rows.some(r => r.debit) ? pm(s.inflow) : '—', s.rows.some(r => r.credit) ? pm(s.outflow) : '—', pm(s.closing)]
          ], 'There is no activity')}`).join('')}
        <div class="st">Journal Entries</div>${
          grid([
            { label: 'Account' }, { label: 'Contact Name' }, { label: 'Description' },
            { label: 'Debit', right: true }, { label: 'Credit', right: true }
          ], data.journals.map(j => [j.account, j.contact || '—', j.description, j.debit ? pm(j.debit) : '—', j.credit ? pm(j.credit) : '—']),
            'There is no data available',
            data.journals.length ? ['Total', '', '', pm(journalTotals.debit), pm(journalTotals.credit)] : undefined)
        }`
    });
  };

  type SumRow = { section: string; date: string; description: string; account: string; contact: string; debit: number; credit: number; balance: number };

  // The workbook is the whole summary laid flat: one row per ledger line and journal entry,
  // so a pivot can be built off it without the screen's grouping.
  const excel = useMemo(() => {
    const rows: SumRow[] = (data?.sections ?? []).flatMap(s => [
      { section: s.label, date: '', description: 'Opening', account: s.accounts.join(', '), contact: '—', debit: 0, credit: 0, balance: s.opening },
      ...s.rows.map(r => ({ section: s.label, ...r })),
      { section: s.label, date: '', description: 'Closing', account: '', contact: '—', debit: 0, credit: 0, balance: s.closing }
    ]);
    (data?.journals ?? []).forEach(j => rows.push(
      { section: 'Journal Entry', date: j.date, description: j.description, account: j.account, contact: j.contact, debit: j.debit, credit: j.credit, balance: 0 }
    ));
    const columns: ExportColumn<SumRow>[] = [
      { label: 'Section', value: r => r.section },
      { label: 'Date', value: r => r.date },
      { label: 'Description', value: r => r.description },
      { label: 'Account', value: r => r.account },
      { label: 'Contact Name', value: r => r.contact },
      { label: 'Debit', value: r => r.debit, align: 'right' },
      { label: 'Credit', value: r => r.credit, align: 'right' },
      { label: 'Balance (PKR)', value: r => r.balance, align: 'right' }
    ];
    return { rows, columns };
  }, [data]);

  // The same front door as every other register: an untick refuses the summary before its tiles
  // and period boxes are drawn for someone who cannot call for them.
  if (!can('rep-business-summary-report:view')) return (
    <div className="card-xenith p-10 text-center">
      <XCircle className="w-7 h-7 text-gray-300 mx-auto mb-2" />
      <p className="card-title">This report is not open to your role</p>
      <p className="text-xs text-gray-400 mt-1">
        Ask an administrator to tick it for you under Setup → User Roles → Reports.
      </p>
      <button type="button" className="btn-xenith-outline mt-4" onClick={() => onNavigate('reports')}>
        Back to Reports
      </button>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="card-xenith p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <button onClick={() => onNavigate('reports')}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-gray-500 hover:text-[#1e88e5] transition-colors">
            <ArrowLeft className="w-3 h-3" /> All Reports
          </button>
          <h1 className="page-title mt-1">Business Summary Report</h1>
          <p className="text-xs text-gray-500 mt-1 max-w-2xl">
            Turnover by document head, and how cash, receivables, payables and undeposited money
            moved between the two dates.
          </p>
        </div>
        <button onClick={() => onNavigate('reports')} className="btn-xenith-warning ml-auto">
          <ArrowLeft className="w-3.5 h-3.5" /> BACK
        </button>
      </div>

      <div className="nb-card">
        <div className="nb-card-body !pb-2">
          <div className="flex flex-wrap items-end gap-x-4 gap-y-3">
            <label className="block min-w-0 w-40 max-w-full">
              <span className="param-label">From Date <span className="text-[#e63946]">*</span></span>
              <input type="date" value={from} max={to} onChange={e => setFrom(e.target.value)} className="input-xenith !min-w-0" />
            </label>
            <label className="block min-w-0 w-40 max-w-full">
              <span className="param-label">To Date <span className="text-[#e63946]">*</span></span>
              <input type="date" value={to} min={from} onChange={e => setTo(e.target.value)} className="input-xenith !min-w-0" />
            </label>
            <label className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-600 cursor-pointer pb-1.5">
              <input type="checkbox" checked={share} onChange={e => setShare(e.target.checked)} className="accent-[#1e88e5]" />
              Show share
            </label>
            <label className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-600 cursor-pointer pb-1.5">
              <input type="checkbox" checked={decimals} onChange={e => setDecimals(e.target.checked)} className="accent-[#1e88e5]" />
              With Decimal
            </label>
            <div className="flex flex-wrap items-center gap-2 ml-auto">
              <button onClick={() => setQuery({ from, to })} className="btn-xenith-success">
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> SHOW
              </button>
              <PrintMenuButton document="Business Summary Report" title="Business Summary Report"
                subtitle={`Period ${query.from} to ${query.to}`}
                className="btn-xenith-primary" label={<><Printer className="w-3.5 h-3.5" /> PRINT</>}
                onPrint={design => printReport(design)} />
              <ExcelMenuButton title="Business Summary Report"
                subtitle={`Period ${query.from} to ${query.to}`} org={tenantName}
                filename="business-summary" columns={excel.columns} rows={excel.rows}
                className="btn-xenith-outline !bg-[#3f51b5] !text-white !border-[#3f51b5] hover:!bg-[#303f9f]"
                label={<><Download className="w-3.5 h-3.5" /> EXPORT TO EXCEL</>} />
            </div>
          </div>
          {from > to && (
            <p className="mt-2 text-[11px] font-semibold text-[#e63946]">
              The from date has to come before the to date — press SHOW once it does.
            </p>
          )}
        </div>
      </div>

      {error && (
        <div className="text-xs font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-3 py-2">{error}</div>
      )}

      {!data && loading && <p className="text-xs text-gray-400">Loading the summary…</p>}

      {data && (
        <>
          <div className="nb-card">
            <div className="nb-card-header">Details</div>
            <div className="nb-card-body">
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {data.tiles.map(t => (
                  <Tile key={t.label} label={t.label} count={t.count} amount={t.amount} decimals={decimals}
                    items={t.items} open={openTile === t.label}
                    onToggle={() => setOpenTile(openTile === t.label ? '' : t.label)} />
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {data.sections.map(s => (
              <React.Fragment key={s.key}>
                <SummaryCard section={s} decimals={decimals} />
                {s.key === 'cash' && <CashDetailCard balance={s.closing} />}
              </React.Fragment>
            ))}
          </div>

          {ledgerSections.map(s => (
            <div className="nb-card" key={s.key}>
              <div className="nb-card-header">
                <span>{s.label} - Detail</span>
                <span className="text-[11px] font-normal text-gray-500">{s.rows.length} movement(s)</span>
              </div>
              <div className="nb-card-body !p-0">
                <table className="xenith-table">
                  <thead>
                    <tr>
                      <th className="w-[28%]">Description</th>
                      <th>Account</th>
                      <th>Contact Name</th>
                      <th className="text-right">Debit</th>
                      <th className="text-right">Credit</th>
                      {share && <th className="text-right">Share</th>}
                      <th className="text-right">Balance (PKR)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-gray-50/70">
                      <td className="font-bold text-gray-700">Opening</td>
                      <td className="text-gray-500">{s.accounts.join(', ')}</td>
                      <td>—</td>
                      <td className="text-right">—</td>
                      <td className="text-right">—</td>
                      {share && <td className="text-right">—</td>}
                      <td className="text-right font-black tabular-nums">{money(s.opening, decimals)}</td>
                    </tr>
                    {!s.rows.length && (
                      <tr>
                        <td colSpan={share ? 7 : 6} className="text-[#e63946] font-semibold">There is no activity</td>
                      </tr>
                    )}
                    {s.rows.map((r, i) => (
                      <tr key={`${r.date}-${r.description}-${i}`}>
                        <td className="font-semibold text-gray-700 break-words">{r.description}</td>
                        <td className="text-gray-500 break-words">{r.account}</td>
                        <td className="text-gray-600 break-words">{r.contact}</td>
                        <td className="text-right tabular-nums">{r.debit ? money(r.debit, decimals) : '—'}</td>
                        <td className="text-right tabular-nums">{r.credit ? money(r.credit, decimals) : '—'}</td>
                        {share && <td className="text-right tabular-nums text-gray-500">{shareOf(s, r)}</td>}
                        <td className={`text-right font-bold tabular-nums ${r.balance < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                          {money(r.balance, decimals)}
                        </td>
                      </tr>
                    ))}
                    <tr className="bg-blue-50/60">
                      <td className="font-black text-gray-800">Closing</td>
                      <td>—</td>
                      <td>—</td>
                      <td className="text-right font-bold tabular-nums">{s.rows.some(r => r.debit) ? money(s.rows.reduce((n, r) => n + r.debit, 0), decimals) : '—'}</td>
                      <td className="text-right font-bold tabular-nums">{s.rows.some(r => r.credit) ? money(s.rows.reduce((n, r) => n + r.credit, 0), decimals) : '—'}</td>
                      {share && <td className="text-right">{s.rows.length ? '100%' : '—'}</td>}
                      <td className={`text-right font-black tabular-nums ${s.closing < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                        {money(s.closing, decimals)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ))}

          <div className="nb-card">
            <div className="nb-card-header">
              <span>Journal Entries</span>
              <span className="text-[11px] font-normal text-gray-500">{period}</span>
            </div>
            <div className="nb-card-body !p-0">
              <table className="xenith-table">
                <thead>
                  <tr>
                    <th>Account</th>
                    <th>Contact Name</th>
                    <th className="w-[34%]">Description</th>
                    <th className="text-right">Debit</th>
                    <th className="text-right">Credit</th>
                  </tr>
                </thead>
                <tbody>
                  {!data.journals.length && (
                    <tr><td colSpan={5} className="text-[#e63946] font-semibold">There is no data available</td></tr>
                  )}
                  {data.journals.map((j, i) => (
                    <tr key={`${j.description}-${j.account}-${i}`}>
                      <td className="font-semibold text-gray-700 break-words">{j.account}</td>
                      <td className="text-gray-600 break-words">{j.contact}</td>
                      <td className="text-gray-500 break-words">{j.description}</td>
                      <td className="text-right tabular-nums">{j.debit ? money(j.debit, decimals) : '—'}</td>
                      <td className="text-right tabular-nums">{j.credit ? money(j.credit, decimals) : '—'}</td>
                    </tr>
                  ))}
                  {!!data.journals.length && (
                    <tr className="bg-blue-50/60">
                      <td colSpan={3} className="font-black text-gray-800">Total</td>
                      <td className="text-right font-black tabular-nums">{money(journalTotals.debit, decimals)}</td>
                      <td className="text-right font-black tabular-nums">{money(journalTotals.credit, decimals)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default BusinessSummaryReport;
