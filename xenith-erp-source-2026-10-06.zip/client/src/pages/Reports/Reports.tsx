import React, { useEffect, useMemo, useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { useInk } from '../../context/ThemeContext';
import { plateOn } from '../../utils/inkOn';
import { ReportCatalog } from '../../types';
import { getReportCatalog } from '../../services/reports.service';
import { ComboSelect } from '../../components/common/ComboSelect';
import {
  ArrowRight, BookOpen, Clock, FileBarChart, RefreshCw, Search, Star, X
} from 'lucide-react';
import { useScreenReload } from '../../utils/screenReload';

const FAV_KEY = 'xenith.report.favourites';
const RECENT_KEY = 'xenith.report.recent';

// A report is found by the words a bookkeeper types, not only by the words the title chose:
// "sales invoice", "invoice sale", "ageing" and "aging" all describe one row. Both sides are
// folded to the same lowercase, punctuation-free, singular form before anything is compared.
const normalise = (s: string) => s.toLowerCase()
  .replace(/[^a-z0-9 ]+/g, ' ')
  .replace(/\bageing\b/g, 'aging')
  .replace(/(\w)s\b/g, '$1')
  .replace(/\s+/g, ' ')
  .trim();

// The key, badge and group name count as the row's own words, so "fbr" or "hs" reaches the
// registers that never spell the term out in their title.
const wordsOf = (r: { title: string; desc: string; key: string; badge?: string },
  g: { label: string; name: string }) =>
  normalise(`${r.title} ${r.desc} ${r.key} ${r.badge ?? ''} ${g.label} ${g.name}`).split(' ');

// Two words stand for the same thing once they agree from the start for nearly all of the
// shorter one: "compare" finds "comparison", "collect" finds "collection", "age" finds
// "aging". Three letters is the floor, so a bare digit does not match every number.
const sameWord = (a: string, b: string) => {
  if (a === b) return true;
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i++;
  return i >= Math.max(3, Math.min(5, Math.min(a.length, b.length) - 1));
};

const readList = (key: string): string[] => {
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; }
};
const writeList = (key: string, list: string[]) => localStorage.setItem(key, JSON.stringify(list.slice(0, 8)));

interface Props {
  onNavigate: (tab: string) => void;
  onOpenReport?: (key: string) => void;
}

export const Reports: React.FC<Props> = ({ onNavigate, onOpenReport }) => {
  const { tenantSlug, branchId } = useTenant();
  const ink = useInk();
  const [catalog, setCatalog] = useState<ReportCatalog | null>(null);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  // The modules the reader wants side by side: no mark is the whole shelf, and several ticks are
  // several shelves at once.
  const [groups, setGroups] = useState<string[]>([]);
  const [favs, setFavs] = useState<string[]>(() => readList(FAV_KEY));
  const [recent, setRecent] = useState<string[]>(() => readList(RECENT_KEY));

  const load = () => {
    setError('');
    getReportCatalog(tenantSlug, branchId).then(setCatalog).catch(e => setError(String(e)));
  };
  useEffect(load, [tenantSlug, branchId]);
  useScreenReload(load);

  const all = useMemo(() => {
    const map = new Map<string, { key: string; title: string; desc: string; badge?: string; group: string; color: string }>();
    for (const g of catalog?.groups ?? [])
      for (const r of g.reports)
        map.set(r.key, { ...r, group: g.label, color: g.color });
    return map;
  }, [catalog]);

  const q = search.trim();
  // Every word has to appear somewhere in the row, in any order.
  const tokens = useMemo(() => normalise(q).split(' ').filter(Boolean), [q]);
  const visibleGroups = useMemo(() => (catalog?.groups ?? [])
    .filter(g => !groups.length || groups.includes(g.name))
    .map(g => ({ ...g, reports: g.reports.filter(r =>
      !tokens.length || tokens.every(t => wordsOf(r, g).some(w => sameWord(t, w)))) }))
    .filter(g => g.reports.length), [catalog, groups, tokens]);

  const open = (key: string) => {
    const next = [key, ...recent.filter(k => k !== key)];
    setRecent(next); writeList(RECENT_KEY, next);
    (onOpenReport ?? ((k: string) => onNavigate(`report:${k}`)))(key);
  };

  const toggleFav = (key: string) => {
    const next = favs.includes(key) ? favs.filter(k => k !== key) : [key, ...favs];
    setFavs(next); writeList(FAV_KEY, next);
  };

  const totalShown = visibleGroups.reduce((s, g) => s + g.reports.length, 0);

  return (
    <div className="space-y-4">
      <div className="card-xenith relative overflow-hidden p-5">
        <div className="absolute -top-16 -right-10 w-56 h-56 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle at center, #1e88e5, transparent 70%)' }} />
        <div className="relative flex flex-wrap items-end justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="w-10 h-10 rounded-xl grid place-items-center text-white shadow-sm"
              style={{ background: 'linear-gradient(135deg,#1565c0,#25a195)' }}>
              <FileBarChart className="w-5 h-5" />
            </span>
            <div>
              <h1 className="page-title">Reports</h1>
              <p className="text-xs text-gray-500">
                {catalog ? `${catalog.total} reports across ${catalog.groups.length} modules — every figure is read live from your documents` : 'Loading report catalog…'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ComboSelect className="!w-48" ariaLabel="Modules on show"
              allLabel="View: All Groups" searchPlaceholder="Search modules..."
              options={(catalog?.groups ?? []).map(g => ({ value: g.name, label: g.label }))}
              selected={groups}
              onToggle={v => setGroups(cur => cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v])}
              onClearAll={() => setGroups([])} />
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search reports"
                className="input-xenith !w-56 !pl-8" />
              {search && (
                <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <button onClick={load} className="btn-xenith-outline"><RefreshCw className="w-3.5 h-3.5" />Refresh</button>
          </div>
        </div>
      </div>

      {error && <div className="card-xenith p-4 text-xs text-red-600">{error}</div>}

      {(favs.length > 0 || recent.length > 0) && !q && (
        <div className="grid lg:grid-cols-2 gap-4">
          {favs.length > 0 && (
            <ShortcutCard label="Favourites" tone="#ff9f1c" icon={<Star className="w-3.5 h-3.5" />}
              keys={favs.filter(k => all.has(k))} all={all} onOpen={open} onNavigate={onNavigate} />
          )}
          {recent.length > 0 && (
            <ShortcutCard label="Recently opened" tone="#845ec2" icon={<Clock className="w-3.5 h-3.5" />}
              keys={recent.filter(k => all.has(k))} all={all} onOpen={open} onNavigate={onNavigate} />
          )}
        </div>
      )}

      {catalog && !visibleGroups.length ? (
        <div className="card-xenith p-10 text-center">
          <BookOpen className="w-7 h-7 text-gray-300 mx-auto mb-2" />
          {catalog.total ? (
            <>
              <p className="card-title">No report matches “{search}”</p>
              <p className="text-xs text-gray-400 mt-1">Try a document name like invoice, ledger, aging or valuation.</p>
            </>
          ) : (
            <>
              <p className="card-title">No report is open to your role</p>
              <p className="text-xs text-gray-400 mt-1">
                An administrator ticks the reports you may call for under Setup → User Roles → Reports.
              </p>
            </>
          )}
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 2xl:grid-cols-3 gap-4 items-start">
          {visibleGroups.map(g => (
            <div key={g.name} className="card-xenith overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-gray-50/60">
                <div className="flex items-center gap-2">
                  <span className="w-1 h-4 rounded-full" style={{ background: g.color }} />
                  <h2 className="section-title" style={{ color: ink(g.color) }}>{g.label}</h2>
                </div>
                <span className="text-[10px] font-bold text-gray-500 bg-white border border-gray-200 rounded-full px-2 py-0.5">
                  {g.reports.length}
                </span>
              </div>
              <div className="divide-y divide-gray-100 max-h-[560px] overflow-y-auto sidebar-scroll">
                {g.reports.map(r => {
                  const on = favs.includes(r.key);
                  return (
                    <div key={r.key} className="group flex items-start gap-2 px-3.5 py-2.5 hover:bg-blue-50/40 transition-colors">
                      <button onClick={() => open(r.key)} className="flex-1 min-w-0 text-left">
                        <span className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] font-bold text-[#1e88e5] group-hover:text-[#1565c0] transition-colors">
                            {r.title}
                          </span>
                          {r.badge && (
                            <span className="text-[8px] font-black uppercase tracking-wide px-1.5 py-px rounded-full"
                              style={{ ...plateOn(g.color) }}>{r.badge}</span>
                          )}
                          <ArrowRight className="w-3 h-3 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-gray-400" />
                        </span>
                        <span className="block text-[10px] text-gray-500 leading-snug mt-0.5">{r.desc}</span>
                      </button>
                      <button onClick={() => toggleFav(r.key)} title={on ? 'Remove from favourites' : 'Add to favourites'}
                        className={`shrink-0 mt-0.5 transition-colors ${on ? 'text-amber-500' : 'text-gray-300 hover:text-amber-400'}`}>
                        <Star className={`w-3.5 h-3.5 ${on ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {catalog && (
        <p className="text-[10px] text-gray-400 text-center pb-2">
          Showing {totalShown} of {catalog.total} reports · click a report to open it, star it to pin it here
        </p>
      )}
    </div>
  );
};

const ShortcutCard: React.FC<{
  label: string; tone: string; icon: React.ReactNode; keys: string[]; all: Map<string, any>;
  onOpen: (key: string) => void; onNavigate: (tab: string) => void;
}> = ({ label, tone, icon, keys, all, onOpen }) => (
  <div className="card-xenith p-4">
    <div className="flex items-center gap-2 mb-2">
      <span className="w-6 h-6 rounded grid place-items-center" style={{ background: `${tone}1a`, color: tone }}>{icon}</span>
      <h3 className="section-title">{label}</h3>
    </div>
    {!keys.length ? (
      <p className="text-[11px] text-gray-400">Nothing here yet.</p>
    ) : (
      <div className="flex flex-wrap gap-1.5">
        {keys.map(k => (
          <button key={k} onClick={() => onOpen(k)}
            className="text-[11px] font-semibold text-gray-700 bg-gray-50 hover:bg-white border border-gray-200 hover:border-gray-300 rounded-full px-2.5 py-1 transition-all hover:-translate-y-px">
            {all.get(k)?.title ?? k}
          </button>
        ))}
      </div>
    )}
  </div>
);

export default Reports;
