import React from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react';

// ── the report's own chrome ──────────────────────────────────────────────────
// A register is asked for in two sittings: the reader states what they want, then reads what
// comes back. These are the pieces both sittings are built from — the trail back to the hub, a
// labelled ask, the sheet of paper the answer is printed on, and the bar that pages it.

/** Where the reader is inside the report shelf, and the one click back to it. */
export const ReportCrumb: React.FC<{
  group?: string; title?: string; onBack: () => void; badge?: string;
}> = ({ group, title, onBack, badge }) => (
  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
    <div className="flex flex-wrap items-center gap-1.5 min-w-0">
      <button onClick={onBack}
        className="inline-flex items-center gap-1 font-bold text-gray-500 hover:text-[var(--accent-text)] transition-colors">
        <ArrowLeft className="w-3 h-3" /> Reports Hub
      </button>
      {group && (
        <>
          <ChevronRight className="w-3 h-3 text-gray-300" />
          <span className="font-bold uppercase tracking-wider text-gray-500">{group}</span>
        </>
      )}
      {title && (
        <>
          <ChevronRight className="w-3 h-3 text-gray-300" />
          <span className="font-black uppercase tracking-wider text-[var(--text)] truncate">{title}</span>
        </>
      )}
    </div>
    {badge && (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-emerald-200 bg-emerald-50 text-emerald-700 font-bold uppercase tracking-wide text-[10px]">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> {badge}
      </span>
    )}
  </div>
);

/** One ask in the form: its question above, its control below, the colon the paper form uses. */
export const Field: React.FC<{
  label: string; children: React.ReactNode; className?: string; wide?: boolean;
}> = ({ label, children, className = '', wide }) => (
  <label className={`block min-w-0 ${wide ? 'sm:col-span-2' : ''} ${className}`}>
    <span className="param-label !normal-case !tracking-normal !font-bold !text-[11px] text-gray-500">{label}:</span>
    <span className="block mt-1">{children}</span>
  </label>
);

/** The card a section of the form sits in, titled in the reference's own voice. */
export const AskSection: React.FC<{
  title: string; hint?: string; icon: React.ReactNode; children: React.ReactNode;
}> = ({ title, hint, icon, children }) => (
  <div className="card-xenith overflow-hidden">
    <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-gray-100">
      <span className="inline-flex items-center gap-2 text-[11px] font-black uppercase tracking-[.12em] text-emerald-700">
        {icon} {title}
      </span>
      {hint && <span className="text-[10px] font-semibold text-gray-400">{hint}</span>}
    </div>
    {children}
  </div>
);

/** A hairline between two blocks of the form. */
export const Rule: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`border-t border-gray-100 ${className}`} />
);

/** Small grey caps that name a row of the form. */
export const RowLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 shrink-0">{children}</span>
);

/** The two sittings of a presentation mode, struck as one segment. */
export const ModeSegment: React.FC<{
  value: string; options: { value: string; label: string; icon?: React.ReactNode }[];
  onPick: (v: string) => void; size?: 'sm' | 'md';
}> = ({ value, options, onPick, size = 'md' }) => (
  <span className="inline-flex items-center gap-1 rounded-lg border border-gray-200 bg-gray-50 p-1">
    {options.map(o => {
      const on = o.value === value;
      return (
        <button key={o.value} onClick={() => onPick(o.value)} aria-pressed={on}
          className={`inline-flex items-center gap-1.5 rounded-md font-bold transition-colors ${
            size === 'sm' ? 'px-2 py-1 text-[10px]' : 'px-3 py-1.5 text-[11px]'} ${
            on ? 'bg-emerald-600 text-white shadow-sm' : 'text-gray-600 hover:bg-white'}`}>
          {o.icon} {o.label}
        </button>
      );
    })}
  </span>
);

/**
 * The answer printed as a sheet of paper: the house tile and name centred at the top, the
 * statement it is filed under beneath, and the categorisation and the window the paper was cut
 * for in the two corners. The screen shows the same sheet the printer takes.
 */
export const PaperSheet: React.FC<{
  org: string; mark: string; heading: string; filing: string; window: string;
  children: React.ReactNode;
}> = ({ org, mark, heading, filing, window: win, children }) => (
  <div className="paper-sheet bg-white text-gray-900 rounded-xl shadow-[0_1px_3px_rgba(15,23,42,.12)] ring-1 ring-gray-200 overflow-hidden">
    <div className="px-5 sm:px-8 pt-6 pb-4 border-b-2 border-gray-800">
      <div className="flex items-start gap-4">
        <span className="w-11 h-11 shrink-0 rounded-lg bg-emerald-700 text-white grid place-items-center text-[13px] font-black tracking-tight">
          {mark}
        </span>
        <div className="flex-1 min-w-0 text-center">
          <h2 className="text-lg sm:text-xl font-black tracking-[.06em] uppercase leading-tight break-words">{org}</h2>
          <p className="text-[10px] font-bold uppercase tracking-[.1em] text-gray-600 mt-1">{heading}</p>
        </div>
        <span className="w-11 shrink-0" />
      </div>
      <div className="mt-3 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 text-[10px]">
        <p className="min-w-0">
          <span className="text-gray-500">Report Categorization: </span>
          <span className="font-black uppercase tracking-wide text-gray-900">{filing}</span>
        </p>
        <p className="shrink-0">
          <span className="text-gray-500">Duration Window Block: </span>
          <span className="font-black text-gray-900">{win}</span>
        </p>
      </div>
    </div>
    <div className="px-5 sm:px-8 py-4">{children}</div>
  </div>
);

/** "Showing 1 to 19 of 19 records · Page 1 of 1", the page size, and the page numbers. */
export const SheetPager: React.FC<{
  from: number; to: number; of: number; noun: string;
  page: number; pages: number; pageSize: number; sizes: number[];
  onPage: (n: number) => void; onSize: (n: number) => void;
}> = ({ from, to, of, noun, page, pages, pageSize, sizes, onPage, onSize }) => (
  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-gray-600">
    <span>
      Showing <b className="text-gray-900">{from}</b> to <b className="text-gray-900">{to}</b> of{' '}
      <b className="text-gray-900">{of.toLocaleString()}</b> {noun}
      {' '}· Page {page} of {pages}
    </span>
    <span className="flex items-center gap-1.5">
      <span className="text-gray-400 font-bold">Per Page:</span>
      <select value={pageSize} onChange={e => onSize(Number(e.target.value))}
        className="input-xenith !py-1 !px-1.5 !w-auto text-[11px]">
        {sizes.map(n => <option key={n} value={n}>{n}</option>)}
      </select>
      <button disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page"
        className="w-7 h-7 grid place-items-center rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50">
        <ChevronLeft className="w-3.5 h-3.5" />
      </button>
      {Array.from({ length: Math.min(pages, 5) }, (_, i) => {
        const n = Math.min(Math.max(1, page - 2), Math.max(1, pages - 4)) + i;
        return n > pages ? null : (
          <button key={n} onClick={() => onPage(n)}
            className={`w-7 h-7 rounded border font-bold tabular-nums transition-colors ${
              n === page ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
            {n}
          </button>
        );
      })}
      <button disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next page"
        className="w-7 h-7 grid place-items-center rounded border border-gray-200 text-gray-600 disabled:opacity-40 hover:bg-gray-50">
        <ChevronRight className="w-3.5 h-3.5" />
      </button>
    </span>
  </div>
);
