import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { useInk } from '../../context/ThemeContext';
import { ReportCatalog, ReportColType, ReportColumn, ReportParam, ReportPayload } from '../../types';
import { getReport, getReportCatalog } from '../../services/reports.service';
import { AgingBucketsModal } from '../../components/modals/AgingBucketsModal';
import { ExportColumn, PrintBand } from '../../utils/exportTable';
import { plateOn } from '../../utils/inkOn';
import { ExcelMenuButton, PrintMenuButton } from '../../components/print/PrintTemplateModal';
import { printTableWithLetterhead } from '../../utils/printWithLetterhead';
import { PrintPrefs } from '../../utils/printDesigns';
import { isoDay, monthStart } from '../../utils/dateRange';
import { Pick } from '../Masters/masterUi';
import { ComboSelect } from '../../components/common/ComboSelect';
import {
  ArrowLeft, ArrowRight, BarChart3, Bookmark, CheckCircle2, ChevronLeft, Download, FileText,
  FileSearch, LayoutGrid, ListFilter, Printer, RefreshCw, RotateCw,
  Save, Search, SlidersHorizontal, XCircle, X
} from 'lucide-react';
import { AskSection, Field, ModeSegment, PaperSheet, ReportCrumb, RowLabel, Rule, SheetPager } from './ReportChrome';

const GROUP_COLORS: Record<string, string> = {
  'Sales': '#1e88e5', 'Purchase': '#845ec2', 'Manufacturing': '#f7b32b', 'CRM': '#2ec4b6',
  'Inventory': '#ff9f1c', 'Business Overview': '#5f7cff', 'Accounts': '#e63946',
  'Human Resources': '#d81b60'
};

const fmt = (v: any, type: ReportColType | undefined, decimals: boolean) => {
  if (v === null || v === undefined || v === '') return '—';
  const n = typeof v === 'number' ? v : Number(v);
  const numeric = !Number.isNaN(n) && typeof v !== 'string';
  if (numeric) {
    if (type === 'money') return n.toLocaleString(undefined, { minimumFractionDigits: decimals ? 2 : 0, maximumFractionDigits: decimals ? 2 : 0 });
    if (type === 'pct') return `${n.toFixed(2)}%`;
    if (type === 'int' || type === 'qty') return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  return String(v);
};
const isNumeric = (type?: ReportColType) => !!type && ['money', 'int', 'qty', 'pct'].includes(type);
// A percentage is a ratio of its own row, so adding that column across rows says nothing.
const isSummed = (type?: ReportColType) => isNumeric(type) && type !== 'pct';
// On screen a column sits under its band heading, so its label can be short. A chip, a sheet
// and a print line have no heading to lean on — there "Discount" twice is two figures nobody
// can tell apart.
const flatLabel = (c: { label: string; band?: string }) => (c.band ? `${c.band} · ${c.label}` : c.label);

// A headline figure the reader is hunting for is a money one, so it carries the accent on the
// sheet and on the printed paper; a plain count stays in ink.
const isMoneyFigure = (label: string) => /revenue|total|amount|balance/i.test(label);

const statusTone = (v: string) =>
  v === 'Approved' || v === 'Converted' || v === 'Completed' || v === 'Fully Delivered' ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
    : v === 'Pending' || v === 'Running' || v === 'Part Delivered' || v === 'Proposal' ? 'bg-amber-50 text-amber-700 border-amber-200'
      : v === 'Void' || v === 'Lost' || v === 'Cancelled' || v === 'Not Delivered' ? 'bg-red-50 text-red-700 border-red-200'
        : 'bg-gray-50 text-gray-600 border-gray-200';

type Comparison = 'none' | 'previous' | 'lastYear';

// The reference registers strike themselves on the page: "… Report (As of: 24/09/2026)".
const dayUk = (iso: string) => (iso || '').split('-').reverse().join('/');

// A ticked dropdown carries several records in one parameter, parted by a pipe — the same shape
// the server's report engine splits a pick on.
const listValue = (v: string | undefined) => (v && v !== 'all' ? v.split('|').filter(Boolean) : []);
const joinValue = (v: string[]) => v.join('|');
const toggleIn = (cur: string[], v: string) =>
  cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v];
// A mark is written against the value already stored rather than the one this render drew, so
// two ticks landing in the same beat of the loop both stay marked.
type Marks = string | ((prev: string) => string);
const markOf = (has: Record<string, string>, key: string, v: Marks) =>
  typeof v === 'function' ? v(has[key] ?? '') : v;

// The reference's tick list opens by naming what a clear box lets through: "All Customers".
const plural = (label: string) => {
  if (/salesman$/i.test(label)) return label.replace(/salesman$/i, 'Salesmen');
  if (/(ch|s|x|z)$/i.test(label)) return `${label}es`;
  if (/[^aeiou]y$/i.test(label)) return `${label.slice(0, -1)}ies`;
  return `${label}s`;
};

// A ticked checkbox asks for '1'; the paper copy should read the name of the choice, not the flag.
const paramLabel = (p: ReportParam | undefined, v: string): string => {
  const list = listValue(v);
  if (list.length > 1) return list.map((x: string) => paramLabel(p, x)).join(', ');
  const one = list[0] ?? v;
  return p?.options?.find(o => o.value === one)?.label ?? (one === '1' ? 'yes' : one);
};

const shiftYear = (d: string) => {
  const [y, m, day] = d.split('-').map(Number);
  return `${y - 1}-${String(m).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
};
const shiftDays = (d: string, n: number) => {
  const t = new Date(`${d}T00:00:00Z`).getTime() + n * 86400000;
  return new Date(t).toISOString().slice(0, 10);
};
const daySpan = (lo: string, hi: string) => Math.max(1, Math.round((new Date(`${hi}T00:00:00Z`).getTime() - new Date(`${lo}T00:00:00Z`).getTime()) / 86400000) + 1);

// ── one filter box under every column ────────────────────────────────────────
// A register is cut the way a reader thinks about it: these three customers, these five bills,
// the paper of the first week. The columns that name a thing carry a box of their own — a list of
// values to tick where the book holds few, a word to search where it holds many, two days where it
// holds dates. The figures are the answer, not a question, so no column of money or quantity is
// narrowed by hand.
interface ColumnAsk { key: string; label: string; kind: 'list' | 'text' | 'date'; options?: string[] }

// The key a column's ask is stored under. A tick list marks whole values, so it travels as the
// column's own name — the shape the register engine has always cut on. The asks that are not a
// list of values name their column after a dot, so no box can be mistaken for another.
const ASK_PREFIX = { text: '__cq', date: '__dq' } as const;
const askKey = (f: ColumnAsk) => f.kind === 'list' ? f.key : `${ASK_PREFIX[f.kind]}.${f.key}`;
const ends = (v: string) => { const [lo = '', hi = ''] = (v || '').split('|'); return { lo, hi }; };

// An ask in words, the way a chip and a printed line have to carry it: a tick list names the marks
// it holds, a search names the word, and a pair of boxes names the span between them.
const askText = (f: ColumnAsk, v: string): string => {
  if (f.kind === 'list') return listValue(v).join(', ');
  if (f.kind === 'text') return v;
  const { lo, hi } = ends(v);
  return `${lo ? dayUk(lo) : 'the start'} – ${hi ? dayUk(hi) : 'no end'}`;
};

// A box holds what the reader types until that typing settles: a search asked one keystroke at a
// time is four reads of the register, and the slowest answer is usually the oldest question. An
// ask taken off from anywhere else on the screen — a chip, Clear all, another register opening —
// takes this box back with it instead of arguing with the value the register answers on.
const FilterDraft: React.FC<{
  value: string; onAsk: (v: string) => void; placeholder: string; title: string;
}> = ({ value, onAsk, placeholder, title }) => {
  const [draft, setDraft] = useState(value);
  const sent = useRef(value);
  const ask = useRef(onAsk);
  useEffect(() => { ask.current = onAsk; }, [onAsk]);
  useEffect(() => {
    if (value === sent.current) return;
    sent.current = value;
    setDraft(value);
  }, [value]);
  useEffect(() => {
    if (draft === sent.current) return;
    const t = window.setTimeout(() => { sent.current = draft; ask.current(draft.trim()); }, 400);
    return () => window.clearTimeout(t);
  }, [draft]);
  return (
    <input value={draft} onChange={e => setDraft(e.target.value)} placeholder={placeholder}
      aria-label={title} title={title}
      className="input-xenith w-full !min-w-0" />
  );
};

// A column cut between two days asks one question, so both boxes are held here and travel up as a
// single ask. One timer for the pair: the register is read once, not once per end typed.
const FilterPair: React.FC<{
  value: string; onAsk: (v: string) => void;
  placeholders: [string, string]; title: string;
}> = ({ value, onAsk, placeholders, title }) => {
  const [pair, setPair] = useState(() => ends(value));
  const sent = useRef(value);
  const ask = useRef(onAsk);
  useEffect(() => { ask.current = onAsk; }, [onAsk]);
  useEffect(() => {
    if (value === sent.current) return;
    sent.current = value;
    setPair(ends(value));
  }, [value]);
  useEffect(() => {
    const joined = pair.lo || pair.hi ? `${pair.lo}|${pair.hi}` : '';
    if (joined === sent.current) return;
    const t = window.setTimeout(() => { sent.current = joined; ask.current(joined); }, 400);
    return () => window.clearTimeout(t);
  }, [pair]);
  const box = (which: 'lo' | 'hi') => ({
    type: 'date' as const, value: pair[which], placeholder: placeholders[which === 'lo' ? 0 : 1],
    'aria-label': `${title} ${placeholders[which === 'lo' ? 0 : 1]}`,
    title: `${title} — ${placeholders[which === 'lo' ? 0 : 1]}`,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
      setPair(p => ({ ...p, [which]: e.target.value })),
    className: 'input-xenith w-full !min-w-0'
  });
  return (
    <span className="grid grid-cols-2 gap-2">
      <input {...box('lo')} />
      <input {...box('hi')} />
    </span>
  );
};

interface Props { reportKey: string; onNavigate: (tab: string) => void }

const NO_PARAMS: Record<string, string> = {};
const PAGE_SIZES = [25, 50, 100, 250, 1000];

// A set of asks the reader comes back to. This lives on the machine it was struck on and nowhere
// else: a shortcut to the filters is not a record of the book, and it should not pretend to be
// one the day the file is carried to another till.
interface Preset {
  name: string; from: string; to: string;
  filt: Record<string, string>; param: Record<string, string>;
}
const presetKey = (slug: string, key: string) => `xenith:report-preset:${slug}:${key}`;
const readPresets = (slug: string, key: string): Preset[] => {
  try {
    const raw = window.localStorage.getItem(presetKey(slug, key));
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list.filter(p => p && typeof p.name === 'string') : [];
  } catch { return []; }
};
const writePresets = (slug: string, key: string, list: Preset[]) => {
  try { window.localStorage.setItem(presetKey(slug, key), JSON.stringify(list)); } catch { /* a full or private store simply keeps nothing */ }
};

// A report's own band headings sit above the columns; a column with no band stands alone
// and spans both header rows.
interface HeaderGroup { band: string; span: number; cols: ReportColumn[] }
interface DocBlock { key: string; head: { label: string; value: string }[]; rows: Record<string, any>[] }
// One ask the register is answering right now, in words, with the click that takes it back off.
// `asked` marks the reader's own filter as against the window the report opened on, so a Reset
// button does not stand on every report for the sake of a default.
interface Applied { key: string; label: string; value: string; clear: () => void; asked: boolean }

// The screen is remounted for every register the reader opens, so a register's asks are held
// outside it: walking BACK to a report finds the window, the parameters and the column filters
// that were left there. Each one is still named on the Applied chips, so nothing narrows the
// paper quietly on account of a visit two screens ago.
type ScreenAsk = { from: string; to: string; filt: Record<string, string>; param: Record<string, string> };
const askedByScreen = new Map<string, ScreenAsk>();

export const ReportViewer: React.FC<Props> = ({ reportKey, onNavigate }) => {
  const { tenantSlug, branchId, tenantName } = useTenant();
  const { user, can } = useAuth();
  const screenKey = `${tenantSlug}:${branchId}:${reportKey}`;
  const left = askedByScreen.get(screenKey);
  const [data, setData] = useState<ReportPayload | null>(null);
  const [catalog, setCatalog] = useState<ReportCatalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [from, setFrom] = useState(left?.from ?? monthStart());
  const [to, setTo] = useState(left?.to ?? isoDay());
  const [search, setSearch] = useState(left?.filt.__q ?? '');
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const [decimals, setDecimals] = useState(false);
  const [comparison, setComparison] = useState<Comparison>('none');
  const [asOf, setAsOf] = useState('');
  const [agingOpen, setAgingOpen] = useState(false);
  // Declared parameters are asked of the server, so the totals on screen close over the
  // same rows the table shows. Values are kept per report so BACK/next does not lose them.
  const [pickedByReport, setPickedByReport] = useState<Record<string, Record<string, string>>>(
    () => ({ [reportKey]: left?.param ?? NO_PARAMS }));
  const picked = pickedByReport[reportKey] ?? NO_PARAMS;
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  // A register is asked for in two sittings, the way the reference paper works: the reader states
  // the constraints, then reads the sheet that comes back. Opening a report always starts at the
  // statement of asks — the sheet is an answer to a question, not a place to land.
  const [stage, setStage] = useState<'form' | 'sheet'>('form');
  const [presets, setPresets] = useState<Preset[]>(() => readPresets(tenantSlug, reportKey));
  const [naming, setNaming] = useState(false);
  const [presetName, setPresetName] = useState('');
  // Summary reads the register in its bands; detailed lays the same rows out line by line, which
  // is what an auditor chasing one entry wants. A register with no bands has only one reading.
  const [mode, setMode] = useState<'summary' | 'detailed'>('summary');
  // Null until the reader says otherwise: a wide register is laid across the paper by itself.
  const [landscape, setLandscape] = useState<boolean | null>(null);

  // The screen's own filters, kept per register: a column ticked here never follows the reader
  // onto a register whose rows do not hold that column, and a search typed here is still here
  // after a walk to the next report and back. A key is either a column's own name — a tick list of
  // its values — or a scoped one (`__cq.column`, `__dq.column`) for the asks that are not a list,
  // alongside the reserved `__q` and `__nz` no single column answers. These are
  // the keys the server's filter layer reads, so the tiles, the footer and the printed paper all
  // answer for the rows the filter left standing rather than the whole book.
  const [ufByReport, setUfByReport] = useState<Record<string, Record<string, string>>>(
    () => ({ [reportKey]: left?.filt ?? NO_PARAMS }));
  const uf = ufByReport[reportKey] ?? NO_PARAMS;

  // What the reader leaves on this register travels with it, so the next visit opens on the
  // same ask rather than on the whole book.
  useEffect(() => {
    askedByScreen.set(screenKey, {
      from, to,
      filt: ufByReport[reportKey] ?? NO_PARAMS,
      param: pickedByReport[reportKey] ?? NO_PARAMS
    });
  }, [screenKey, reportKey, from, to, ufByReport, pickedByReport]);

  const setUf = (key: string, value: Marks) => {
    setPage(1);
    setUfByReport(p => {
      const cur = p[reportKey] ?? NO_PARAMS;
      return { ...p, [reportKey]: { ...cur, [key]: markOf(cur, key, value) } };
    });
  };

  const setParam = (key: string, value: Marks) => {
    setPage(1);
    setPickedByReport(p => {
      const cur = p[reportKey] ?? NO_PARAMS;
      return { ...p, [reportKey]: { ...cur, [key]: markOf(cur, key, value) } };
    });
  };

  // A typed box would otherwise send a read per keystroke; the register narrows on screen the
  // instant it is typed and asks the server a beat after the typing settles.
  useEffect(() => {
    const want = search.trim();
    if ((uf.__q ?? '') === want) return;
    const t = window.setTimeout(() => setUf('__q', want), 400);
    return () => window.clearTimeout(t);
  }, [search, uf.__q]);

  // The register narrows on screen the instant a box is typed in and asks the server a beat after
  // the typing settles; every one of its own boxes holds that beat, so nothing else has to wait.

  // The group's own hue, read at the depth this theme's surface asks for: a saturated
  // periwinkle is ink enough on white and sinks into a midnight card.
  const ink = useInk();
  const color = ink(GROUP_COLORS[data?.group ?? ''] ?? '#1e88e5');
  const cols = data?.columns ?? [];
  const statement = !!data?.statement;
  // A statement groups its rows with heading bands, so the section column would only repeat them.
  const shownCols = statement ? cols.filter(c => c.key !== 'section') : cols;
  const dateCol = useMemo(() => cols.find(c => c.type === 'date')?.key, [cols]);
  const bucketCol = useMemo(() => cols.find(c => c.key === 'bucket')?.key, [cols]);
  // A report can be banded without showing the band as a column (the receivable split is one
  // column per band), so the server says so outright rather than the button guessing.
  const canConfigureAging = !!bucketCol || !!data?.agingDriven;
  const declaredParams = data?.params ?? [];
  const groupBy = data?.groupBy;
  const shareRow = data?.shareRow;
  const totalsLabel = data?.totalsLabel;

  // A report that names its own date window owns it outright: the server has already cut the
  // rows to it, so the screen must not lay a second pair of pickers over the top.
  const ownFrom = declaredParams.some(p => p.kind === 'from');
  const ownTo = declaredParams.some(p => p.kind === 'to');
  const ownAsOf = declaredParams.some(p => p.kind === 'asof');
  const ownsWindow = ownFrom || ownTo || ownAsOf;
  // An "As of" report is struck at a single day and its rows carry the history that built the
  // running figure, so the screen must not hide the earlier lines behind its own month window.
  const cuts = ownFrom || ownTo || !ownAsOf;
  // Whichever pair of dates the screen is actually asking for: its own tiles, or the ones the
  // report declared and the server cut the rows with.
  const winFrom = ownFrom ? (picked.from ?? '') : (cuts ? from : '');
  const winTo = ownTo ? (picked.to ?? '') : (cuts ? to : '');

  // What the register is asked for beyond its own parameters: the screen's filters as the
  // server reads them, plus the period pair the screen is holding. A statement is left alone —
  // it writes its own subtotals before anything narrows its rows, so its screen filters stay
  // the local cut they have always been, and its tiles already answer for the whole paper.
  // Every input here is a value rather than the payload itself, deliberately: reading the
  // payload would give this map a fresh identity on each answer, and the register would then
  // fetch itself in a circle.
  const filt = useMemo(() => {
    if (statement) return NO_PARAMS;
    const out: Record<string, string> = { ...uf };
    if (dateCol && cuts) {
      if (!ownFrom && from) out.__from = from;
      if (!ownTo && to) out.__to = to;
    }
    Object.keys(out).forEach(k => { if (!out[k] || out[k] === 'all') delete out[k]; });
    return out;
  }, [statement, dateCol, cuts, ownFrom, ownTo, from, to, uf]);

  // Two filters changed in a row send two reads, and the slower one is usually the older
  // question. Without this the register can finish on the figure the cashier asked first.
  const asked = React.useRef(0);
  const load = useCallback(() => {
    const mine = ++asked.current;
    setLoading(true); setError('');
    getReport(tenantSlug, branchId, reportKey, asOf, picked, filt)
      .then(d => { if (mine !== asked.current) return; setData(d); if (d.asOf) setAsOf(a => a || d.asOf!); })
      .catch(e => { if (mine === asked.current) setError(String(e)); })
      .finally(() => { if (mine === asked.current) setLoading(false); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantSlug, branchId, reportKey, asOf, picked, filt]);

  useEffect(load, [load]);
  useEffect(() => { getReportCatalog(tenantSlug, branchId).then(setCatalog).catch(() => setCatalog(null)); }, [tenantSlug, branchId]);

  // A fresh report opens on its own filters, not the ones the last register was narrowed with.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { setSearch(ufByReport[reportKey]?.__q ?? ''); setSort(null); setPage(1); }, [reportKey]);

  // A dropdown with nothing in it is a question nobody can answer, so an empty pick stands down;
  // the Batch filter returns on its own once documents start carrying batches.
  const paramTiles = useMemo(
    () => declaredParams.filter(p => p.kind !== 'pick' || (p.options?.length ?? 0) > 0),
    [declaredParams]);
  // A register's date asks are the window row of the form — the pair of days the sheet is cut
  // over — rather than fields standing among the column asks. The rest sit in the grid.
  const windowTiles = useMemo(
    () => paramTiles.filter(p => p.kind === 'asof' || p.kind === 'from' || p.kind === 'to'),
    [paramTiles]);
  const fieldTiles = useMemo(
    () => paramTiles.filter(p => p.kind !== 'asof' && p.kind !== 'from' && p.kind !== 'to'),
    [paramTiles]);
  // The reference sheet names its order in words the reader thinks in — "Date (Newest First)" —
  // so each column offers both directions of its own kind.
  const sortOptions = useMemo(() => shownCols.flatMap(c => {
    const pair = c.type === 'date' ? [['Newest First', -1], ['Oldest First', 1]]
      : isNumeric(c.type) ? [['High to Low', -1], ['Low to High', 1]]
        : [['A to Z', 1], ['Z to A', -1]];
    return pair.map(([how, dir]) => ({ value: `${c.key}|${dir}`, label: `${flatLabel(c)} (${how})` }));
  }), [shownCols]);

  // The reference form opens with its window already struck, and so does this one: a register that
  // declares a pair of dates and is handed an empty pair is being asked for the whole book, which
  // is the slowest question in the building and rarely the one the reader came to ask. Once per
  // register — a window the reader clears by hand stays cleared.
  const struckFor = useRef('');
  useEffect(() => {
    if (!data || struckFor.current === screenKey) return;
    struckFor.current = screenKey;
    const want: Record<string, string> = {};
    if (data.params?.some(p => p.kind === 'from') && !picked.from) want.from = monthStart();
    if (data.params?.some(p => p.kind === 'to') && !picked.to) want.to = isoDay();
    if (Object.keys(want).length) {
      setPickedByReport(m => ({ ...m, [reportKey]: { ...(m[reportKey] ?? NO_PARAMS), ...want } }));
    }
  }, [data, screenKey, reportKey, picked.from, picked.to, setPickedByReport]);


  // Every column the register can be cut on, each with the box that column asks for. The engine
  // answers this rather than the screen guessing which columns happen to read low-cardinality — so
  // a tick list keeps every name the book holds instead of shrinking to whatever the last tick left
  // standing, and a report that declares its own form gains boxes for the columns that form never
  // thought to ask about.
  const colAsks = useMemo<ColumnAsk[]>(() => data?.facets ?? [], [data]);
  // One ask per shown column, whichever way it is asked. A dropdown the report declares with no
  // choices left in the book is a question nobody can tick, so that column keeps a typed search
  // instead — the server reads it against the same rows either way.
  const extraAsks = useMemo<ColumnAsk[]>(() => declaredParams
    .filter(p => p.kind === 'pick' && !(p.options?.length ?? 0) && p.col)
    .map(p => ({ key: p.col!, label: p.label, kind: 'text' as const }))
    .filter(f => shownCols.some(c => c.key === f.key)), [declaredParams, shownCols]);
  const allAsks = useMemo(() => [...colAsks, ...extraAsks], [colAsks, extraAsks]);
  // The register's own period window is this column's date filter already, so the form keeps one
  // pair of days for it rather than laying a second, contradictory window beside it.
  const periodAsk = dateCol && cuts ? dateCol : '';

  // Which columns the reader has actually asked, and what each ask says in words. The chips over
  // the table, the strip under the letterhead and the spreadsheet cover all read this list, so the
  // three cannot disagree about what a register was cut by.
  const activeAsks = useMemo(
    () => allAsks.map(f => ({ f, v: uf[askKey(f)] ?? '' })).filter(x => !!x.v && x.v !== 'all'),
    [allAsks, uf]);
  const hideZero = uf.__nz === '1';
  const activeParams = Object.entries(picked).filter(([, v]) => !!v && v !== 'all');

  // The same questions the server's filter layer bit on, asked over the rows here as well: the
  // table narrows the instant a box settles rather than a beat later when the answer lands, and
  // both readings keep the same rows, so the tiles above and the paper below never disagree.
  const narrows = useCallback((r: Record<string, any>) => allAsks.every(f => {
    const v = uf[askKey(f)] ?? '';
    if (!v || v === 'all') return true;
    const cell = r[f.key];
    if (f.kind === 'list') return listValue(v).includes(String(cell ?? '').trim());
    if (f.kind === 'text') return String(cell ?? '').toLowerCase().includes(v.trim().toLowerCase());
    const { lo, hi } = ends(v);
    const d = String(cell ?? '');
    // A row carrying no date is not a row outside the window — an aggregate register keeps its
    // open figures whatever the window says. The server reads that row the same way.
    if (d.length !== 10) return true;
    return (!lo || d >= lo) && (!hi || d <= hi);
  }), [allAsks, uf]);

  const withinRange = useCallback((rows: Record<string, any>[], lo: string, hi: string) =>
    !dateCol ? rows : rows.filter(r => {
      const d = String(r[dateCol] ?? '');
      // A row carrying no date is not a row outside the window — an aggregate register keeps its
      // open figures whatever the window says. The server reads the same row the same way.
      return d.length !== 10 || ((!lo || d >= lo) && (!hi || d <= hi));
    }), [dateCol]);

  const range = useMemo(() => {
    if (!dateCol && !ownFrom && !ownTo) return null;
    const dates = (data?.rows ?? []).map(r => String(r[dateCol ?? ''] ?? '')).filter(d => d.length === 10).sort();
    const lo = winFrom || dates[0] || '';
    const hi = winTo || dates[dates.length - 1] || '';
    return lo && hi ? { lo, hi } : null;
  }, [data, dateCol, winFrom, winTo, ownFrom, ownTo]);

  const comparisonRange = useMemo(() => {
    if (!range || comparison === 'none') return null;
    if (comparison === 'lastYear') return { lo: shiftYear(range.lo), hi: shiftYear(range.hi) };
    const span = daySpan(range.lo, range.hi);
    return { lo: shiftDays(range.lo, -span), hi: shiftDays(range.lo, -1) };
  }, [range, comparison]);

  const moneyCols = useMemo(() => cols.filter(c => c.type === 'money'), [cols]);
  const closingKeys = useMemo(() => new Set(data?.closingTotals ?? []), [data]);

  // A running column closes on its last figure. Where the ledger runs one line per account
  // it closes account by account, so the footer is what every account still carries rather
  // than the balance of whichever document happens to be last on the page.
  const closingOf = useCallback((rows: Record<string, any>[], key: string) => {
    const group = data?.closingGroups?.[key];
    if (!group) return Number([...rows].reverse().find(r => typeof r[key] === 'number')?.[key]) || 0;
    const last = new Map<string, number>();
    for (const r of rows) if (typeof r[key] === 'number') last.set(String(r[group] ?? ''), Number(r[key]));
    return roundMoney([...last.values()].reduce((s, v) => s + v, 0));
  }, [data]);

  const sumOf = useCallback((rows: Record<string, any>[], key: string) =>
    closingKeys.has(key)
      ? closingOf(rows, key)
      : rows.reduce((s, r) => s + (Number(r[key]) || 0), 0), [closingKeys, closingOf]);

  // The comparison is the same register read over the stretch before it, with every filter the
  // screen holds still applied. Asking the server for that window rather than fishing earlier
  // rows out of the answer already on screen is the only honest way round: the window the
  // register was cut to no longer holds the period being compared with.
  const [compareData, setCompareData] = useState<ReportPayload | null>(null);
  const compAsked = React.useRef(0);
  useEffect(() => {
    if (!comparisonRange || statement) { setCompareData(null); return; }
    const mine = ++compAsked.current;
    getReport(tenantSlug, branchId, reportKey, asOf, picked,
      { ...filt, __from: comparisonRange.lo, __to: comparisonRange.hi })
      .then(d => { if (mine === compAsked.current) setCompareData(d); })
      .catch(() => { if (mine === compAsked.current) setCompareData(null); });
  }, [comparisonRange, statement, tenantSlug, branchId, reportKey, asOf, picked, filt]);

  const compareRows = compareData?.rows ?? null;

  const rows = useMemo(() => {
    let out = withinRange(data?.rows ?? [], winFrom, winTo);
    out = out.filter(narrows);
    // The same families of figure the server's filter bit on, so a register cleared of its
    // zero rows on screen cannot carry a row the paper copy still counts.
    if (hideZero) {
      const figs = cols.filter(c => c.type === 'money' || c.type === 'int' || c.type === 'qty');
      if (figs.length) out = out.filter(r => figs.some(c => Math.abs(Number(r[c.key]) || 0) > 0));
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      out = out.filter(r => cols.some(c => String(r[c.key] ?? '').toLowerCase().includes(q)));
    }
    if (sort) out = [...out].sort((a, b) => {
      const x = a[sort.key], y = b[sort.key];
      if (typeof x === 'number' && typeof y === 'number') return (x - y) * sort.dir;
      return String(x ?? '').localeCompare(String(y ?? '')) * sort.dir;
    });
    return out;
  }, [data, winFrom, winTo, withinRange, narrows, hideZero, search, sort, cols]);

  // How wide the register was before any of the screen's asks bit. The server answers with it,
  // because its rows are now the narrowed ones — a count of "40 of 40" would say nothing.
  const registerRows = data?.rowCount ?? data?.rows.length ?? 0;

  // The server says which columns its footer closes, so a rate or an average sitting beside
  // the flows it explains is not quietly added up.
  const totalKeys = useMemo(() => new Set(Object.keys(data?.totals ?? {})), [data]);

  const totals = useMemo(() => {
    const t: Record<string, number> = {};
    for (const c of cols) {
      // Percentages are ratios per row, so the column has no meaningful total.
      if (!isSummed(c.type) || !totalKeys.has(c.key)) continue;
      // Running balances close at their last value; only flows are summed over the filter.
      t[c.key] = closingKeys.has(c.key)
        ? data?.closingGroups?.[c.key]
          ? closingOf(rows, c.key)
          : Number(data?.totals?.[c.key]) || 0
        : rows.reduce((s, r) => s + (Number(r[c.key]) || 0), 0);
    }
    return t;
  }, [rows, cols, data, closingKeys, totalKeys, closingOf]);

  // Two-row header: columns that belong to one figure family print under a shared band.
  const headerGroups = useMemo<HeaderGroup[] | null>(() => {
    if (!shownCols.some(c => c.band)) return null;
    const out: HeaderGroup[] = [];
    for (const c of shownCols) {
      const prev = out[out.length - 1];
      if (c.band && prev && prev.band === c.band) { prev.span++; prev.cols.push(c); }
      else out.push({ band: c.band ?? '', span: 1, cols: [c] });
    }
    return out;
  }, [shownCols]);

  // A line register reads as one band per document: the band names it, the lines follow,
  // and the band closes with the figures the report asked for.
  const blocks = useMemo<DocBlock[] | null>(() => {
    if (!groupBy) return null;
    const out: DocBlock[] = [];
    let cur: DocBlock | null = null;
    for (const r of rows) {
      const key = String(r[groupBy.key] ?? '');
      if (!cur || cur.key !== key) {
        cur = { key, head: groupBy.head.map(h => ({ label: h.label, value: String(r[h.col] ?? '—') })), rows: [] };
        out.push(cur);
      }
      cur.rows.push(r);
    }
    return out;
  }, [rows, groupBy]);

  // Summary reads the register in its bands; detailed lays the very same rows out line by line, so
  // a reader chasing one entry sees one table instead of a heading every few lines.
  const bandBlocks = mode === 'summary' ? blocks : null;

  // A grouped page cuts on document bands, so a band never splits across two pages and
  // closes with sums that cover all of its lines.
  const paged = useMemo(() => {
    const units: (DocBlock | Record<string, any>)[] = bandBlocks ?? rows;
    const count = Math.max(1, Math.ceil(units.length / pageSize));
    const at = Math.min(page, count);
    const slice = units.slice((at - 1) * pageSize, at * pageSize);
    return {
      count, at,
      blocks: bandBlocks ? (slice as DocBlock[]) : null,
      rows: bandBlocks ? slice.flatMap(u => (u as DocBlock).rows) : slice as Record<string, any>[],
      // The sheet's own count line, in the reference's words: the first and last unit this page
      // carries, out of everything the register holds.
      from: units.length ? (at - 1) * pageSize + 1 : 0,
      to: Math.min(at * pageSize, units.length)
    };
  }, [bandBlocks, rows, pageSize, page]);


  // A statement has no column totals to show, so its header tiles are the section
  // subtotals the report already worked out.
  const kpis = useMemo(() => {
    // A register that reads its own headline figures off the rows it kept shows those,
    // rather than the generic running total of its first money columns.
    if (data?.cards?.length) return data.cards.slice(0, 4);
    if (!statement) {
      // The tiles are the same figures the footer of the register closes, counted over the
      // rows the filters kept — a register narrowed to one day must not keep quoting the
      // whole book above it.
      const heads = cols.filter(c => c.type === 'money' && totalKeys.has(c.key)).slice(0, 3)
        .map(c => ({ label: flatLabel(c), value: 'PKR ' + fmt(roundMoney(totals[c.key] || 0), 'money', false) }));
      return [{ label: 'Records', value: String(rows.length) }, ...heads].slice(0, 4);
    }
    const totals2 = (data?.rows ?? []).filter(r => r.kind === 'total').slice(0, 3)
      .map(r => ({ label: String(r.account), value: fmt(r.amount, 'money', decimals) }));
    return [{ label: `Records${data?.asOf ? ` · ${data.asOf}` : ''}`, value: String(rows.length) }, ...totals2];
  }, [statement, data, rows, decimals, cols, totals, totalKeys]);

  const neighbours = useMemo(() => {
    const flat = (catalog?.groups ?? []).flatMap(g => g.reports.map(r => ({ ...r, group: g.label })));
    const i = flat.findIndex(r => r.key === reportKey);
    return { prev: i > 0 ? flat[i - 1] : null, next: i >= 0 && i < flat.length - 1 ? flat[i + 1] : null };
  }, [catalog, reportKey]);

  // A statement heading is a band on screen, so its empty figures stay empty on paper too.
  const isHeading = (r: Record<string, any>) => statement && r.kind === 'heading';

  // On paper a loss reads in accounting brackets, the way red reads on screen.
  const fig = (v: any, type?: ReportColType) => {
    const n = Number(v);
    return type === 'money' && n < 0 ? `(${fmt(Math.abs(n), type, decimals)})` : fmt(v, type, decimals);
  };

  // Excel wants the number, not the screen's rounding, so the export columns stay raw.
  // A spreadsheet has no bands to sit under, so on an export the document each line belongs
  // to rides along as its own column — without it the sheet could not be tied back to a paper.

  const identityCols = useMemo<ExportColumn<Record<string, any>>[]>(() => (groupBy?.head ?? [])
    .filter(h => !shownCols.some(c => c.key === h.col))
    .map(h => {
      const src = cols.find(c => c.key === h.col);
      return {
        label: h.label,
        value: (r: Record<string, any>) => {
          const v = r[h.col];
          return typeof v === 'number' ? v : String(v ?? '');
        },
        align: src && isNumeric(src.type) ? 'right' as const : 'left' as const
      };
    }), [groupBy, cols, shownCols]);

  const exportCols = useMemo<ExportColumn<Record<string, any>>[]>(
    () => [...identityCols, ...shownCols.map(c => ({
      label: flatLabel(c),
      value: (r: Record<string, any>) => {
        // A group head names itself in the workbook too — the same blank line the paper used
        // to lose "Assets" over would leave a reader paging through rows with no chapter.
        if (isHeading(r)) return c.key === 'account' ? String(r.account ?? '') : '';
        return typeof r[c.key] === 'number' ? r[c.key] : String(r[c.key] ?? '');
      },
      align: (isNumeric(c.type) ? 'right' : 'left') as 'right' | 'left'
    }))], [shownCols, identityCols, statement]);

  // Paper and screen must agree, so the print columns carry the same formatting,
  // statement indentation and negative-money emphasis the table shows. A text column is also
  // the only kind allowed a second line on paper: a date or a figure that wraps mid-token is a
  // mis-read, so the sheet fits itself by type instead of by breaking the reader's numbers.
  const printCols = useMemo<ExportColumn<Record<string, any>>[]>(() => shownCols.map(c => ({
    label: flatLabel(c),
    value: r => {
      // A group head is the statement's own chapter title. It used to print as a blank line —
      // every cell was cleared for a heading row, the name along with the figures — so the
      // paper lost "Assets", "Current Assets" and "Total Assets" and read as an undifferentiated
      // list. It now names its group in the widest column and carries no figures.
      if (isHeading(r)) return c.key === 'account' ? String(r.account ?? '').toUpperCase() : '';
      const text = fig(r[c.key], c.type);
      if (statement && c.key === 'account') {
        // Non-breaking spaces: HTML collapses ordinary ones, so the hierarchy would flatten.
        return `${' '.repeat(Math.min(6, Number(r.depth) || 0) * 3)}${text}`;
      }
      return text;
    },
    align: isNumeric(c.type) ? 'right' : 'left',
    wrap: c.type === 'text'
  })), [shownCols, decimals, statement]);

  // Every ask the register is answering right now, in words, with the one click that takes it
  // back off. The chips over the bar, the printed sheet and the spreadsheet all read this list,
  // so the three cannot disagree about what was filtered.
  const periodEdited = ownFrom || ownTo
    ? (ownFrom ? !!picked.from : from !== monthStart()) || (ownTo ? !!picked.to : to !== isoDay())
    : from !== monthStart() || to !== isoDay();
  const applied = useMemo<Applied[]>(() => {
    const out: Applied[] = [];
    if (range) out.push({
      key: 'period', label: 'Period', value: `${dayUk(range.lo)} – ${dayUk(range.hi)}`,
      asked: periodEdited,
      clear: () => {
        if (ownFrom) setParam('from', ''); else setFrom(monthStart());
        if (ownTo) setParam('to', ''); else setTo(isoDay());
      }
    });
    activeAsks.forEach(({ f, v }) => out.push({
      key: `c:${askKey(f)}`, label: f.label, value: askText(f, v), asked: true,
      clear: () => setUf(askKey(f), '')
    }));
    activeParams.forEach(([k, v]) => {
      const p = declaredParams.find(x => x.key === k);
      out.push({ key: `p:${k}`, label: p?.label ?? k, value: paramLabel(p, v), asked: true, clear: () => setParam(k, '') });
    });
    if (search.trim()) out.push({
      key: 'q', label: 'Search', value: search.trim(), asked: true, clear: () => setSearch('')
    });
    if (hideZero) out.push({
      key: 'nz', label: 'Rows', value: 'Carrying a figure only', asked: true, clear: () => setUf('__nz', '')
    });
    return out;
  }, [range, periodEdited, ownFrom, ownTo, activeAsks, activeParams, declaredParams, search, hideZero]);

  const printFilters = useMemo(() => [
    data?.asOf ? `As on ${dayUk(data.asOf)}` : '',
    ...applied.map(a => a.key === 'period' ? `Period ${a.value}` : `${a.label}: ${a.value}`),
    decimals ? 'With decimals' : ''
  ].filter(Boolean).join('  ·  '), [data, applied, decimals]);

  // The same asks, one fact per entry: the strip under the letterhead has to be read at a
  // glance, so a register narrowed six ways prints six short labelled facts rather than one
  // long sentence in capitals that wraps into noise.
  const printMeta = useMemo<string[]>(() => [
    ...applied.map(a => a.key === 'period' ? `Period: ${a.value}` : `${a.label}: ${a.value}`),
    data?.asOf ? `As on: ${dayUk(data.asOf)}` : '',
    decimals ? 'Figures: with decimals' : ''
  ].filter(Boolean), [data, applied, decimals]);

  // The closing figure and the rank of each row belong to the register, not to one of the two
  // ways it leaves the building — paper and workbook carry the same totals and the same
  // hierarchy, or the reader has to reconcile two answers.
  const totalsRow = useMemo<(string | undefined)[] | undefined>(() => (statement || !rows.length ? undefined
    : Array.from({ length: shownCols.length }, (_, i) => {
      const c = shownCols[i];
      if (isSummed(c.type)) return fig(totals[c.key], c.type);
      return i === 0 ? (totalsLabel || `Total (${rows.length})`) : '';
    })), [statement, rows.length, shownCols, totals, totalsLabel, decimals]);
  const rowRank = (r: Record<string, any>) => r.kind === 'heading' ? 'sh'
    : r.kind === 'total' ? 'total' : r.kind === 'group' ? 'sg' : '';

  // A wide register is laid across the paper unless the reader says otherwise, and the toolbar's
  // Layout chip names whichever answer is actually in force.
  const landscapeUsed = landscape ?? exportCols.length > 6;

  const printReport = (design?: PrintPrefs) => printTableWithLetterhead(tenantSlug, branchId, {
    title: data?.title ?? 'Report',
    subtitle: data?.desc,
    // The paper carries the same stamp the sheet on screen does — which filing the register is,
    // the window it was cut for, and the four figures the reader looks for first — so the two
    // answers cannot drift into two different documents.
    filing,
    windowBlock,
    cards: kpis.map(s => ({ ...s, hot: isMoneyFigure(s.label) })),
    meta: printMeta,
    printedBy: user?.name || user?.username,
    org: tenantName,
    columns: printCols,
    rows,
    // A banded register prints in its bands: the sheet has to say which document each line
    // belongs to, the way the screen does.
    bands: printBands,
    footer: totalsRow,
    landscape: landscapeUsed,
    // The paper keeps the register's own hierarchy: a group head is a band, a closing figure
    // carries the accent rule, and a sub-group is bolder than the lines under it.
    rowClass: rowRank,
    design
  });

  // "Clear" takes every ask back off, the window along with them: the register returns to the
  // shape it opened in rather than to an empty book.
  const clearAll = () => {
    setFrom(monthStart()); setTo(isoDay()); setSearch(''); setComparison('none'); setSort(null); setPage(1);
    setUfByReport(p => ({ ...p, [reportKey]: NO_PARAMS }));
    setPickedByReport(p => ({ ...p, [reportKey]: NO_PARAMS }));
  };
  const dirty = applied.some(a => a.asked) || comparison !== 'none';

  // ── the two sittings, and the presets between them ─────────────────────────
  // Generate asks the register for the constraints just stated and turns the page over to the
  // sheet. The asks stay live the whole time — the reader sees the register narrow while they
  // type — so this is a turning of the page, not a submission.
  const generate = () => { setPage(1); setStage('sheet'); load(); };

  // A preset is the whole set of asks: the window, the report's own parameters and every column
  // box. Recalling one puts all three back, so a Monday register reads the same on Friday.
  const usePreset = (p: Preset) => {
    setPage(1);
    setFrom(p.from); setTo(p.to);
    setPickedByReport(m => ({ ...m, [reportKey]: { ...(p.param ?? NO_PARAMS) } }));
    setUfByReport(m => ({ ...m, [reportKey]: { ...(p.filt ?? NO_PARAMS) } }));
    setSearch(p.filt?.__q ?? '');
  };
  const keepPreset = () => {
    const name = presetName.trim();
    if (!name) return;
    const next = [...presets.filter(x => x.name !== name),
      { name, from, to, filt: { ...uf }, param: { ...picked } }];
    setPresets(next); writePresets(tenantSlug, reportKey, next);
    setPresetName(''); setNaming(false);
  };
  const forgetPreset = (name: string) => {
    const next = presets.filter(x => x.name !== name);
    setPresets(next); writePresets(tenantSlug, reportKey, next);
  };

  // The register's own bands decide whether there are two readings to choose between at all.
  const modes = blocks?.length ? [
    { value: 'summary', label: 'Summary View (Category Breakdown)', icon: <LayoutGrid className="w-3 h-3" /> },
    { value: 'detailed', label: 'Detailed View (Line Breakdown)', icon: <FileText className="w-3 h-3" /> }
  ] : [];

  // What the sheet is filed under, in the reference's own words: the register's name, the reading
  // it is laid out in, and the block of days it was cut over. The window is the one the rows were
  // actually read over — the pair the reader set, or the span the register itself spans.
  const filing = `${data?.title ?? reportKey} [${mode === 'detailed' ? 'DETAILED' : 'SUMMARY'} VIEW]`;
  const windowBlock = range
    ? `${range.lo} up to ${range.hi}`
    : ((ownAsOf || statement) && asOf ? `struck on ${asOf}` : 'the whole book');


  // One header cell, sortable unless the report lays its own rows out.
  const thLabel = (c: ReportColumn) => statement ? c.label : (
    <button onClick={() => setSort(s => ({ key: c.key, dir: s?.key === c.key && s.dir === 1 ? -1 : 1 }))}
      className={`inline-flex items-center gap-1 hover:text-[#1e88e5] transition-colors ${sort?.key === c.key ? 'text-[#1e88e5]' : ''}`}>
      {c.label}
      <span className="text-[8px]">{sort?.key === c.key ? (sort.dir === 1 ? '▲' : '▼') : '↕'}</span>
    </button>
  );
  const thClass = (c: ReportColumn) =>
    `${isNumeric(c.type) ? 'text-right' : ''} ${statement && c.key === 'account' ? 'w-[52%]' : ''}`;

  // The field a column asks for, beside the report's own parameters in the form above the table.
  // A list to tick where the book holds few values, a word to search where it holds many, two days
  // for a date. Every one writes the key the server's filter layer reads, so the field narrows the
  // register itself — the tiles, the footer, the count and the printed paper — rather than only the
  // lines on the screen.
  const askField = (label: string, f: ColumnAsk) => {
    const key = askKey(f);
    const value = uf[key] ?? '';
    const all = `All ${plural(label)}`;
    if (f.kind === 'list') return (
      <ComboSelect options={(f.options ?? []).map(o => ({ value: o, label: o }))}
        selected={listValue(value)} allLabel={all} title={all} searchPlaceholder={`Search ${plural(label)}`}
        ariaLabel={label} className="!min-w-0"
        onToggle={v => setUf(key, prev => joinValue(toggleIn(listValue(prev), v)))}
        onClearAll={() => setUf(key, '')} />
    );
    if (f.kind === 'text') return (
      <FilterDraft value={value} onAsk={v => setUf(key, v)} placeholder={all} title={label} />
    );
    return (
      <FilterPair value={value} onAsk={v => setUf(key, v)}
        placeholders={['from', 'to']} title={label} />
    );
  };

  // The columns the form asks about: every one the engine offered a field for, less the date column
  // the register's own period window already cuts — one window, not two to reconcile.
  const colFields = useMemo(() => allAsks.filter(f => f.key !== periodAsk), [allAsks, periodAsk]);

  const cells = (r: Record<string, any>) => shownCols.map(c => (
    <td key={c.key} className={isNumeric(c.type) ? 'text-right tabular-nums' : ''}>
      {c.type === 'status' ? (
        <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border ${statusTone(String(r[c.key] ?? ''))}`}>
          {String(r[c.key] ?? '—')}
        </span>
      ) : c.type === 'link' ? (
        // The value is a real figure or number on paper; on screen it is the question to ask next.
        <button onClick={() => setParam(c.key, String(r[c.key] ?? ''))}
          title={`Only ${String(r[c.key] ?? '')}`}
          className="text-[#1e88e5] font-semibold underline decoration-dotted underline-offset-2 hover:text-[#1565c0]">
          {String(r[c.key] ?? '—')}
        </button>
      ) : c.type === 'money' ? (
        <span className={Number(r[c.key]) < 0 ? 'text-red-600 font-semibold' : ''}>{fmt(r[c.key], c.type, decimals)}</span>
      ) : (
        fmt(r[c.key], c.type, decimals)
      )}
    </td>
  ));

  // Every figure a band closes, worded the same way on screen and on paper: the register's
  // foot, the printed band and nothing else re-reads them, so one arithmetic serves all three.
  const bandFigures = useCallback((blockRows: Record<string, any>[]) => {
    // A block of mixed units (4 Sets and 25 Rolls) has no single unit to print, so the suffix
    // only appears when every line in the band agrees.
    const units = [...new Set(blockRows.map(r => String(r.unit ?? '').trim()).filter(u => u && u !== '—'))];
    const unit = units.length === 1 ? units[0] : '';
    return (groupBy?.sums ?? []).map(s => {
      // Freight is charged once per delivery, so the band reads it off the head rather
      // than adding it up the lines.
      const raw = s.mode === 'first' ? blockRows[0]?.[s.col]
        : s.mode === 'ratio' ? (() => {
          const den = sumOf(blockRows, s.by ?? '');
          return den ? Number(sumOf(blockRows, s.col)) / den * 100 : 0;
        })()
          : sumOf(blockRows, s.col);
      const type = s.type ?? 'money';
      return {
        col: s.col,
        label: s.label,
        text: type === 'money' ? `PKR ${fmt(raw, type, true)}`
          : type === 'pct' ? `${Number(raw).toFixed(2)}%`
            : `${fmt(raw, type, true)}${type === 'qty' && unit && unit !== '—' ? ` ${unit}` : ''}`
      };
    });
  }, [groupBy, sumOf, decimals]);

  // The band's figures stood in the columns they belong to, with the word naming the line in
  // the first column that carries no figure. Paper and screen read this one list, so a column
  // adds up the same way in both hands.
  const bandCells = useCallback((blockRows: Record<string, any>[]) => {
    const cells: (string | undefined)[] = shownCols.map(() => undefined);
    bandFigures(blockRows).forEach(f => {
      const at = shownCols.findIndex(c => c.key === f.col);
      if (at >= 0) cells[at] = f.text;
    });
    if (cells.some(c => c)) {
      const free = cells.findIndex(c => !c);
      cells[free >= 0 ? free : 0] = 'Subtotal';
    }
    return cells;
  }, [bandFigures, shownCols]);

  const bandWords = useCallback((blockRows: Record<string, any>[]) =>
    bandFigures(blockRows).map(f => `${f.label} : ${f.text}`).join('  ·  '), [bandFigures]);

  const bandTotals = (blockRows: Record<string, any>[]) => {
    const cells = bandCells(blockRows);
    return shownCols.map((c, i) => (
      <td key={c.key} className={`font-black text-gray-800 ${isNumeric(c.type) ? 'text-right tabular-nums' : ''}`}>
        {cells[i] ?? ''}
      </td>
    ));
  };

  // A printer takes the register the way the screen lays it out: the band names its document and
  // states its figures along that line, the lines follow, and the band closes with the same
  // figures standing in their own columns.
  const printBands = useMemo<PrintBand<Record<string, any>>[] | undefined>(() => {
    if (!bandBlocks) return undefined;
    return bandBlocks.map(b => ({
      heading: b.head.map(h => `${h.label} : ${h.value}`).join('  ·  '),
      rows: b.rows,
      totals: bandWords(b.rows),
      totalCells: bandCells(b.rows)
    }));
  }, [bandBlocks, bandWords, bandCells]);

  // An untick shuts the door, it does not only hide the handle. The filter form spells out a
  // register's whole shape — its columns, its parameters — so a role that was never given the
  // report is turned away here rather than after it has filled the form in and pressed Run.
  if (!can(`rep-${reportKey}:view`)) return (
    <div className="card-xenith p-10 text-center">
      <XCircle className="w-7 h-7 text-gray-300 mx-auto mb-2" />
      <p className="card-title">This report is not open to your role</p>
      <p className="text-xs text-gray-400 mt-1">
        Check the name if you typed the address; otherwise ask an administrator to tick it for you
        under Setup → User Roles → Reports.
      </p>
      <button type="button" className="btn-xenith-outline mt-4" onClick={() => onNavigate('reports')}>
        Back to Reports
      </button>
    </div>
  );

  return (
    <div className="space-y-4">
      <ReportCrumb group={data?.group} title={data?.title} badge="Direct Parameter Filter"
        onBack={() => onNavigate('reports')} />

      {stage === 'form' ? (
        <>
          {/* ── which register the asks are for ─────────────────────────────── */}
          <div className="card-xenith p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0">
              <span className="w-11 h-11 shrink-0 rounded-xl grid place-items-center text-white" style={{ background: color }}>
                <BarChart3 className="w-5 h-5" />
              </span>
              <div className="min-w-0">
                <h1 className="text-lg font-black text-[var(--text)] leading-tight flex items-center gap-2 flex-wrap">
                  {data?.title ?? 'Report'}
                  {ownAsOf && asOf && <span className="text-[11px] font-bold text-gray-400">(As of: {dayUk(asOf)})</span>}
                  {data?.badge && (
                    <span className="text-[9px] font-black uppercase tracking-wide px-1.5 py-0.5 rounded-full" style={plateOn(color)}>
                      {data.badge}
                    </span>
                  )}
                </h1>
                <p className="text-xs text-gray-500 mt-1 max-w-2xl">{data?.desc}</p>
              </div>
            </div>
            <button onClick={() => onNavigate('reports')} className="btn-xenith-outline shrink-0">
              <ArrowLeft className="w-3.5 h-3.5" /> Change Report
            </button>
          </div>

          {/* ── the filter sets kept for this register ──────────────────────── */}
          <div className="card-xenith px-4 py-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-gray-600">
              <Bookmark className="w-3.5 h-3.5" /> Saved Presets:
            </span>
            {presets.length ? presets.map(p => (
              <span key={p.name} className="inline-flex items-center gap-1 pl-2.5 pr-1 py-1 rounded-md border border-emerald-200 bg-emerald-50 text-emerald-800 text-[10px] font-bold">
                <button onClick={() => usePreset(p)} title={`Put the ${p.name} asks back on this register`}
                  className="max-w-[180px] truncate hover:underline">{p.name}</button>
                <button onClick={() => forgetPreset(p.name)} title={`Throw the ${p.name} preset away`}
                  aria-label={`Throw the ${p.name} preset away`}
                  className="w-4 h-4 grid place-items-center rounded-full hover:bg-white">
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )) : <span className="text-[11px] italic text-gray-400">No saved presets yet for this report.</span>}
            {naming ? (
              <span className="ml-auto flex items-center gap-1.5">
                <input autoFocus value={presetName} onChange={e => setPresetName(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') keepPreset();
                    if (e.key === 'Escape') { setNaming(false); setPresetName(''); }
                  }}
                  placeholder="Name this filter set" aria-label="Name this filter set"
                  className="input-xenith !w-48 !py-1 text-[11px]" />
                <button onClick={keepPreset} className="btn-xenith-success !py-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Save
                </button>
                <button onClick={() => { setNaming(false); setPresetName(''); }} className="btn-xenith-outline !py-1.5">Cancel</button>
              </span>
            ) : (
              <button onClick={() => setNaming(true)}
                className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-300 bg-white text-emerald-800 text-[11px] font-bold hover:bg-emerald-50 transition-colors">
                <Save className="w-3.5 h-3.5" /> Save Current Filter Preset
              </button>
            )}
          </div>

          {/* ── the asks themselves ───────────────────────────────────────────
              One labelled field per ask: the parameters the report names, a field for the
              columns that name a thing, and the window of days the sheet is cut over. A field
              left standing is a question not asked, so the register answers for all its records
              until the reader says otherwise. Every one of them bites at the server, so the
              sheet, the tiles, the footer and the printed paper read the same rows. */}
          <AskSection title="Target parameters & query constraints"
            hint="Leave blank to include all records" icon={<ListFilter className="w-3.5 h-3.5" />}>
            <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3 p-4">

              {fieldTiles.map(p => p.kind === 'check' ? (
                // A box carries its own question on the paper forms, so the ask sits beside the
                // tick rather than above it like the dropdowns.
                <label key={p.key} className="flex items-center gap-2 min-w-0 cursor-pointer">
                  <input type="checkbox" checked={picked[p.key] === '1'}
                    onChange={e => setParam(p.key, e.target.checked ? '1' : '')}
                    className="accent-emerald-600 w-3.5 h-3.5" />
                  <span className="text-[11px] font-bold text-gray-700">{p.options?.[0]?.label ?? p.label}</span>
                </label>
              ) : p.kind === 'compare' ? (
                // A report that spreads its own months across the table has no room left for the
                // screen's period-over-period overlay, so the comparison is the report's own ask.
                <Field key={p.key} label={p.label}>
                  <select value={picked[p.key] ?? ''} onChange={e => setParam(p.key, e.target.value)}
                    className="input-xenith !min-w-0">
                    <option value="">no comparison</option>
                    {(p.options ?? []).map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </Field>
              ) : p.kind === 'pick' && p.multi ? (
                // A record list on a report is a tick list with a search box over it, because the
                // ask is often several records at once — these three customers, these two
                // warehouses. The register says which of its dropdowns may be marked that way, so
                // a fixed single choice (a sort order, a person type) keeps its plain shape. A book
                // holding one such record still gets the tick list: the shape of the ask should not
                // change because the shop is small today.
                <Field key={p.key} label={p.label}>
                  <ComboSelect options={(p.options ?? []).map(o => ({ value: o.value, label: o.label }))}
                    selected={listValue(picked[p.key] ?? '')}
                    allLabel={`All ${plural(p.label)}`} searchPlaceholder={`Search ${plural(p.label)}...`}
                    ariaLabel={p.label} className="!min-w-0"
                    onToggle={v => setParam(p.key, prev => joinValue(toggleIn(listValue(prev), v)))}
                    onClearAll={() => setParam(p.key, '')} />
                </Field>
              ) : (
                <Field key={p.key} label={p.label}>
                  <Pick value={picked[p.key] ?? ''}
                    onChange={e => setParam(p.key, e.target.value)}
                    search={p.search}
                    className="!min-w-0">
                    {/* Nothing picked yet: the report keeps its own default rather than an empty filter. */}
                    <option value="">{p.kind === 'pick' ? `All ${plural(p.label)}` : p.options?.[0]?.label ?? '—'}</option>
                    {(p.options ?? []).map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </Pick>
                </Field>
              ))}
              {/* Then one field for every other column the rows carry, labelled the same way: the
                  register is cut the way it is read, and the reader picks the column they came for. */}
              {colFields.map(f => (
                <Field key={f.key} label={f.label}>
                  {askField(f.label, f)}
                </Field>
              ))}
              {/* A search across every column at once, for the reader who has a word and not a
                  column in hand. */}
              <Field label="Search every column" wide>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search every column"
                    className="input-xenith !min-w-0 !pl-8 !pr-7" />
                  {search && (
                    <button type="button" onClick={() => setSearch('')} title="Clear search" aria-label="Clear search"
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700">
                      <XCircle className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </Field>
            </div>

            {/* ── the window, and the order the sheet is read in ──────────────── */}
            <Rule />
            <div className="grid sm:grid-cols-3 gap-x-6 gap-y-3 p-4">
              {!statement && (
                <Field label="Sort By">
                  <select value={sort ? `${sort.key}|${sort.dir}` : ''}
                    onChange={e => {
                      const [k, d] = e.target.value.split('|');
                      setSort(k ? { key: k, dir: Number(d) as 1 | -1 } : null);
                    }}
                    className="input-xenith !min-w-0">
                    <option value="">the register's own order</option>
                    {sortOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </Field>
              )}
              {windowTiles.map(p => (
                <Field key={p.key} label={p.label}>
                  <input type="date" value={p.kind === 'asof' ? asOf : (picked[p.key] ?? '')}
                    onChange={e => p.kind === 'asof' ? setAsOf(e.target.value) : setParam(p.key, e.target.value)}
                    className="input-xenith !min-w-0" />
                </Field>
              ))}
              {!ownAsOf && statement && (
                <Field label="As On">
                  <input type="date" value={asOf} onChange={e => setAsOf(e.target.value)} className="input-xenith !min-w-0" />
                </Field>
              )}
              {dateCol && cuts && !ownFrom && (
                <Field label="From Date">
                  <input type="date" value={from} onChange={e => setFrom(e.target.value)} className="input-xenith !min-w-0" />
                </Field>
              )}
              {dateCol && cuts && !ownTo && (
                <Field label="To Date">
                  <input type="date" value={to} onChange={e => setTo(e.target.value)} className="input-xenith !min-w-0" />
                </Field>
              )}
              {/* A report that spreads its own months across the table has no room left for the
                  screen's period-over-period overlay, so the comparison stands down. */}
              {dateCol && !ownsWindow && !declaredParams.some(p => p.kind === 'compare') && (
                <Field label="Comparison">
                  <select value={comparison} onChange={e => setComparison(e.target.value as Comparison)}
                    className="input-xenith !min-w-0">
                    <option value="none">no comparison</option>
                    <option value="previous">previous period</option>
                    <option value="lastYear">same period last year</option>
                  </select>
                </Field>
              )}
            </div>

            {/* ── how the answer is read ──────────────────────────────────────── */}
            {(!!modes.length || canConfigureAging) && (
              <>
                <Rule />
                <div className="px-4 py-3.5">
                  <div className="flex flex-wrap items-center gap-3">
                    {!!modes.length && (
                      <>
                        <RowLabel>Report Presentation Mode:</RowLabel>
                        <ModeSegment value={mode} options={modes} onPick={v => setMode(v as 'summary' | 'detailed')} />
                      </>
                    )}
                    {canConfigureAging && (
                      <button onClick={() => setAgingOpen(true)} className="btn-xenith-outline !py-1.5">
                        <SlidersHorizontal className="w-3.5 h-3.5" /> Configure Aging
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}

            <Rule />
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5">
              <span className="flex flex-wrap items-center gap-4">
                <button onClick={() => onNavigate('reports')}
                  className="inline-flex items-center gap-1.5 text-[11px] font-bold text-gray-500 hover:text-[var(--accent-text)] transition-colors">
                  <ArrowLeft className="w-3.5 h-3.5" /> Cancel &amp; Back
                </button>
                {dirty && (
                  <button onClick={clearAll}
                    className="inline-flex items-center gap-1.5 text-[11px] font-bold text-gray-500 hover:text-red-600 transition-colors">
                    <XCircle className="w-3.5 h-3.5" /> Clear all
                  </button>
                )}
              </span>
              <button onClick={generate} className="btn-xenith-success !px-5 !py-2.5 text-[12px] font-black">
                <CheckCircle2 className="w-4 h-4" /> Generate {data?.title ?? 'Report'}
              </button>
            </div>
          </AskSection>
        </>
      ) : (
        <>
          {/* ── the sheet, and the ways out of it ───────────────────────────── */}
          <div className="card-xenith px-3 py-2.5 flex flex-wrap items-center justify-between gap-2 print:hidden">
            <button onClick={() => setStage('form')}
              className="inline-flex items-center gap-1.5 text-[11px] font-bold text-gray-600 hover:text-[var(--accent-text)] transition-colors">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Report Filter
            </button>
            <div className="flex flex-wrap items-center gap-2">
              {!!modes.length && (
                <ModeSegment size="sm" value={mode} options={modes.map(m => ({
                  value: m.value, label: m.label.replace(/\s*\(.*\)$/, ''), icon: m.icon
                }))} onPick={v => { setMode(v as 'summary' | 'detailed'); setPage(1); }} />
              )}
              <button onClick={() => setLandscape(!landscapeUsed)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-[10px] font-bold text-gray-600 hover:bg-gray-50 transition-colors">
                <RotateCw className="w-3 h-3" /> Layout: {landscapeUsed ? 'LANDSCAPE' : 'PORTRAIT'}
              </button>
              {/* The two switches the reader keeps flipping once the sheet is in front of them,
                  so they ride on the sheet's own header rather than on the form behind it. */}
              <button onClick={() => setDecimals(!decimals)} title="Show paisa on every figure"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-[10px] font-bold text-gray-600 hover:bg-gray-50 transition-colors">
                Decimals: {decimals ? 'ON' : 'OFF'}
              </button>
              {!statement && (
                <button onClick={() => setUf('__nz', hideZero ? '' : '1')}
                  title="Keep only the rows that carry a figure"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-[10px] font-bold text-gray-600 hover:bg-gray-50 transition-colors">
                  Rows: {hideZero ? 'carrying a figure' : 'all'}
                </button>
              )}
              <ExcelMenuButton title={data?.title ?? 'Report'}
                subtitle={data?.desc} meta={printMeta} printedBy={user?.name || user?.username}
                org={tenantName} filename={reportKey}
                columns={exportCols} rows={rows} footer={totalsRow} rowClass={rowRank}
                landscape={landscapeUsed}
                className="btn-xenith-outline !py-1.5 text-[11px]"
                label={<><Download className="w-3.5 h-3.5" />Export Excel</>} />
              <PrintMenuButton document={data?.title ?? reportKey} title={data?.title ?? 'Report'}
                subtitle={printFilters || data?.desc} className="btn-xenith-success !py-1.5 text-[11px]"
                label={<><Printer className="w-3.5 h-3.5" />Print Report</>} onPrint={design => printReport(design)} />
              <button onClick={load} title="Ask the register again" aria-label="Ask the register again"
                className="w-8 h-8 grid place-items-center rounded-lg border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 transition-colors">
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {comparisonRange && compareRows && (
            <div className="card-xenith p-3 print:hidden">
              <h2 className="card-title mb-2">
                Comparison · {comparisonRange.lo} to {comparisonRange.hi}
              </h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {moneyCols.slice(0, 3).map(c => {
                  const now = totals[c.key] ?? 0;
                  const then = sumOf(compareRows, c.key);
                  const delta = now - then;
                  const pct = then ? (delta / Math.abs(then)) * 100 : null;
                  return (
                    <div key={c.key} className="rounded-lg border border-gray-100 bg-gray-50/60 px-3 py-2">
                      <p className="text-[10px] font-black uppercase tracking-wider text-gray-400 truncate">{c.label}</p>
                      <p className="text-sm font-bold text-gray-900 tabular-nums">{fmt(now, 'money', decimals)}</p>
                      <p className="text-[11px] text-gray-500 tabular-nums">was {fmt(then, 'money', decimals)}</p>
                      <p className={`text-[11px] font-black tabular-nums ${delta > 0 ? 'text-emerald-600' : delta < 0 ? 'text-red-600' : 'text-gray-400'}`}>
                        {delta > 0 ? '▲' : delta < 0 ? '▼' : '—'} {fmt(Math.abs(delta), 'money', decimals)}
                        {pct !== null && <span className="ml-1 font-semibold">({pct > 0 ? '+' : ''}{pct.toFixed(1)}%)</span>}
                      </p>
                    </div>
                  );
                })}
                <div className="rounded-lg border border-gray-100 bg-gray-50/60 px-3 py-2">
                  <p className="text-[10px] font-black uppercase tracking-wider text-gray-400">Records</p>
                  <p className="text-sm font-bold text-gray-900 tabular-nums">{rows.length}</p>
                  <p className="text-[11px] text-gray-500 tabular-nums">was {compareRows.length}</p>
                </div>
              </div>
            </div>
          )}

          <PaperSheet org={tenantName || 'Xenith'} mark={(tenantName || 'N').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase()}
            heading={data?.desc || data?.title || 'Report'} filing={filing} window={windowBlock}>
            {/* The headline figures, read off the rows the filters kept. */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
              {kpis.map(s => (
                <div key={s.label} className="rounded-lg border-2 border-gray-200 px-3 py-2.5 text-center">
                  <p className="text-[9px] font-black uppercase tracking-wider text-gray-500">{s.label}</p>
                  <p className="text-sm font-black tabular-nums mt-1" style={{ color: isMoneyFigure(s.label) ? '#047857' : '#111827' }}>
                    {s.value}
                  </p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pb-2">
              <SheetPager from={paged.from} to={paged.to} of={paged.count ? (bandBlocks?.length ?? rows.length) : 0}
                noun={bandBlocks ? 'groups' : 'records'}
                page={paged.at} pages={paged.count} pageSize={pageSize} sizes={PAGE_SIZES}
                onPage={setPage} onSize={n => { setPageSize(n); setPage(1); }} />
            </div>

      {error ? (
        <div className="py-10 text-center">
          <FileSearch className="w-7 h-7 text-gray-300 mx-auto mb-2" />
          <p className="text-[13px] font-black text-gray-900">This report could not be generated</p>
          <p className="text-[11px] text-gray-400 mt-1">{error}</p>
        </div>
      ) : loading ? (
        <div className="py-6 space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-7 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 6}%` }} />
          ))}
        </div>
      ) : (
        <>
          <div className="overflow-x-auto app-scroll">
            <table className="xenith-table">
              <thead className="sticky top-0 z-10">
                <tr>
                  {headerGroups ? headerGroups.map(g => g.band ? (
                    <th key={`band-${g.cols[0].key}`} colSpan={g.span} className="text-center border-l border-white/20">{g.band}</th>
                  ) : (
                    <th key={g.cols[0].key} rowSpan={2} className={thClass(g.cols[0])}>{thLabel(g.cols[0])}</th>
                  )) : shownCols.map(c => (
                    <th key={c.key} className={thClass(c)}>{thLabel(c)}</th>
                  ))}
                </tr>
                {headerGroups && (
                  <tr>
                    {headerGroups.filter(g => g.band).flatMap(g => g.cols.map(c => (
                      <th key={c.key} className={thClass(c)}>{thLabel(c)}</th>
                    )))}
                  </tr>
                )}
              </thead>
              <tbody>
                {!rows.length ? (
                  <tr>
                    <td colSpan={shownCols.length} className="text-center py-10 text-gray-500 text-xs">
                      {/* An empty register and a filtered one are two different answers. */}
                      {dirty ? 'No rows match the current filters.'
                        : 'Nothing on the books — this branch has no paper of this kind yet.'}
                    </td>
                  </tr>
                ) : statement ? paged.rows.map((r, i) => (
                  r.kind === 'heading' ? (
                    <tr key={i} className="bg-gray-100/80">
                      <td colSpan={shownCols.length} className="text-[10px] font-black uppercase tracking-wider text-gray-600">{r.account}</td>
                    </tr>
                  ) : (
                    <tr key={i} className={
                      r.tone === 'yellow' ? 'bg-amber-50'
                        : r.tone === 'green' ? 'bg-emerald-50'
                          : r.tone === 'red' ? 'bg-rose-50'
                            : r.kind === 'total' ? 'bg-gray-50/70 border-t border-gray-200' : ''}>
                      {shownCols.map(c => (
                        <td key={c.key} className={`align-top ${isNumeric(c.type) ? 'text-right tabular-nums' : ''} ${
                          r.kind === 'total' ? 'font-black text-gray-800' : r.kind === 'group' ? 'font-bold text-gray-700' : 'text-gray-600'}`}>
                          {c.key === 'account'
                            ? <span style={{ paddingLeft: `${Number(r.depth || 0) * 16}px` }}>{String(r[c.key] ?? '')}</span>
                            : c.type === 'money'
                              ? <span className={Number(r[c.key]) < 0 ? 'text-red-600 font-semibold' : ''}>{r[c.key] === '' ? '—' : fmt(r[c.key], c.type, decimals)}</span>
                              : fmt(r[c.key], c.type, decimals)}
                        </td>
                      ))}
                    </tr>
                  )
                )) : paged.blocks ? paged.blocks.map(b => (
                  <React.Fragment key={b.key}>
                    {/* The band opens with a dark line that names what it is and states its own
                        figures at the same time, so a reader scanning the sheet never has to
                        reach the foot of a long block to find what the block adds up to. */}
                    <tr className="band-head">
                      <td colSpan={shownCols.length} className="text-[10px] font-bold">
                        <span className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                          <span className="min-w-0">
                            {b.head.map(h => (
                              <span key={h.label} className="inline-block mr-4 whitespace-nowrap">
                                <span className="opacity-70">{h.label} :</span>{' '}
                                <span className="font-black uppercase tracking-wide">{h.value}</span>
                              </span>
                            ))}
                          </span>
                          {groupBy?.sums?.length && (
                            <span className="whitespace-nowrap tabular-nums opacity-90">{bandWords(b.rows)}</span>
                          )}
                        </span>
                      </td>
                    </tr>
                    {b.rows.map((r, i) => <tr key={i}>{cells(r)}</tr>)}
                    {/* A band that only names its head — the bulk ledger, whose figures close
                        in the tiles above the register — has no foot line to print. */}
                    {groupBy?.sums?.length ? <tr className="band-foot">{bandTotals(b.rows)}</tr> : null}
                  </React.Fragment>
                )) : paged.rows.map((r, i) => <tr key={i}>{cells(r)}</tr>)}
              </tbody>
              {!statement && Object.keys(totals).length > 0 && !!rows.length && (
                <tfoot>
                  <tr className="bg-gray-50/80">
                    {shownCols.map((c, idx) => (
                      <td key={c.key} className={`font-black text-gray-800 ${isNumeric(c.type) ? 'text-right tabular-nums' : ''}`}>
                        {isSummed(c.type) && c.key in totals ? fmt(totals[c.key], c.type, decimals)
                          : idx === 0 ? (totalsLabel || `Total (${rows.length})`) : ''}
                      </td>
                    ))}
                  </tr>
                  {/* The reference registers close with each figure read against one column,
                      so paid and outstanding show as a share of billed rather than as more sums.
                      A register with no named columns means every figure the row above summed. */}
                  {shareRow && (
                    <tr className="bg-gray-50/80">
                      {shownCols.map((c, idx) => {
                        const shares = !shareRow.cols.length ? isSummed(c.type) : shareRow.cols.includes(c.key);
                        if (!shares) {
                          return <td key={c.key} className={idx === 0 ? 'text-[10px] font-black uppercase tracking-wide text-gray-500' : ''}>
                            {idx === 0 ? '% Share' : ''}
                          </td>;
                        }
                        const base = Number(totals[shareRow.of]) || 0;
                        return <td key={c.key} className="text-right tabular-nums font-black text-gray-700">
                          {base ? `${((Number(totals[c.key]) || 0) / base * 100).toFixed(2)}%` : '—'}
                        </td>;
                      })}
                    </tr>
                  )}
                </tfoot>
              )}
            </table>
          </div>
          <div className="pt-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-gray-500">
            <span>
              {rows.length} of {registerRows.toLocaleString()} rows
              {cols.some(c => c.type === 'money') ? ' · amounts in PKR' : ''} · generated {new Date().toLocaleString()}
            </span>
            <span className="flex items-center gap-2">
              {neighbours.prev && (
                <button onClick={() => onNavigate(`report:${neighbours.prev!.key}`)}
                  className="inline-flex items-center gap-1 font-bold hover:text-[var(--accent-text)] transition-colors">
                  <ChevronLeft className="w-3 h-3" /> {neighbours.prev.title}
                </button>
              )}
              {neighbours.next && (
                <button onClick={() => onNavigate(`report:${neighbours.next!.key}`)}
                  className="inline-flex items-center gap-1 font-bold hover:text-[var(--accent-text)] transition-colors">
                  {neighbours.next.title} <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </span>
          </div>
        </>
      )}
          </PaperSheet>
        </>
      )}

      {agingOpen && <AgingBucketsModal onClose={() => setAgingOpen(false)} onSaved={load} />}
    </div>
  );
};

export default ReportViewer;
