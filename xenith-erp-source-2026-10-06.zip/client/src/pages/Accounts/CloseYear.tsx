import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CalendarX2, CheckCircle2, Lock, RefreshCw, RotateCcw, ScrollText, Unlock } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import {
  closeBooks, getCloseYearState, previewCloseYear, reopenBooks,
  BookClose, CloseYearState, ClosingPreview
} from '../../services/closeYear.service';
import { Field, IconAction, SectionTitle, StatStrip } from '../Masters/masterUi';
import { useScreenReload } from '../../utils/screenReload';

const money = (n: number) => Number(n || 0).toLocaleString();

// Both the seal and its undo take the books apart on paper, so neither happens on one click:
// the row arms first and says what it is about to do.
const Arm: React.FC<{
  label: string; warn: string; busy?: boolean;
  onConfirm: () => void; onCancel: () => void; tone?: 'danger' | 'success';
}> = ({ label, warn, busy, onConfirm, onCancel, tone = 'danger' }) => (
  <div className="flex flex-wrap items-center gap-1.5">
    <span className={`text-[11px] font-semibold ${tone === 'danger' ? 'text-red-600' : 'text-amber-700'}`}>{warn}</span>
    <button type="button" disabled={busy} onClick={onConfirm}
      className={`text-[10px] font-bold text-white rounded px-2.5 py-1 disabled:opacity-50 ${
        tone === 'danger' ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-600 hover:bg-emerald-700'}`}>
      {busy ? 'Working…' : label}
    </button>
    <IconAction title="Leave the books as they stand" tone="muted" onClick={onCancel}>
      <CalendarX2 className="w-4 h-4" />
    </IconAction>
  </div>
);

const CloseYear: React.FC = () => {
  const { tenantSlug, branchId, tenantName, currency } = useTenant();
  const { can } = useAuth();
  const [state, setState] = useState<CloseYearState | null>(null);
  const [to, setTo] = useState('');
  const [preview, setPreview] = useState<ClosingPreview | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<'preview' | 'close' | 'reopen' | ''>('');
  const [armClose, setArmClose] = useState(false);
  const [armReopen, setArmReopen] = useState<number | null>(null);

  const load = useCallback(async () => {
    setError('');
    try {
      const s = await getCloseYearState(tenantSlug, branchId);
      setState(s);
      // The date box opens on the fiscal year the clock is standing in — the one answer the
      // owner is nearly always looking for — and keeps whatever he has since picked.
      setTo(prev => prev || s.suggestedTo);
    } catch (e: any) {
      setError(e?.message || 'The closing register could not be read');
    }
  }, [tenantSlug, branchId]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  // A new date always asks the ledger again: the preview is the figure being signed off, and
  // a stale one would be a different year's number.
  useEffect(() => {
    setPreview(null);
    setArmClose(false);
  }, [to]);

  const runPreview = async () => {
    setBusy('preview');
    setError('');
    try {
      setPreview(await previewCloseYear(tenantSlug, branchId, to));
    } catch (e: any) {
      setError(e?.message || 'This period could not be read');
      setPreview(null);
    } finally {
      setBusy('');
    }
  };

  const runClose = async () => {
    setBusy('close');
    setError('');
    try {
      await closeBooks(tenantSlug, branchId, to);
      setArmClose(false);
      setPreview(null);
      // The day just closed is no longer a closing date, so the box offers the next one.
      setTo('');
      await load();
    } catch (e: any) {
      setError(e?.message || 'The books could not be closed');
    } finally {
      setBusy('');
    }
  };

  const runReopen = async (id: number) => {
    setBusy('reopen');
    setError('');
    try {
      await reopenBooks(tenantSlug, branchId, id);
      setArmReopen(null);
      // The days just released are the ones the box should now offer, so the pick that was
      // sealed away is dropped and the register's own suggestion takes its place.
      setTo('');
      await load();
    } catch (e: any) {
      setError(e?.message || 'The year could not be reopened');
    } finally {
      setBusy('');
    }
  };

  const mayClose = !!state?.canClose && can('close-year:add');
  const mayReopen = !!state?.canReopen && can('close-year:delete');
  // A closing that a year row already offers to reopen is not given a second button in the
  // register — one paper, one way back.
  const sealedByYear = new Set((state?.years || []).map(y => y.close?.id).filter((x): x is number => !!x));
  const openFrom = state?.openFrom || state?.years.find(y => y.state !== 'Closed')?.from || state?.today || '';
  const stats = useMemo(() => [
    { label: 'Fiscal year starts', value: state?.financialYearStart || '—' },
    { label: 'Books closed up to', value: state?.closedThrough || 'Nothing yet' },
    { label: 'Open period from', value: openFrom || '—' },
    { label: 'Papers in the open period', value: state?.papersStillOpen ?? 0, tone: 'ok' as const }
  ], [state, openFrom]);

  return (
    <div className="space-y-3">
      <div className="nb-card px-4 py-3">
        <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2">
          <div>
            <h1 className="page-title">Close Year</h1>
            <p className="text-xs text-gray-500">
              Carries {tenantName}'s profit out of the trading heads and seals the days behind it, so a
              year already stood behind cannot gain, lose or change a paper.
            </p>
          </div>
          <button type="button" onClick={load} title="Read the closing register again"
            className="btn-xenith-outline">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
        <div className="mt-3">
          <StatStrip stats={stats} />
        </div>
      </div>

      {error && (
        <div className="nb-card px-4 py-3 border-l-4 border-l-red-500">
          <p className="text-xs font-semibold text-red-600 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" /> {error}
          </p>
        </div>
      )}

      <div className="grid grid-cols-12 gap-3">
        {/* ── The close itself ─────────────────────────────────────────────────── */}
        <div className="col-span-12 xl:col-span-7 lg:self-start">
          <div className="nb-card p-0">
            <div className="px-4 py-3 border-b border-gray-100">
              <SectionTitle>Close the books up to</SectionTitle>
              <p className="text-[11px] text-gray-500 mt-0.5">
                {state?.closedThrough
                  ? `The books stand open from ${state.openFrom}. Anything on or before ${state.closedThrough} is already sealed.`
                  : 'Nothing has been closed on this book yet. The first close carries every day the book holds.'}
              </p>
            </div>

            <div className="p-4 space-y-3">
              <div className="flex flex-wrap items-end gap-3">
                <Field label="Closing date" required className="w-44">
                  <input type="date" className="input-xenith" value={to} min={openFrom || undefined}
                    max={state?.today} onChange={e => setTo(e.target.value)} />
                </Field>
                <button type="button" onClick={runPreview} disabled={!to || busy === 'preview'}
                  className="btn-xenith-outline disabled:opacity-50">
                  <ScrollText className="w-3.5 h-3.5" />
                  <span>{busy === 'preview' ? 'Reading the ledger…' : 'Preview the year'}</span>
                </button>
              </div>

              <p className="text-[11px] text-gray-500">
                A date on the last day of a fiscal year closes that year whole. Any other date closes the
                stretch up to it and leaves the rest of the year open.
              </p>

              {to && to === state?.today && (
                // The seal is honest about the day it covers: closing on today's date also stops today's
                // next bill, so the owner reads that before signing rather than after being refused.
                <p className="text-[11px] font-semibold text-amber-700 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 mt-px shrink-0" />
                  {to} is today. This seal holds the rest of today as well — a bill, voucher or salary
                  sheet raised after it will be refused until the period is reopened. Close the last day
                  you have actually finished with instead.
                </p>
              )}

              {!preview ? (
                <div className="table-empty">
                  <p>{to ? 'Nothing read yet' : 'Choose the closing date'}</p>
                  <span>{to
                    ? 'Preview states the profit the entry carries and lists every line of it before anything is written.'
                    : 'The date box opens on the current fiscal year end.'}</span>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="rounded-lg border border-gray-200 divide-y divide-gray-100">
                    <div className="px-3 py-2 flex items-center justify-between bg-gray-50">
                      <span className="text-[11px] font-black uppercase tracking-wide text-gray-600">
                        {preview.period}
                      </span>
                      <span className="text-[11px] font-semibold text-gray-500">
                        {preview.papers} paper{preview.papers === 1 ? '' : 's'} sealed
                      </span>
                    </div>
                    {([
                      ['Revenue', preview.figures.revenue],
                      ['Direct cost of goods', -preview.figures.cogs],
                      ['Gross profit', preview.figures.grossProfit],
                      ['Running costs', -preview.figures.operating],
                      ['Other income', preview.figures.otherIncome],
                      ['Net profit for the period', preview.net]
                    ] as [string, number][]).map(([label, v], i) => (
                      <div key={label} className={`px-3 py-1.5 flex items-center justify-between ${
                        i === 5 ? 'bg-emerald-50' : ''}`}>
                        <span className={`text-[12px] ${i === 2 || i === 5 ? 'font-black text-gray-800' : 'text-gray-600'}`}>
                          {label}
                        </span>
                        <span className={`text-[12px] tabular-nums font-bold ${
                          i === 5 ? (v < 0 ? 'text-red-600' : 'text-emerald-700') : v < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                          {currency} {money(v)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {preview.drafts > 0 && (
                    <p className="text-[11px] font-semibold text-amber-700 flex items-start gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 mt-px shrink-0" />
                      {preview.drafts} unsigned paper{preview.drafts === 1 ? '' : 's'} sit
                      {preview.drafts === 1 ? 's' : ''} inside this stretch. A close carries signed figures only,
                      and once sealed a draft can no longer be approved either — sign them off, or void them,
                      before closing.
                    </p>
                  )}

                  {preview.lines.length ? (
                    <div className="rounded-lg border border-gray-200 overflow-hidden">
                      <div className="px-3 py-2 bg-gray-50 border-b border-gray-100">
                        <span className="text-[11px] font-black uppercase tracking-wide text-gray-600">
                          The carrying entry
                        </span>
                      </div>
                      <div className="max-h-64 overflow-y-auto">
                        <table className="w-full text-[12px]">
                          <thead className="sticky top-0 bg-white">
                            <tr className="text-left text-[10px] uppercase tracking-wide text-gray-500">
                              <th className="px-3 py-1.5 font-bold">Account head</th>
                              <th className="px-3 py-1.5 font-bold text-right w-28">Debit</th>
                              <th className="px-3 py-1.5 font-bold text-right w-28">Credit</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-50">
                            {preview.lines.map((l, i) => (
                              <tr key={`${l.account}-${i}`} className={l.account === state?.carriedHead ? 'bg-emerald-50/60' : ''}>
                                <td className="px-3 py-1.5">
                                  <span className="font-semibold text-gray-800">{l.account}</span>
                                  {l.description && <span className="text-gray-400"> · {l.description}</span>}
                                </td>
                                <td className="px-3 py-1.5 text-right tabular-nums">{l.debit ? money(l.debit) : ''}</td>
                                <td className="px-3 py-1.5 text-right tabular-nums">{l.credit ? money(l.credit) : ''}</td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot className="bg-gray-50 border-t border-gray-200">
                            <tr>
                              <td className="px-3 py-1.5 text-[11px] font-black uppercase tracking-wide text-gray-600">Total</td>
                              <td className="px-3 py-1.5 text-right tabular-nums font-black">{money(preview.totalDebit)}</td>
                              <td className="px-3 py-1.5 text-right tabular-nums font-black">{money(preview.totalCredit)}</td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-gray-500">
                      No profit-and-loss head moved inside this stretch, so there is nothing to carry. The
                      close seals the days without raising an entry.
                    </p>
                  )}

                  {mayClose ? (
                    armClose ? (
                      <Arm
                        tone="success"
                        busy={busy === 'close'}
                        label={`Close ${preview.period}`}
                        warn={preview.lines.length
                          ? `This writes the carrying entry and seals every paper dated ${to} or earlier — nothing inside it can be added, edited, approved, voided or deleted afterwards.`
                          : `There is nothing to carry in this stretch, so the seal is all this writes. Every paper dated ${to} or earlier is then sealed — it cannot be added, edited, approved, voided or deleted afterwards.`}
                        onConfirm={runClose}
                        onCancel={() => setArmClose(false)}
                      />
                    ) : (
                      <button type="button" onClick={() => setArmClose(true)}
                        className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-700
                          text-white text-[13px] font-bold px-4 py-2.5">
                        <Lock className="w-4 h-4" />
                        Close the books up to {to}
                      </button>
                    )
                  ) : (
                    <p className="text-[11px] font-semibold text-gray-500 flex items-start gap-1.5">
                      <Unlock className="w-3.5 h-3.5 mt-px shrink-0" />
                      Your role can read the closing register but not sign a year off — the Close tick on
                      Accounts → Close Year belongs to the owner's chair.
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── The years, closed and standing ───────────────────────────────────── */}
        <div className="col-span-12 xl:col-span-5 lg:self-start">
          <div className="nb-card p-0">
            <div className="px-4 py-3 border-b border-gray-100">
              <SectionTitle>Years on this book</SectionTitle>
              <p className="text-[11px] text-gray-500 mt-0.5">
                The result of a closed year lives on <span className="font-semibold">{state?.carriedHead}</span>
                {' '}inside Retained Earnings, and the balance sheet reads it from there.
              </p>
            </div>

            {!state?.years.length ? (
              <div className="table-empty">
                <p>No trading year on this book yet</p>
                <span>The first papers will open the current year here.</span>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {state.years.slice().reverse().map(y => (
                  <div key={y.year} className="px-4 py-3">
                    <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`w-6 h-6 shrink-0 rounded-full grid place-items-center ${
                          y.state === 'Closed' ? 'bg-emerald-100 text-emerald-700'
                            : y.state === 'Partly closed' ? 'bg-amber-100 text-amber-700'
                              : 'bg-gray-100 text-gray-500'}`}>
                          {y.state === 'Closed' ? <Lock className="w-3.5 h-3.5" />
                            : y.state === 'Partly closed' ? <AlertTriangle className="w-3.5 h-3.5" />
                              : <Unlock className="w-3.5 h-3.5" />}
                        </span>
                        <span className="text-[13px] font-black text-gray-800">{y.label}</span>
                        <span className="text-[11px] text-gray-400 tabular-nums">{y.from} → {y.to}</span>
                      </div>
                      <div className="text-right">
                        {/* The same number means two different things depending on whether a close
                            signed it off, so the row says which one the figure is. */}
                        <span className="block text-[10px] font-bold uppercase tracking-[.06em] text-gray-400">
                          {y.close ? 'Carried to result' : 'Result so far'}
                        </span>
                        <span className={`text-[12px] font-bold tabular-nums ${y.netProfit < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                          {currency} {money(y.netProfit)}
                        </span>
                      </div>
                    </div>

                    {y.close ? (
                      <div className="mt-1.5 pl-8 flex flex-wrap items-center justify-between gap-x-3 gap-y-1.5">
                        <span className="text-[11px] text-gray-500">
                          Sealed up to <span className="font-bold text-gray-700">{y.close.to}</span>
                          {' · '}{y.close.papers} paper{y.close.papers === 1 ? '' : 's'}
                          {' · '}{y.close.journalNumber || 'no entry'}
                          {' · by '}{y.close.closedBy}
                        </span>
                        {mayReopen ? (
                          armReopen === y.close.id ? (
                            <Arm
                              busy={busy === 'reopen'}
                              label="Reopen the year"
                              warn={`This lifts the seal and deletes ${y.close.journalNumber || 'the carrying entry'} — until it is closed again every paper inside the year can move.`}
                              onConfirm={() => runReopen(y.close!.id)}
                              onCancel={() => setArmReopen(null)}
                            />
                          ) : (
                            <IconAction title={`Reopen ${y.label}`} tone="primary" onClick={() => setArmReopen(y.close!.id)}>
                              <RotateCcw className="w-4 h-4" />
                            </IconAction>
                          )
                        ) : (
                          <span className="text-[10px] font-semibold text-gray-400"
                            title="Your role cannot open a year that has been closed">Read only</span>
                        )}
                      </div>
                    ) : (
                      <div className="mt-1 pl-8">
                        <span className="text-[11px] text-gray-400">
                          {y.state === 'Partly closed'
                            ? 'Closed partway through — see the register below for the exact stretch.'
                            : 'Standing open.'}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {!!state?.closes.length && (
            <div className="nb-card p-0 mt-3">
              <div className="px-4 py-3 border-b border-gray-100">
                <SectionTitle>Closings on record</SectionTitle>
              </div>
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="text-left text-[10px] uppercase tracking-wide text-gray-500 border-b border-gray-100">
                    <th className="px-4 py-2 font-bold">Period</th>
                    <th className="px-4 py-2 font-bold text-right">Net profit carried</th>
                    <th className="px-4 py-2 font-bold">Closed by</th>
                    <th className="px-4 py-2 font-bold">Entry</th>
                    <th className="px-4 py-2 font-bold text-right">Seal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {state.closes.map(c => (
                    <tr key={c.id}>
                      <td className="px-4 py-2 tabular-nums text-gray-700">{c.from || 'book start'} → {c.to}</td>
                      <td className={`px-4 py-2 text-right tabular-nums font-bold ${c.netProfit < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                        {money(c.netProfit)}
                      </td>
                      <td className="px-4 py-2 text-gray-600">{c.closedBy}</td>
                      <td className="px-4 py-2 text-gray-600">{c.journalNumber || '—'}</td>
                      {/* A stretch closed partway through a year answers to no year row, so the
                          register itself is where that seal is lifted. */}
                      <td className="px-4 py-2 text-right">
                        {sealedByYear.has(c.id) ? (
                          <span className="text-[10px] font-semibold text-gray-400">Reopen from the year above</span>
                        ) : mayReopen ? (
                          armReopen === c.id ? (
                            <Arm
                              busy={busy === 'reopen'}
                              label="Reopen the period"
                              warn={`This lifts the seal on ${c.from || 'the book start'} → ${c.to} and deletes ${c.journalNumber || 'the carrying entry'} — until it is closed again every paper inside it can move.`}
                              onConfirm={() => runReopen(c.id)}
                              onCancel={() => setArmReopen(null)}
                            />
                          ) : (
                            <IconAction title={`Reopen ${c.from || 'book start'} → ${c.to}`} tone="primary" onClick={() => setArmReopen(c.id)}>
                              <RotateCcw className="w-4 h-4" />
                            </IconAction>
                          )
                        ) : (
                          <span className="text-[10px] font-semibold text-gray-400"
                            title="Your role cannot open a period that has been closed">Read only</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {!!state?.closedThrough && (
            <div className="nb-card px-4 py-3 mt-3 border-l-4 border-l-emerald-500">
              <p className="text-[11px] text-gray-600 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 mt-px shrink-0 text-emerald-600" />
                Every bill, challan, voucher, journal, POS bill and salary sheet dated on or before{' '}
                <span className="font-bold">{state.closedThrough}</span> is sealed. The server refuses it by name
                and says which year to reopen.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CloseYear;
