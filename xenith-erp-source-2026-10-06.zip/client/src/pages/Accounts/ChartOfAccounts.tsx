import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ChevronDown, ChevronRight, Pencil, RefreshCw, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { LedgerAccount } from '../../types';
import {
  addLedgerAccount, deleteLedgerAccount, getLedgerAccounts, getProposedLedgerCode, updateLedgerAccount
} from '../../services/accounts.service';
import {
  Area, Check, ExportPair, Field, FormFooter, IconAction, ListToolbar, Pick, RegisterStat, SearchBox, SearchPick,
  SectionTitle, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { useScreenReload } from '../../utils/screenReload';

const ACCOUNT_TYPES: LedgerAccount['type'][] = ['Asset', 'Liability', 'Equity', 'Income', 'Expense'];

// A head, the group under it, and the account that finally takes the postings. The four
// sections printed above the heads are a reading order, not another level, so a live account
// is never further down than the third row of a branch.
const CHART_MAX_LEVEL = 3;

// The chart is read under four sections, not five: what the business owes outsiders and what
// it owes its owner are the two halves of the same side of the balance sheet, so capital is
// read inside the liabilities section. An account keeps its own type — the section it hangs
// in is a reading order, not a level.
const SECTION_TYPES: Record<string, LedgerAccount['type'][]> = {
  Liabilities: ['Liability', 'Equity'],
  Assets: ['Asset'],
  Income: ['Income'],
  Expenses: ['Expense']
};
const SECTION_ORDER = ['Assets', 'Liabilities', 'Income', 'Expenses'] as const;

const sectionOf = (t: LedgerAccount['type']) => SECTION_ORDER.find(s => SECTION_TYPES[s].includes(t)) ?? 'Assets';

const typeColor: Record<string, string> = {
  Asset: 'bg-blue-100 text-blue-700',
  Liability: 'bg-amber-100 text-amber-700',
  Equity: 'bg-purple-100 text-purple-700',
  Income: 'bg-green-100 text-green-700',
  Expense: 'bg-red-100 text-red-600',
};

interface FormState {
  id?: number;
  code: string;
  name: string;
  type: LedgerAccount['type'];
  parentId: number | null;
  isGroup: boolean;
  openingBalance: number;
  description: string;
  isActive: boolean;
  bankName: string;
  accountNumber: string;
  branchCode: string;
  branchName: string;
  iban: string;
  acceptsChequeBook: boolean;
  acceptsCreditCard: boolean;
}

const blank = (): FormState => ({
  code: '', name: '', type: 'Asset', parentId: null, isGroup: false, openingBalance: 0,
  description: '', isActive: true, bankName: '', accountNumber: '', branchCode: '', branchName: '',
  iban: '', acceptsChequeBook: false, acceptsCreditCard: false
});

const ofRecord = (a: LedgerAccount): FormState => ({
  ...blank(), ...a, type: a.type, parentId: a.parentId ?? null, isGroup: !!a.isGroup,
  openingBalance: a.openingBalance ?? 0, description: a.description ?? '', isActive: a.isActive !== false,
  bankName: a.bankName ?? '', accountNumber: a.accountNumber ?? '', branchCode: a.branchCode ?? '',
  branchName: a.branchName ?? '', iban: a.iban ?? '',
  acceptsChequeBook: !!a.acceptsChequeBook, acceptsCreditCard: !!a.acceptsCreditCard
});

export const ChartOfAccounts: React.FC = () => {
  const { tenantSlug, branchId, allBranches, currency } = useTenant();
  const [records, setRecords] = useState<LedgerAccount[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how "Clear every filter" empties the box.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [kindFilter, setKindFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  // Rows the user has opened. The chart is a head, a group and the account under them, and a
  // full book runs to hundreds of accounts, so it arrives folded to its four sections and only
  // the rows clicked open show their children.
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const openRow = (key: string) => setExpanded(e => ({ ...e, [key]: !e[key] }));
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getLedgerAccounts(tenantSlug, branchId, search);
      setRecords(res.data ?? []);
      setNotice('');
    } catch (e) {
      setNotice((e as Error).message || 'Chart of accounts is not available right now.');
    } finally {
      setLoading(false);
    }
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const childrenOf = useMemo(() => {
    const map: Record<number, LedgerAccount[]> = {};
    records.forEach(a => {
      if (!a.parentId) return;
      (map[a.parentId] = map[a.parentId] ?? []).push(a);
    });
    return map;
  }, [records]);

  const visible = useMemo(() => records.filter(a =>
    (!typeFilter || SECTION_TYPES[typeFilter as keyof typeof SECTION_TYPES].includes(a.type)) &&
    (!kindFilter || (kindFilter === 'group') === !!a.isGroup) &&
    (!statusFilter || (statusFilter === 'active') === (a.isActive !== false))
  ), [records, typeFilter, kindFilter, statusFilter]);

  // A search or a filter has to keep matching sub-accounts visible, otherwise a hit buried
  // under a group looks like it disappeared.
  const topLevel = visible.filter(a => !a.parentId || !visible.some(p => p.id === a.parentId));

  // One pass builds the tree the table shows: a folded row keeps its children out of the
  // list, so what is on screen is exactly what is open.
  const tree = useMemo(() => {
    const out: { section: string; entries: { account: LedgerAccount; depth: number }[] }[] = [];
    SECTION_ORDER.forEach(section => {
      const roots = topLevel.filter(a => SECTION_TYPES[section].includes(a.type));
      const entries: { account: LedgerAccount; depth: number }[] = [];
      if (expanded[`t${section}`]) {
        const walk = (list: LedgerAccount[], depth: number) => list.forEach(a => {
          entries.push({ account: a, depth });
          const kids = (childrenOf[a.id] ?? []).filter(k => visible.includes(k));
          if (kids.length && expanded[`a${a.id}`]) walk(kids, depth + 1);
        });
        walk(roots, 0);
      }
      if (roots.length) out.push({ section, entries });
    });
    return out;
  }, [childrenOf, visible, expanded, topLevel.map(a => a.id).join(',')]);

  // The export is the whole chart in reading order, whatever happens to be unfolded on
  // screen — a folded section is a viewing choice, not missing accounts.
  const flatForExport = useMemo(() => {
    const out: LedgerAccount[] = [];
    SECTION_ORDER.forEach(section => {
      const walk = (list: LedgerAccount[]) => list.forEach(a => { out.push(a); walk(childrenOf[a.id] ?? []); });
      walk(topLevel.filter(a => SECTION_TYPES[section].includes(a.type)));
    });
    return out;
  }, [childrenOf, topLevel.map(a => a.id).join(',')]);

  // Counts only. A chart cannot be summed across all accounts, because a group already carries
  // its children, and the balance a head holds is the ledger's answer, not this screen's.
  const stats: RegisterStat[] = [
    {
      label: 'Accounts', value: String(visible.length),
      title: 'Heads the search and the filters leave in the chart. Folding a section hides rows to read, it does not remove accounts.'
    },
    { label: 'Transactional', value: visible.filter(a => !a.isGroup).length },
    { label: 'Groups', value: visible.filter(a => a.isGroup).length },
    ...(visible.some(a => a.isActive === false)
      ? [{ label: 'Inactive', value: visible.filter(a => a.isActive === false).length, tone: 'warn' as const }]
      : [])
  ];

  const typeCounts = SECTION_ORDER.map(s => ({
    value: s as string, label: s, count: records.filter(a => SECTION_TYPES[s].includes(a.type)).length
  }));
  const kindCounts = [
    { value: '', label: 'All heads', count: records.length },
    { value: 'transactional', label: 'Transactional', count: records.filter(a => !a.isGroup).length },
    { value: 'group', label: 'Group / Control', count: records.filter(a => a.isGroup).length }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    typeFilter && `section ${typeFilter}`,
    kindFilter && `head ${kindFilter === 'group' ? 'Group / Control' : 'Transactional'}`,
    statusFilter && `status ${statusFilter === 'active' ? 'Active' : 'Inactive'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setTypeFilter('');
    setKindFilter('');
    setStatusFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns = [
    { label: 'Code', value: (a: LedgerAccount) => a.code },
    { label: 'Account Name', value: (a: LedgerAccount) => a.name },
    { label: 'Type', value: (a: LedgerAccount) => a.type },
    { label: 'Head', value: (a: LedgerAccount) => (a.isGroup ? 'Group' : 'Transactional') },
    { label: 'Parent', value: (a: LedgerAccount) => a.parentName ?? '' },
    { label: 'Status', value: (a: LedgerAccount) => (a.isActive ? 'Active' : 'Inactive') }
  ];

  // The picker guards the shape two ways: a row never offers one of its own descendants as a
  // parent, and a branch that has already reached the third level offers no parent at all.
  // The server checks the same thing on the save, so a stale screen cannot grow a fourth.
  const descendantsOf = (id: number) => {
    const out = new Set<number>();
    const stack = [id];
    while (stack.length) {
      const cur = stack.pop()!;
      (childrenOf[cur] ?? []).forEach(k => { if (!out.has(k.id)) { out.add(k.id); stack.push(k.id); } });
    }
    return out;
  };

  // How deep an account already sits. The four sections are headings, not levels.
  const levelOf = (a: LedgerAccount | null | undefined) => {
    let n = a ? 1 : 0, cur = a;
    while (cur?.parentId) { cur = records.find(r => r.id === cur!.parentId) ?? null; n++; }
    return n;
  };

  const openNew = async (parent?: LedgerAccount) => {
    setError('');
    const base = blank();
    if (parent) {
      base.parentId = parent.id;
      base.type = parent.type;
    }
    base.code = await getProposedLedgerCode(tenantSlug, branchId, base.type, base.parentId).catch(() => '');
    setForm(base);
  };

  const reparent = async (parentId: number | null, type: LedgerAccount['type']) => {
    setForm(f => (f ? { ...f, parentId, type: parentId ? (records.find(r => r.id === parentId)?.type ?? f.type) : f.type } : f));
    const code = await getProposedLedgerCode(tenantSlug, branchId, parentId ? (records.find(r => r.id === parentId)?.type ?? type) : type, parentId).catch(() => '');
    if (code) setForm(f => (f ? { ...f, code } : f));
  };

  const submit = async (andNew = false) => {
    if (!form) return;
    if (!form.name.trim()) { setError('Account name is required'); return; }
    if (!form.code.trim()) { setError('Account code is required — use the refresh button to take the next free one'); return; }
    setSaving(true);
    setError('');
    try {
      const body: Partial<LedgerAccount> = { ...form };
      if (form.id) await updateLedgerAccount(tenantSlug, branchId, form.id, body);
      else await addLedgerAccount(tenantSlug, branchId, body);
      if (andNew) { await openNew(records.find(r => r.id === form.parentId)); }
      else setForm(null);
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (a: LedgerAccount) => {
    if (!window.confirm(`Delete ${a.code} · ${a.name}?`)) return;
    try {
      await deleteLedgerAccount(tenantSlug, branchId, a.id);
      load();
    } catch (e) {
      setNotice((e as Error).message);
    }
  };

  if (form) {
    const set = (patch: Partial<FormState>) => setForm(f => (f ? { ...f, ...patch } : f));
    const parent = form.parentId ? records.find(r => r.id === form.parentId) : null;
    const blocked = form.id ? descendantsOf(form.id) : new Set<number>();
    // Only a branch with room below it can take another row: an account at the third level is
    // the end of its branch, and a group needs two levels under it to hold anything.
    const parentChoices = records.filter(r =>
      r.id !== form.id && !blocked.has(r.id) &&
      levelOf(r) < (form.isGroup ? CHART_MAX_LEVEL - 1 : CHART_MAX_LEVEL));
    const isBankHead = !!parent && /bank/i.test(parent.name);
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => setForm(null)} className="btn-xenith-outline">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Chart of Accounts</span>
          </button>
          <span className="text-[11px] text-gray-500">{form.id ? `EDIT · ${form.code}` : 'NEW ACCOUNT'}</span>
        </div>

        <div className="nb-card p-0">
          <div className="px-4 py-3 border-b border-gray-100">
            <h2 className="page-title">{form.id ? 'Edit Account' : 'New Account'}</h2>
            <p className="text-xs text-gray-500">
              To add <span className="font-semibold">account openings</span>, please create a Journal Entry.
            </p>
          </div>

          {error && <p className="px-4 pt-3 text-xs text-red-600">{error}</p>}

          <div className="p-4 space-y-4">
            <div>
              <SectionTitle>General</SectionTitle>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Account Name" required>
                  <Text value={form.name} onChange={e => set({ name: e.target.value })} placeholder="e.g. Meezan Business Account" />
                </Field>
                <Field label="Account Code" required>
                  <div className="flex items-center gap-2">
                    <Text value={form.code} onChange={e => set({ code: e.target.value })} className="flex-1" />
                    <button
                      type="button"
                      title="Propose the next free code"
                      onClick={async () => set({ code: await getProposedLedgerCode(tenantSlug, branchId, form.type, form.parentId) })}
                      className="btn-xenith-outline !px-2"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </Field>
                <Field label="Parent Account" hint={parent
                  ? (form.isGroup && levelOf(parent) > 1
                      ? `A group stands only under a head — ${parent.name} is level ${levelOf(parent)} and already holds accounts.`
                      : `Becomes level ${levelOf(parent) + 1} under ${parent.name}.`)
                  : 'Leave blank for a top-level head.'}>
                  <SearchPick
                    options={parentChoices.map(r => ({ id: r.id, label: r.name, sub: `${r.code} · ${r.type} · level ${levelOf(r)}` }))}
                    valueId={form.parentId}
                    valueLabel={parent?.name}
                    onPick={o => reparent(o?.id ?? null, form.type)}
                    placeholder="Type to search account..."
                  />
                </Field>
                <Field label="Account Type" hint={parent ? 'Taken from the parent account.' : undefined}>
                  <Pick value={form.type} disabled={!!parent} onChange={e => set({ type: e.target.value as LedgerAccount['type'] })}>
                    {ACCOUNT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </Pick>
                </Field>
              </div>
            </div>

            <div>
              <SectionTitle>Posting</SectionTitle>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Head" hint="(Cannot be changed once account created)">
                  <div className="flex items-center gap-5 pt-1">
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 cursor-pointer">
                      <input type="radio" name="head" checked={!form.isGroup} disabled={!!form.id && form.isGroup === false}
                        onChange={() => set({ isGroup: false })} className="accent-[#1e88e5]" />
                      Transactional
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 cursor-pointer">
                      <input type="radio" name="head" checked={form.isGroup} disabled={!!form.id && form.isGroup === true}
                        onChange={() => set({ isGroup: true })} className="accent-[#1e88e5]" />
                      Group / Control
                    </label>
                  </div>
                  <p className="text-[11px] text-gray-500 mt-1">
                    {form.isGroup
                      ? 'A group only collects its sub-accounts — journal entries must use a sub-account.'
                      : 'This account can receive journal entries, receipts and payments.'}
                  </p>
                </Field>
                <Field label={`Opening Balance (${currency})`} hint="Debits positive, credits negative.">
                  <Text type="number" value={String(form.openingBalance)} onChange={e => set({ openingBalance: Number(e.target.value) })} disabled={form.isGroup} />
                </Field>
              </div>
            </div>

            {isBankHead && (
              <div>
                <SectionTitle>Bank Details</SectionTitle>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Bank Name">
                    <Text value={form.bankName} onChange={e => set({ bankName: e.target.value })} />
                  </Field>
                  <Field label="Account Number">
                    <Text value={form.accountNumber} onChange={e => set({ accountNumber: e.target.value })} />
                  </Field>
                  <Field label="Branch Code">
                    <Text value={form.branchCode} onChange={e => set({ branchCode: e.target.value })} />
                  </Field>
                  <Field label="Branch Name">
                    <Pick value={form.branchName} onChange={e => set({ branchName: e.target.value })}>
                      <option value="">Select branch...</option>
                      {allBranches.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                    </Pick>
                  </Field>
                  <Field label="IBAN">
                    <Text value={form.iban} onChange={e => set({ iban: e.target.value })} />
                  </Field>
                  <div className="flex items-end gap-6 pb-1">
                    <Check checked={form.acceptsChequeBook} onChange={v => set({ acceptsChequeBook: v })} label="Issue cheque book" />
                    <Check checked={form.acceptsCreditCard} onChange={v => set({ acceptsCreditCard: v })} label="Credit card account" />
                  </div>
                </div>
              </div>
            )}

            <div>
              <SectionTitle>Notes</SectionTitle>
              <Field label="Description">
                <Area rows={2} value={form.description} onChange={e => set({ description: e.target.value })} />
              </Field>
              <div className="mt-3">
                <Check checked={form.isActive} onChange={v => set({ isActive: v })} label="Active — available on documents and journals" />
              </div>
            </div>
          </div>

          <FormFooter
            onSave={(status) => submit(status === 'new')}
            onClose={() => setForm(null)}
            saving={saving}
            saveLabel={form.id ? 'SAVE ACCOUNT' : 'ADD ACCOUNT'}
            statusOptions={[{ label: 'Save and New', value: 'new' }]}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Chart of Accounts</h2>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD ACCOUNT" onAdd={() => openNew()}>
            <button type="button" onClick={load} className="btn-xenith-outline"><RefreshCw className="w-3.5 h-3.5" />Refresh</button>
          </ListToolbar>
        </div>
        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by code, name, type or bank" onSearch={setSearch} />
          <StatusPills value={typeFilter} onChange={setTypeFilter} counts={typeCounts} />
          <span className="filter-plate">
            <select aria-label="Filter by head" value={kindFilter} onChange={e => setKindFilter(e.target.value)}>
              {kindCounts.map(c => <option key={c.value || 'all'} value={c.value}>{c.label}</option>)}
            </select>
            {kindFilter && (
              <button type="button" title="Show every head" onClick={() => setKindFilter('')} className="text-gray-400 hover:text-gray-600">
                <X className="w-3 h-3" />
              </button>
            )}
          </span>
          <span className="filter-plate">
            <select aria-label="Filter by status" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
              <option value="">Any status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            {statusFilter && (
              <button type="button" title="Show both statuses" onClick={() => setStatusFilter('')} className="text-gray-400 hover:text-gray-600">
                <X className="w-3 h-3" />
              </button>
            )}
          </span>
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Chart of Accounts" filename="chart-of-accounts" columns={columns} rows={flatForExport} />
          </span>
        </div>
      </div>

      {notice && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 flex items-start justify-between gap-3">
          <span>{notice}</span>
          <button type="button" className="text-red-400 hover:text-red-700 leading-none" onClick={() => setNotice('')} aria-label="Dismiss">×</button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
        <table className="xenith-table">
          <thead className="sticky top-0 z-10">
            <tr>
              <th className="w-[12%]">Code</th>
              <th>Account Name</th>
              <th className="w-[12%]">Type</th>
              <th className="w-[14%]">Head</th>
              <th className="w-[10%]">Status</th>
              <th className="text-center w-[14%]">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 7 }).map((_, i) => (
              <tr key={i}>
                <td colSpan={6}>
                  <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 6}%` }} />
                </td>
              </tr>
            ))}
            {!loading && tree.length === 0 && (
              <TableEmpty colSpan={6} noun="accounts" filters={activeFilters} cleared={clearAll}
                addLabel={records.length ? undefined : 'ADD ACCOUNT'} onAdd={() => openNew()} />
            )}
            {!loading && tree.map(({ section, entries }) => {
              const open = !!expanded[`t${section}`];
              const countOf = records.filter(r => SECTION_TYPES[section].includes(r.type)).length;
              return (
                <React.Fragment key={section}>
                  <tr className="bg-gray-50">
                    <td colSpan={6}>
                      <button
                        type="button"
                        onClick={() => openRow(`t${section}`)}
                        className="flex items-center gap-1.5 font-bold text-gray-700 text-xs uppercase tracking-wide"
                      >
                        {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                        {section}
                        <span className="font-normal normal-case text-gray-400">({countOf})</span>
                      </button>
                    </td>
                  </tr>
                  {entries.map(({ account: a, depth }) => {
                    const kids = (childrenOf[a.id] ?? []).filter(k => visible.includes(k));
                    const isOpen = !!expanded[`a${a.id}`];
                    return (
                      <tr key={a.id} className={a.isGroup ? 'bg-blue-50/40' : ''}>
                        <td className="font-mono text-blue-700">{a.code}</td>
                        <td>
                          <span style={{ paddingLeft: `${depth * 18}px` }} className="inline-flex items-center gap-1.5">
                            {kids.length > 0 && (
                              <button
                                type="button"
                                title={isOpen ? 'Hide sub-accounts' : `Show ${kids.length} sub-account(s)`}
                                onClick={() => openRow(`a${a.id}`)}
                                className="text-gray-400 hover:text-gray-700"
                              >
                                {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                              </button>
                            )}
                            {/* The name is the thing a reader aims at, so it opens the row
                                too — no hunting for a chevron three pixels wide. */}
                            {kids.length > 0 ? (
                              <button type="button" onClick={() => openRow(`a${a.id}`)}
                                className={`text-left hover:text-[#1e88e5] transition-colors ${depth === 0 ? 'font-semibold text-gray-800' : 'text-gray-700'}`}>
                                {a.name}
                              </button>
                            ) : (
                              <span className={depth === 0 ? 'font-semibold text-gray-800' : 'text-gray-700'}>{a.name}</span>
                            )}
                            {kids.length > 0 && <span className="text-[10px] text-gray-400">({kids.length})</span>}
                          </span>
                        </td>
                        <td>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${typeColor[a.type]}`}>{a.type}</span>
                        </td>
                        <td className="text-xs text-gray-600">{a.isGroup ? 'Group / Control' : 'Transactional'}</td>
                        <td>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${a.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                            {a.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="text-center whitespace-nowrap">
                          {/* The third level is where the postings live, so a row standing there
                              has nothing to add beneath it. */}
                          {depth + 1 < CHART_MAX_LEVEL && (
                            <IconAction title={`Add a sub-account under ${a.name}`} tone="success" onClick={() => openNew(a)}>
                              <span className="text-sm font-bold">+</span>
                            </IconAction>
                          )}
                          <IconAction title={`Edit ${a.name}`} onClick={() => { setError(''); setForm(ofRecord(a)); }}><Pencil className="w-4 h-4" /></IconAction>
                          <IconAction title={`Delete ${a.name}`} tone="danger" onClick={() => remove(a)}><Trash2 className="w-4 h-4" /></IconAction>
                        </td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
};

export default ChartOfAccounts;
