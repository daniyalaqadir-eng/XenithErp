import React, { useState, useEffect } from 'react';
import { useTenant } from '../../context/TenantContext';
import { DetailBGroup } from '../../types';
import { getDetailBGroup, markDetailBGroupDefault, saveDetailBGroup, updateDetailBGroup } from '../../services/groups.service';
import { Save, ChevronDown, PlusCircle, Star, X } from 'lucide-react';

interface DetailBGroupFormProps {
  groupId?: number | null;
  onClose: () => void;
}

export const DetailBGroupForm: React.FC<DetailBGroupFormProps> = ({ groupId, onClose }) => {
  const { tenantSlug, branchId, branches, enableBranch } = useTenant();
  const [name, setName] = useState('');
  const [selectedBranchIds, setSelectedBranchIds] = useState<number[]>([branchId]);
  const [isDefault, setIsDefault] = useState(false);
  // A record created here keeps the id the server gave it, so a second Save updates that row
  // instead of writing a twin of it.
  const [editId, setEditId] = useState<number | null>(groupId ?? null);
  const [errors, setErrors] = useState<{ name?: string; branches?: string }>({});
  const [formError, setFormError] = useState('');
  const [notice, setNotice] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveAction, setSaveAction] = useState<'save-and-close' | 'save-only' | 'save-and-new'>('save-and-close');
  const [showSaveDropdown, setShowSaveDropdown] = useState(false);
  const mode = editId ? 'edit' : 'add';

  useEffect(() => {
    setEditId(groupId ?? null);
    setFormError(''); setNotice('');
    if (groupId) {
      getDetailBGroup(tenantSlug, branchId, groupId)
        .then(data => {
          setName(data.name);
          setIsDefault(!!data.isDefault);
          setSelectedBranchIds(data.branchIds || []);
        })
        .catch(e => setFormError((e as Error).message));
    } else {
      setName('');
      setSelectedBranchIds([branchId]);
      setIsDefault(false);
    }
  }, [groupId, tenantSlug, branchId]);

  const toggleBranch = (bId: number) => {
    if (selectedBranchIds.includes(bId)) {
      setSelectedBranchIds(selectedBranchIds.filter(id => id !== bId));
    } else {
      setSelectedBranchIds([...selectedBranchIds, bId]);
    }
  };

  const validate = (): boolean => {
    const errs: { name?: string; branches?: string } = {};
    if (!name.trim()) {
      errs.name = 'Customer Group name is required.';
    }
    // Without a branch on the list the group exists but no branch can file a client under it.
    if (enableBranch && !selectedBranchIds.length) {
      errs.branches = 'Tick at least one branch that may use this group.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = (action = saveAction) => {
    if (!validate()) return;
    setIsSubmitting(true);
    setFormError(''); setNotice('');

    const payload = {
      name: name.trim(),
      branchIds: selectedBranchIds,
      isDefault
    };

    const req = editId
      ? updateDetailBGroup(tenantSlug, branchId, editId, payload)
      : saveDetailBGroup(tenantSlug, branchId, payload);

    req.then(saved => {
      if (saved?.id) setEditId(saved.id);
      setIsSubmitting(false);
      if (action === 'save-and-close') {
        onClose();
      } else if (action === 'save-and-new') {
        setEditId(null);
        setName('');
        setSelectedBranchIds([branchId]);
        setIsDefault(false);
        setNotice(editId ? `${payload.name} has been updated.` : `${payload.name} has been added.`);
      } else {
        setNotice(editId ? `${payload.name} has been updated.` : `${payload.name} has been saved. Its id is now on the form, so the next Save updates it.`);
      }
    })
      .catch(e => { setIsSubmitting(false); setFormError((e as Error).message); });
  };

  const markAsDefault = () => {
    if (!editId) return;
    setFormError(''); setNotice('');
    markDetailBGroupDefault(tenantSlug, branchId, editId)
      .then(() => { setIsDefault(true); setNotice(`${name} is now the default customer group.`); })
      .catch(e => setFormError((e as Error).message));
  };

  return (
    <div className="space-y-4">
      {/* Form Card */}
      <div className="nb-card">
        <div className="nb-card-header page-head">
          <div className="flex items-center gap-2">
            <span className="text-gray-700">
              Customer Group - {mode === 'edit' ? 'Edit' : 'Add'}
            </span>
            {name && <span className="font-bold text-gray-900">[{name.toUpperCase()}]</span>}
          </div>
          {isDefault && (
            <span className="bg-emerald-50 text-emerald-600 border border-emerald-200 px-2 py-0.5 rounded text-[11px] font-bold">
              DEFAULT
            </span>
          )}
        </div>

        <div className="nb-card-body space-y-4">
          {/* Group Name Input */}
          <div className="max-w-md">
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Customer Group Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              maxLength={100}
              placeholder="Customer Group Name"
              onChange={e => {
                setName(e.target.value);
                if (errors.name) setErrors({});
              }}
              className={`w-full border rounded px-3 py-1.5 text-xs focus:outline-none focus:ring-1 ${
                errors.name ? 'border-red-400 focus:ring-red-400' : 'border-gray-300 focus:ring-blue-500'
              }`}
            />
            {errors.name && (
              <p className="text-red-500 text-[11px] mt-1">{errors.name}</p>
            )}
          </div>

          {/* Assigned Branches (app-detail-selector) */}
          {enableBranch && (
            <div className="border-t border-gray-100 pt-4">
              <label className="block text-xs font-semibold text-gray-700 mb-2">
                Assigned Branches
              </label>
              <div className="max-w-md bg-gray-50 border border-gray-200 rounded p-3 space-y-2">
                <div className="text-[11px] text-gray-500 font-medium pb-1 border-b border-gray-200">
                  Select branches that have access to this group:
                </div>
                {branches.map(b => {
                  const isChecked = selectedBranchIds.includes(b.id);
                  return (
                    <label
                      key={b.id}
                      className="flex items-center gap-2 cursor-pointer text-xs text-gray-700 hover:text-gray-900"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleBranch(b.id)}
                        className="rounded border-gray-300 text-blue-600 focus:ring-0"
                      />
                      <span>{b.name}</span>
                      {b.isMain && (
                        <span className="text-[10px] text-gray-400 bg-gray-200/60 px-1.5 py-0.2 rounded">
                          Main
                        </span>
                      )}
                    </label>
                  );
                })}
              </div>
              {errors.branches && (
                <p className="text-red-500 text-[11px] mt-1">{errors.branches}</p>
              )}
            </div>
          )}

          {(formError || notice) && (
            <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
              formError ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
              <span>{formError || notice}</span>
              <button type="button" onClick={() => { setFormError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
            </div>
          )}

          <hr className="border-gray-100" />

          {/* Action Buttons: 3-Way Save Dropdown + Close + Mark as Default */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              {/* 3-Way Save Button */}
              <div className="relative flex items-center">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => handleSave(saveAction)}
                  className="bg-[#2ec4b6] hover:bg-[#25a195] text-white px-3 py-1.5 rounded-l text-xs font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>
                    {saveAction === 'save-and-close' && 'Save & Close'}
                    {saveAction === 'save-only' && 'Save'}
                    {saveAction === 'save-and-new' && 'Save & New'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowSaveDropdown(!showSaveDropdown)}
                  className="bg-[#25a195] hover:bg-[#1f877d] text-white px-1.5 py-1.5 rounded-r border-l border-[#208a80] text-xs transition-colors"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {showSaveDropdown && (
                  <div className="absolute left-0 bottom-full mb-1 w-36 bg-white border border-gray-200 rounded shadow-lg py-1 z-50 text-xs">
                    <button
                      onClick={() => { setSaveAction('save-only'); setShowSaveDropdown(false); handleSave('save-only'); }}
                      className="w-full text-left px-3 py-1.5 hover:bg-gray-100 flex items-center gap-1.5 text-gray-700"
                    >
                      <PlusCircle className="w-3 h-3 text-emerald-500" /> Save
                    </button>
                    <button
                      onClick={() => { setSaveAction('save-and-new'); setShowSaveDropdown(false); handleSave('save-and-new'); }}
                      className="w-full text-left px-3 py-1.5 hover:bg-gray-100 flex items-center gap-1.5 text-gray-700"
                    >
                      <PlusCircle className="w-3 h-3 text-blue-500" /> Save & New
                    </button>
                    <button
                      onClick={() => { setSaveAction('save-and-close'); setShowSaveDropdown(false); handleSave('save-and-close'); }}
                      className="w-full text-left px-3 py-1.5 hover:bg-gray-100 flex items-center gap-1.5 text-gray-700"
                    >
                      <PlusCircle className="w-3 h-3 text-purple-500" /> Save & Close
                    </button>
                  </div>
                )}
              </div>

              {/* Close Button */}
              <button
                type="button"
                onClick={onClose}
                className="btn-xenith-warning"
              >
                <X className="w-3.5 h-3.5" />
                <span>Close</span>
              </button>
            </div>

            {/* Mark as Default Button */}
            {mode === 'edit' && !isDefault && (
              <button
                type="button"
                onClick={markAsDefault}
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Star className="w-3.5 h-3.5" />
                <span>Mark as Default</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
