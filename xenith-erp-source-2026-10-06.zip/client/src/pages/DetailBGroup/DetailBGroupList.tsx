import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, Pencil, Trash2, Users, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { DetailBGroup } from '../../types';
import {
  deleteDetailBGroup, getDetailBGroups, markDetailBGroupDefault
} from '../../services/groups.service';
import { DetailBGroupForm } from './DetailBGroupForm';
import {
  DeleteConfirm, ExportPair, IconAction, ListToolbar, RegisterStat, SearchBox,
  SortHeader, SortState, StatStrip, StatusPills, TableEmpty
} from '../Masters/masterUi';
import { ExportColumn } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

// The original book calls these Detail B groups; on screen they are the customer groups a
// branch is allowed to file clients under.
const CAPTION = 'Customer Groups';
const SINGULAR = 'Customer Group';

export const DetailBGroupList: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  const [groups, setGroups] = useState<DetailBGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [state, setState] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'name', dir: 'asc' });
  const [editing, setEditing] = useState<number | null | 'new'>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const load = useCallback(() => {
    setLoading(true); setLoadError('');
    getDetailBGroups(tenantSlug, branchId)
      .then(list => setGroups(Array.isArray(list) ? list : []))
      .catch(e => setLoadError((e as Error).message))
      .finally(() => setLoading(false));
  }, [tenantSlug, branchId]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const editable = can('detail-b-groups:edit');

  const branchNames = (g: DetailBGroup) => (g.branches || []).map(b => b.name);

  const searched = useMemo(() => {
    const term = search.trim().toLowerCase();
    return groups.filter(g => !term
      || `${g.name} ${branchNames(g).join(' ')}`.toLowerCase().includes(term));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groups, search]);

  const visible = useMemo(() => {
    const list = searched.filter(g => !state
      || (state === 'Default' ? !!g.isDefault : !g.isDefault));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      if (sort.key === 'branchCount') return ((a.branchIds?.length ?? 0) - (b.branchIds?.length ?? 0)) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [searched, state, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const stats: RegisterStat[] = [
    {
      label: CAPTION,
      value: (search || state) ? `${visible.length} of ${groups.length}` : String(groups.length),
      title: 'Groups the search and the state pill leave on screen'
    },
    {
      label: 'Reaching this branch',
      value: groups.filter(g => (g.branchIds || []).includes(Number(branchId))).length, tone: 'ok',
      title: `Groups whose access list includes the branch currently open. A group without it cannot be picked on this branch's papers`
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: searched.length },
    { value: 'Default', label: 'Default', count: searched.filter(g => g.isDefault).length },
    { value: 'Other', label: 'Other', count: searched.filter(g => !g.isDefault).length }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    state && `state ${state === 'Default' ? 'the default group' : 'other groups'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setState('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<DetailBGroup>[] = [
    { label: SINGULAR + ' Name', value: g => g.name },
    { label: 'Default', value: g => g.isDefault ? 'Yes' : 'No' },
    { label: 'Assigned Branches', value: g => branchNames(g).join(', ') || 'None' },
    { label: 'Branch Count', value: g => String((g.branchIds || []).length), align: 'right' }
  ];

  const makeDefault = async (g: DetailBGroup) => {
    setError(''); setNotice('');
    try {
      await markDetailBGroupDefault(tenantSlug, branchId, g.id!);
      setNotice(`${g.name} is now the default ${SINGULAR.toLowerCase()}.`);
      load();
    } catch (e) { setError((e as Error).message); }
  };

  const remove = async (g: DetailBGroup) => {
    setError(''); setNotice('');
    try {
      await deleteDetailBGroup(tenantSlug, branchId, g.id!);
      setNotice(`${g.name} has been deleted.`);
      load();
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  if (editing !== null) {
    return (
      <DetailBGroupForm
        groupId={editing === 'new' ? null : editing}
        onClose={() => { setEditing(null); load(); }}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">{CAPTION} (Detail B)</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Buckets clients are filed under, each with the list of branches allowed to use it.
              One group is the default a new customer opens on; a group missing this branch cannot
              be picked on the papers being written here.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {can('detail-b-groups:add') && (
            <ListToolbar addLabel={`ADD ${SINGULAR.toUpperCase()}`} onAdd={() => setEditing('new')} />
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by group or branch name" onSearch={setSearch} />
          <StatusPills value={state} onChange={setState} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={`${CAPTION} (Detail B)`}
              subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="customer-groups" columns={columns} rows={visible} />
          </span>
        </div>
      </div>

      {(error || loadError || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || loadError ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || loadError || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label={SINGULAR + ' Name'} sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Branch access" sortKey="branchCount" sort={sort} onSort={onSort} />
                <th className="w-40 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={3}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={3} noun={CAPTION.toLowerCase()} filters={activeFilters} cleared={clearAll}
                  addLabel={groups.length || !can('detail-b-groups:add') ? undefined : `ADD ${SINGULAR.toUpperCase()}`}
                  onAdd={() => setEditing('new')} />
              )}
              {!loading && visible.map(g => {
                const here = (g.branchIds || []).includes(Number(branchId));
                return (
                  <tr key={g.id}>
                    <td>
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                        <span className="flex items-center gap-2 font-bold text-gray-800">
                          <Users className="w-4 h-4 text-gray-400" />
                          <span>{g.name}</span>
                        </span>
                        {g.isDefault && (
                          <span className="text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-full px-1.5">
                            Default group
                          </span>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="flex flex-wrap items-center gap-1">
                        {/* The branch the screen is open on is marked, since that is the one line
                            deciding whether this group can be picked here at all. */}
                        {(g.branches || []).map(b => (
                          <span key={b.id} title={b.id === Number(branchId) ? 'The branch this screen is open on' : undefined}
                            className={`text-[10px] px-1.5 py-0.5 rounded border ${
                              b.id === Number(branchId)
                                ? 'bg-teal-50 text-[#25a195] border-teal-100 font-bold'
                                : 'bg-gray-100 text-gray-600 border-gray-200'}`}>
                            {b.name}
                          </span>
                        ))}
                        {!(g.branchIds || []).length && <span className="text-[11px] text-gray-400">No branch can pick this group</span>}
                        {!here && !!g.branchIds?.length && (
                          <span className="text-[10px] text-amber-600 font-semibold">not on this branch</span>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center gap-1 justify-end">
                        {!g.isDefault && editable && (
                          <IconAction title={`Make ${g.name} the default ${SINGULAR.toLowerCase()}`} tone="success"
                            onClick={() => makeDefault(g)}><Check className="w-4 h-4" /></IconAction>
                        )}
                        {editable && (
                          <IconAction title={`Edit ${g.name}`} tone="primary"
                            onClick={() => setEditing(g.id!)}><Pencil className="w-4 h-4" /></IconAction>
                        )}
                        {can('detail-b-groups:delete') && (g.isDefault ? (
                          <IconAction title={`The default ${SINGULAR.toLowerCase()} cannot be deleted — make another one default first`} disabled>
                            <Trash2 className="w-4 h-4" />
                          </IconAction>
                        ) : confirmId === g.id ? (
                          <DeleteConfirm onConfirm={() => remove(g)} onCancel={() => setConfirmId(null)}
                            keepLabel={`Keep ${g.name} on the register`} />
                        ) : (
                          <IconAction title={`Delete ${SINGULAR.toLowerCase()}`} tone="danger" onClick={() => setConfirmId(g.id!)}>
                            <Trash2 className="w-4 h-4" />
                          </IconAction>
                        ))}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {/* No figure adds up here — access lists carry branch names, not money or quantity —
                so neither the table nor the export closes with a totals line. */}
          </table>
        </div>
      </div>
    </div>
  );
};

export default DetailBGroupList;
