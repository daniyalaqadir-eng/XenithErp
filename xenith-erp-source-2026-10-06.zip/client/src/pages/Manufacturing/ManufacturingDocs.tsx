import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { isoDay } from '../../utils/dateRange';
import {
  ArrowLeft, ChevronDown, Columns3, Edit2, Factory, Plus, RefreshCw,
  Save, Trash2, X
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import { getLedgerAccounts } from '../../services/accounts.service';
import {
  deleteMfgDoc, getMfgDocs, getMfgItems, getMfgProposedNumber, MfgDoc, MfgExpense,
  MfgItem, MfgKindKey, MfgLine, MfgStatus, saveMfgDoc, updateMfgDoc
} from '../../services/manufacturing.service';
import {
  AttachmentBox, DateWindow, DeleteConfirm, ExportPair, Field, IconAction, ListToolbar, NumCell, Pick, RegisterStat,
  SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

export interface MfgKindSpec {
  key: MfgKindKey;
  title: string;
  formTitle: string;
  addLabel: string;
  productLabel: string;
  listProductLabel: string;
  detailsLabel: string;
  qtyLabel: string;
  hasDueDate: boolean;
  hasMethod: boolean;
  hasAttachments: boolean;
  // What this kind of paper is for, stated above the register instead of leaving the reader
  // to guess it from a column list.
  blurb: string;
  icon: React.ReactNode;
}

export const MFG_BY_TAB: Record<string, MfgKindSpec> = {
  'manufacturing-job-orders': {
    key: 'job-orders', title: 'Job Orders / Assembling', formTitle: 'Job Orders', addLabel: 'ADD JOB ORDER',
    productLabel: 'Product To Assemble', listProductLabel: 'Assembly Product', detailsLabel: 'Assembly Details',
    qtyLabel: 'Quantity To Produce',
    hasDueDate: true, hasMethod: true, hasAttachments: true,
    blurb: 'Materials and expenses go into a build, the finished product comes out of it carrying their total as its '
      + 'cost. The register below is the cost sheet of every build the workshop has written up.',
    icon: <Factory className="w-4 h-4" />
  },
  'manufacturing-disassemblies': {
    key: 'disassemblies', title: 'Disassembling', formTitle: 'Disassemblies', addLabel: 'ADD DISASSEMBLY',
    productLabel: 'Product To Disassemble', listProductLabel: 'Disassembly Product', detailsLabel: 'Disassembly Details',
    qtyLabel: 'Quantity to disassemble',
    hasDueDate: false, hasMethod: false, hasAttachments: false,
    blurb: 'One product goes in and several come out — a bundle broken up, a returned unit stripped for parts. What '
      + 'came out is priced by splitting what went in across it.',
    icon: <Columns3 className="w-4 h-4" />
  }
};

const STATUSES: MfgStatus[] = ['Draft', 'Confirmed', 'Completed', 'Cancelled'];

const STATUS_BADGE: Record<MfgStatus, string> = {
  Draft: 'bg-gray-100 text-gray-600 border-gray-200',
  Confirmed: 'bg-blue-50 text-blue-700 border-blue-200',
  Completed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Cancelled: 'bg-red-50 text-red-700 border-red-200'
};

const round2 = roundMoney;
const money = (n: number) => round2(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const blankLine = (costPercent = 100): MfgLine => ({
  productId: null, productName: '', sku: '', batch: '', quantity: 0, cost: 0, costPercent, amount: 0
});
const blankExpense = (): MfgExpense => ({ accountName: '', description: '', amount: 0 });

const blankDoc = (spec: MfgKindSpec, number: string): Partial<MfgDoc> => ({
  number, date: isoDay(), dueDate: spec.hasDueDate ? isoDay() : '',
  reference: '', productName: '', productId: null, quantity: 0,
  calculationMethod: 'Method 1', status: 'Draft',
  inputs: [blankLine()], outputs: [blankLine()], expenses: [], comments: '', attachments: []
});

// Mirrors the server's recomputeMfg so the form totals move while you type.
interface Derived { inputs: MfgLine[]; outputs: MfgLine[]; materialCost: number; expenseCost: number; totalCost: number; producedQty: number; unitCost: number }
const derive = (f: Partial<MfgDoc>): Derived => {
  const inputs = (f.inputs || []).map(l => ({ ...l, amount: round2(l.quantity * l.cost) }));
  const materialCost = round2(inputs.reduce((s, l) => s + l.amount, 0));
  const expenseCost = round2((f.expenses || []).reduce((s, e) => s + e.amount, 0));
  const producedQty = round2((f.outputs || []).reduce((s, l) => s + l.quantity, 0));
  const byPercent = (f.calculationMethod || 'Method 1') === 'Method 1';
  const pool = materialCost + expenseCost;
  const outputs = (f.outputs || []).map(l => (byPercent
    ? { ...l, amount: round2(pool * (l.costPercent / 100)), cost: l.quantity ? round2(pool * (l.costPercent / 100) / l.quantity) : 0 }
    : { ...l, amount: round2(l.quantity * l.cost) }));
  const totalCost = byPercent ? round2(pool) : round2(outputs.reduce((s, l) => s + l.amount, 0));
  return { inputs, outputs, materialCost, expenseCost, totalCost, producedQty, unitCost: producedQty ? round2(totalCost / producedQty) : 0 };
};

export const ManufacturingDocs: React.FC<{ spec: MfgKindSpec }> = ({ spec }) => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<MfgDoc[]>([]);
  const [items, setItems] = useState<MfgItem[]>([]);
  const [accounts, setAccounts] = useState<{ id: number; name: string }[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'date', dir: 'desc' });
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<Partial<MfgDoc>>(blankDoc(spec, ''));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [showExpenses, setShowExpenses] = useState(false);

  // The status pill writes a count, so the register asks the server for the whole search
  // result and cuts the status out of it here — otherwise the pill could only ever show one.
  const load = useCallback(async () => {
    setLoading(true);
    const res = await getMfgDocs(spec.key, tenantSlug, branchId, search, '');
    setRows(res.data);
    setLoading(false);
  }, [spec.key, tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);
  useEffect(() => {
    getMfgItems(tenantSlug, branchId).then(setItems).catch(() => setItems([]));
    getLedgerAccounts(tenantSlug, branchId)
      .then(r => setAccounts(r.data.filter(a => a.type === 'Expense').map(a => ({ id: a.id, name: a.name }))))
      .catch(() => setAccounts([]));
  }, [tenantSlug, branchId]);

  const productOptions: SelectOption[] = useMemo(
    () => items.map(i => ({ id: i.id, label: i.name, hint: `${i.sku} · stock ${i.stockQty}` })),
    [items]
  );

  const qtyOf = (r: MfgDoc) => r.producedQty || r.quantity;
  const colCount = 7 + (spec.hasDueDate ? 1 : 0);

  // Everything but the status pill: a pill writes its own count, so that count is taken
  // over the documents the search and the window still leave standing. These run above the
  // form branch, because a screen cannot trade in its hooks for the shape of a paper.
  const inScope = useMemo(() => rows.filter(r =>
    (!fromDate || r.date >= fromDate) && (!toDate || r.date <= toDate)), [rows, fromDate, toDate]);

  const visible = useMemo(() => {
    const list = status ? inScope.filter(r => r.status === status) : inScope;
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    const val = (r: any, k: string) => (k === 'qty' ? qtyOf(r) : r[k]);
    return [...list].sort((a: any, b: any) => {
      const av = val(a, sort.key), bv = val(b, sort.key);
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [inScope, status, sort]);

  // Each column added up as it is printed, so a chip can never disagree with the line under
  // the table, nor with the sheet and the workbook.
  const shown = useMemo(() => ({
    qty: round2(visible.reduce((s, r) => s + qtyOf(r), 0)),
    cost: round2(visible.reduce((s, r) => s + r.totalCost, 0)),
    open: visible.filter(r => r.status === 'Draft' || r.status === 'Confirmed').length
  }), [visible]);

  const derived = useMemo(() => derive(form), [form]);
  const set = (changes: Partial<MfgDoc>) => setForm(f => ({ ...f, ...changes }));

  const patchLine = (field: 'inputs' | 'outputs', i: number, changes: Partial<MfgLine>) =>
    setForm(f => ({ ...f, [field]: (f[field] || []).map((l, j) => (j === i ? { ...l, ...changes } : l)) }));

  const addLine = (field: 'inputs' | 'outputs') =>
    setForm(f => ({ ...f, [field]: [...(f[field] || []), blankLine()] }));

  const dropLine = (field: 'inputs' | 'outputs', i: number) =>
    setForm(f => ({ ...f, [field]: (f[field] || []).filter((_, j) => j !== i) }));

  const pickProduct = (field: 'inputs' | 'outputs', i: number, id: number | null) => {
    const item = items.find(x => x.id === id);
    patchLine(field, i, {
      productId: id, productName: item?.name || '', sku: item?.sku || '',
      cost: item ? (field === 'inputs' ? item.cost : item.cost || item.price) : 0
    });
  };

  const openNew = async () => {
    setError('');
    const number = await getMfgProposedNumber(spec.key, tenantSlug, branchId).catch(() => '');
    setForm(blankDoc(spec, number));
    setShowExpenses(false);
    setEditId(null);
    setMode('form');
  };

  const openEdit = (doc: MfgDoc) => {
    setError('');
    setForm(doc);
    setEditId(doc.id);
    setShowExpenses((doc.expenses || []).length > 0);
    setMode('form');
  };

  const handleSave = async (asNew = false, nextStatus?: MfgStatus) => {
    setError('');
    if (!form.productName?.trim()) { setError('A product is required before the document can be saved.'); return; }
    if (!form.date) { setError('Date is required.'); return; }
    const payload: Partial<MfgDoc> = {
      ...form,
      status: nextStatus || form.status || 'Draft',
      expenses: showExpenses ? (form.expenses || []) : [],
      outputs: (form.outputs || []).filter(l => l.productName),
      inputs: (form.inputs || []).filter(l => l.productName)
    };
    setSaving(true);
    try {
      const saved = editId
        ? await updateMfgDoc(spec.key, tenantSlug, branchId, editId, payload)
        : await saveMfgDoc(spec.key, tenantSlug, branchId, payload);
      if (asNew) {
        setForm(blankDoc(spec, await getMfgProposedNumber(spec.key, tenantSlug, branchId)));
        setShowExpenses(false);
        setEditId(null);
      } else {
        setMode('list');
      }
      load();
      return saved;
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (r: MfgDoc) => {
    setConfirmId(null); setError(''); setNotice('');
    try {
      await deleteMfgDoc(spec.key, tenantSlug, branchId, r.id);
      setNotice(`${r.number} has been taken back off the register.`);
      load();
    } catch (e) { setError((e as Error).message); }
  };

  if (mode === 'form') {
    const jumpTargets = rows.filter(r => r.id !== editId);
    return (
      <div className="animate-[fadeUp_.3s_ease-out_backwards]">
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button type="button" onClick={() => setMode('list')} className="btn-xenith-outline !px-2" title="Back to list">
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
            <span className="w-8 h-8 rounded-lg bg-[#2ec4b6]/10 text-[#1ba396] flex items-center justify-center shrink-0">{spec.icon}</span>
            <div className="min-w-0">
              <h1 className="page-title">
                {spec.formTitle} - [{form.number || 'new'}]
              </h1>
              <p className="text-[11px] text-gray-400 truncate">{form.productName || 'Select a product to begin'}</p>
            </div>
            <span className={`shrink-0 px-2 py-0.5 rounded-full border text-[10px] font-black tracking-wider ${STATUS_BADGE[(form.status || 'Draft') as MfgStatus]}`}>
              {(form.status || 'Draft').toUpperCase()}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-gray-400">Total Cost</span>
            <span className="text-sm font-black text-gray-800 tabular-nums whitespace-nowrap">PKR {money(derived.totalCost)}</span>
          </div>
        </div>

        <div className="panel-xenith">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
            <h2 className="section-title">{spec.detailsLabel}</h2>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
            <Field label={spec.productLabel} required className="sm:col-span-2 xl:col-span-1">
              <SearchSelect options={productOptions} value={form.productId ?? null}
                onChange={id => {
                  const item = items.find(x => x.id === id);
                  set({ productId: id, productName: item?.name || '' });
                }}
                invalid={!form.productName} />
            </Field>

            <Field label="Number">
              <div className="flex items-stretch gap-1">
                <Text value={form.number || ''} readOnly className="bg-gray-50 font-mono text-[11px]" />
                <details className="relative group">
                  <summary className="list-none cursor-pointer bg-[#2ec4b6] hover:bg-[#25a195] text-white px-1.5 rounded inline-flex items-center" title="Jump to another record">
                    <ChevronDown className="w-3.5 h-3.5" />
                  </summary>
                  <ul className="absolute right-0 top-full mt-1 max-h-56 overflow-y-auto w-56 bg-white border border-gray-200 rounded shadow-lg z-40 text-xs">
                    {jumpTargets.length === 0 && <li className="px-3 py-2 text-gray-400">No other records</li>}
                    {jumpTargets.map(r => (
                      <li key={r.id}>
                        <button type="button" className="w-full text-left px-3 py-1.5 hover:bg-blue-50 text-gray-700" onClick={() => openEdit(r)}>
                          {r.number} — {r.productName}
                        </button>
                      </li>
                    ))}
                  </ul>
                </details>
                <button type="button" title="Get the next number"
                  onClick={() => getMfgProposedNumber(spec.key, tenantSlug, branchId).then(number => set({ number }))}
                  className="btn-xenith-outline !px-2 !py-0">
                  <RefreshCw className="w-3.5 h-3.5 text-[#1ba396]" />
                </button>
              </div>
            </Field>

            <Field label="Date" required><Text type="date" value={form.date || ''} onChange={e => set({ date: e.target.value })} /></Field>
            {spec.hasDueDate && <Field label="Due Date"><Text type="date" value={form.dueDate || ''} onChange={e => set({ dueDate: e.target.value })} /></Field>}
            <Field label={spec.qtyLabel}><NumCell value={form.quantity || 0} min={0} onChange={e => set({ quantity: Number(e.target.value) })} /></Field>
            <Field label="Reference"><Text value={form.reference || ''} onChange={e => set({ reference: e.target.value })} placeholder="Batch note, order reference…" /></Field>
            <Field label="Total Cost (PKR)" hint="read-only, from the lines below">
              <Text value={money(derived.totalCost)} readOnly className="bg-gray-50 text-gray-600 text-right tabular-nums" />
            </Field>

            {spec.hasMethod && (
              <Field label="Calculation Method" className="sm:col-span-2 xl:col-span-1"
                hint={editId ? undefined : '(Cannot be changed once joborder saved.)'}>
                <div className="flex items-center gap-1">
                  <Pick value={form.calculationMethod || 'Method 1'} disabled={!!editId}
                    onChange={e => set({ calculationMethod: e.target.value as MfgDoc['calculationMethod'] })}>
                    <option value="Method 1">Method 1</option>
                    <option value="Method 2">Method 2</option>
                  </Pick>
                </div>
                <p className="mt-1 text-[11px] leading-snug text-red-500 font-semibold">
                  {editId ? 'Saved job order — the method is locked.'
                    : form.calculationMethod === 'Method 2'
                      ? 'Each output product carries its own cost.'
                      : 'Consumed cost is pushed onto the outputs by Cost %.'}
                </p>
              </Field>
            )}
          </div>

          <div className="px-4 py-3 border-y border-gray-100 bg-gray-50/60 flex items-center justify-between gap-3">
            <h2 className="section-title">Input (Consumption)</h2>
            <span className="text-[11px] text-gray-500 tabular-nums">Material cost {money(derived.materialCost)}</span>
          </div>
          <LineTable kind="input" lines={derived.inputs} options={productOptions}
            onChange={(i, c) => patchLine('inputs', i, c)} onPick={(i, id) => pickProduct('inputs', i, id)}
            onAdd={() => addLine('inputs')} onDrop={i => dropLine('inputs', i)} items={items} />

          <div className="px-4 py-2 border-y border-gray-100 bg-white">
            <label className="flex items-center gap-1.5 text-xs font-semibold text-gray-700 cursor-pointer">
              <input type="checkbox" checked={showExpenses} className="accent-[#1e88e5]"
                onChange={e => {
                  setShowExpenses(e.target.checked);
                  if (e.target.checked && !(form.expenses || []).length) set({ expenses: [blankExpense()] });
                }} />
              Account Expenses (Optional)
            </label>
          </div>
          {showExpenses && (
            <div className="overflow-x-auto">
              <table className="xenith-table">
                <thead><tr><th>Account</th><th>Description</th><th className="text-right">Amount</th><th></th></tr></thead>
                <tbody>
                  {(form.expenses || []).map((ex, i) => (
                    <tr key={i}>
                      <td className="min-w-40">
                        <SearchSelect options={accounts.map(a => ({ id: a.id, label: a.name }))} value={accounts.find(a => a.name === ex.accountName)?.id ?? null}
                          placeholder="Select account"
                          onChange={id => {
                            const acc = accounts.find(a => a.id === id);
                            setForm(f => ({ ...f, expenses: (f.expenses || []).map((x, j) => (j === i ? { ...x, accountName: acc?.name || '' } : x)) }));
                          }} />
                      </td>
                      <td className="min-w-40"><Text value={ex.description} onChange={e => setForm(f => ({ ...f, expenses: f.expenses!.map((x, j) => (j === i ? { ...x, description: e.target.value } : x)) }))} /></td>
                      <td className="w-28"><NumCell value={ex.amount} onChange={e => setForm(f => ({ ...f, expenses: f.expenses!.map((x, j) => (j === i ? { ...x, amount: Number(e.target.value) } : x)) }))} /></td>
                      <td>
                        <button type="button" title="Delete expense" onClick={() => setForm(f => ({ ...f, expenses: (f.expenses || []).filter((_, j) => j !== i) }))}
                          className="text-gray-400 hover:text-red-600 px-1"><Trash2 className="w-3.5 h-3.5" /></button>
                      </td>
                    </tr>
                  ))}
                  {(form.expenses || []).length === 0 && (
                    <tr><td colSpan={4} className="text-center py-4 text-gray-400">No account expenses added</td></tr>
                  )}
                </tbody>
                {(form.expenses || []).length > 0 && (
                  <tfoot><tr><td colSpan={2} className="text-right font-black text-gray-600">Expense total</td>
                    <td className="text-right font-black tabular-nums">{money(derived.expenseCost)}</td><td></td></tr></tfoot>
                )}
              </table>
              <div className="px-3 py-2 bg-gray-50 border-t border-gray-200">
                <button type="button" title="Add an account expense"
                  onClick={() => setForm(f => ({ ...f, expenses: [...(f.expenses || []), blankExpense()] }))}
                  className="btn-xenith-outline !px-2 !py-1 text-[11px]">
                  <Plus className="w-3.5 h-3.5" /><span>ADD ACCOUNT EXPENSE LINE</span>
                </button>
              </div>
            </div>
          )}

          <div className="px-4 py-3 border-y border-gray-100 bg-gray-50/60 flex items-center justify-between gap-3">
            <h2 className="section-title">Output (Production)</h2>
            <span className="text-[11px] text-gray-500 tabular-nums">Produced {money(derived.producedQty)}</span>
          </div>
          <LineTable kind="output" lines={derived.outputs} options={productOptions}
            onChange={(i, c) => patchLine('outputs', i, c)} onPick={(i, id) => pickProduct('outputs', i, id)}
            onAdd={() => addLine('outputs')} onDrop={i => dropLine('outputs', i)}
            showCostPercent={(form.calculationMethod || 'Method 1') === 'Method 1'} items={items} />

          <div className="px-4 py-2.5 flex flex-wrap items-center justify-end gap-x-5 gap-y-1 border-y border-gray-100 bg-white">
            <span className="text-xs text-gray-500">Unit cost <b className="text-gray-800 tabular-nums">{money(derived.unitCost)}</b></span>
            <span className="text-xs font-black text-gray-700 whitespace-nowrap">Total Production Cost:
              <span className="ml-1 tabular-nums text-[#1ba396]">{money(derived.totalCost)}</span>
            </span>
          </div>

          <div className="p-4 grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Field label="Comments"><Text value={form.comments || ''} onChange={e => set({ comments: e.target.value })} placeholder="Internal note saved with this document" /></Field>
            {spec.hasAttachments && (
              <Field label="Attachments">
                <AttachmentBox items={form.attachments || []} onChange={attachments => set({ attachments })} />
              </Field>
            )}
          </div>

          {error && (
            <p className="mx-4 mb-3 text-[11px] font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5">{error}</p>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2 px-4 py-3 border-t border-gray-100 bg-white">
            <div className="flex items-stretch">
              <button type="button" disabled={saving} onClick={() => handleSave(true)} className="btn-xenith-primary rounded-r-none disabled:opacity-50">
                <Save className="w-3.5 h-3.5" /> {saving ? 'Saving…' : 'SAVE AND NEW'}
              </button>
              <details className="relative group">
                <summary className="list-none cursor-pointer bg-[#1e88e5] hover:bg-[#1769aa] text-white px-1.5 rounded-r inline-flex items-center">
                  <ChevronDown className="w-3.5 h-3.5" />
                </summary>
                <ul className="absolute bottom-full right-0 mb-1 w-44 bg-white border border-gray-200 rounded shadow-lg z-40 text-xs">
                  {STATUSES.map(s => (
                    <li key={s}>
                      <button type="button" className="w-full text-left px-3 py-2 hover:bg-blue-50 text-gray-700" onClick={() => handleSave(false, s)}>
                        Save as {s}
                      </button>
                    </li>
                  ))}
                </ul>
              </details>
            </div>
            <button type="button" onClick={() => setMode('list')} className="btn-xenith-warning"><X className="w-3.5 h-3.5" /> CLOSE</button>
          </div>
        </div>
      </div>
    );
  }

  const exportCols: ExportColumn<MfgDoc>[] = [
    { label: 'Number', value: r => r.number },
    { label: 'Date', value: r => r.date },
    { label: 'Reference', value: r => r.reference || '—' },
    { label: spec.listProductLabel, value: r =>
      `${r.productName} · Cost ${money(r.totalCost)} · unit ${money(r.unitCost)}${spec.hasMethod ? ` · ${r.calculationMethod}` : ''}` },
    ...(spec.hasDueDate ? [{ label: 'Due Date', value: (r: MfgDoc) => r.dueDate || '—' }] : []),
    { label: 'Quantity', value: r => money(r.producedQty || r.quantity), align: 'right' },
    { label: 'Status', value: r => r.status }
  ];

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const blended = shown.qty ? round2(shown.cost / shown.qty) : 0;

  const stats: RegisterStat[] = [
    {
      label: 'Documents',
      value: status ? `${visible.length} of ${inScope.length}` : String(inScope.length),
      title: 'Records the search, the window and the status pill leave on screen'
    },
    { label: 'Quantity', value: money(shown.qty), title: 'The Quantity column added up exactly as printed' },
    { label: 'Cost', value: money(shown.cost), title: 'The Cost figure printed on every row, added up' },
    {
      label: 'Cost per unit', value: money(blended),
      title: `Cost ÷ quantity for the rows shown (${money(shown.cost)} over ${money(shown.qty)})`
    },
    {
      label: 'Not completed', value: shown.open,
      tone: shown.open ? 'warn' : undefined,
      title: 'Still Draft or Confirmed — the build these papers describe has not been closed yet'
    }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: inScope.length },
    ...STATUSES.map(s => ({ value: s, label: s, count: inScope.filter(r => r.status === s).length }))
  ];

  const activeFilters = [
    search && `search “${search}”`,
    status && `status ${status}`,
    (fromDate || toDate) && `dated ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const subtitle = activeFilters.length ? activeFilters.join(' · ')
    : `Every ${spec.title.toLowerCase()} on the register (${inScope.length})`;

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title flex items-center gap-2">{spec.icon} {spec.title}</h2>
            <p className="text-xs text-gray-500 mt-0.5">{spec.blurb}</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel={spec.addLabel} onAdd={openNew} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by number, product or reference" onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={statusCounts} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={spec.title} subtitle={subtitle} filename={spec.key}
              columns={exportCols} rows={visible}
              footer={footerRow(exportCols.length, {
                0: `Total (${visible.length})`, 3: money(shown.cost), [exportCols.length - 2]: money(shown.qty)
              })}
              landscape={exportCols.length > 6} />
          </span>
        </div>
      </div>

      {(error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Number" sortKey="number" sort={sort} onSort={onSort} />
                <SortHeader label="Date" sortKey="date" sort={sort} onSort={onSort} />
                <SortHeader label="Reference" sortKey="reference" sort={sort} onSort={onSort} />
                <SortHeader label={spec.listProductLabel} sortKey="productName" sort={sort} onSort={onSort} />
                {spec.hasDueDate && <SortHeader label="Due Date" sortKey="dueDate" sort={sort} onSort={onSort} />}
                <SortHeader label="Quantity" sortKey="qty" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th className="text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={colCount}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={colCount} noun={spec.title.toLowerCase()} filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : spec.addLabel} onAdd={openNew} />
              )}
              {!loading && visible.map(r => (
                <tr key={r.id}>
                  <td className="font-mono text-[11px] font-bold text-gray-700 whitespace-nowrap">{r.number}</td>
                  <td className="whitespace-nowrap text-gray-600">{r.date}</td>
                  <td className="text-gray-600">{r.reference || '—'}</td>
                  <td><span className="font-bold text-gray-800">{r.productName}</span>
                    <span className="block text-[10px] text-gray-400 tabular-nums">
                      Cost {money(r.totalCost)} · unit {money(r.unitCost)}{spec.hasMethod ? ` · ${r.calculationMethod}` : ''}
                    </span>
                  </td>
                  {spec.hasDueDate && <td className="whitespace-nowrap text-gray-600">{r.dueDate || '—'}</td>}
                  <td className="text-right tabular-nums">{money(qtyOf(r))}</td>
                  <td><span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${STATUS_BADGE[r.status]}`}>{r.status}</span></td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      <IconAction title="Open this record" tone="primary" onClick={() => openEdit(r)}><Edit2 size={12} /></IconAction>
                      {confirmId === r.id ? (
                        <DeleteConfirm onConfirm={() => handleDelete(r)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${r.number} on the floor`} />
                      ) : (
                        <IconAction title="Delete this record" tone="danger" onClick={() => setConfirmId(r.id)}><Trash2 size={12} /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  {/* The same figures the chips above write, and the sheet and the workbook close with. */}
                  <td colSpan={3} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.cost)}</td>
                  {spec.hasDueDate && <td />}
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.qty)}</td>
                  <td colSpan={2} className="text-[11px] text-gray-500">
                    Every row as printed{status ? `, incl. ${status.toLowerCase()}` : ''}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

const LineTable: React.FC<{
  kind: 'input' | 'output';
  lines: MfgLine[];
  items: MfgItem[];
  options: SelectOption[];
  showCostPercent?: boolean;
  onChange: (i: number, changes: Partial<MfgLine>) => void;
  onPick: (i: number, id: number | null) => void;
  onAdd: () => void;
  onDrop: (i: number) => void;
}> = ({ kind, lines, items, options, showCostPercent = false, onChange, onPick, onAdd, onDrop }) => {
  const cols = kind === 'input' ? 8 : 8;
  return (
    <div className="overflow-x-auto">
      <table className="xenith-table">
        <thead>
          <tr>
            <th className="min-w-40">Product</th><th className="w-24">Batch</th>
            {kind === 'input' && <th className="text-right w-20">Stock Available</th>}
            <th className="w-24 text-right">Quantity</th>
            {kind === 'output' && showCostPercent && <th className="w-20 text-right">Cost %</th>}
            <th className="w-28 text-right">Cost</th><th className="w-28 text-right">Amount</th><th className="w-16">Action</th>
          </tr>
        </thead>
        <tbody>
          {lines.length === 0 && <tr><td colSpan={cols} className="text-center py-4 text-gray-400">No lines yet</td></tr>}
          {lines.map((l, i) => {
            const stock = items.find(x => x.id === l.productId)?.stockQty;
            return (
              <tr key={i}>
                <td>
                  <SearchSelect options={options} value={l.productId} placeholder={l.productName || 'Select product'}
                    onChange={id => onPick(i, id)} invalid={!l.productName} />
                </td>
                <td><Text value={l.batch} onChange={e => onChange(i, { batch: e.target.value })} placeholder="—" /></td>
                {kind === 'input' && <td className="text-right tabular-nums">{stock === undefined ? '—' : stock}</td>}
                <td><NumCell value={l.quantity} min={0} onChange={e => onChange(i, { quantity: Number(e.target.value) })} /></td>
                {kind === 'output' && showCostPercent && (
                  <td><NumCell value={l.costPercent} min={0} max={100} onChange={e => onChange(i, { costPercent: Number(e.target.value) })} /></td>
                )}
                <td>{showCostPercent
                  ? <Text value={money(l.cost)} readOnly className="bg-gray-50 text-gray-500 text-right tabular-nums" />
                  : <NumCell value={l.cost} min={0} onChange={e => onChange(i, { cost: Number(e.target.value) })} />}</td>
                <td className="text-right font-bold tabular-nums text-gray-700 whitespace-nowrap">{money(l.amount)}</td>
                <td>
                  <button type="button" title="Delete line" onClick={() => onDrop(i)} disabled={lines.length === 1}
                    className="text-gray-400 hover:text-red-600 disabled:opacity-30">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="px-3 py-2 bg-gray-50 border-t border-gray-200">
        <button type="button" onClick={onAdd} className="btn-xenith-outline !px-2 !py-1 text-[11px]">
          <Plus className="w-3.5 h-3.5" />
          <span>{kind === 'input' ? 'APPEND CONSUMED ITEM ROW' : 'APPEND OUTPUT ROW'}</span>
        </button>
      </div>
    </div>
  );
};

export default ManufacturingDocs;
