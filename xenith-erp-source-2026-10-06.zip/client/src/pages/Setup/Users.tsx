import React, { useMemo, useState } from 'react';
import { UserCog, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { deleteUser, getUsers, saveUser, updateUser, UserRow } from '../../services/access.service';
import { Branch } from '../../types';
import { Check, DeleteConfirm, ExportPair, Field, ListToolbar, Pick, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, TableEmpty, Text, IconAction } from '../Masters/masterUi';
import { useHub } from './useHub';
import { ExportColumn } from '../../utils/exportTable';
import { plateOn } from '../../utils/inkOn';
import { useScreenReload } from '../../utils/screenReload';

interface UserDraft {
  id: number; name: string; username: string; email: string; phone: string;
  roleId: number; branchIds: number[]; isActive: boolean; password: string;
}

const blankUser = (roles: { id: number }[], branches: Branch[]): UserDraft => ({
  id: 0, name: '', username: '', email: '', phone: '',
  roleId: roles[0]?.id ?? 0, branchIds: branches.slice(0, 1).map(b => b.id), isActive: true, password: ''
});

const initials = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase() ?? '').join('');
const lastSeen = (iso: string | null) => {
  if (!iso) return 'Never';
  const d = new Date(iso);
  return `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
};

export const UsersPage: React.FC = () => {
  const { tenantSlug, branchId, allBranches } = useTenant();
  const { user: signedIn } = useAuth();
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [sort, setSort] = useState<SortState | null>({ key: 'name', dir: 'asc' });
  const [draft, setDraft] = useState<UserDraft | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [stayOpen, setStayOpen] = useState(false);

  const hub = useHub(() => getUsers(tenantSlug, branchId), [tenantSlug, branchId]);
  useScreenReload(hub.reload);
  const roles = hub.value?.roles ?? [];
  const branches = hub.value?.branches ?? allBranches;

  const rows = useMemo(() => {
    const list = (hub.value?.data ?? []).filter(u =>
      !search.trim() || `${u.name} ${u.email} ${u.username} ${u.roleName}`.toLowerCase().includes(search.trim().toLowerCase()));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [hub.value, search, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const loaded = hub.value?.data ?? [];
  const disabled = loaded.filter(u => !u.isActive).length;

  const stats: RegisterStat[] = [
    {
      label: 'Accounts',
      value: search ? `${rows.length} of ${loaded.length}` : String(loaded.length),
      title: search ? `${loaded.length} accounts on the register, the search leaves ${rows.length} on screen` : 'Sign-in accounts on this branch’s register'
    },
    ...(disabled ? [{
      label: 'Disabled', value: disabled, tone: 'warn' as const,
      title: `${disabled} of them are marked Disabled and cannot sign in`
    }] : [])
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];

  const clearAll = () => {
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const open = (u: UserRow) => setDraft({
    id: u.id, name: u.name, username: u.username, email: u.email, phone: u.phone,
    roleId: u.roleId, branchIds: [...u.branchIds], isActive: u.isActive, password: ''
  });

  const toggleBranch = (id: number) => setDraft(d => d && {
    ...d, branchIds: d.branchIds.includes(id) ? d.branchIds.filter(x => x !== id) : [...d.branchIds, id]
  });

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError('');
    const body: Partial<UserRow> & { password?: string } = { ...draft };
    if (!draft.password) delete (body as any).password;
    try {
      if (draft.id === 0) await saveUser(tenantSlug, branchId, body);
      else await updateUser(tenantSlug, branchId, draft.id, body);
      const keepOpen = draft.id === 0 && stayOpen;
      setDraft(keepOpen ? { ...blankUser(roles, branches) } : null);
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const remove = async (u: UserRow) => {
    setError('');
    try { await deleteUser(tenantSlug, branchId, u.id); hub.reload(); }
    catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  const roleOf = (id: number) => roles.find(r => r.id === id);

  const columns: ExportColumn<UserRow>[] = [
    { label: 'User', value: u => u.name },
    { label: 'Username', value: u => u.username },
    { label: 'Email', value: u => u.email },
    { label: 'User Role', value: u => u.roleName },
    { label: 'Branches', value: u => u.branchNames.join(', ') || '-' },
    { label: 'Last Login', value: u => lastSeen(u.lastLogin) },
    { label: 'Status', value: u => u.isActive ? 'Active' : 'Disabled' }
  ];

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><UserCog className="w-4 h-4" /> Users</span>
        <StatStrip stats={stats} />
      </div>
      <div className="nb-card-body">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <ListToolbar addLabel="ADD USER" onAdd={() => { setDraft(blankUser(roles, branches)); setError(''); }}>
            <ExportPair title="Users" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="users" columns={columns} rows={rows} landscape />
            <SearchBox key={searchEpoch} className="ml-auto w-56 max-w-full" placeholder={"Search users..."} onSearch={setSearch} />
          </ListToolbar>
        </div>

        {error && (
          <div className="mb-3 text-xs font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-3 py-2 flex items-center justify-between">
            <span>{error}</span>
            <button type="button" onClick={() => setError('')}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        {draft && (
          <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-3">
              <h3 className="card-title">
                {draft.id ? `Edit User - [${draft.name || 'untitled'}]` : 'Create User'}
              </h3>
              <span className="text-[11px] text-gray-500">
                {draft.roleId ? `${roleOf(draft.roleId)?.name ?? '-'} · ${roleOf(draft.roleId)?.description ?? ''}` : 'Choose a role to see its access'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <Field label="Name" required>
                <Text value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="Full name" />
              </Field>
              <Field label="Username" required hint="used to sign in">
                <Text value={draft.username} onChange={e => setDraft({ ...draft, username: e.target.value })} placeholder="e.g. ayesha" />
              </Field>
              <Field label="Email" required>
                <Text type="email" value={draft.email} onChange={e => setDraft({ ...draft, email: e.target.value })} placeholder="user@company.com" />
              </Field>
              <Field label="Mobile">
                <Text value={draft.phone} onChange={e => setDraft({ ...draft, phone: e.target.value })} placeholder="+92 3xx xxxxxxx" />
              </Field>
              <Field label="User Role" required>
                <Pick value={String(draft.roleId)} disabled={draft.id === signedIn?.id}
                  onChange={e => setDraft({ ...draft, roleId: Number(e.target.value) })}>
                  <option value="0">-Choose-</option>
                  {roles.map(r => <option key={r.id} value={String(r.id)}>{r.name}</option>)}
                </Pick>
              </Field>
              <Field label={draft.id ? 'New Password' : 'Password'} required={draft.id === 0}
                hint={draft.id ? 'leave blank to keep the current one' : 'minimum 6 characters'}>
                <Text type="password" value={draft.password} onChange={e => setDraft({ ...draft, password: e.target.value })} placeholder="••••••••" />
              </Field>
            </div>

            <div className="mt-3">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Branch Access <span className="text-red-500">*</span></label>
              <div className="flex flex-wrap gap-3 p-2 bg-white border border-gray-200 rounded">
                {branches.map(b => (
                  <Check key={b.id} checked={draft.branchIds.includes(b.id)} onChange={() => toggleBranch(b.id)}
                    label={`${b.name}${b.code ? ` (${b.code})` : ''}`} />
                ))}
              </div>
              <p className="mt-1 text-[11px] text-gray-400">
                The branch menu in the header only shows the branches ticked here.
              </p>
            </div>

            <div className="flex items-center justify-between gap-2 mt-3">
              <div className="flex items-center gap-4">
                <Check checked={draft.isActive} onChange={v => setDraft({ ...draft, isActive: v })} label="Account active" />
                {draft.id === 0 && (
                  <Check checked={stayOpen} onChange={setStayOpen} label="Keep the form open after saving" />
                )}
              </div>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Close
                </button>
                <button type="button" onClick={submit} disabled={saving || !draft.name.trim() || !draft.email.trim() || !draft.roleId}
                  className="btn-xenith-success disabled:opacity-50">
                  {saving ? 'Saving...' : draft.id === 0 && stayOpen ? 'SAVE AND NEW' : 'SAVE'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="User" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Username" sortKey="username" sort={sort} onSort={onSort} />
                <SortHeader label="Email" sortKey="email" sort={sort} onSort={onSort} />
                <SortHeader label="User Role" sortKey="roleName" sort={sort} onSort={onSort} />
                <th>Branches</th>
                <SortHeader label="Last Login" sortKey="lastLogin" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {!hub.value && <tr><td colSpan={8} className="text-center text-gray-400 py-6">Loading...</td></tr>}
              {hub.value && rows.length === 0 && (
                <TableEmpty colSpan={8} noun="users" filters={activeFilters} cleared={clearAll}
                  addLabel={hub.value.data.length ? undefined : 'ADD USER'}
                  onAdd={() => { setDraft(blankUser(roles, branches)); setError(''); }} />
              )}
              {rows.map(u => (
                <tr key={u.id}>
                  <td>
                    <span className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full text-[10px] font-bold flex items-center justify-center shrink-0"
                        style={plateOn(u.avatarColor)}>
                        {initials(u.name)}
                      </span>
                      <span className="font-medium">{u.name}</span>
                      {u.id === signedIn?.id && <span className="text-[10px] font-bold text-[#25a195]">YOU</span>}
                      {u.isOwner && <span className="text-[10px] text-gray-400">Owner</span>}
                    </span>
                  </td>
                  <td className="text-gray-600">{u.username}</td>
                  <td>{u.email}</td>
                  <td>{u.roleName}</td>
                  <td className="text-gray-500">{u.branchNames.join(', ') || <span className="text-gray-300">-</span>}</td>
                  <td className="text-gray-500">{lastSeen(u.lastLogin)}</td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${u.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {u.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Edit user" tone="primary" onClick={() => open(u)}><Pencil className="w-4 h-4" /></IconAction>
                      {u.isOwner ? (
                        <IconAction title="The company owner cannot be deleted" disabled><Trash2 className="w-4 h-4" /></IconAction>
                      ) : confirmId === u.id ? (
                        <DeleteConfirm onConfirm={() => remove(u)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${u.name}`} />
                      ) : (
                        <IconAction title="Delete user" tone="danger" onClick={() => setConfirmId(u.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UsersPage;
