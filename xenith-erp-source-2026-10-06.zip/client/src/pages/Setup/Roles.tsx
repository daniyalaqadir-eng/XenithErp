import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ShieldCheck, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import {
  deleteRole, getPermissionCatalog, getRoles, saveRole, updateRole, PermissionCatalog, PermScreenDef, RoleRow
} from '../../services/access.service';
import { Area, Check, ExportPair, Field, ListToolbar, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, TableEmpty, Text, IconAction } from '../Masters/masterUi';
import { useHub } from './useHub';
import { ExportColumn } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

interface RoleDraft { id: number; name: string; description: string; isSystem: boolean; salesmanScoped: boolean; permissions: string[] }

// A partly ticked row must say so; showing "NONE" for a role that holds three of six
// actions reads as a bug and makes the administrator re-tick from scratch.
const BulkToggle: React.FC<{
  granted: number; of: number; title: string; disabled?: boolean; onClick: () => void;
}> = ({ granted, of, title, disabled, onClick }) => {
  const state = granted === 0 ? 'NONE' : granted === of ? 'ALL' : `${granted}/${of}`;
  return (
    <button type="button" disabled={disabled} title={title} onClick={onClick}
      className={`text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap ${
        granted === 0 ? 'bg-gray-100 text-gray-500' : granted === of ? 'bg-teal-50 text-[#25a195]' : 'bg-blue-50 text-[#1e88e5]'}`}>
      {state}
    </button>
  );
};

// A module whose screens come from one long list — the reports, each filed under the section of
// the books it reads — is drawn with a heading per family and a tick that opens or shuts that
// family whole. A hundred and twenty rows with no landmark in them cannot be scanned.
const subGroups = (screens: PermScreenDef[]) => {
  const out: { name: string; screens: PermScreenDef[] }[] = [];
  screens.forEach(s => {
    const last = out[out.length - 1];
    if (last && last.name === (s.sub ?? '')) last.screens.push(s);
    else out.push({ name: s.sub ?? '', screens: [s] });
  });
  return out;
};

// A new role is started on the executive desk with every band on it, plus the header's
// company switcher: a role created with nothing ticked opens the Dashboard to an empty page
// and reads as a broken build. The other two desks are ticked on purpose.
const starterPerms = (cat: PermissionCatalog | null) => (cat?.screens ?? [])
  .filter(s => s.key === 'company-switcher'
    || s.key === 'dashboard-executive'
    || (s.key.startsWith('dash-') && !s.key.startsWith('dash-sm-') && !s.key.startsWith('dash-wh-')))
  .flatMap(s => s.actions.map(a => key(s.key, a)));

const blankRole = (cat: PermissionCatalog | null): RoleDraft =>
  ({ id: 0, name: '', description: '', isSystem: false, salesmanScoped: false,
    permissions: ['dashboard:view', ...starterPerms(cat)] });
const key = (module: string, action: string) => `${module}:${action}`;

export const RolesPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [sort, setSort] = useState<SortState | null>({ key: 'name', dir: 'asc' });
  const [draft, setDraft] = useState<RoleDraft | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const catalog = useHub<PermissionCatalog | null>(() => getPermissionCatalog(tenantSlug, branchId).then(c => c), [tenantSlug, branchId]);
  const roles = useHub<RoleRow[]>(() => getRoles(tenantSlug, branchId), [tenantSlug, branchId]);

  const reload = useCallback(() => { roles.reload(); catalog.reload(); }, [roles.reload, catalog.reload]);
  useScreenReload(reload);

  const rows = useMemo(() => {
    const list = (roles.value || []).filter(r =>
      !search.trim() || `${r.name} ${r.description}`.toLowerCase().includes(search.trim().toLowerCase()));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [roles.value, search, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const loaded = roles.value ?? [];
  const custom = loaded.filter(r => !r.isSystem).length;

  const stats: RegisterStat[] = [
    {
      label: 'On register',
      value: search ? `${rows.length} of ${loaded.length}` : String(loaded.length),
      title: search ? `${loaded.length} roles on the register, the search leaves ${rows.length} on screen` : 'Roles on the register'
    },
    ...(custom ? [{
      label: 'Custom', value: custom,
      title: `${custom} of them were created here; the rest are built in`
    } as RegisterStat] : [])
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];

  const clearAll = () => {
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<RoleRow>[] = [
    { label: 'Role', value: r => r.name },
    { label: 'Permissions', value: r => `${r.granted}/${r.of}` },
    { label: 'Users', value: r => r.userCount, align: 'right' },
    { label: 'Description', value: r => r.description || '-' },
    { label: 'Status', value: r => r.isSystem ? 'Built in' : 'Custom' }
  ];

  const open = (r: RoleRow) => setDraft({ id: r.id, name: r.name, description: r.description, isSystem: r.isSystem, salesmanScoped: !!r.salesmanScoped, permissions: [...r.permissions] });

  // Ticking Add on a screen implies seeing it, otherwise the menu would hide the
  // very entry the tick was meant to open. View itself stays freely untickable.
  const withView = (keys: string[]) => [
    ...keys,
    ...keys.filter(k => !k.endsWith(':view')).map(k => `${k.slice(0, k.lastIndexOf(':'))}:view`)
  ];

  const setKeys = (raw: string[], on: boolean) => setDraft(d => {
    if (!d || d.isSystem) return d;
    const keys = on ? [...new Set(withView(raw))] : raw;
    const rest = d.permissions.filter(p => !keys.includes(p));
    return { ...d, permissions: on ? [...rest, ...keys] : rest };
  });

  const toggle = (perm: string) => setDraft(d => {
    if (!d) return d;
    return {
      ...d,
      permissions: d.permissions.includes(perm)
        ? d.permissions.filter(p => p !== perm)
        : [...new Set([...d.permissions, ...withView([perm])])]
    };
  });

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError('');
    try {
      if (draft.id === 0) await saveRole(tenantSlug, branchId, draft);
      else await updateRole(tenantSlug, branchId, draft.id, draft);
      setDraft(null);
      reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const remove = async (r: RoleRow) => {
    setError('');
    try { await deleteRole(tenantSlug, branchId, r.id); reload(); }
    catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  const locked = !!draft?.isSystem;
  const everyPerm = (catalog.value?.screens ?? []).flatMap(s => s.actions.map(a => key(s.key, a)));
  const grantedInDraft = draft ? new Set(draft.permissions).size : 0;

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><ShieldCheck className="w-4 h-4" /> User Roles &amp; Permissions</span>
        <StatStrip stats={stats} />
      </div>
      <div className="nb-card-body">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <ListToolbar addLabel="ADD ROLE" onAdd={() => { setDraft(blankRole(catalog.value)); setError(''); }}>
            <ExportPair title="User Roles & Permissions" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="user-roles" columns={columns} rows={rows} />
            <SearchBox key={searchEpoch} className="ml-auto w-56 max-w-full" placeholder={"Search roles..."} onSearch={setSearch} />
          </ListToolbar>
        </div>

        {error && (
          <div className="mb-3 text-xs font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-3 py-2 flex items-center justify-between">
            <span>{error}</span>
            <button type="button" onClick={() => setError('')}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        {draft && catalog.value && (
          <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-3">
              <h3 className="card-title">{draft.id ? `Edit Role - [${draft.name || 'untitled'}]` : 'Create Role'}</h3>
              <span className="text-[11px] text-gray-500">{grantedInDraft} of {catalog.value.total} permissions granted</span>
            </div>

            {locked && (
              <div className="mb-3 text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1.5">
                The built-in Administrator role always keeps full control, so it cannot be changed.
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
              <Field label="Role Name" required>
                <Text value={draft.name} disabled={locked} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Credit Manager" />
              </Field>
              <Field label="Description">
                <Area rows={2} value={draft.description} disabled={locked}
                  onChange={e => setDraft({ ...draft, description: e.target.value })} placeholder="What this role is allowed to do" />
              </Field>
            </div>

            <label className={`flex items-start gap-2 mb-3 text-[12px] text-gray-600 ${locked ? 'opacity-60' : 'cursor-pointer'}`}>
              <input type="checkbox" className="mt-0.5 accent-[#1e88e5]" disabled={locked}
                checked={draft.salesmanScoped}
                onChange={e => setDraft({ ...draft, salesmanScoped: e.target.checked })} />
              <span>
                <b>Salesperson&rsquo;s own desk.</b> Users in this role see only the sale documents they raised, anything they
                save waits here for an administrator to approve it, and they cannot approve or delete booked paper themselves.
              </span>
            </label>

            <div className="space-y-3">
              {catalog.value.buckets.map(bucket => (
                <div key={bucket.name} className="bg-white border border-gray-200 rounded overflow-hidden">
                  <div className="px-3 py-1.5 bg-gray-100 text-[11px] font-bold uppercase tracking-wide text-gray-500">{bucket.name}</div>
                  <table className="xenith-table">
                    <thead>
                      <tr>
                        <th>Screen</th>
                        {catalog.value!.actions.map(a => {
                          const supported = bucket.modules.flatMap(m => m.screens).filter(s => s.actions.includes(a.key));
                          const allOn = supported.length > 0 && supported.every(s => draft.permissions.includes(key(s.key, a.key)));
                          return (
                            <th key={a.key} className="text-center w-20" title={a.hint}>
                              {supported.length === 0 ? <span className="text-gray-300">{a.label}</span> : (
                                <label className="flex flex-col items-center gap-0.5 cursor-pointer" title={`Every screen in ${bucket.name}`}>
                                  <span>{a.label}</span>
                                  <input type="checkbox" className="accent-[#1e88e5]" disabled={locked} checked={allOn}
                                    onChange={e => setKeys(supported.map(s => key(s.key, a.key)), e.target.checked)} />
                                </label>
                              )}
                            </th>
                          );
                        })}
                        <th className="w-10" />
                      </tr>
                    </thead>
                    <tbody>
                      {bucket.modules.map(m => {
                        const screenKeys = m.screens.flatMap(s => s.actions.map(a => key(s.key, a)));
                        const moduleOn = screenKeys.filter(p => draft.permissions.includes(p)).length;
                        const moduleAll = moduleOn === screenKeys.length;
                        return (
                          <React.Fragment key={m.key}>
                            <tr className="bg-gray-50/80">
                              <td className="font-bold text-gray-700">
                                <span className="flex items-center gap-2">
                                  {m.label}
                                  <span className="text-[10px] font-normal text-gray-400 normal-case tracking-normal">
                                    {m.screens.length} screen{m.screens.length === 1 ? '' : 's'}
                                  </span>
                                </span>
                              </td>
                              {catalog.value!.actions.map(a => {
                                const supported = m.screens.filter(s => s.actions.includes(a.key));
                                if (supported.length === 0) return <td key={a.key} />;
                                const on = supported.every(s => draft.permissions.includes(key(s.key, a.key)));
                                return (
                                  <td key={a.key} className="text-center">
                                    <input type="checkbox" className="accent-[#1e88e5] cursor-pointer" disabled={locked} title={`This whole section`}
                                      checked={on}
                                      onChange={e => setKeys(supported.map(s => key(s.key, a.key)), e.target.checked)} />
                                  </td>
                                );
                              })}
                              <td className="text-center">
                                <BulkToggle disabled={locked} granted={moduleOn} of={screenKeys.length}
                                  title={moduleAll ? 'Clear this whole section' : 'Tick this whole section'}
                                  onClick={() => setKeys(screenKeys, !moduleAll)} />
                              </td>
                            </tr>
                            {subGroups(m.screens).map((g, gi) => {
                              const groupKeys = g.screens.flatMap(s => s.actions.map(a => key(s.key, a)));
                              const groupOn = groupKeys.filter(p => draft.permissions.includes(p)).length;
                              const groupAll = groupOn === groupKeys.length;
                              return (
                                <React.Fragment key={g.name || `ungrouped-${gi}`}>
                                  {g.name && (
                                    <tr>
                                      <td className="pl-3 text-[11px] font-bold uppercase tracking-wide text-gray-500">
                                        <span className="flex items-center gap-2">
                                          {g.name}
                                          <span className="text-[10px] font-normal text-gray-400 normal-case tracking-normal">
                                            {g.screens.length} report{g.screens.length === 1 ? '' : 's'}
                                          </span>
                                        </span>
                                      </td>
                                      {catalog.value!.actions.map(a => {
                                        const supported = g.screens.filter(s => s.actions.includes(a.key));
                                        if (supported.length === 0) return <td key={a.key} />;
                                        const on = supported.every(s => draft.permissions.includes(key(s.key, a.key)));
                                        return (
                                          <td key={a.key} className="text-center">
                                            <input type="checkbox" className="accent-[#1e88e5] cursor-pointer" disabled={locked}
                                              title={`Every ${g.name} report on this role`}
                                              checked={on}
                                              onChange={e => setKeys(supported.map(s => key(s.key, a.key)), e.target.checked)} />
                                          </td>
                                        );
                                      })}
                                      <td className="text-center">
                                        <BulkToggle disabled={locked} granted={groupOn} of={groupKeys.length}
                                          title={groupAll ? `Clear the ${g.name} reports` : `Tick every ${g.name} report`}
                                          onClick={() => setKeys(groupKeys, !groupAll)} />
                                      </td>
                                    </tr>
                                  )}
                                  {g.screens.map(s => {
                                    const keys = s.actions.map(a => key(s.key, a));
                                    const on = keys.filter(p => draft.permissions.includes(p)).length;
                                    const rowAll = on === keys.length;
                                    return (
                                      <tr key={s.key}>
                                        <td className="pl-6 text-gray-600">{s.label}</td>
                                        {catalog.value!.actions.map(a => (
                                          <td key={a.key} className="text-center">
                                            {s.actions.includes(a.key) ? (
                                              <input type="checkbox" className="accent-[#1e88e5] cursor-pointer" disabled={locked}
                                                checked={draft.permissions.includes(key(s.key, a.key))}
                                                onChange={() => toggle(key(s.key, a.key))} />
                                            ) : <span className="text-gray-200">-</span>}
                                          </td>
                                        ))}
                                        <td className="text-center">
                                          <BulkToggle disabled={locked} granted={on} of={keys.length}
                                            title={rowAll ? 'Clear this screen' : 'Tick this whole screen'}
                                            onClick={() => setKeys(keys, !rowAll)} />
                                        </td>
                                      </tr>
                                    );
                                  })}
                                </React.Fragment>
                              );
                            })}
                          </React.Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between gap-2 mt-3">
              <Check checked={everyPerm.length > 0 && everyPerm.every(p => draft.permissions.includes(p))} disabled={locked}
                onChange={v => setDraft(d => (d && !d.isSystem ? { ...d, permissions: v ? everyPerm : [] } : d))}
                label="Full control over every screen" />
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Close
                </button>
                <button type="button" disabled={saving || !draft.name.trim()} onClick={submit} className="btn-xenith-success disabled:opacity-50">
                  {saving ? 'Saving...' : 'SAVE'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Role" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Permissions" sortKey="granted" sort={sort} onSort={onSort} />
                <SortHeader label="Users" sortKey="userCount" sort={sort} onSort={onSort} />
                <th>Description</th>
                <SortHeader label="Status" sortKey="isSystem" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {(!roles.value) && <tr><td colSpan={6} className="text-center text-gray-400 py-6">Loading...</td></tr>}
              {roles.value && rows.length === 0 && (
                <TableEmpty colSpan={6} noun="roles" filters={activeFilters} cleared={clearAll}
                  addLabel={roles.value.length ? undefined : 'ADD ROLE'}
                  onAdd={() => { setDraft(blankRole(catalog.value)); setError(''); }} />
              )}
              {rows.map(r => (
                <tr key={r.id}>
                  <td className="font-medium">
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-gray-400" /> {r.name}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <span className="w-24 h-1.5 rounded bg-gray-100 overflow-hidden">
                        <span className="block h-full bg-[#2ec4b6]" style={{ width: `${Math.round((r.granted / r.of) * 100)}%` }} />
                      </span>
                      <span className="text-[11px] text-gray-500">{r.granted}/{r.of}</span>
                    </div>
                  </td>
                  <td>{r.userCount}</td>
                  <td className="max-w-[320px] text-gray-500">{r.description || <span className="text-gray-300">-</span>}</td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${r.isSystem ? 'bg-blue-50 text-[#1e88e5]' : 'bg-gray-100 text-gray-500'}`}>
                      {r.isSystem ? 'Built in' : 'Custom'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Edit role" tone="primary" onClick={() => open(r)}><Pencil className="w-4 h-4" /></IconAction>
                      {r.isSystem ? (
                        <IconAction title="The built-in Administrator role cannot be deleted" disabled><Trash2 className="w-4 h-4" /></IconAction>
                      ) : confirmId === r.id ? (
                        <button type="button" onClick={() => remove(r)} className="h-7 px-2 rounded text-[10px] font-bold text-white bg-red-500 hover:bg-red-600">
                          Confirm
                        </button>
                      ) : (
                        <IconAction title="Delete role" tone="danger" onClick={() => setConfirmId(r.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RolesPage;
