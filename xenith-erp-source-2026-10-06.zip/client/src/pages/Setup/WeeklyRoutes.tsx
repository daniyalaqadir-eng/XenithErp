import React, { useEffect, useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Clock, MapPin, Plus, RefreshCw, Route as RouteIcon, Trash2, Truck, X, Pencil } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import {
  getDayPlan, getWeeklyRoutes, saveWeeklyRoute, updateWeeklyRoute, deleteWeeklyRoute,
  DayPlan, RouteDay, RouteStop, ROUTE_DAYS, WeeklyRoute
} from '../../services/routes.service';
import { Check, DeleteConfirm, ExportPair, Field, ListToolbar, Pick, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, TableEmpty, Text, IconAction } from '../Masters/masterUi';
import { useHub } from './useHub';
import { ExportColumn } from '../../utils/exportTable';
import { companyNow } from '../../utils/clock';

type Days = Record<RouteDay, boolean>;

const noStops = (): Days =>
  ROUTE_DAYS.reduce((acc, d) => ({ ...acc, [d]: d !== 'Sunday' }), {} as Days);

const sameDayStops = (stops: RouteStop[]) => ROUTE_DAYS.reduce((acc, d) => ({
  ...acc, [d]: stops.filter(s => s.day === d).length
}), {} as Record<RouteDay, number>);

const todayName = (): RouteDay =>
  ROUTE_DAYS[(companyNow().getDay() + 6) % 7];

type Draft = {
  id?: number; name: string; code: string; branchId: number;
  salesmanId: number | null; deliverymanId: number | null;
  vehicleNumber: string; frequency: WeeklyRoute['frequency'];
  isActive: boolean; notes: string; days: Days; stops: RouteStop[];
};

const blankDraft = (branchId: number): Draft => ({
  name: '', code: '', branchId, salesmanId: null, deliverymanId: null,
  vehicleNumber: '', frequency: 'Weekly', isActive: true, notes: '',
  days: noStops(), stops: []
});

export const WeeklyRoutesPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [draft, setDraft] = useState<Draft | null>(null);
  const [stopDay, setStopDay] = useState<RouteDay>('Monday');
  const [newStop, setNewStop] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [planDay, setPlanDay] = useState<RouteDay>(todayName());
  const [plan, setPlan] = useState<DayPlan | null>(null);

  const hub = useHub(() => getWeeklyRoutes(tenantSlug, branchId), [tenantSlug, branchId]);
  const rows = hub.value?.data ?? [];

  useEffect(() => {
    getDayPlan(tenantSlug, branchId, planDay).then(setPlan).catch(() => setPlan(null));
  }, [tenantSlug, branchId, planDay, hub.value]);

  const visible = useMemo(() => {
    const list = rows.filter(r => !search.trim() ||
      `${r.name} ${r.code} ${r.branchName} ${r.salesmanName} ${r.deliverymanName} ${r.vehicleNumber}`
        .toLowerCase().includes(search.trim().toLowerCase()));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [rows, search, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const closed = rows.filter(r => !r.isActive).length;

  const stats: RegisterStat[] = [
    {
      label: 'Routes',
      value: search ? `${visible.length} of ${rows.length}` : String(rows.length),
      title: search ? `${rows.length} routes on the register, the search leaves ${visible.length} on screen` : 'Routes on the register'
    },
    ...(closed ? [{
      label: 'Closed', value: closed, tone: 'warn' as const,
      title: `${closed} of them are marked Closed on the register`
    }] : [])
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];

  const clearAll = () => {
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<WeeklyRoute>[] = [
    { label: 'Code', value: r => r.code || '-' },
    { label: 'Route Name', value: r => r.name },
    { label: 'Branch', value: r => r.branchName || '-' },
    { label: 'Salesman', value: r => r.salesmanName || '-' },
    { label: 'Deliveryman', value: r => r.deliverymanName || '-' },
    { label: 'Vehicle', value: r => r.vehicleNumber ? r.vehicleNumber.toUpperCase() : '-' },
    { label: 'Stops', value: r => r.stops.length, align: 'right' },
    { label: 'Customers', value: r => r.customers, align: 'right' },
    { label: 'Days', value: r => r.daysRun.join(', ') },
    { label: 'Status', value: r => r.isActive ? 'Running' : 'Closed' }
  ];

  const proposeCode = () => {
    const next = rows.reduce((max, r) => Math.max(max, Number(String(r.code).replace(/\D/g, '')) || 0), 0) + 1;
    setDraft(d => (d ? { ...d, code: `RT-${String(next).padStart(2, '0')}` } : d));
  };

  const reload = () => { hub.reload(); setDraft(null); setNewStop(''); };

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError(''); setNotice('');
    const body = {
      ...draft,
      stops: draft.stops.map(s => ({ customerId: s.customerId, day: s.day, time: s.time, note: s.note }))
    };
    try {
      if (draft.id) {
        await updateWeeklyRoute(tenantSlug, branchId, draft.id, body);
        setNotice(`${draft.name} has been updated.`);
      } else {
        const created = await saveWeeklyRoute(tenantSlug, branchId, body);
        setNotice(`${created.name} has been added with ${created.stops.length} stop(s).`);
      }
      reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const remove = async (r: WeeklyRoute) => {
    setError(''); setNotice('');
    try {
      await deleteWeeklyRoute(tenantSlug, branchId, r.id);
      setNotice(`${r.name} has been deleted.`);
      reload();
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  // -- draft editing ----------------------------------------------------------
  const counts = draft ? sameDayStops(draft.stops) : null;
  const runningDays = draft ? ROUTE_DAYS.filter(d => draft.days[d]) : [];

  const toggleDay = (day: RouteDay, on: boolean) => {
    if (!draft) return;
    if (on) { setDraft({ ...draft, days: { ...draft.days, [day]: true } }); return; }
    const dropped = (counts?.[day] ?? 0) > 0;
    setDraft({
      ...draft,
      days: { ...draft.days, [day]: false },
      stops: dropped ? draft.stops.filter(s => s.day !== day) : draft.stops
    });
    if (dropped) setNotice(`${counts?.[day] ?? 0} stop(s) on ${day} were removed with that day.`);
  };

  const dayStops = draft ? draft.stops.filter(s => s.day === stopDay) : [];
  const taken = new Set(dayStops.map(s => s.customerId));
  const options = (hub.value?.customers ?? []).filter(c => !taken.has(c.id));

  const addStop = () => {
    const id = Number(newStop);
    if (!draft || !id) return;
    const last = dayStops[dayStops.length - 1];
    const stop: RouteStop = { customerId: id, day: stopDay, time: last?.time || '09:00', note: '' };
    setDraft({ ...draft, stops: [...draft.stops, stop] });
    setNewStop('');
    setNotice('');
  };

  const patchStop = (idx: number, patch: Partial<RouteStop>) => {
    if (!draft) return;
    let seen = -1;
    setDraft({
      ...draft,
      stops: draft.stops.map(s => {
        if (s.day !== stopDay) return s;
        seen += 1;
        return seen === idx ? { ...s, ...patch } : s;
      })
    });
  };

  const dropStop = (idx: number) => {
    if (!draft) return;
    let seen = -1;
    setDraft({ ...draft, stops: draft.stops.filter(s => { if (s.day !== stopDay) return true; seen += 1; return seen !== idx; }) });
  };

  const moveStop = (idx: number, dir: -1 | 1) => {
    if (!draft) return;
    const j = idx + dir;
    if (j < 0 || j >= dayStops.length) return;
    const reordered = [...dayStops];
    [reordered[idx], reordered[j]] = [reordered[j], reordered[idx]];
    setDraft({ ...draft, stops: [...draft.stops.filter(s => s.day !== stopDay), ...reordered] });
  };

  const startEdit = (r: WeeklyRoute) => {
    setError(''); setNotice('');
    setDraft({
      id: r.id, name: r.name, code: r.code, branchId: r.branchId,
      salesmanId: r.salesmanId, deliverymanId: r.deliverymanId,
      vehicleNumber: r.vehicleNumber, frequency: r.frequency,
      isActive: r.isActive, notes: r.notes, days: { ...r.days },
      stops: r.stops.map(s => ({ customerId: s.customerId, day: s.day, time: s.time, note: s.note }))
    });
    setStopDay(r.daysRun[0] || 'Monday');
  };

  const customerOf = (id: number) => (hub.value?.customers ?? []).find(c => c.id === id);

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><RouteIcon className="w-4 h-4" /> Weekly Route</span>
        <StatStrip stats={stats} />
      </div>
      <div className="nb-card-body">
        {/* Day sheet */}
        <div className="nb-plate">
          <div className="flex flex-wrap items-center gap-1.5 mb-2">
            <span className="text-xs font-bold text-gray-700 mr-1">Day sheet</span>
            {ROUTE_DAYS.map(d => (
              <button key={d} type="button" onClick={() => { setPlanDay(d); setNotice(''); setError(''); }}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-all duration-200 ${
                  planDay === d ? 'bg-[#1e88e5] text-white shadow-sm' : 'bg-white border border-gray-200 text-gray-600 hover:border-blue-300'}`}>
                {d.slice(0, 3)}
                {d === todayName() && <span className={`ml-1 ${planDay === d ? 'text-inherit' : 'text-[#2ec4b6]'}`}>•</span>}
              </button>
            ))}
            <button type="button" onClick={() => setPlanDay(todayName())}
              className="ml-auto text-[11px] font-bold text-[#1e88e5] hover:underline">Jump to today</button>
          </div>
          {plan && (
            <>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-gray-500 mb-2">
                <span><b className="text-gray-800">{plan.routes}</b> route{plan.routes === 1 ? '' : 's'} on {plan.day}</span>
                <span><b className="text-gray-800">{plan.totalStops}</b> visits</span>
                <span><b className="text-gray-800">{plan.customers}</b> customers</span>
                <span>Money on the road: <b className="text-gray-800">PKR {plan.collectionValue.toLocaleString()}</b></span>
              </div>
              {plan.data.length === 0 && (
                <p className="text-xs text-gray-400 py-2">Nothing is planned for {plan.day}. Tick the day on a route to schedule it.</p>
              )}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                {plan.data.map(r => (
                  <div key={r.id} className="bg-white border border-gray-100 rounded p-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                      <span className="text-xs font-bold text-gray-800">{r.code} · {r.name}</span>
                      <span className="flex items-center gap-1 text-[10px] text-gray-500">
                        <Truck className="w-3 h-3" />{r.vehicleNumber || 'no vehicle'} · {r.salesmanName}
                      </span>
                    </div>
                    <ol className="space-y-1">
                      {r.stops.map((s, i) => (
                        <li key={`${s.customerId}-${i}`} className="flex items-start gap-2 text-[11px]">
                          <span className="shrink-0 w-4 text-gray-400 font-bold">{i + 1}.</span>
                          <span className="min-w-0 flex-1">
                            <span className="block font-semibold text-gray-700 truncate" title={s.customerName}>{s.customerName}</span>
                            <span className="block text-gray-400 truncate">{s.address || s.city || '-'}{s.phone ? ` · ${s.phone}` : ''}</span>
                          </span>
                          <span className="shrink-0 text-right">
                            <span className="block text-gray-500 font-mono">{s.time || '-'}</span>
                            {s.due ? <span className="block text-amber-600 font-semibold">PKR {s.due.toLocaleString()}</span> : null}
                          </span>
                        </li>
                      ))}
                    </ol>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {(error || hub.error || notice) && (
          <div className={`mb-3 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
            error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
            <span>{error || hub.error || notice}</span>
            <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 mb-3">
          <ListToolbar addLabel="ADD ROUTE" onAdd={() => { setDraft(blankDraft(branchId)); setStopDay('Monday'); setError(''); setNotice(''); }}>
            {/* Stops and Customers carry no totals line on the register, and a customer can sit on
                several routes, so summing that column would double-count. */}
            <ExportPair title="Weekly Route" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="weekly-routes" columns={columns} rows={visible} landscape />
            <SearchBox key={searchEpoch} className="ml-auto w-56 max-w-full" placeholder={"Search routes..."} onSearch={setSearch} />
          </ListToolbar>
        </div>

        {draft && (
          <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-3">
              <h3 className="card-title">
                {draft.id ? `Edit Route - [${draft.name || 'untitled'}]` : 'Create Route'}
              </h3>
              <span className="text-[11px] text-gray-400">
                {draft.stops.length} stop{draft.stops.length === 1 ? '' : 's'} on {runningDays.length} day(s)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Field label="Route Name" required>
                <Text value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Saddar Market Walk" />
              </Field>
              <Field label="Route Code">
                <div className="flex items-center gap-1">
                  <Text value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value.toUpperCase() })} placeholder="RT-04" />
                  <button type="button" onClick={proposeCode} title="Propose the next code"
                    className="h-[30px] w-8 shrink-0 rounded border border-blue-200 bg-blue-50 text-[#1e88e5] hover:bg-blue-100 flex items-center justify-center">
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Field>
              <Field label="Branch" required>
                <Pick value={String(draft.branchId)} onChange={e => setDraft({ ...draft, branchId: Number(e.target.value) })}>
                  {(hub.value?.branches ?? []).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </Pick>
              </Field>
              <Field label="Frequency">
                <Pick value={draft.frequency} onChange={e => setDraft({ ...draft, frequency: e.target.value as WeeklyRoute['frequency'] })}>
                  {(hub.value?.frequencies ?? ['Weekly', 'Alternative days', 'Fortnightly']).map(f => <option key={f} value={f}>{f}</option>)}
                </Pick>
              </Field>
              <Field label="Salesman" hint="order booker on the field">
                <Pick value={String(draft.salesmanId ?? '')} onChange={e => setDraft({ ...draft, salesmanId: Number(e.target.value) || null })}>
                  <option value="">- none -</option>
                  {(hub.value?.salesmen ?? []).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </Pick>
              </Field>
              <Field label="Deliveryman">
                <Pick value={String(draft.deliverymanId ?? '')} onChange={e => setDraft({ ...draft, deliverymanId: Number(e.target.value) || null })}>
                  <option value="">- none -</option>
                  {(hub.value?.deliverymen ?? []).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </Pick>
              </Field>
              <Field label="Vehicle">
                <Text value={draft.vehicleNumber} list="route-vehicles"
                  onChange={e => setDraft({ ...draft, vehicleNumber: e.target.value.toUpperCase() })} placeholder="HIACE / REG-1234" />
                <datalist id="route-vehicles">
                  {(hub.value?.vehicles ?? []).map(v => <option key={v} value={v} />)}
                </datalist>
              </Field>
              <div className="flex items-end gap-4 pb-1.5">
                <Check checked={draft.isActive} onChange={v => setDraft({ ...draft, isActive: v })} label="Route is running" />
              </div>
            </div>

            {/* Running days */}
            <div className="mt-3">
              <p className="text-xs font-semibold text-gray-600 mb-1.5">Running days</p>
              <div className="flex flex-wrap items-center gap-1.5">
                {ROUTE_DAYS.map(d => (
                  <button key={d} type="button" onClick={() => toggleDay(d, !draft.days[d])}
                    className={`relative px-3 py-1.5 rounded text-[11px] font-semibold border transition-all duration-200 ${
                      draft.days[d]
                        ? 'bg-teal-50 border-[#2ec4b6]/50 text-[#25a195]'
                        : 'bg-white border-gray-200 text-gray-400 hover:border-gray-300'}`}>
                    {d.slice(0, 3)}
                    {(counts?.[d] ?? 0) > 0 && (
                      <span className="ml-1.5 inline-block min-w-[16px] px-1 rounded-full bg-[#1e88e5] text-white text-[9px] leading-4">
                        {counts?.[d]}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Stops */}
            <div className="mt-3 bg-white border border-gray-200 rounded p-2.5">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <MapPin className="w-3.5 h-3.5 text-gray-400" />
                <span className="text-xs font-bold text-gray-700">Visiting order</span>
                <div className="ml-auto flex items-center gap-1">
                  <Pick value={newStop} onChange={e => setNewStop(e.target.value)} className="!w-auto max-w-[240px] text-[11px]">
                    <option value="">Add a customer to {stopDay}...</option>
                    {options.map(c => (
                      <option key={c.id} value={c.id}>{c.name} · {c.city || '-'}</option>
                    ))}
                  </Pick>
                  <button type="button" onClick={addStop} disabled={!newStop}
                    className="btn-xenith-primary !py-1 disabled:opacity-40"><Plus className="w-3.5 h-3.5" />Add</button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-1 mb-2">
                {runningDays.map(d => (
                  <button key={d} type="button" onClick={() => setStopDay(d)}
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                      stopDay === d ? 'bg-[#1e88e5] text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                    {d.slice(0, 3)} ({counts?.[d] ?? 0})
                  </button>
                ))}
                {runningDays.length === 0 && (
                  <span className="text-[11px] text-gray-400">Tick a running day above to plan stops.</span>
                )}
              </div>

              {dayStops.length === 0 ? (
                <p className="text-[11px] text-gray-400 py-2">No stops on {stopDay} yet. Pick a customer above.</p>
              ) : (
                <div className="space-y-1">
                  {dayStops.map((s, i) => {
                    const c = customerOf(s.customerId);
                    return (
                      <div key={`${s.customerId}-${i}`} className="flex flex-wrap items-center gap-2 text-[11px]">
                        <span className="w-5 shrink-0 text-gray-400 font-bold text-right">{i + 1}.</span>
                        <span className="min-w-[9rem] flex-1 truncate font-semibold text-gray-700" title={c?.name}>
                          {c?.name || `Customer #${s.customerId}`}
                        </span>
                        <span className="shrink-0 text-gray-400">{c?.city || ''}</span>
                        <span className="flex items-center gap-1 shrink-0">
                          <Clock className="w-3 h-3 text-gray-400" />
                          <input type="time" value={s.time} onChange={e => patchStop(i, { time: e.target.value })}
                            className="input-xenith !w-[86px] !py-0.5 text-[11px]" />
                        </span>
                        <input value={s.note} onChange={e => patchStop(i, { note: e.target.value })}
                          placeholder="note for this visit" className="input-xenith flex-1 min-w-[8rem] !py-0.5 text-[11px]" />
                        <span className="flex items-center gap-0.5 shrink-0">
                          <button type="button" onClick={() => moveStop(i, -1)} disabled={i === 0}
                            className="text-gray-400 hover:text-gray-700 disabled:text-gray-200"><ChevronUp className="w-4 h-4" /></button>
                          <button type="button" onClick={() => moveStop(i, 1)} disabled={i === dayStops.length - 1}
                            className="text-gray-400 hover:text-gray-700 disabled:text-gray-200"><ChevronDown className="w-4 h-4" /></button>
                          <button type="button" onClick={() => dropStop(i)}
                            className="text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <Field label="Notes" className="mt-3">
              <Text value={draft.notes} onChange={e => setDraft({ ...draft, notes: e.target.value })}
                placeholder="Anything the salesman must carry on this route" />
            </Field>

            <div className="flex items-center justify-between gap-2 mt-3">
              <p className="text-[11px] text-gray-400">
                A stop on a day the route does not run is dropped, so the day sheet never promises a visit nobody makes.
              </p>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning"><X className="w-3.5 h-3.5" /> Close</button>
                <button type="button" onClick={submit} disabled={saving || !draft.name.trim()}
                  className="btn-xenith-success disabled:opacity-50">
                  {saving ? 'Saving...' : 'SAVE'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Route Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Branch" sortKey="branchName" sort={sort} onSort={onSort} />
                <SortHeader label="Salesman" sortKey="salesmanName" sort={sort} onSort={onSort} />
                <SortHeader label="Deliveryman" sortKey="deliverymanName" sort={sort} onSort={onSort} />
                <SortHeader label="Vehicle" sortKey="vehicleNumber" sort={sort} onSort={onSort} />
                <SortHeader label="Stops" sortKey="stops" sort={sort} onSort={onSort} />
                <SortHeader label="Customers" sortKey="customers" sort={sort} onSort={onSort} />
                <SortHeader label="Days" sortKey="days" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {hub.value && visible.length === 0 && (
                <TableEmpty colSpan={11} noun="routes" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'ADD ROUTE'}
                  onAdd={() => { setDraft(blankDraft(branchId)); setStopDay('Monday'); setError(''); setNotice(''); }} />
              )}
              {visible.map(r => (
                <tr key={r.id}>
                  <td className="font-medium">{r.code || '-'}</td>
                  <td>
                    <button type="button" onClick={() => setPlanDay(r.daysRun[0] || planDay)}
                      className="font-medium text-left hover:text-[#1e88e5] transition-colors">{r.name}</button>
                  </td>
                  <td>{r.branchName || <span className="text-gray-300">-</span>}</td>
                  <td>{r.salesmanName || <span className="text-gray-300">-</span>}</td>
                  <td>{r.deliverymanName || <span className="text-gray-300">-</span>}</td>
                  <td className="uppercase">{r.vehicleNumber || <span className="text-gray-300 normal-case">-</span>}</td>
                  <td>{r.stops.length}</td>
                  <td>{r.customers}</td>
                  <td>
                    <span className="flex flex-wrap gap-0.5">
                      {ROUTE_DAYS.map(d => (
                        <span key={d} title={d}
                          className={`w-5 text-center text-[9px] font-bold rounded ${
                            r.days[d] ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-50 text-gray-300'}`}>
                          {d.slice(0, 1)}
                        </span>
                      ))}
                    </span>
                  </td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                      r.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {r.isActive ? 'Running' : 'Closed'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Edit route" tone="primary" onClick={() => startEdit(r)}><Pencil className="w-4 h-4" /></IconAction>
                      {confirmId === r.id ? (
                        <DeleteConfirm onConfirm={() => remove(r)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${r.name} on the route plan`} />
                      ) : (
                        <IconAction title="Delete route" tone="danger" onClick={() => setConfirmId(r.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WeeklyRoutesPage;
