import React, { useEffect, useMemo, useState } from 'react';
import { RefreshCw, Warehouse as WarehouseIcon, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { getUsers } from '../../services/access.service';
import {
  deleteWarehouse, getWarehouses, saveWarehouse, updateWarehouse, updateWarehouseSettings,
  Warehouse, WarehouseSettings
} from '../../services/warehouses.service';
import { Check, DeleteConfirm, ExportPair, Field, ListToolbar, Pick, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, TableEmpty, Text, IconAction } from '../Masters/masterUi';
import { useHub } from './useHub';
import { ExportColumn } from '../../utils/exportTable';

type Draft = Partial<Warehouse> & { name: string };

const blankWarehouse = (branchId: number): Draft => ({
  name: '', code: '', branchId, city: '', address: '', phone: '', email: '',
  managerName: '', applicationUserId: null, isActive: true, isMoveable: false, isDefault: false
});

const FLAGS: { key: keyof WarehouseSettings; label: string; hint: string }[] = [
  {
    key: 'trackStockPerWarehouse',
    label: 'Track stock per warehouse',
    hint: 'Item balances, transfers and the warehouse-wise stock report split by location instead of one company total.'
  },
  {
    key: 'requireWarehouseOnDocuments',
    label: 'Require a warehouse on stock documents',
    hint: 'Deliveries, goods receipts and returns cannot be saved until a warehouse is chosen. Needs per-warehouse stock.'
  },
  {
    key: 'allowNegativeStock',
    label: 'Allow negative stock',
    hint: 'Lets a document go through even when the chosen warehouse does not hold the quantity. Useful while opening balances are still being entered.'
  }
];

export const WarehousesPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [flags, setFlags] = useState<WarehouseSettings | null>(null);
  // The login a gate is worked from: a keeper posted to one warehouse is served that
  // warehouse's deliveries and nobody else's.
  const [users, setUsers] = useState<{ id: number; name: string; email: string; isActive: boolean }[]>([]);

  useEffect(() => {
    getUsers(tenantSlug, branchId)
      .then(d => setUsers(d.data.map(u => ({ id: u.id, name: u.name, email: u.email, isActive: u.isActive }))))
      .catch(() => setUsers([]));
  }, [tenantSlug, branchId]);

  const hub = useHub(() => getWarehouses(tenantSlug, branchId), [tenantSlug, branchId]);
  const current = flags ?? hub.value?.settings ?? null;
  const rows = hub.value?.data ?? [];

  const visible = useMemo(() => {
    const list = rows.filter(w => !search.trim() ||
      `${w.name} ${w.code} ${w.city} ${w.branchName} ${w.managerName} ${w.keeperName ?? ''}`.toLowerCase().includes(search.trim().toLowerCase()));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [rows, search, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const closed = rows.filter(w => !w.isActive).length;

  const stats: RegisterStat[] = [
    {
      label: 'On register',
      value: search ? `${visible.length} of ${rows.length}` : String(rows.length),
      title: search ? `${rows.length} locations on the register, the search leaves ${visible.length} on screen` : 'Locations on the register'
    },
    ...(closed ? [{
      label: 'Closed', value: closed, tone: 'warn' as const,
      title: `${closed} of them are marked Closed on the register`
    }] : [])
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];

  const clearAll = () => {
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<Warehouse>[] = [
    { label: 'Code', value: w => w.code },
    { label: 'Warehouse Name', value: w => w.name },
    { label: 'Branch', value: w => w.branchName || '-' },
    { label: 'City', value: w => w.city || '-' },
    { label: 'In Charge', value: w => w.managerName || '-' },
    { label: 'Keeper Login', value: w => w.keeperName || '-' },
    { label: 'Stock', value: w => w.stock.toLocaleString(), align: 'right' },
    { label: 'Documents', value: w => w.documents, align: 'right' },
    { label: 'Status', value: w => w.isActive ? 'Active' : 'Closed' }
  ];

  const proposeCode = () => {
    const next = rows.reduce((max, w) => Math.max(max, Number(String(w.code).replace(/\D/g, '')) || 0), 0) + 1;
    setDraft(d => (d ? { ...d, code: `WH-${String(next).padStart(2, '0')}` } : d));
  };

  const reload = () => { hub.reload(); setFlags(null); };

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError(''); setNotice('');
    try {
      if (draft.id) {
        await updateWarehouse(tenantSlug, branchId, draft.id, draft);
        setNotice(`${draft.name} has been updated.`);
      } else {
        const created = await saveWarehouse(tenantSlug, branchId, draft);
        setNotice(`${created.name} has been added.`);
      }
      reload();
      setDraft(null);
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const saveFlags = async (next: WarehouseSettings) => {
    setFlags(next);
    setError(''); setNotice('');
    try {
      const saved = await updateWarehouseSettings(tenantSlug, branchId, next);
      setFlags(saved);
      hub.reload();
      setNotice('Warehouse settings saved.');
    } catch (e) { setError((e as Error).message); }
  };

  const remove = async (w: Warehouse) => {
    setError(''); setNotice('');
    try {
      await deleteWarehouse(tenantSlug, branchId, w.id);
      setNotice(`${w.name} has been deleted.`);
      reload();
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><WarehouseIcon className="w-4 h-4" /> Warehouses</span>
        <StatStrip stats={stats} />
      </div>
      <div className="nb-card-body">
        {current && (
          <div className="nb-note">
            <label className="flex items-start gap-2 cursor-pointer">
              <input type="checkbox" className="mt-0.5 accent-[#2ec4b6]" checked={current.enabled}
                onChange={e => saveFlags({ ...current, enabled: e.target.checked })} />
              <span>
                <span className="block text-xs font-bold text-gray-700">Use multiple warehouses in this company</span>
                <span className="block text-[11px] text-gray-500">
                  Stock is kept location-wise instead of one pool per branch. Every warehouse belongs to a branch, and one of them is the default that documents open on.
                </span>
              </span>
            </label>
            {current.enabled && (
              <div className="mt-3 pl-6 space-y-1.5">
                {FLAGS.map(f => (
                  <div key={f.key}>
                    <Check checked={current[f.key]}
                      disabled={f.key === 'requireWarehouseOnDocuments' && !current.trackStockPerWarehouse}
                      onChange={v => saveFlags({ ...current, [f.key]: v })} label={f.label} />
                    <p className="pl-5 text-[10px] text-gray-400">{f.hint}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(error || hub.error || notice) && (
          <div className={`mb-3 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
            error || hub.error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
            <span>{error || hub.error || notice}</span>
            <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 mb-3">
          <ListToolbar addLabel="ADD WAREHOUSE" onAdd={() => { setDraft(blankWarehouse(branchId)); setError(''); setNotice(''); }}>
            {/* The Stock column holds each location's items in their own units, so a totals line
                would add unlike quantities; neither the table nor the export carries one. */}
            <ExportPair title="Warehouses" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="warehouses" columns={columns} rows={visible} landscape />
            <SearchBox key={searchEpoch} className="ml-auto w-56 max-w-full" placeholder={"Search warehouses..."} onSearch={setSearch} />
          </ListToolbar>
        </div>

        {draft && (
          <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-3">
              <h3 className="card-title">
                {draft.id ? `Edit Warehouse - [${draft.name || 'untitled'}]` : 'Create Warehouse'}
              </h3>
              {!current?.enabled && (
                <span className="text-[11px] font-semibold text-amber-600">Multiple warehouses are currently switched off.</span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <Field label="Warehouse Name" required>
                <Text value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. SITE Warehouse" />
              </Field>
              <Field label="Warehouse Code" required>
                <div className="flex items-center gap-1">
                  <Text value={draft.code || ''} onChange={e => setDraft({ ...draft, code: e.target.value.toUpperCase() })} placeholder="WH-04" />
                  <button type="button" onClick={proposeCode} title="Propose the next code"
                    className="h-[30px] w-8 shrink-0 rounded border border-teal-200 bg-teal-50 text-[#25a195] hover:bg-teal-100 flex items-center justify-center">
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Field>
              <Field label="Branch" required>
                <Pick value={String(draft.branchId ?? '')} onChange={e => setDraft({ ...draft, branchId: Number(e.target.value) })}>
                  {(hub.value?.branches ?? []).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </Pick>
              </Field>
              <Field label="City">
                <Text value={draft.city || ''} onChange={e => setDraft({ ...draft, city: e.target.value })} />
              </Field>
              <Field label="Address" className="lg:col-span-2">
                <Text value={draft.address || ''} onChange={e => setDraft({ ...draft, address: e.target.value })} />
              </Field>
              <Field label="In Charge">
                <Text value={draft.managerName || ''} onChange={e => setDraft({ ...draft, managerName: e.target.value })} />
              </Field>
              <Field label="Warehouse Keeper (login)"
                hint="This login is served its own gate's deliveries and no other; one keeper holds one warehouse.">
                <Pick value={String(draft.applicationUserId ?? '')} onChange={e => {
                  const id = e.target.value ? Number(e.target.value) : null;
                  setDraft({ ...draft, applicationUserId: id });
                }}>
                  <option value="">-Choose-</option>
                  {users.filter(u => u.isActive).map(u => <option key={u.id} value={String(u.id)}>{u.name} ({u.email})</option>)}
                </Pick>
              </Field>
              <Field label="Phone">
                <Text value={draft.phone || ''} onChange={e => setDraft({ ...draft, phone: e.target.value })} />
              </Field>
              <Field label="Email">
                <Text type="email" value={draft.email || ''} onChange={e => setDraft({ ...draft, email: e.target.value })} />
              </Field>
              <div className="flex items-end gap-4 pb-1.5 lg:col-span-3">
                <Check checked={!!draft.isActive} onChange={v => setDraft({ ...draft, isActive: v })} label="Active" />
                <Check checked={!!draft.isMoveable} onChange={v => setDraft({ ...draft, isMoveable: v })} label="Moveable location" />
                {/* One warehouse is default at a time, so the box can be ticked onto this
                    one but never unticked from it — unticking would leave the branch with none. */}
                <Check checked={!!draft.isDefault} onChange={v => v && setDraft({ ...draft, isDefault: true })}
                  disabled={!!draft.isDefault} label="Make default warehouse" />
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 mt-3">
              <p className="text-[11px] text-gray-400">
                {draft.isMoveable
                  ? 'A moveable location (van, kiosk, road show) can hold stock that travels with it.'
                  : 'Documents that carry stock open on the default warehouse of the branch you are working in.'}
              </p>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning"><X className="w-3.5 h-3.5" /> Close</button>
                <button type="button" onClick={submit} disabled={saving || !draft.name.trim() || !draft.code?.trim()}
                  className="btn-xenith-success disabled:opacity-50">
                  {saving ? 'Saving...' : 'SAVE'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Warehouse Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Branch" sortKey="branchName" sort={sort} onSort={onSort} />
                <SortHeader label="City" sortKey="city" sort={sort} onSort={onSort} />
                <SortHeader label="In Charge" sortKey="managerName" sort={sort} onSort={onSort} />
                <SortHeader label="Keeper Login" sortKey="keeperName" sort={sort} onSort={onSort} />
                <SortHeader label="Stock" sortKey="stock" sort={sort} onSort={onSort} />
                <SortHeader label="Documents" sortKey="documents" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {hub.value && visible.length === 0 && (
                <TableEmpty colSpan={10} noun="warehouses" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'ADD WAREHOUSE'}
                  onAdd={() => { setDraft(blankWarehouse(branchId)); setError(''); setNotice(''); }} />
              )}
              {visible.map(w => (
                <tr key={w.id}>
                  <td className="font-medium">{w.code}</td>
                  <td>
                    <span className="flex items-center gap-2">
                      <span className="font-medium">{w.name}</span>
                      {w.isDefault && <span className="text-[10px] font-bold uppercase text-[#1e88e5] bg-blue-50 px-1.5 py-0.5 rounded">Default</span>}
                      {w.isMoveable && <span className="text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">Moveable</span>}
                    </span>
                  </td>
                  <td>{w.branchName || <span className="text-gray-300">-</span>}</td>
                  <td>{w.city || <span className="text-gray-300">-</span>}</td>
                  <td>{w.managerName || <span className="text-gray-300">-</span>}</td>
                  <td>{w.keeperName || <span className="text-gray-300">-</span>}</td>
                  <td className={w.stock < 0 ? 'text-red-600 font-semibold' : ''}>{w.stock.toLocaleString()}</td>
                  <td>{w.documents}</td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${w.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {w.isActive ? 'Active' : 'Closed'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Edit warehouse" tone="primary" onClick={() => { setDraft({ ...w }); setError(''); setNotice(''); }}><Pencil className="w-4 h-4" /></IconAction>
                      {w.isDefault ? (
                        <IconAction title="The default warehouse cannot be deleted" disabled><Trash2 className="w-4 h-4" /></IconAction>
                      ) : confirmId === w.id ? (
                        <DeleteConfirm onConfirm={() => remove(w)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${w.name}`} />
                      ) : (
                        <IconAction title="Delete warehouse" tone="danger" onClick={() => setConfirmId(w.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WarehousesPage;
