import React, { useEffect, useMemo, useState } from 'react';
import { useHub } from './useHub';
import {
  AlertCircle, ArrowLeft, BadgeCheck, Building2, Check as CheckIcon, Copy, KeyRound,
  MessageCircle, Plus, RefreshCw, Save, Search, Send, Stamp, Trash2, Trophy, Users, X
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { SalesPersonDocSetting } from '../../types';
import { getSalesPersonSettings, saveSalesPersonSettings } from '../../services/masters.service';
import {
  activateTemplate, addWhatsAppAccount, ApiKey, createApiKey, deactivateTemplate, deleteApiKey,
  deleteTemplate, deleteWhatsAppAccount, getActivityLog, getApiKeys, getCompanyHub, getLoyalty, getPrintingTemplates,
  getSmtp, getWhatsAppAccounts, getWhatsAppMessages, getWhatsAppReminder, getWhatsAppReminders,
  linkWhatsApp, LoyaltyProgram, PrintTemplate, ReminderDraft, ReminderGroup, saveCompanyHub, saveLoyalty,
  getSampleBook, loadSampleBook, clearSampleBook, SampleBookRun, SampleBookState, saveSmtp, sendWhatsApp,
  SettingField, SettingValue, SmtpSettings, TemplateDesign, updateApiKey,
  updateWhatsAppAccount, ActivityEntry, CompanyHub, WhatsAppAccount, WhatsAppMessage
} from '../../services/settings.service';
import { FOOTER_OPTIONS, LETTERHEAD_OPTIONS, PRINT_THEMES, themeOf } from '../../utils/printDesigns';
import { PrintDesignPanel } from '../../components/print/PrintTemplateModal';
import { Area, Check, Field, ImagePicker, NumCell, Pick, TabStrip, Text } from '../Masters/masterUi';

const TABS = [
  'Information', 'Settings', 'Sales Person', 'SMTP', 'WhatsApp Setting', 'API Keys',
  'Printing Templates', 'Customer Loyalty Program', 'Activity Log', 'Sample Data',
];

const Panel: React.FC<{ title: string; children: React.ReactNode; right?: React.ReactNode }> = ({ title, children, right }) => (
  <div className="panel-xenith mb-4">
    <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-2">
      <h2 className="section-title">{title}</h2>
      {right}
    </div>
    <div className="p-4">{children}</div>
  </div>
);

const SaveBar: React.FC<{ onSave: () => void; saving?: boolean; saved?: boolean; error?: string; disabled?: boolean; label?: string }> = ({
  onSave, saving, saved, error, disabled, label = 'SAVE'
}) => (
  <div className="flex flex-wrap items-center justify-end gap-3 pt-1">
    {error && (
      <p className="mr-auto flex items-start gap-1.5 text-[11px] font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5 max-w-xl">
        <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-px" /> {error}
      </p>
    )}
    {saved && !error && <span className="mr-auto text-[11px] font-bold text-[#25a195]">Saved</span>}
    <button type="button" onClick={onSave} disabled={saving || disabled} className="btn-xenith-success disabled:opacity-50">
      <Save className="w-3.5 h-3.5" /> {saving ? 'Saving…' : label}
    </button>
  </div>
);

const Modal: React.FC<{ title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode }> = ({
  title, subtitle, onClose, children, footer
}) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 animate-[fadeUp_.2s_ease-out_backwards]" onClick={onClose}>
    <div className="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[calc(100vh-2rem)] overflow-y-auto" onClick={e => e.stopPropagation()}>
      <div className="flex items-start justify-between gap-3 px-5 py-3 border-b border-gray-100">
        <div>
          <h2 className="card-title">{title}</h2>
          {subtitle && <p className="text-[11px] text-gray-400">{subtitle}</p>}
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="w-4 h-4" /></button>
      </div>
      <div className="p-4 space-y-3">{children}</div>
      {footer && <div className="flex flex-wrap items-center justify-end gap-2 px-5 py-3 border-t border-gray-100">{footer}</div>}
    </div>
  </div>
);


// ─── Information ─────────────────────────────────────────────────────────────
const InformationTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: hub, error: loadError, loading } = useHub<CompanyHub>(() => getCompanyHub(tenantSlug, branchId), [tenantSlug, branchId]);
  const [profile, setProfile] = useState(hub?.profile);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { if (hub) setProfile(hub.profile); }, [hub]);
  if (loading || !hub || !profile) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading company profile…'}</p>;

  const set = (k: keyof typeof profile, v: string) => { setProfile({ ...profile, [k]: v }); setSaved(false); };
  const states = hub.options.states[profile.country] || [];

  const submit = async () => {
    setSaving(true); setError('');
    try {
      await saveCompanyHub(tenantSlug, branchId, { profile });
      setSaved(true);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="Branding">
        <div className="flex flex-wrap gap-8">
          <div className="text-center">
            <p className="param-label mb-2">Upload Image</p>
            <ImagePicker round value={profile.logo} onChange={logo => set('logo', logo)} />
          </div>
          <div className="text-center">
            <p className="param-label mb-2">Upload Signature</p>
            <ImagePicker round value={profile.signature} onChange={signature => set('signature', signature)} />
          </div>
        </div>
      </Panel>

      <Panel title="Company Identity">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
          <Field label="Company Name" required><Text value={profile.name} onChange={e => set('name', e.target.value)} /></Field>
          <Field label="Type of Organization">
            <Pick value={profile.typeOfOrganization} onChange={e => set('typeOfOrganization', e.target.value)}>
              {hub.options.orgTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </Pick>
          </Field>
          <Field label="Slug" hint="assigned by Xenith ERP"><Text value={profile.slug} readOnly className="bg-gray-50 font-mono text-[11px] text-gray-500" /></Field>
          <Field label="Address Line 1" className="sm:col-span-2"><Text value={profile.addressLine1} onChange={e => set('addressLine1', e.target.value)} /></Field>
          <Field label="Address Line 2"><Text value={profile.addressLine2} onChange={e => set('addressLine2', e.target.value)} /></Field>
          <Field label="Country">
            <Pick value={profile.country} onChange={e => set('country', e.target.value)}>
              {hub.options.countries.map(c => <option key={c} value={c}>{c}</option>)}
            </Pick>
          </Field>
          <Field label="State">
            <Pick value={states.includes(profile.state) ? profile.state : ''} onChange={e => set('state', e.target.value)}>
              <option value="">Select state</option>
              {states.map(s => <option key={s} value={s}>{s}</option>)}
            </Pick>
          </Field>
          <Field label="City"><Text value={profile.city} onChange={e => set('city', e.target.value)} /></Field>
          <Field label="Zip Code"><Text value={profile.zip} onChange={e => set('zip', e.target.value)} /></Field>
          <Field label="Email"><Text type="email" value={profile.email} onChange={e => set('email', e.target.value)} /></Field>
          <Field label="Contact Person"><Text value={profile.contactPerson} onChange={e => set('contactPerson', e.target.value)} /></Field>
          <Field label="Phone"><Text value={profile.phone} onChange={e => set('phone', e.target.value)} /></Field>
          <Field label="Fax"><Text value={profile.fax} onChange={e => set('fax', e.target.value)} /></Field>
          <Field label="NTN"><Text value={profile.ntn} onChange={e => set('ntn', e.target.value)} /></Field>
          <Field label="CNIC"><Text value={profile.cnic} onChange={e => set('cnic', e.target.value)} /></Field>
        </div>
      </Panel>

      <SaveBar onSave={submit} saving={saving} saved={saved} error={error} disabled={!profile.name.trim()} />
    </div>
  );
};

// ─── Settings (rendered from the server schema) ──────────────────────────────
const SettingControl: React.FC<{ field: SettingField; value: SettingValue; onChange: (v: SettingValue) => void }> = ({ field, value, onChange }) => {
  if (field.kind === 'flag') {
    return (
      <div className="sm:col-span-2 xl:col-span-1">
        <Check checked={Boolean(value)} onChange={onChange} label={field.label} />
        {field.hint && <p className="ml-5 text-[11px] text-gray-400">{field.hint}</p>}
      </div>
    );
  }
  return (
    <Field label={field.label} hint={field.hint}>
      {field.kind === 'select' ? (
        <Pick value={String(value)} onChange={e => onChange(e.target.value)}>
          {(field.options || []).map(o => <option key={o} value={o}>{o}</option>)}
        </Pick>
      ) : field.kind === 'number' ? (
        <NumCell value={Number(value)} min={field.min} max={field.max} onChange={e => onChange(Number(e.target.value))} />
      ) : (
        <Text value={String(value)} onChange={e => onChange(e.target.value)} />
      )}
      {field.note && <p className="mt-1 text-[11px] leading-snug text-[#25a195] font-semibold">{field.note}</p>}
      {field.warning && <p className="mt-1 text-[11px] leading-snug text-amber-600 font-semibold">{field.warning}</p>}
    </Field>
  );
};

const SettingsTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: hub, error: loadError, loading, reload } = useHub<CompanyHub>(() => getCompanyHub(tenantSlug, branchId), [tenantSlug, branchId]);
  const [draft, setDraft] = useState<Record<string, SettingValue>>({});
  const [branches, setBranches] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (hub) { setDraft(hub.settings); setBranches(hub.linkedBranchIds); }
  }, [hub]);
  if (loading || !hub) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading settings…'}</p>;

  const dirty = Object.keys(draft).filter(k => draft[k] !== hub.settings[k]);
  const changedBranches = JSON.stringify([...branches].sort()) !== JSON.stringify([...hub.linkedBranchIds].sort());

  const submit = async () => {
    setSaving(true); setError('');
    try {
      const patch: Record<string, SettingValue> = {};
      dirty.forEach(k => { patch[k] = draft[k]; });
      const res = await saveCompanyHub(tenantSlug, branchId, { settings: patch, linkedBranchIds: branches });
      reload();
      setDraft(res.settings);
      setSaved(true);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      {hub.sections.map(section => (
        <Panel key={section.id} title={section.title}
          right={section.id === 'branch' ? undefined : (
            <span className="text-[11px] text-gray-400">{section.fields.length} option(s)</span>
          )}>
          {section.id === 'branch' ? (
            <div className="space-y-3">
              <div className="flex flex-wrap items-end gap-4">
                {section.fields.map(f => (
                  <SettingControl key={f.key} field={f} value={draft[f.key]} onChange={v => { setDraft({ ...draft, [f.key]: v }); setSaved(false); }} />
                ))}
              </div>
              <div>
                <p className="param-label">Linked Branches</p>
                <div className="flex flex-wrap gap-x-6 gap-y-2">
                  {hub.linkedBranches.map(b => (
                    <Check key={b.id} label={`${b.name}${b.isMain ? ' (main)' : ''} — ${b.city}`} checked={branches.includes(b.id)}
                      onChange={v => setBranches(prev => (v ? [...prev, b.id] : prev.filter(x => x !== b.id)))} />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
              {section.fields.map(f => (
                <SettingControl key={f.key} field={f} value={draft[f.key]} onChange={v => { setDraft({ ...draft, [f.key]: v }); setSaved(false); }} />
              ))}
            </div>
          )}
        </Panel>
      ))}

      <SaveBar onSave={submit} saving={saving} saved={saved} error={error}
        disabled={!dirty.length && !changedBranches} label={`SAVE${dirty.length ? ` (${dirty.length} change${dirty.length > 1 ? 's' : ''})` : ''}`} />

      <div className="mt-6 panel-xenith !border-red-200">
        <div className="px-4 py-3 border-b border-red-100 bg-red-50/60">
          <h2 className="text-xs font-black uppercase tracking-[.14em] text-red-600">Delete Company</h2>
        </div>
        <p className="p-4 text-[11px] text-gray-500 max-w-xl">
          Deleting a company removes its ledgers, documents and stock history. This build keeps the
          destructive call out on purpose so no data can be lost.
        </p>
      </div>
    </div>
  );
};

// ─── Sales Person ────────────────────────────────────────────────────────────
interface DocCard { document: string; label: string; orderBooker?: boolean; deliveryPerson?: boolean; salesman: boolean }
const CARDS: DocCard[] = [
  { document: 'SalesDelivery', label: 'Sales Delivery', deliveryPerson: true, salesman: true },
  { document: 'SalesInvoice', label: 'Sales Invoice', orderBooker: true, deliveryPerson: true, salesman: true },
  { document: 'SalesReturn', label: 'Sales Return', deliveryPerson: true, salesman: true },
  { document: 'ReceivePayment', label: 'Receive Payment', salesman: true },
  { document: 'CustomerRefund', label: 'Customer Refund', salesman: true },
  { document: 'Pos', label: 'POS', salesman: true },
  { document: 'OtherCollections', label: 'Other Collections', salesman: true },
];

const SalesPersonTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<SalesPersonDocSetting[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => { getSalesPersonSettings(tenantSlug, branchId).then(setRows).catch(() => setRows([])); }, [tenantSlug, branchId]);

  const setFlag = (document: string, key: keyof Omit<SalesPersonDocSetting, 'document'>, value: boolean) => {
    setRows(rs => rs.map(r => (r.document === document ? { ...r, [key]: value } : r)));
    setSaved(false);
  };

  const submit = async () => {
    setSaving(true);
    try { setRows(await saveSalesPersonSettings(tenantSlug, branchId, rows)); setSaved(true); } finally { setSaving(false); }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
        {CARDS.map(card => {
          const row = rows.find(r => r.document === card.document);
          if (!row) return null;
          return (
            <div key={card.document} className="nb-card mb-0">
              <div className="nb-card-header">{card.label}</div>
              <div className="nb-card-body space-y-2">
                {card.orderBooker && <Check checked={row.showOrderBooker} onChange={v => setFlag(card.document, 'showOrderBooker', v)} label="Show Order Booker" />}
                {card.deliveryPerson && <Check checked={row.showDeliveryPerson} onChange={v => setFlag(card.document, 'showDeliveryPerson', v)} label="Show Delivery Person" />}
                {card.salesman && <Check checked={row.showSalesman} onChange={v => setFlag(card.document, 'showSalesman', v)} label="Show Salesman" />}
              </div>
            </div>
          );
        })}
      </div>
      <SaveBar onSave={submit} saving={saving} saved={saved} disabled={!rows.length} />
    </div>
  );
};

// ─── SMTP ────────────────────────────────────────────────────────────────────
const SmtpTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: smtp, loading, error: loadError, reload } = useHub<SmtpSettings>(() => getSmtp(tenantSlug, branchId), [tenantSlug, branchId]);
  const [draft, setDraft] = useState<Partial<SmtpSettings> & { password?: string }>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { if (smtp) setDraft(smtp); }, [smtp]);
  if (loading || !smtp) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading mail settings…'}</p>;

  const set = (k: string, v: string | number | boolean) => { setDraft(d => ({ ...d, [k]: v })); setSaved(false); };

  const submit = async () => {
    setSaving(true); setError('');
    try { await saveSmtp(tenantSlug, branchId, draft); reload(); setSaved(true); }
    catch (e) { setError((e as Error).message); }
    finally { setSaving(false); }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="Outgoing Mail">
        <div className="space-y-4">
          <Check checked={Boolean(draft.useOwnAddress)} onChange={v => set('useOwnAddress', v)} label="Use own address for emails" />
          {draft.useOwnAddress ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
              <Field label="SMTP Host" required><Text value={draft.host || ''} onChange={e => set('host', e.target.value)} placeholder="smtp.gmail.com" /></Field>
              <Field label="Port"><NumCell value={draft.port || 0} onChange={e => set('port', Number(e.target.value))} /></Field>
              <Field label="Username"><Text value={draft.username || ''} onChange={e => set('username', e.target.value)} /></Field>
              <Field label="Password" hint={smtp.passwordSet ? 'A password is already saved; type a new one to replace it.' : 'Stored on the server and never sent back to the browser.'}>
                <Text type="password" value={draft.password || ''} onChange={e => set('password', e.target.value)} placeholder={smtp.passwordSet ? '••••••••' : ''} />
              </Field>
              <Field label="From Name"><Text value={draft.fromName || ''} onChange={e => set('fromName', e.target.value)} /></Field>
              <Field label="From Email"><Text value={draft.fromEmail || ''} onChange={e => set('fromEmail', e.target.value)} /></Field>
              <div className="sm:col-span-2 xl:col-span-1">
                <Check checked={Boolean(draft.secure)} onChange={v => set('secure', v)} label="Use TLS / SSL" />
              </div>
            </div>
          ) : (
            <p className="text-xs text-gray-500">
              Xenith ERP sends invoices, statements and reminders through its own mail service for this company.
            </p>
          )}
        </div>
      </Panel>
      <SaveBar onSave={submit} saving={saving} saved={saved} error={error} />
    </div>
  );
};

// ─── WhatsApp Business accounts ──────────────────────────────────────────────
const BLANK_WA: Partial<WhatsAppAccount> = { pin: '', phoneId: '', whatsappId: '', token: '' };
const pkr = (n: number) => `PKR ${Math.round(n).toLocaleString('en-US')}`;

const WhatsAppTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: accounts, loading, error: loadError, reload } = useHub<WhatsAppAccount[]>(() => getWhatsAppAccounts(tenantSlug, branchId), [tenantSlug, branchId]);
  const { value: groups, reload: reloadGroups } = useHub<ReminderGroup[]>(() => getWhatsAppReminders(tenantSlug, branchId), [tenantSlug, branchId]);
  const { value: outbox, reload: reloadOutbox } = useHub<WhatsAppMessage[]>(() => getWhatsAppMessages(tenantSlug, branchId), [tenantSlug, branchId]);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [hadToken, setHadToken] = useState(false);
  const [draft, setDraft] = useState<Partial<WhatsAppAccount>>(BLANK_WA);
  const [hint, setHint] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  // The reminder is read off the due list by the server, so the screen only ever edits what was
  // composed — it never types a balance by hand.
  const [customerId, setCustomerId] = useState(0);
  const [paper, setPaper] = useState<ReminderDraft | null>(null);
  const [to, setTo] = useState('');
  const [text, setText] = useState('');
  const [accountId, setAccountId] = useState(0);
  const [sending, setSending] = useState(false);
  const [verdict, setVerdict] = useState('');
  const [rejected, setRejected] = useState(false);

  const startAdd = () => { setEditId(null); setHadToken(false); setDraft(BLANK_WA); setError(''); setHint(''); setOpen(true); };
  const startEdit = (a: WhatsAppAccount) => {
    setEditId(a.id); setHadToken(!!a.hasToken);
    setDraft({ pin: a.pin, phoneId: a.phoneId, whatsappId: a.whatsappId, token: '' });
    setError(''); setHint(''); setOpen(true);
  };

  const login = async () => {
    setError('');
    try {
      const res = await linkWhatsApp(tenantSlug, branchId);
      setHint(res.hint);
      window.open(res.loginUrl, '_blank', 'noopener');
    } catch (e) { setError((e as Error).message); }
  };

  const submit = async () => {
    setError('');
    setSaving(true);
    try {
      if (editId) await updateWhatsAppAccount(tenantSlug, branchId, editId, draft);
      else await addWhatsAppAccount(tenantSlug, branchId, draft);
      setOpen(false);
      reload();
      reloadGroups();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: number) => {
    if (!window.confirm('Unlink this WhatsApp Business account?')) return;
    await deleteWhatsAppAccount(tenantSlug, branchId, id);
    reload();
  };

  const compose = async (id: number) => {
    setPaper(null); setVerdict(''); setRejected(false);
    if (!id) return;
    try {
      const d = await getWhatsAppReminder(tenantSlug, branchId, id);
      setPaper(d); setTo(d.to); setText(d.text);
    } catch (e) { setVerdict((e as Error).message); setRejected(true); }
  };

  const pickCustomer = (id: number) => { setCustomerId(id); void compose(id); };

  const sendNow = async () => {
    setSending(true); setVerdict(''); setRejected(false);
    try {
      const m = await sendWhatsApp(tenantSlug, branchId, {
        to, text, subject: paper ? `Payment reminder — ${paper.customer}` : 'Payment reminder',
        accountId: accountId || undefined
      });
      setVerdict(`Meta accepted the message. Its id is ${m.reference || '—'}.`);
    } catch (e) {
      setVerdict((e as Error).message); setRejected(true);
    } finally {
      setSending(false);
      reloadOutbox();
      reload();
    }
  };

  if (loading || !accounts) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading WhatsApp accounts…'}</p>;

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="WhatsApp Business Accounts" right={
        <button type="button" onClick={startAdd} className="btn-xenith-success"><Plus className="w-3.5 h-3.5" /> ADD WHATSAPP BUSINESS ACCOUNT</button>
      }>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead><tr><th>Pin</th><th>Phone Id</th><th>Whatsapp Id</th><th>Token</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {accounts.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-6 text-gray-500">
                    No WhatsApp business account saved yet. Add one to send payment reminders from your own number.
                  </td>
                </tr>
              )}
              {accounts.map(a => (
                <tr key={a.id}>
                  <td className="font-mono text-[11px] font-bold text-gray-700">{a.pin}</td>
                  <td className="font-mono text-[11px] text-gray-500">{a.phoneId}</td>
                  <td className="font-mono text-[11px] text-gray-500">{a.whatsappId}</td>
                  <td className="font-mono text-[11px] text-gray-500">{a.token || <span className="text-gray-400">Not saved</span>}</td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${
                      a.connected ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-gray-100 text-gray-500 border-gray-200'}`}>
                      {a.connected ? 'Linked' : 'Not linked'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="btn-xenith-outline !px-1.5 !py-1" title="Edit account" onClick={() => startEdit(a)}>
                        <MessageCircle className="w-3 h-3" />
                      </button>
                      <button className="btn-xenith-danger !px-1.5 !py-1" title="Unlink" onClick={() => remove(a.id)}><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel title="Send a Due Reminder" right={
        <button type="button" onClick={reloadGroups} className="btn-xenith-outline"><RefreshCw className="w-3.5 h-3.5" /> REFRESH DUE LIST</button>
      }>
        <p className="text-[11px] text-gray-500 mb-3 max-w-3xl">
          The message is composed from Reports → Customer Due Invoices for this branch, so what a customer is
          told cannot disagree with the book. Rewrite it before sending if you like — nothing leaves until Send is pressed.
        </p>
        {!groups || groups.length === 0 ? (
          <p className="py-6 text-center text-xs text-gray-400">No customer carries an outstanding invoice with a due date today, so there is nothing to remind.</p>
        ) : (
          <div className="grid gap-3 lg:grid-cols-3">
            <Field label="Customer" required>
              <Pick value={customerId} onChange={e => pickCustomer(Number(e.target.value))}>
                <option value={0}>Select a customer…</option>
                {groups.map(g => (
                  <option key={g.customerId ?? g.name} value={g.customerId ?? ''}>
                    {g.name} — {pkr(g.amount)}{g.overdue ? ` · ${g.overdue} past due` : ''}
                  </option>
                ))}
              </Pick>
            </Field>
            <Field label="Send to (WhatsApp number)" required hint="Country code then digits. Point it at your own number to test.">
              <Text value={to} onChange={e => setTo(e.target.value)} placeholder="923223805981" />
            </Field>
            <Field label="Send from" hint={accounts.some(a => a.token && a.phoneId) ? undefined : 'No account has both a Phone Id and a token — save yours above first.'}>
              <Pick value={accountId} onChange={e => setAccountId(Number(e.target.value))}>
                <option value={0}>Any linked account</option>
                {accounts.map(a => (
                  <option key={a.id} value={a.id}>{a.whatsappId} · {a.token ? 'token saved' : 'no token'} · {a.graphVersion}</option>
                ))}
              </Pick>
            </Field>
          </div>
        )}

        {paper && (
          <>
            <div className="mt-4 overflow-x-auto">
              <table className="xenith-table">
                <thead>
                  <tr><th>#</th><th>Invoice</th><th>Date</th><th>Due</th><th>Status</th><th className="text-right">Balance</th><th className="text-right">Past due</th></tr>
                </thead>
                <tbody>
                  {paper.lines.map((l, i) => (
                    <tr key={l.number}>
                      <td>{i + 1}</td>
                      <td className="font-mono text-[11px] font-bold text-gray-700">{l.number}</td>
                      <td className="text-[11px] text-gray-500">{l.date}</td>
                      <td className="text-[11px] text-gray-500">{l.dueDate}</td>
                      <td className="text-[11px] text-gray-500">{l.status}</td>
                      <td className="text-right font-mono text-[11px]">{pkr(l.balance)}</td>
                      <td className="text-right font-mono text-[11px]">{l.pastDue > 0 ? `${l.pastDue} ${l.pastDue === 1 ? 'day' : 'days'}` : '—'}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={5} className="text-[11px] font-bold">Total outstanding</td>
                    <td className="text-right font-mono text-[11px] font-bold">{pkr(paper.total)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
            <div className="mt-3">
              <Field label="Message">
                <Area rows={12} value={text} onChange={e => setText(e.target.value)} className="font-mono text-[11px] leading-relaxed" />
              </Field>
            </div>
          </>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button type="button" onClick={sendNow} disabled={sending || !text.trim() || !to.trim()} className="btn-xenith-success disabled:opacity-50">
            <Send className="w-3.5 h-3.5" /> {sending ? 'Sending…' : 'SEND ON WHATSAPP'}
          </button>
          {verdict && (
            <p className={`mr-auto flex items-start gap-1.5 text-[11px] font-semibold max-w-xl ${
              rejected ? 'text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5' : 'text-[#25a195]'}`}>
              {rejected ? <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-px" /> : <BadgeCheck className="w-3.5 h-3.5 shrink-0 mt-px" />} {verdict}
            </p>
          )}
        </div>
      </Panel>

      <Panel title="WhatsApp Outbox" right={
        <button type="button" onClick={reloadOutbox} className="btn-xenith-outline"><RefreshCw className="w-3.5 h-3.5" /> REFRESH</button>
      }>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead><tr><th>When</th><th>To</th><th>Subject</th><th>From</th><th>Status</th><th>Meta</th></tr></thead>
            <tbody>
              {!outbox || outbox.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-6 text-gray-400">Nothing has been sent from this branch yet.</td></tr>
              ) : outbox.map(m => (
                <tr key={m.id}>
                  <td className="text-[11px] whitespace-nowrap text-gray-500">{m.date}</td>
                  <td className="font-mono text-[11px] font-bold text-gray-700">{m.to}</td>
                  <td className="text-[11px] text-gray-500">{m.subject}</td>
                  <td className="font-mono text-[11px] text-gray-500">{m.account}</td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${
                      m.status === 'Sent' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                      {m.status}
                    </span>
                  </td>
                  <td className="text-[11px] text-gray-500">
                    {m.status === 'Sent' ? <span className="font-mono">{m.reference}</span> : m.error}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      {open && (
        <Modal title="Link to WhatsApp" subtitle="Sign in with Facebook to pull the numbers Meta already issued for you."
          onClose={() => setOpen(false)}
          footer={
            <>
              <button type="button" onClick={login} disabled={!!editId} className="btn-xenith-primary disabled:opacity-40">LOGIN WITH FACEBOOK</button>
              <button type="button" onClick={submit} disabled={saving} className="btn-xenith-success disabled:opacity-50">{saving ? 'Saving…' : 'ADD'}</button>
              <button type="button" onClick={() => setOpen(false)} className="btn-xenith-warning">CLOSE</button>
            </>
          }>
          <Field label="WhatsApp Id" required>
            <Text value={draft.whatsappId || ''} onChange={e => setDraft({ ...draft, whatsappId: e.target.value })} placeholder="109876543210987654" />
          </Field>
          <Field label="PIN" required hint={editId ? undefined : 'Leave blank to let Meta generate one.'}>
            <Text value={draft.pin || ''} onChange={e => setDraft({ ...draft, pin: e.target.value.toUpperCase() })} />
          </Field>
          <Field label="Phone Id" required>
            <Text value={draft.phoneId || ''} onChange={e => setDraft({ ...draft, phoneId: e.target.value })} placeholder="1784658901234567" />
          </Field>
          <Field label="Token" required={!editId}
            hint={editId ? (hadToken ? 'Blank keeps the token on file. Type a new one only to replace it.' : 'No token is saved yet — paste the permanent token from Meta.') : undefined}>
            <Text value={draft.token || ''} type="password" onChange={e => setDraft({ ...draft, token: e.target.value })} placeholder={hadToken ? '•••••••• saved on the server' : 'EAAG…'} />
          </Field>
          {hint && <p className="text-[11px] font-semibold text-[#25a195]">{hint}</p>}
          {error && <p className="text-[11px] font-semibold text-red-600">{error}</p>}
        </Modal>
      )}
    </div>
  );
};

// ─── API keys ────────────────────────────────────────────────────────────────
const ApiKeysTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [search, setSearch] = useState('');
  const { value: keys, loading, reload } = useHub<ApiKey[]>(() => getApiKeys(tenantSlug, branchId, search), [tenantSlug, branchId, search]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState('');

  const create = async () => {
    setError('');
    setSaving(true);
    try {
      await createApiKey(tenantSlug, branchId, name);
      setOpen(false); setName('');
      reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (k: ApiKey) => {
    await updateApiKey(tenantSlug, branchId, k.id, { status: k.status === 'Active' ? 'Inactive' : 'Active' });
    reload();
  };

  const copy = async (k: ApiKey) => {
    try {
      await navigator.clipboard.writeText(k.key);
      setCopied(k.applicationName);
      window.setTimeout(() => setCopied(''), 1800);
    } catch {
      setCopied('');
    }
  };

  const remove = async (id: number) => {
    if (!window.confirm('Revoke this API key? Integrations using it will stop working.')) return;
    await deleteApiKey(tenantSlug, branchId, id);
    reload();
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="API Keys" right={
        <button type="button" onClick={() => { setError(''); setOpen(true); }} className="btn-xenith-success"><Plus className="w-3.5 h-3.5" /> CREATE API KEY</button>
      }>
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <Search size={14} className="text-gray-400" />
          <input className="input-xenith flex-1 min-w-32" placeholder="Search application or key…" value={search} onChange={e => setSearch(e.target.value)} />
          <button className="btn-xenith-outline" onClick={reload}><RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Refresh</button>
        </div>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead><tr><th>Application Name</th><th>Key</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {!keys?.length && (
                <tr>
                  <td colSpan={4} className="text-center py-6 text-gray-500">
                    {search ? `No API key answers to “${search}”.` : 'No API key has been issued for this company yet.'}
                  </td>
                </tr>
              )}
              {(keys || []).map(k => (
                <tr key={k.id}>
                  <td>
                    <span className="font-bold text-gray-800">{k.applicationName}</span>
                    <span className="block text-[10px] text-gray-400">Created {k.createdDate} · {k.lastUsed || 'never used'}</span>
                  </td>
                  <td className="font-mono text-[11px] text-gray-600 whitespace-nowrap">{k.key}</td>
                  <td>
                    <button type="button" onClick={() => toggle(k)} title="Toggle status"
                      className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${
                        k.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-gray-100 text-gray-500 border-gray-200'}`}>
                      {k.status}
                    </button>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="btn-xenith-outline !px-1.5 !py-1" title="Copy key" onClick={() => copy(k)}><Copy size={12} /></button>
                      <button className="btn-xenith-outline !px-1.5 !py-1" title="Generate a new key"
                        onClick={async () => { await updateApiKey(tenantSlug, branchId, k.id, { regenerate: true }); reload(); }}><RefreshCw size={12} /></button>
                      <button className="btn-xenith-danger !px-1.5 !py-1" title="Revoke" onClick={() => remove(k.id)}><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {copied && <p className="mt-2 text-[11px] font-bold text-[#25a195]">{copied} key copied to the clipboard</p>}
      </Panel>

      {open && (
        <Modal title="Api Key" subtitle="Enter application name you want to use with this api key."
          onClose={() => setOpen(false)}
          footer={
            <>
              <button type="button" onClick={create} disabled={saving || !name.trim()} className="btn-xenith-success disabled:opacity-50">
                <KeyRound className="w-3.5 h-3.5" /> GENERATE
              </button>
              <button type="button" onClick={() => setOpen(false)} className="btn-xenith-warning">CLOSE</button>
            </>
          }>
          <Field label="Application Name" required><Text value={name} onChange={e => setName(e.target.value)} placeholder="Courier Gateway" autoFocus /></Field>
          {error && <p className="text-[11px] font-semibold text-red-600">{error}</p>}
        </Modal>
      )}
    </div>
  );
};

// ─── Printing templates ──────────────────────────────────────────────────────
// The miniature on a template card is drawn from the design the template actually carries,
// so the list shows what the printer will do rather than only what the paper is called.
const PaperPreview: React.FC<{ paper: string; design?: TemplateDesign }> = ({ paper, design }) => {
  const box = paper.includes('Receipt') ? 'w-14 h-24'
    : paper.includes('Landscape') ? 'w-24 h-16'
      : paper.includes('A5') ? 'w-14 h-20' : 'w-16 h-24';
  const theme = themeOf(design?.theme);
  const accent = design?.accent || theme.accent;
  const dark = theme.header === 'block';
  const head = dark
    ? <div className="h-2 w-full rounded-sm" style={{ background: accent }} />
    : theme.header === 'centered'
      ? <div className="text-center"><div className="h-1 w-1/2 mx-auto rounded-full" style={{ background: accent }} /></div>
      : <div className="flex items-center gap-1"><div className="h-1 flex-1 rounded-full bg-gray-300" />
        <div className="h-1 w-2 rounded-full" style={{ background: accent }} /></div>;
  return (
    <div className={`${box} bg-white border border-gray-200 rounded-sm shadow-sm p-1.5 space-y-1`}>
      {head}
      <div className="h-px w-full" style={{ borderTop: `1px ${theme.header === 'hairline' || theme.header === 'plain' ? '' : 'solid'} ${theme.rule}` }} />
      <div className="h-px w-full bg-gray-100" />
      <div className="h-px w-3/4 bg-gray-100" />
      <div className="h-px w-full bg-gray-100" />
      <div className="h-1 w-1/2 ml-auto rounded-full" style={{ background: design?.footer === 'none' ? '#f3f4f6' : accent }} />
    </div>
  );
};

// What a template's design says in one line, for the card under its name.
const designLine = (d?: TemplateDesign) => {
  if (!d) return 'Inherits the design set on any print';
  const theme = PRINT_THEMES.find(t => t.key === d.theme)?.name || 'Modern Card';
  const head = LETTERHEAD_OPTIONS.find(o => o.value === d.letterhead)?.label || 'Full letterhead';
  const foot = FOOTER_OPTIONS.find(o => o.value === d.footer)?.label || 'Note + contact strip';
  return `${theme} · ${head} · ${foot}${d.landscape ? ' · landscape' : ''}`;
};

const PrintingTemplatesTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: data, loading, error: loadError, reload } = useHub(
    () => getPrintingTemplates(tenantSlug, branchId), [tenantSlug, branchId]
  );
  const [doc, setDoc] = useState('Sale Invoice');

  const templates = useMemo(() => (data?.templates || []).filter(t => t.document === doc), [data, doc]);
  if (loading || !data) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading templates…'}</p>;

  const activate = async (t: PrintTemplate) => { await activateTemplate(tenantSlug, branchId, t.id); reload(); };
  const clearActive = async () => { await deactivateTemplate(tenantSlug, branchId, doc); reload(); };
  const remove = async (t: PrintTemplate) => {
    if (!window.confirm(`Delete “${t.name}” for ${t.document}? A template the printer no longer offers cannot be brought back.`)) return;
    await deleteTemplate(tenantSlug, branchId, t.id);
    reload();
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <div className="flex flex-wrap gap-x-4 gap-y-1 border-b border-gray-200 px-1 pb-1 mb-4">
        {data.documents.map(d => (
          <button key={d} type="button" onClick={() => setDoc(d)}
            className={`pb-1.5 text-[11px] font-semibold border-b-2 -mb-px transition-colors ${
              doc === d ? 'border-[#2ec4b6] text-[#1ba396]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {d}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 mb-4">
        {templates.map(t => (
          <div key={t.id} className={`card-xenith p-3 flex gap-3 ${t.isActive ? 'ring-1 ring-[#2ec4b6]' : ''}`}>
            <PaperPreview paper={t.paper} design={t.design} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-black text-gray-800 truncate">{t.name}</span>
                {t.isActive && (
                  <span className="shrink-0 text-[9px] font-black uppercase tracking-wider text-[#1ba396]">Active</span>
                )}
              </div>
              <p className="text-[11px] text-gray-500 leading-snug mt-0.5">{t.description}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{t.paper} · {designLine(t.design)}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <button type="button" onClick={() => activate(t)} disabled={t.isActive} className="btn-xenith-primary !px-2 !py-1 text-[11px] disabled:opacity-40">
                  <CheckIcon className="w-3 h-3" /> {t.isActive ? 'IN USE' : 'SELECT'}
                </button>
                <button type="button" onClick={() => remove(t)} title={`Delete “${t.name}”`}
                  className="text-gray-400 hover:text-red-600 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {templates.length === 0 && <p className="text-xs text-gray-400 py-6">No template is available for {doc}.</p>}
      </div>

      <Panel title={`${doc} — print design`}>
        <p className="text-[11.5px] text-gray-500 leading-snug mb-3">
          This is what a {doc} prints in. Set the look here once and the PRINT button on that
          screen goes straight to the printer — nothing asks you for a template every time.
        </p>
        {templates.some(t => t.isActive) && (
          <div className="flex flex-wrap items-center gap-2 mb-3 text-[11px] text-gray-600">
            <span>
              {doc} is printing in <b className="font-bold">{templates.find(t => t.isActive)?.name}</b>.
            </span>
            <button type="button" onClick={clearActive}
              className="font-semibold text-[#1ba396] hover:underline">
              Stop using a template — print the design below instead
            </button>
          </div>
        )}
        <PrintDesignPanel document={doc} title={doc} onSaved={reload} />
      </Panel>
    </div>
  );
};

// ─── Customer loyalty program ────────────────────────────────────────────────
const LoyaltyTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: program, loading, error: loadError, reload } = useHub<LoyaltyProgram>(() => getLoyalty(tenantSlug, branchId), [tenantSlug, branchId]);
  const [draft, setDraft] = useState<LoyaltyProgram | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { if (program) setDraft(program); }, [program]);
  if (loading || !draft) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading loyalty program…'}</p>;

  const setTier = (i: number, changes: Partial<LoyaltyProgram['tiers'][number]>) =>
    setDraft({ ...draft, tiers: draft.tiers.map((t, j) => (j === i ? { ...t, ...changes } : t)) });

  const submit = async () => {
    setSaving(true); setError('');
    try { await saveLoyalty(tenantSlug, branchId, draft); reload(); setSaved(true); }
    catch (e) { setError((e as Error).message); }
    finally { setSaving(false); }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="Reward Rules">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-x-4 gap-y-3">
          <div className="sm:col-span-2 xl:col-span-4">
            <Check checked={draft.enabled} onChange={enabled => setDraft({ ...draft, enabled })} label="Enable the customer loyalty program" />
          </div>
          <Field label="Earn 1 point per (PKR)"><NumCell value={draft.pointsPerAmount} min={1} onChange={e => setDraft({ ...draft, pointsPerAmount: Number(e.target.value) })} /></Field>
          <Field label="Redeem points"><NumCell value={draft.redeemPoints} min={1} onChange={e => setDraft({ ...draft, redeemPoints: Number(e.target.value) })} /></Field>
          <Field label="Equals (PKR)"><NumCell value={draft.redeemValue} min={0} onChange={e => setDraft({ ...draft, redeemValue: Number(e.target.value) })} /></Field>
          <Field label="Points expire after (months)"><NumCell value={draft.expiryMonths} min={1} onChange={e => setDraft({ ...draft, expiryMonths: Number(e.target.value) })} /></Field>
        </div>
      </Panel>

      <Panel title="Tiers" right={
        <button type="button" className="btn-xenith-outline"
          onClick={() => setDraft({ ...draft, tiers: [...draft.tiers, { name: 'New Tier', minPoints: 0, discountPercent: 0 }] })}>
          <Plus className="w-3.5 h-3.5" /> Add tier
        </button>
      }>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead><tr><th>Tier</th><th className="text-right">Min Points</th><th className="text-right">Discount %</th><th></th></tr></thead>
            <tbody>
              {draft.tiers.map((t, i) => (
                <tr key={i}>
                  <td className="w-40"><Text value={t.name} onChange={e => setTier(i, { name: e.target.value })} /></td>
                  <td className="w-28"><NumCell value={t.minPoints} min={0} onChange={e => setTier(i, { minPoints: Number(e.target.value) })} /></td>
                  <td className="w-28"><NumCell value={t.discountPercent} min={0} max={100} onChange={e => setTier(i, { discountPercent: Number(e.target.value) })} /></td>
                  <td>
                    <button type="button" className="text-red-400 hover:text-red-600 disabled:opacity-30" disabled={draft.tiers.length <= 1}
                      onClick={() => setDraft({ ...draft, tiers: draft.tiers.filter((_, j) => j !== i) })}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <SaveBar onSave={submit} saving={saving} saved={saved} error={error} />
    </div>
  );
};

// ─── Activity log ────────────────────────────────────────────────────────────
const ActivityTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [search, setSearch] = useState('');
  const [user, setUser] = useState('');
  const { value, loading, reload } = useHub(
    () => getActivityLog(tenantSlug, branchId, search, user), [tenantSlug, branchId, search, user]
  );
  const rows: ActivityEntry[] = value?.data || [];

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="Activity Log" right={
        <button className="btn-xenith-outline" onClick={reload}><RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Refresh</button>
      }>
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <Search size={14} className="text-gray-400" />
          <input className="input-xenith flex-1 min-w-32" placeholder="Search action, screen or record…" value={search} onChange={e => setSearch(e.target.value)} />
          <Pick className="w-auto min-w-0" value={user} onChange={e => setUser(e.target.value)}>
            <option value="">All users</option>
            {(value?.users || []).map(u => <option key={u} value={u}>{u}</option>)}
          </Pick>
        </div>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead><tr><th>Date &amp; Time</th><th>User</th><th>Action</th><th>Screen</th><th>Record</th><th>IP Address</th></tr></thead>
            <tbody>
              {rows.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-gray-400">No activity recorded yet</td></tr>}
              {rows.map(e => (
                <tr key={e.id}>
                  <td className="whitespace-nowrap text-gray-600">{e.date}</td>
                  <td className="font-bold text-gray-800">{e.user}</td>
                  <td><span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100 text-[10px] font-bold whitespace-nowrap">{e.action}</span></td>
                  <td className="text-gray-600">{e.screen}</td>
                  <td className="font-mono text-[11px] text-gray-500">{e.record}</td>
                  <td className="font-mono text-[11px] text-gray-400">{e.ipAddress}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
};

// ─── Sample trading history ──────────────────────────────────────────────────
// The registers the teaching book writes into, named the way the menus name them.
const SAMPLE_LABELS: Record<string, string> = {
  mockCategories: 'Categories', mockProducts: 'Products', mockCustomers: 'Customers',
  mockVendors: 'Vendors', mockSalesPersons: 'Sales persons', mockEmployees: 'Employees',
  mockPosCounters: 'POS counters', mockLedgerAccounts: 'Chart of accounts',
  mockBankAccounts: 'Bank accounts', mockAdjustmentTypes: 'Adjustment types',
  mockPosBills: 'POS bills', mockJournalEntries: 'Journal entries', mockPettyCash: 'Petty cash',
  'doc:goodReceivings': 'Good receivings', 'doc:purchaseBills': 'Purchase bills',
  'doc:importInvoices': 'Import invoices', 'doc:saleInvoices': 'Sale invoices',
  'doc:saleReturns': 'Sale returns', 'doc:saleDeliveries': 'Sale deliveries',
  'doc:receivePayments': 'Customer receipts', 'doc:vendorPayments': 'Vendor payments',
  'doc:cashVouchers': 'Cash payment vouchers', 'doc:cashReceiptVouchers': 'Cash receipt vouchers',
  'doc:bankVouchers': 'Bank payment vouchers', 'doc:bankReceiptVouchers': 'Bank receipt vouchers',
  'doc:stockAdjustments': 'Stock adjustments', 'doc:stockAudits': 'Stock audits',
  'doc:stockMovements': 'Stock movements'
};
// A register this build learns about later still names itself on the card: the key read as
// English beats a row silently missing from the list.
const sampleLabel = (key: string) => SAMPLE_LABELS[key]
  ?? key.replace(/^doc:/, '').replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase());

const SampleDataTab: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { value: book, loading, error: loadError, reload, setValue } = useHub<SampleBookState>(
    () => getSampleBook(tenantSlug, branchId), [tenantSlug, branchId]
  );
  const [busy, setBusy] = useState('');
  const [done, setDone] = useState('');
  const [error, setError] = useState('');
  const [confirming, setConfirming] = useState(false);

  if (loading || !book) return <p className="py-10 text-center text-xs text-gray-400">{loadError || 'Loading the sample book…'}</p>;

  const filled = book.total > 0;
  const rows = Object.entries(book.counts).sort((a, b) => sampleLabel(a[0]).localeCompare(sampleLabel(b[0])));

  // Either press answers with its own tally, but the card re-reads the book rather than
  // repeating it: what the screen says is what the registers actually hold.
  const run = async (what: 'load' | 'clear') => {
    setBusy(what); setError(''); setDone('');
    try {
      const res = what === 'load' ? await loadSampleBook(tenantSlug, branchId) : await clearSampleBook(tenantSlug, branchId);
      const state = await getSampleBook(tenantSlug, branchId);
      setValue(state);
      setDone(what === 'load'
        ? `Loaded: ${state.total} row(s) across ${Object.keys(state.counts).length} register(s).`
        : 'Every sample row has been taken back out. Your own records were not touched.');
      if (res.failed?.length) setError(`${res.failed.length} row(s) did not move: ${res.failed.slice(0, 3).join(' | ')}`);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy('');
      setConfirming(false);
    }
  };

  return (
    <div className="animate-[fadeUp_.25s_ease-out_backwards]">
      <Panel title="Sample trading history" right={
        <button type="button" className="btn-xenith-outline" onClick={reload}><RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Refresh</button>
      }>
        <p className="text-[12px] text-gray-600 leading-relaxed max-w-3xl">
          A short, complete trading history that touches every module this software offers — goods
          received onto a purchase bill and paid to the vendor, invoices sold and collected, counter
          bills, returns, cash and bank vouchers, a journal entry, petty cash, a stock adjustment and
          a stock audit. Every paper was raised by the normal saving routes, so the ledgers, stock
          cards and reports agree with it. A brand-new installation fills itself once; this card is
          for loading it again after clearing, and for taking it out when the client starts their own
          books.
        </p>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${filled ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>
            {filled ? `On the book: ${book.total} sample row(s)` : 'Nothing sample on this book'}
          </span>
          {book.loadedAt && (
            <span className="text-[11px] text-gray-500">Loaded {new Date(book.loadedAt).toLocaleString()}</span>
          )}
          {!filled && book.fresh && (
            <span className="text-[11px] text-gray-500">This book has never held a record of its own.</span>
          )}
        </div>

        {(error || done) && (
          <p className={`mt-3 flex items-start gap-1.5 text-[11px] font-semibold rounded px-2 py-1.5 max-w-3xl ${
            error ? 'text-red-700 bg-red-50 border border-red-100' : 'text-[#1b7f76] bg-[#e8f7f5] border border-[#b8e3de]'}`}>
            {error ? <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-px" /> : <CheckIcon className="w-3.5 h-3.5 shrink-0 mt-px" />}
            {error || done}
          </p>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          <button type="button" className="btn-xenith-success disabled:opacity-50" disabled={filled || busy !== ''} onClick={() => run('load')}>
            <Stamp className="w-3.5 h-3.5" /> {busy === 'load' ? 'Raising the sample papers…' : 'Load sample data'}
          </button>
          <button type="button" className="btn-xenith-warning disabled:opacity-50" disabled={!filled || busy !== ''} onClick={() => setConfirming(true)}>
            <Trash2 className="w-3.5 h-3.5" /> {busy === 'clear' ? 'Taking the sample back out…' : 'Clear all sample data'}
          </button>
        </div>

        {book.skipped.length > 0 && (
          <p className="mt-3 text-[11px] text-gray-500 max-w-3xl">
            Not every module is on this subscription, so {book.skipped.length} paper(s) were left for
            the owner to raise: {book.skipped.slice(0, 4).join('; ')}{book.skipped.length > 4 ? '…' : ''}
          </p>
        )}
      </Panel>

      {filled && (
        <Panel title="What the sample put on the book">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-6 gap-y-1">
            {rows.map(([key, count]) => (
              <div key={key} className="flex items-center justify-between gap-3 border-b border-gray-100 py-1.5">
                <span className="text-[12px] text-gray-700">{sampleLabel(key)}</span>
                <span className="text-[12px] font-bold text-gray-900">{count}</span>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {confirming && (
        <Modal
          title="Clear the sample history?"
          subtitle="Only the rows this card loaded are taken back out."
          onClose={() => setConfirming(false)}
          footer={
            <>
              <button type="button" className="btn-xenith-outline" onClick={() => setConfirming(false)}>Keep it</button>
              <button type="button" className="btn-xenith-warning" disabled={busy !== ''} onClick={() => run('clear')}>
                <Trash2 className="w-3.5 h-3.5" /> Clear all sample data
              </button>
            </>
          }
        >
          <p className="text-[12px] text-gray-600 leading-relaxed">
            {book.total} row(s) go: bills, invoices, vouchers, payments, goods, parties and the
            accounts the sample raised, each deleted the way a clerk deletes it — so anything a real
            record of yours has come to depend on will refuse to go rather than break. Your own
            records are not part of this list and are not touched.
          </p>
        </Modal>
      )}
    </div>
  );
};

// ─── Shell ───────────────────────────────────────────────────────────────────
export const CompanySettings: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { tenantName } = useTenant();
  const [tab, setTab] = useState('Information');

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2 min-w-0">
          <Building2 className="w-4 h-4 text-[#2ec4b6] shrink-0" />
          <span className="truncate">Company Settings — {tenantName}</span>
        </span>
        <button type="button" onClick={onBack} className="btn-xenith-warning">
          <ArrowLeft className="w-3.5 h-3.5" /> Back
        </button>
      </div>

      <TabStrip tabs={TABS} active={tab} onChange={setTab} />

      <div className="nb-card-body">
        {tab === 'Information' && <InformationTab />}
        {tab === 'Settings' && <SettingsTab />}
        {tab === 'Sales Person' && <SalesPersonTab />}
        {tab === 'SMTP' && <SmtpTab />}
        {tab === 'WhatsApp Setting' && <WhatsAppTab />}
        {tab === 'API Keys' && <ApiKeysTab />}
        {tab === 'Printing Templates' && <PrintingTemplatesTab />}
        {tab === 'Customer Loyalty Program' && <LoyaltyTab />}
        {tab === 'Activity Log' && <ActivityTab />}
        {tab === 'Sample Data' && <SampleDataTab />}
      </div>

      <div className="px-4 py-2 border-t border-gray-100 text-[11px] text-gray-400 flex flex-wrap items-center gap-x-4 gap-y-1">
        <span className="flex items-center gap-1"><BadgeCheck className="w-3.5 h-3.5 text-[#2ec4b6]" /> Settings apply to every branch of this company</span>
        <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> Sales Person drives the columns on document forms</span>
        <span className="flex items-center gap-1"><Stamp className="w-3.5 h-3.5" /> Printing templates decide what your documents look like</span>
        <span className="flex items-center gap-1"><Trophy className="w-3.5 h-3.5" /> Loyalty points appear on the customer ledger</span>
      </div>
    </div>
  );
};

export default CompanySettings;
