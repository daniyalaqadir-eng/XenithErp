import React, { useMemo, useState } from 'react';
import { Building2, RefreshCw, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import {
  deleteBranch, getBranchSettings, getUsers, saveBranch, updateBranch, updateBranchSettings,
  BranchSettings
} from '../../services/access.service';
import { Branch } from '../../types';
import { Check, DeleteConfirm, ExportPair, Field, ListToolbar, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, TableEmpty, Text, IconAction } from '../Masters/masterUi';
import { useHub } from './useHub';
import { ExportColumn } from '../../utils/exportTable';

type Draft = Partial<Branch> & { name: string; code: string };

const blankBranch = (): Draft => ({
  name: '', code: '', city: '', address: '', phone: '', email: '', taxNumber: '', managerName: '', isActive: true, isMain: false
});

const FLAGS: { key: keyof BranchSettings; label: string; hint: string }[] = [
  { key: 'crossBranchStock', label: 'Allow stock transfer between branches', hint: 'Stock moves and adjustments can pick a source and a destination branch.' },
  { key: 'separateNumberSeries', label: 'Separate document number series per branch', hint: 'Each branch numbers its own invoices, e.g. BR-02/INV/0012.' },
  { key: 'showBranchOnDocuments', label: 'Print the branch on documents', hint: 'The issuing branch appears in the header of invoices and reports.' }
];

export const BranchesPage: React.FC = () => {
  const { tenantSlug, branchId, allBranches, enableBranch, refreshBranches, setBranchEnabled } = useTenant();
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const users = useHub(() => getUsers(tenantSlug, branchId), [tenantSlug, branchId]);
  const settings = useHub(() => getBranchSettings(tenantSlug, branchId), [tenantSlug, branchId]);
  const [flags, setFlags] = useState<BranchSettings | null>(null);
  const current = flags ?? settings.value?.settings ?? null;

  const rows = useMemo(() => {
    const list = allBranches.filter(b => !search.trim() || `${b.name} ${b.code} ${b.city ?? ''}`.toLowerCase().includes(search.trim().toLowerCase()));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [allBranches, search, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const closed = rows.filter(b => b.isActive === false).length;

  const stats: RegisterStat[] = [
    {
      label: 'On register',
      value: search ? `${rows.length} of ${allBranches.length}` : String(allBranches.length),
      title: search ? `${allBranches.length} branches on the register, the search leaves ${rows.length} on screen` : 'Branches on the register'
    },
    ...(closed ? [{
      label: 'Closed', value: closed, tone: 'warn' as const,
      title: `${closed} of the branches on screen are marked Closed`
    }] : [])
  ];

  const activeFilters = [search && `search “${search}”`].filter(Boolean) as string[];

  const clearAll = () => {
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const staffCount = (id: number) => (users.value?.data ?? []).filter(u => u.branchIds.includes(id)).length;

  const columns: ExportColumn<Branch>[] = [
    { label: 'Code', value: b => b.code },
    { label: 'Branch Name', value: b => b.name },
    { label: 'City', value: b => b.city || '-' },
    { label: 'Address', value: b => b.address || '-' },
    { label: 'Manager', value: b => b.managerName || '-' },
    { label: 'Phone', value: b => b.phone || '-' },
    { label: 'Users', value: b => staffCount(b.id), align: 'right' },
    { label: 'Status', value: b => b.isActive !== false ? 'Active' : 'Closed' }
  ];

  const proposeCode = () => {
    const next = allBranches.reduce((max, b) => Math.max(max, Number(String(b.code).replace(/\D/g, '')) || 0), 0) + 1;
    setDraft(d => (d ? { ...d, code: `BR-${String(next).padStart(2, '0')}` } : d));
  };

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError(''); setNotice('');
    try {
      if (draft.id) {
        await updateBranch(tenantSlug, branchId, draft.id, draft);
        if (draft.isMain) setNotice(`${draft.name} is now the main branch.`);
      } else {
        await saveBranch(tenantSlug, branchId, draft);
        setNotice(`${draft.name} has been added.`);
      }
      refreshBranches();
      users.reload();
      setDraft(null);
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const saveFlags = async (next: BranchSettings) => {
    setFlags(next);
    setError(''); setNotice('');
    try {
      await updateBranchSettings(tenantSlug, branchId, next);
      setBranchEnabled(next.enabled);
      settings.reload();
      setNotice('Branch settings saved.');
    } catch (e) { setError((e as Error).message); }
  };

  const remove = async (b: Branch) => {
    setError(''); setNotice('');
    try {
      await deleteBranch(tenantSlug, branchId, b.id);
      refreshBranches();
      users.reload();
      setNotice(`${b.name} has been deleted.`);
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><Building2 className="w-4 h-4" /> Branches</span>
        <StatStrip stats={stats} />
      </div>
      <div className="nb-card-body">
        {current && (
          <div className="nb-note">
            <label className="flex items-start gap-2 cursor-pointer">
              <input type="checkbox" className="mt-0.5 accent-[#2ec4b6]" checked={current.enabled}
                onChange={e => saveFlags({ ...current, enabled: e.target.checked })} />
              <span>
                <span className="block text-xs font-bold text-gray-700">Use multiple branches in this company</span>
                <span className="block text-[11px] text-gray-500">
                  Turns the branch switcher on in the header, and makes branch access on every user account mean something.
                </span>
              </span>
            </label>
            {current.enabled && (
              <div className="mt-3 pl-6 space-y-1.5">
                {FLAGS.map(f => (
                  <div key={f.key}>
                    <Check checked={current[f.key]} onChange={v => saveFlags({ ...current, [f.key]: v })} label={f.label} />
                    <p className="pl-5 text-[10px] text-gray-400">{f.hint}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(error || notice) && (
          <div className={`mb-3 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
            error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
            <span>{error || notice}</span>
            <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 mb-3">
          <ListToolbar addLabel="ADD BRANCH" onAdd={() => { setDraft(blankBranch()); setError(''); setNotice(''); }}>
            <ExportPair title="Branches" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="branches" columns={columns} rows={rows} landscape />
            <SearchBox key={searchEpoch} className="ml-auto w-56 max-w-full" placeholder={"Search branches..."} onSearch={setSearch} />
          </ListToolbar>
        </div>

        {draft && (
          <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded">
            <div className="flex items-center justify-between mb-3">
              <h3 className="card-title">
                {draft.id ? `Edit Branch - [${draft.name || 'untitled'}]` : 'Create Branch'}
              </h3>
              {!enableBranch && (
                <span className="text-[11px] font-semibold text-amber-600">
                  Multiple branches are currently switched off.
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <Field label="Branch Name" required>
                <Text value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Karachi Clifton Branch" />
              </Field>
              <Field label="Branch Code" required>
                <div className="flex items-center gap-1">
                  <Text value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value.toUpperCase() })} placeholder="BR-04" />
                  <button type="button" onClick={proposeCode} title="Propose the next code"
                    className="h-[30px] w-8 shrink-0 rounded border border-teal-200 bg-teal-50 text-[#25a195] hover:bg-teal-100 flex items-center justify-center">
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Field>
              <Field label="City">
                <Text value={draft.city || ''} onChange={e => setDraft({ ...draft, city: e.target.value })} />
              </Field>
              <Field label="Address" className="lg:col-span-2">
                <Text value={draft.address || ''} onChange={e => setDraft({ ...draft, address: e.target.value })} />
              </Field>
              <Field label="Branch Manager">
                <Text value={draft.managerName || ''} onChange={e => setDraft({ ...draft, managerName: e.target.value })} />
              </Field>
              <Field label="Phone">
                <Text value={draft.phone || ''} onChange={e => setDraft({ ...draft, phone: e.target.value })} />
              </Field>
              <Field label="Email">
                <Text type="email" value={draft.email || ''} onChange={e => setDraft({ ...draft, email: e.target.value })} />
              </Field>
              <Field label="Tax Number">
                <Text value={draft.taxNumber || ''} onChange={e => setDraft({ ...draft, taxNumber: e.target.value })} />
              </Field>
              <Field label="Latitude">
                <Text type="number" step="any" value={draft.latitude ?? ''} onChange={e => setDraft({ ...draft, latitude: e.target.value === '' ? undefined : Number(e.target.value) })} />
              </Field>
              <Field label="Longitude">
                <Text type="number" step="any" value={draft.longitude ?? ''} onChange={e => setDraft({ ...draft, longitude: e.target.value === '' ? undefined : Number(e.target.value) })} />
              </Field>
              <div className="flex items-end gap-4 pb-1.5">
                <Check checked={!!draft.isActive} onChange={v => setDraft({ ...draft, isActive: v })} label="Active" />
                {/* A new branch always starts as a working branch; the main title is handed
                    over from a branch that already exists, so the box waits for an id. */}
                {!!draft.id && (
                  <Check checked={!!draft.isMain} onChange={v => setDraft({ ...draft, isMain: v })}
                    disabled={!!draft.isMain} label="Make main branch" />
                )}
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 mt-3">
              <p className="text-[11px] text-gray-400">
                {draft.isMain
                  ? 'The main branch holds the company settings and cannot be deleted.'
                  : 'New branches start with no stock; move opening stock from Item Master.'}
              </p>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning"><X className="w-3.5 h-3.5" /> Close</button>
                <button type="button" onClick={submit} disabled={saving || !draft.name.trim() || !draft.code.trim()}
                  className="btn-xenith-success disabled:opacity-50">
                  {saving ? 'Saving...' : 'SAVE'}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Branch Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="City" sortKey="city" sort={sort} onSort={onSort} />
                <th>Address</th>
                <SortHeader label="Manager" sortKey="managerName" sort={sort} onSort={onSort} />
                <SortHeader label="Phone" sortKey="phone" sort={sort} onSort={onSort} />
                <th>Users</th>
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <TableEmpty colSpan={9} noun="branches" filters={activeFilters} cleared={clearAll}
                  addLabel={allBranches.length ? undefined : 'ADD BRANCH'}
                  onAdd={() => { setDraft(blankBranch()); setError(''); setNotice(''); }} />
              )}
              {rows.map(b => (
                <tr key={b.id}>
                  <td className="font-medium">{b.code}</td>
                  <td>
                    <span className="flex items-center gap-2">
                      <span className="font-medium">{b.name}</span>
                      {b.isMain && <span className="text-[10px] font-bold uppercase text-[#1e88e5] bg-blue-50 px-1.5 py-0.5 rounded">Main</span>}
                    </span>
                  </td>
                  <td>{b.city || <span className="text-gray-300">-</span>}</td>
                  <td className="text-gray-500">{b.address || <span className="text-gray-300">-</span>}</td>
                  <td>{b.managerName || <span className="text-gray-300">-</span>}</td>
                  <td>{b.phone || <span className="text-gray-300">-</span>}</td>
                  <td>{staffCount(b.id)}</td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${b.isActive !== false ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {b.isActive !== false ? 'Active' : 'Closed'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <IconAction title="Edit branch" tone="primary" onClick={() => { setDraft({ ...b }); setError(''); setNotice(''); }}><Pencil className="w-4 h-4" /></IconAction>
                      {b.isMain ? (
                        <IconAction title="The main branch cannot be deleted" disabled><Trash2 className="w-4 h-4" /></IconAction>
                      ) : confirmId === b.id ? (
                        <DeleteConfirm onConfirm={() => remove(b)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${b.name}`} />
                      ) : (
                        <IconAction title="Delete branch" tone="danger" onClick={() => setConfirmId(b.id)}><Trash2 className="w-4 h-4" /></IconAction>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BranchesPage;
