import { useCallback, useEffect, useState } from 'react';

// One fetch hook for the settings screens: it keeps the value, the error text and a reload handle.
export function useHub<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [value, setValue] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const reload = useCallback(() => {
    setLoading(true);
    fn().then(v => setValue(v)).catch(e => setError((e as Error).message)).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => { reload(); }, [reload]);

  return { value, error, loading, reload, setValue };
}
