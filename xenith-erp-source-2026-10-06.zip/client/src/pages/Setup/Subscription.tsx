import React, { useEffect, useMemo, useState } from 'react';
import { CreditCard, Save, ShieldCheck, Building2, X, ChevronDown, ChevronRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { getLicense, saveLicense, LicenseInfo, CompanyLicense } from '../../services/access.service';
import { Check, Field, Pick, Text } from '../Masters/masterUi';
import { useHub } from './useHub';

// What a trading firm, a shop and a factory typically buy. The owner picks one and
// then fine-tunes, instead of ticking thirteen boxes from an empty page.
const PRESETS: { label: string; modules: string[] }[] = [
  { label: 'Trading', modules: ['dashboard', 'reports', 'crm', 'sales', 'purchase', 'classification', 'banking', 'weekly-route', 'setup'] },
  { label: 'Trading + POS', modules: ['dashboard', 'reports', 'crm', 'sales', 'purchase', 'pos', 'classification', 'banking', 'setup'] },
  { label: 'Manufacturing', modules: ['dashboard', 'reports', 'crm', 'purchase', 'inventory', 'manufacturing', 'classification', 'banking', 'setup'] },
  { label: 'Full suite', modules: [] }
];

export const SubscriptionPage: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const { setLicensedScreens } = useAuth();
  const hub = useHub<LicenseInfo | null>(() => getLicense(tenantSlug, branchId), [tenantSlug, branchId]);
  const [target, setTarget] = useState(tenantSlug);
  const [modules, setModules] = useState<string[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [plan, setPlan] = useState('');
  const [seats, setSeats] = useState(5);
  const [renewsOn, setRenewsOn] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const info = hub.value;
  const alwaysOn = info?.alwaysOnScreens ?? [];
  const company = useMemo(
    () => info?.companies.find(c => c.slug === target),
    [info, target]
  );

  // Every feature of the modules on the sale — what a plain module sale has always meant.
  const wholeSale = (mods: string[]) => (info?.modules ?? [])
    .filter(m => mods.includes(m.key)).flatMap(m => m.screens.map(s => s.key));
  // A saved sale either names its features or names none, and the second means the first.
  const featuresOf = (lic: CompanyLicense) =>
    lic.screens?.length ? lic.screens : wholeSale(lic.modules);
  const sameSet = (a: string[], b: string[]) =>
    a.length === b.length && a.every(k => b.includes(k));

  // Loading a company's allocation, or switching to another one, refills the form.
  useEffect(() => {
    if (!company || !info) return;
    setModules([...company.license.modules]);
    setFeatures(featuresOf(company.license));
    setPlan(company.license.plan);
    setSeats(company.license.seats);
    setRenewsOn(company.license.renewsOn);
    setError(''); setNotice('');
  }, [company, info]);

  // A module and the features inside it are one decision: switching the module off retires
  // its whole row of ticks, switching it back hands every one of them over again.
  const toggleModule = (key: string) => {
    const m = info?.modules.find(x => x.key === key);
    if (!m) return;
    const keys = m.screens.map(s => s.key);
    if (modules.includes(key)) {
      setModules(list => list.filter(k => k !== key));
      setFeatures(list => list.filter(s => !keys.includes(s)));
    } else {
      setModules(list => [...list, key]);
      setFeatures(list => [...new Set([...list, ...keys])]);
    }
  };
  const toggleFeature = (key: string) => {
    // These two are the buyer's own door into the product; the server refuses without them too.
    if (alwaysOn.includes(key)) return;
    setFeatures(list => list.includes(key) ? list.filter(s => s !== key) : [...list, key]);
  };
  const setModuleFeatures = (moduleKey: string, on: boolean) => {
    const m = info?.modules.find(x => x.key === moduleKey);
    if (!m) return;
    const keys = m.screens.map(s => s.key);
    setFeatures(list => on
      ? [...new Set([...list, ...keys])]
      : list.filter(s => !keys.includes(s) || alwaysOn.includes(s)));
  };

  const dirty = !!company && (
    company.license.plan !== plan || company.license.seats !== seats ||
    company.license.renewsOn !== renewsOn ||
    !sameSet(modules, company.license.modules) ||
    !sameSet(features, featuresOf(company.license))
  );

  const submit = async () => {
    setSaving(true); setError(''); setNotice('');
    try {
      const res = await saveLicense(tenantSlug, branchId, { slug: target, modules, plan, seats, screens: features });
      // Editing this company's own sale takes effect on the menu straight away.
      setLicensedScreens(res.licensedScreens);
      setNotice('Allocation saved. Users of that company see the change the next time they open the menu.');
      hub.reload();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  if (!info) {
    return (
      <div className="nb-card">
        <div className="nb-card-header page-head"><span className="flex items-center gap-2"><CreditCard className="w-4 h-4" /> Subscription &amp; Modules</span></div>
        <div className="nb-card-body text-center text-gray-400 py-8 text-xs">Loading...</div>
      </div>
    );
  }

  const grouped = info.modules.reduce<Record<string, typeof info.modules>>((acc, m) => {
    (acc[m.bucket] ||= []).push(m);
    return acc;
  }, {});
  // What a company was sold is the vendor's act, so the buyer's own screen shows the plan he
  // stands inside rather than a form that would only answer 403.
  const editable = info.canSetSale !== false;
  const sold = modules.length;
  const offered = wholeSale(modules);
  const chosen = offered.filter(k => features.includes(k));
  const applyModules = (mods: string[]) => { setModules(mods); setFeatures(wholeSale(mods)); };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><CreditCard className="w-4 h-4" /> Subscription &amp; Modules</span>
        <span className="text-xs font-normal text-gray-500">
          {sold} of {info.totalModules} modules &middot; {chosen.length} of {offered.length} features switched on
        </span>
      </div>
      <div className="nb-card-body">
        <p className="text-xs text-gray-500 mb-3 max-w-3xl">
          This is where a sale is handed over. Whatever is switched on here is the whole product for that
          company &mdash; anything else disappears from their menus, their role matrix and their API.
          A module may also be sold one feature at a time: open it and tick the screens inside.
        </p>

        {!editable && (
          <div className="mb-3 text-xs font-semibold text-gray-700 bg-gray-50 border border-gray-200 rounded px-3 py-2">
            This is the plan your firm was sold. Modules are added, taken back and priced by your
            vendor, so the switches below show your sale and saving them is refused.
          </div>
        )}
        {error && (
          <div className="mb-3 text-xs font-semibold text-red-600 bg-red-50 border border-red-100 rounded px-3 py-2 flex items-center justify-between">
            <span>{error}</span>
            <button type="button" onClick={() => setError('')}><X className="w-3.5 h-3.5" /></button>
          </div>
        )}
        {notice && (
          <div className="mb-3 text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-100 rounded px-3 py-2">{notice}</div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mb-4">
          <div className="lg:col-span-1 p-3 bg-gray-50 border border-gray-200 rounded space-y-3">
            <div className="text-[11px] font-bold uppercase tracking-wide text-gray-500 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5" /> Sold to
            </div>
            <Field label="Company">
              <Pick value={target} onChange={e => setTarget(e.target.value)}>
                {info.companies.map(c => <option key={c.slug} value={c.slug}>{c.name}</option>)}
              </Pick>
            </Field>
            <Field label="Billing plan">
              <Pick value={plan} disabled={!editable} onChange={e => setPlan(e.target.value)}>
                {info.plan.map(p => <option key={p} value={p}>{p}</option>)}
              </Pick>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="User seats" hint="logins allowed">
                <Text type="number" value={String(seats)} disabled={!editable} onChange={e => setSeats(Number(e.target.value) || 0)} />
              </Field>
              <Field label="Renews on">
                <Text type="date" value={renewsOn} disabled={!editable} onChange={e => setRenewsOn(e.target.value)} />
              </Field>
            </div>
            <div className="flex items-center gap-2 text-[11px]">
              <span className={`font-bold uppercase px-2 py-0.5 rounded ${company?.license.status === 'Trial' ? 'bg-amber-50 text-amber-600' : 'bg-teal-50 text-[#25a195]'}`}>
                {company?.license.status || 'Active'}
              </span>
              <span className="text-gray-500">{info.companies.length} companies under this login</span>
            </div>
            <div className="pt-1 border-t border-gray-200">
              <div className="text-[11px] font-bold uppercase tracking-wide text-gray-500 mb-1.5">Quick packages</div>
              <div className="flex flex-wrap gap-1.5">
                {PRESETS.map(p => (
                  <button key={p.label} type="button" disabled={!editable}
                    onClick={() => applyModules(p.modules.length ? p.modules : info.modules.map(m => m.key))}
                    className={`text-[11px] font-semibold px-2 py-1 rounded border border-gray-200 bg-white text-gray-600 hover:border-[#1e88e5] hover:text-[#1e88e5] ${editable ? '' : 'opacity-40'}`}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <div className="text-[11px] font-bold uppercase tracking-wide text-gray-500">Modules included in the sale</div>
              <div className="text-[11px] text-gray-500">{chosen.length} of {offered.length} features their roles can be given</div>
            </div>
            <div className="space-y-2 max-h-[52vh] overflow-y-auto app-scroll pr-1">
              {Object.entries(grouped).map(([bucket, list]) => (
                <div key={bucket} className="bg-white border border-gray-200 rounded overflow-hidden">
                  <div className="px-3 py-1.5 bg-gray-100 text-[11px] font-bold uppercase tracking-wide text-gray-500">{bucket}</div>
                  <ul className="divide-y divide-gray-100">
                    {list.map(m => {
                      const on = modules.includes(m.key);
                      // Switching either of these off would hide the very screen in use.
                      const required = m.key === 'dashboard' || m.key === 'setup';
                      const keys = m.screens.map(s => s.key);
                      const ticked = keys.filter(k => features.includes(k)).length;
                      const partial = on && ticked < keys.length;
                      const expanded = !!open[m.key];
                      return (
                        <li key={m.key} className="px-3 py-2">
                          <div className="flex items-start gap-3">
                            <span className="pt-0.5">
                              <input type="checkbox" className="accent-[#1e88e5]" checked={on}
                                disabled={required || !editable}
                                title={required ? 'Needed to keep the company able to sign in' : undefined}
                                onChange={() => toggleModule(m.key)} />
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className={`text-xs font-semibold ${on ? 'text-gray-800' : 'text-gray-400'}`}>{m.label}</div>
                              {(!on || !expanded) && (
                                <div className="text-[10px] text-gray-400">{keys.map(k => m.screens.find(s => s.key === k)?.label).join(' · ')}</div>
                              )}
                            </div>
                            {on ? (
                              <button type="button" onClick={() => setOpen(o => ({ ...o, [m.key]: !o[m.key] }))}
                                title={expanded ? 'Hide the features of this module' : 'Tick the features of this module one by one'}
                                className={`text-[10px] font-bold whitespace-nowrap flex items-center gap-1 px-1.5 py-0.5 rounded border ${
                                  partial ? 'text-amber-700 border-amber-300 bg-amber-50' : 'text-[#25a195] border-teal-200 bg-teal-50'}`}>
                                {ticked} of {keys.length} feature{keys.length === 1 ? '' : 's'}
                                {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                              </button>
                            ) : (
                              <span className="text-[10px] font-bold whitespace-nowrap text-gray-300">
                                {keys.length} feature{keys.length === 1 ? '' : 's'}
                              </span>
                            )}
                          </div>
                          {on && expanded && (
                            <div className="mt-2 ml-6 border border-gray-200 rounded bg-gray-50 p-2">
                              <div className="flex items-center justify-between mb-1.5">
                                <span className="text-[10px] font-bold uppercase tracking-wide text-gray-500">
                                  Features inside {m.label}
                                </span>
                                <span className="flex items-center gap-2">
                                  <button type="button" disabled={!editable} onClick={() => setModuleFeatures(m.key, true)}
                                    className="text-[10px] font-semibold text-[#1e88e5] hover:underline disabled:text-gray-300 disabled:no-underline">All</button>
                                  <button type="button" disabled={!editable} onClick={() => setModuleFeatures(m.key, false)}
                                    className="text-[10px] font-semibold text-gray-500 hover:underline disabled:text-gray-300 disabled:no-underline">None</button>
                                </span>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                                {m.screens.map(s => {
                                  const locked = alwaysOn.includes(s.key);
                                  const picked = features.includes(s.key);
                                  return (
                                    <label key={s.key}
                                      className={`flex items-center gap-2 text-[11px] px-2 py-1 rounded border bg-white ${
                                        locked ? 'border-gray-200' : 'border-transparent'}`}>
                                      <input type="checkbox" className="accent-[#1e88e5]" checked={picked}
                                        disabled={locked || !editable}
                                        title={locked ? 'Kept on so this company can always sign in and be sold the rest back' : undefined}
                                        onChange={() => toggleFeature(s.key)} />
                                      <span className={picked ? 'text-gray-800' : 'text-gray-400'}>{s.label}</span>
                                      {locked && <span className="ml-auto text-[9px] font-bold uppercase text-gray-400">always</span>}
                                    </label>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <Check disabled={!editable}
            checked={modules.length === info.modules.length && chosen.length === offered.length}
            onChange={v => applyModules(v ? info.modules.map(m => m.key) : ['dashboard', 'setup'])}
            label="Every module Xenith ERP sells" />
          <div className="flex items-center gap-2">
            {!editable ? (
              <span className="text-[11px] text-gray-500">Your vendor holds these switches.</span>
            ) : (!dirty && !notice && <span className="text-[11px] text-gray-400">Nothing to save</span>)}
            <button type="button" disabled={!editable || !dirty || saving || !company} onClick={submit}
              className="btn-xenith-success disabled:opacity-50">
              <Save className="w-3.5 h-3.5" /> {saving ? 'Saving...' : 'SAVE ALLOCATION'}
            </button>
          </div>
        </div>

        {modules.length > 0 && (
          <div className="mt-3 text-[11px] text-gray-500 flex items-start gap-2">
            <ShieldCheck className="w-3.5 h-3.5 mt-0.5 text-[#25a195] shrink-0" />
            <span>
              Roles keep whatever was ticked for a module or a feature that later switches off, so holding
              Returns back from a firm hides it at once &mdash; and giving it back restores their ticks exactly
              as they were.
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionPage;
