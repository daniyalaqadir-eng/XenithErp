import React, { useMemo, useState } from 'react';
import { Check as CheckIcon, Eye, EyeOff, KeyRound, ShieldCheck, UserRound } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { Field, TabStrip, Text } from '../Masters/masterUi';
import { useHub } from './useHub';
import { getPermissionCatalog } from '../../services/access.service';
import { plateOn } from '../../utils/inkOn';

const TABS = ['My Profile', 'Change Password'];

export const MyProfilePage: React.FC<{ startOn?: string }> = ({ startOn }) => {
  const { user, saveProfile, changePassword } = useAuth();
  const { tenantSlug, branchId, allBranches } = useTenant();
  const [tab, setTab] = useState(startOn ?? TABS[0]);

  const catalog = useHub(() => getPermissionCatalog(tenantSlug, branchId), [tenantSlug, branchId]);

  const [name, setName] = useState(user?.name ?? '');
  const [username, setUsername] = useState(user?.username ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [phone, setPhone] = useState(user?.phone ?? '');
  const [profileMsg, setProfileMsg] = useState('');
  const [profileError, setProfileError] = useState('');
  const [busy, setBusy] = useState(false);

  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [show, setShow] = useState(false);
  const [pwMsg, setPwMsg] = useState('');
  const [pwError, setPwError] = useState('');

  const myBranches = useMemo(
    () => allBranches.filter(b => (user?.branchIds ?? []).includes(b.id)),
    [allBranches, user?.branchIds]
  );

  // Access is listed screen by screen, since that is the level the role is ticked at.
  const access = useMemo(() => {
    const perms = new Set(user?.permissions ?? []);
    return (catalog.value?.modules ?? []).map(m => ({
      label: m.label,
      screens: m.screens
        .filter(s => perms.has(`${s.key}:view`))
        .map(s => ({ label: s.label, actions: s.actions.filter(a => perms.has(`${s.key}:${a}`)) }))
    })).filter(m => m.screens.length > 0);
  }, [catalog.value, user?.permissions]);

  if (!user) return null;

  const save = async () => {
    setBusy(true); setProfileMsg(''); setProfileError('');
    try {
      await saveProfile({ name, username, email, phone });
      setProfileMsg('Profile updated.');
    } catch (e) { setProfileError((e as Error).message); }
    setBusy(false);
  };

  const submitPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPw.length < 6) { setPwError('New password must be at least 6 characters'); return; }
    if (newPw !== confirmPw) { setPwError('The two new passwords do not match'); return; }
    setBusy(true); setPwMsg(''); setPwError('');
    try {
      await changePassword(currentPw, newPw);
      setPwMsg('Password updated. Your next sign in uses the new password.');
      setCurrentPw(''); setNewPw(''); setConfirmPw('');
    } catch (err) { setPwError((err as Error).message); }
    setBusy(false);
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span className="flex items-center gap-2"><UserRound className="w-4 h-4" /> My Account</span>
        <span className="text-xs font-normal text-gray-500">{user.roleName}</span>
      </div>
      <TabStrip tabs={TABS} active={tab} onChange={setTab} />
      <div className="nb-card-body">
        <div className="nb-plate flex items-center gap-3">
          <div className="w-14 h-14 rounded-full text-lg font-bold flex items-center justify-center shadow-sm"
            style={plateOn(user.avatarColor)}>
            {user.name.split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase()).join('')}
          </div>
          <div>
            <div className="card-title flex items-center gap-2">
              {user.name}
              {user.isOwner && <span className="text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">Owner</span>}
            </div>
            <div className="text-[11px] text-gray-500">{user.email} · username: {user.username}</div>
            <div className="text-[11px] text-gray-400">
              Last login: {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'this session'}
            </div>
          </div>
          <div className="ml-auto text-right">
            <div className="text-[10px] uppercase tracking-wide text-gray-400">Role</div>
            <div className="text-xs font-bold text-[#1e88e5] flex items-center gap-1 justify-end">
              <ShieldCheck className="w-3.5 h-3.5" /> {user.roleName}
            </div>
          </div>
        </div>

        {tab === 'My Profile' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="Name" required><Text value={name} onChange={e => setName(e.target.value)} /></Field>
                <Field label="Username" required hint="sign-in name">
                  <Text value={username} onChange={e => setUsername(e.target.value)} />
                </Field>
                <Field label="Email" required><Text type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>
                <Field label="Mobile"><Text value={phone} onChange={e => setPhone(e.target.value)} /></Field>
              </div>
              {(profileMsg || profileError) && (
                <div className={`mt-3 text-xs font-semibold rounded px-3 py-2 ${profileError ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
                  {profileError || profileMsg}
                </div>
              )}
              <div className="flex justify-end mt-3">
                <button type="button" onClick={save} disabled={busy || !name.trim() || !email.trim()} className="btn-xenith-success disabled:opacity-50">
                  {busy ? 'Saving...' : 'SAVE'}
                </button>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">Branch Access</div>
              <ul className="text-xs space-y-1">
                {myBranches.map(b => (
                  <li key={b.id} className="flex items-center justify-between border border-gray-100 rounded px-2 py-1 bg-gray-50/60">
                    <span>{b.name}</span>
                    <span className="text-gray-400">{b.code}</span>
                  </li>
                ))}
                {myBranches.length === 0 && <li className="text-gray-400">All branches</li>}
              </ul>

              <div className="text-xs font-semibold text-gray-700 uppercase tracking-wide mt-4 mb-2">What I can do</div>
              <ul className="text-[11px] space-y-1 max-h-64 overflow-y-auto app-scroll">
                {access.map(m => (
                  <li key={m.label} className="border-b border-gray-50 pb-1.5">
                    <div className="font-bold text-gray-700">{m.label}</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                      {m.screens.map(s => (
                        <div key={s.label} className="flex items-start justify-between gap-2">
                          <span className="text-gray-600">{s.label}</span>
                          <span className="text-right text-gray-400">{s.actions.join(', ')}</span>
                        </div>
                      ))}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {tab === 'Change Password' && (
          <form className="max-w-sm space-y-3" onSubmit={submitPassword}>
            <Field label="Current Password" required>
              <div className="relative">
                <Text type={show ? 'text' : 'password'} value={currentPw} onChange={e => setCurrentPw(e.target.value)} className="pr-8" />
                <button type="button" onClick={() => setShow(s => !s)} className="absolute right-2 top-1.5 text-gray-400 hover:text-gray-600">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </Field>
            <Field label="New Password" required hint="at least 6 characters">
              <Text type={show ? 'text' : 'password'} value={newPw} onChange={e => setNewPw(e.target.value)} />
            </Field>
            <Field label="Confirm New Password" required>
              <Text type={show ? 'text' : 'password'} value={confirmPw} onChange={e => setConfirmPw(e.target.value)} />
            </Field>
            {(pwMsg || pwError) && (
              <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center gap-2 ${pwError ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
                {pwMsg && <CheckIcon className="w-3.5 h-3.5" />}
                <span>{pwError || pwMsg}</span>
              </div>
            )}
            <div className="flex items-center justify-between">
              <button type="button" onClick={() => setShow(s => !s)} className="text-[11px] text-gray-500 hover:text-blue-600 inline-flex items-center gap-1">
                {show ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />} {show ? 'Hide' : 'Show'} passwords
              </button>
              <button type="submit" disabled={busy || !currentPw || !newPw || !confirmPw} className="btn-xenith-success disabled:opacity-50">
                <KeyRound className="w-3.5 h-3.5" /> {busy ? 'Updating...' : 'UPDATE PASSWORD'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default MyProfilePage;
