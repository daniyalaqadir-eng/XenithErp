import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useTenant } from '../context/TenantContext';
import { useAuth } from '../context/AuthContext';
import { THEMES, useInk, useTheme } from '../context/ThemeContext';
import { ReportPayload } from '../types';
import { getReport } from '../services/reports.service';
import {
  ArrowRight,
  BarChart2,
  BellRing,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Contact2,
  Eye,
  EyeOff,
  FileBarChart,
  FileText,
  Layers,
  Palette,
  Percent,
  RefreshCw,
  Receipt,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Truck,
  Wallet
} from 'lucide-react';
import { XenithBarChart } from '../components/charts/XenithBarChart';
import { XenithDoughnutChart } from '../components/charts/XenithDoughnutChart';
import { useScreenReload } from '../utils/screenReload';

/* ── motion helpers ─────────────────────────────────────────── */

// A figure counts up when the screen can actually paint. A tab in the background gets no
// animation frames at all, and a tile that never left its first frame would sit there reading
// PKR 0 while the books say otherwise — so a tile that cannot animate shows the real number
// from the start, and a snap timer guarantees the animation always finishes on that number.
export const useCountUp = (target: number) => {
  const animates = typeof window !== 'undefined'
    && !document.hidden
    && !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const [value, setValue] = useState(animates ? 0 : target);
  useEffect(() => {
    if (!animates) { setValue(target); return; }
    let raf = 0;
    const start = performance.now();
    const duration = 850;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      setValue(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const snap = window.setTimeout(() => setValue(target), duration + 120);
    return () => { cancelAnimationFrame(raf); window.clearTimeout(snap); };
  }, [target, animates]);
  return value;
};

const useReport = (s: string, b: number | string, key: string) => {
  const [data, setData] = useState<ReportPayload | null>(null);
  useEffect(() => {
    let alive = true;
    getReport(s, b, key).then(d => { if (alive) setData(d); }).catch(() => { if (alive) setData(null); });
    return () => { alive = false; };
  }, [s, b, key]);
  return data;
};

const Amount: React.FC<{ value: number; decimals: boolean; privacy: boolean; className?: string }> = ({
  value, decimals, privacy, className = ''
}) => {
  const shown = useCountUp(value);
  const digits = { minimumFractionDigits: decimals ? 2 : 0, maximumFractionDigits: decimals ? 2 : 0 };
  if (privacy) return <span className={`font-bold text-gray-400 ${className}`}>PKR ••••••</span>;
  return <span className={`font-bold tabular-nums ${className}`}>PKR {shown.toLocaleString(undefined, digits)}</span>;
};

const Ring: React.FC<{ pct: number; color: string; size?: number }> = ({ pct, color, size = 58 }) => {
  const p = useCountUp(Math.max(0, Math.min(100, pct)));
  const ink = useInk();
  return (
    <div className="relative shrink-0 rounded-full grid place-items-center transition-all duration-500"
      style={{ width: size, height: size, background: `conic-gradient(${color} ${p}%, var(--surface-3) ${p}% 100%)` }}>
      <div className="bg-white rounded-full grid place-items-center" style={{ width: size - 11, height: size - 11 }}>
        <span className="text-[11px] font-black" style={{ color: ink(color) }}>{Math.round(p)}%</span>
      </div>
    </div>
  );
};

// A percentage needs something to stand against it. An empty previous window is not a flat
// line, so it says so in words instead of printing an arrow at 0.00%.
const Delta: React.FC<{ pct: number; basis: string; prior?: number }> = ({ pct, basis, prior }) => {
  const up = pct >= 0;
  if (!prior) return (
    <span className="flex items-center justify-end gap-1.5 text-[11px]">
      <span className="inline-flex items-center font-black px-1.5 py-0.5 rounded bg-gray-100 text-gray-400">—</span>
      <span className="text-gray-400 whitespace-nowrap">nothing {basis}</span>
    </span>
  );
  return (
    <span className="flex items-center justify-end gap-1.5 text-[11px]">
      <span className={`inline-flex items-center gap-0.5 font-bold px-1.5 py-0.5 rounded ${up ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
        {up ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
        {Math.abs(pct).toFixed(2)}%
      </span>
      <span className="text-gray-400 whitespace-nowrap">vs {basis}</span>
    </span>
  );
};

// An alert is a row to read, not a coloured box to admire: the severity is the dot, the wash
// only arrives under the pointer.
const ALERT_TONES = {
  red: { dot: '#e63946', text: 'text-red-600', wash: 'hover:bg-red-50/70' },
  amber: { dot: '#ff9f1c', text: 'text-amber-700', wash: 'hover:bg-amber-50/70' },
  blue: { dot: '#1e88e5', text: 'text-blue-600', wash: 'hover:bg-blue-50/70' },
};

const Section: React.FC<{ label: string; tone: string; right?: React.ReactNode }> = ({ label, tone, right }) => {
  const ink = useInk();
  return (
    <div className="dash-rail pt-1">
      <span className="flex items-center gap-2 min-w-0 shrink-0">
        <span className="w-1 h-3.5 rounded-full shrink-0" style={{ background: tone }} />
        <span className="text-[11px] font-black uppercase tracking-[.16em]" style={{ color: ink(tone) }}>{label}</span>
      </span>
      <span className="dash-rail-rule" />
      {right ?? <span className="shrink-0" />}
    </div>
  );
};

const SectionLink: React.FC<{ label: string; onClick: () => void; tone?: string }> = ({ label, onClick, tone = '#1e88e5' }) => {
  const ink = useInk();
  return (
    <button onClick={onClick}
      className="group inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider transition-colors shrink-0"
      style={{ color: ink(tone) }}>
      {label}
      <ArrowRight className="w-3 h-3 transition-transform duration-300 group-hover:translate-x-1" />
    </button>
  );
};

/* The desk tools live on the band, so they are glass chips in the band's own ink rather than
   white pills — and the one that is switched on inverts to solid ink, which reads from
   across the room without needing a second colour to say "on". */
const Toggle: React.FC<{ on: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({
  on, onClick, icon, label
}) => (
  <button type="button" onClick={onClick} aria-pressed={on} className="hero-glass">
    {icon}{label}
  </button>
);

const QuickAction: React.FC<{
  icon: React.ReactNode; label: string; hint: string; onClick: () => void;
}> = ({ icon, label, hint, onClick }) => (
  <button type="button" onClick={onClick} className="hero-quick group">
    <span className="hero-quick-ico">{icon}</span>
    <span className="min-w-0 flex-1">
      <span className="block text-[11.5px] font-bold leading-snug">{label}</span>
      <span className="block text-[10.5px] leading-tight truncate text-[var(--faint)]">{hint}</span>
    </span>
    <ArrowRight className="w-3.5 h-3.5 shrink-0 opacity-40 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100" />
  </button>
);

// The surfaces of the workspace are tokens, so a swatch here repaints every screen.
// Only the chosen colour sits in the header — with a dozen themes a row of swatches
// would eat the whole bar, so the rest wait inside the dropdown.
// `divider` is the hairline that separates it from its neighbours on a paper surface; the
// dashboard's band already has its own ink, where a grey rule would read as a smudge.
export const ThemePicker: React.FC<{ divider?: boolean }> = ({ divider = true }) => {
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const [box, setBox] = useState<{ top: number; right: number; maxHeight: number } | null>(null);
  const btnRef = useRef<HTMLSpanElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const active = THEMES.find(t => t.key === theme) ?? THEMES[0];

  useLayoutEffect(() => {
    if (!open) return;
    // A dozen swatches is taller than a short window, and the list hangs under the header
    // at the top of the screen — so it takes whatever height is left above the taskbar and
    // scrolls the rest, instead of running off the bottom out of sight.
    const place = () => {
      const r = btnRef.current?.getBoundingClientRect();
      if (!r) return;
      const top = r.bottom + 6;
      setBox({
        top, right: Math.max(8, window.innerWidth - r.right),
        maxHeight: Math.max(160, window.innerHeight - top - 10)
      });
    };
    place();
    window.addEventListener('resize', place);
    return () => window.removeEventListener('resize', place);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (btnRef.current?.contains(t) || listRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <span ref={btnRef} className={`relative flex items-center ${divider ? 'pl-2 ml-1 border-l border-gray-200' : ''}`}>
      <button type="button" aria-haspopup="listbox" aria-expanded={open}
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 rounded-full border border-gray-200 bg-white pl-1.5 pr-2 py-1 hover:border-[var(--ink)] transition-colors">
        <Palette className="w-3.5 h-3.5 text-gray-400" />
        <span className="w-[15px] h-[15px] rounded-full border border-gray-300"
          style={{ background: active.swatch, boxShadow: '0 0 0 2px var(--surface), 0 0 0 3px var(--ink)' }} />
        <span className="text-[11px] font-bold text-gray-600 whitespace-nowrap">{active.label}</span>
        <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && box && createPortal(
        <div ref={listRef} role="listbox" aria-label="Workspace theme"
          className="fixed z-[90] w-[228px] bg-white border border-gray-200 rounded-lg shadow-xl py-1 text-xs overflow-y-auto overscroll-contain"
          style={{ top: box.top, right: box.right, maxHeight: box.maxHeight }}>
          <p className="sticky top-0 z-10 bg-white px-3 py-1.5 text-[10px] font-black uppercase tracking-[.12em] text-gray-400">Workspace colour</p>
          {THEMES.map(t => {
            const on = t.key === theme;
            return (
              <button key={t.key} type="button" role="option" aria-selected={on}
                onClick={() => { setTheme(t.key); setOpen(false); }}
                className={`w-full flex items-center gap-2.5 px-3 py-1.5 text-left hover:bg-blue-50 ${on ? 'bg-blue-50/60' : ''}`}>
                <span className="w-4 h-4 shrink-0 rounded-full border border-gray-300" style={{ background: t.swatch }} />
                <span className="min-w-0 flex-1">
                  <span className="block font-bold text-gray-800 leading-tight">{t.label}</span>
                  <span className="block text-[10px] text-gray-400 truncate">{t.hint}</span>
                </span>
                {on && <CheckCircle2 className="w-3.5 h-3.5 text-[#1e88e5] shrink-0" />}
              </button>
            );
          })}
        </div>,
        document.body
      )}
    </span>
  );
};

/* ── cards ──────────────────────────────────────────────────── */

interface Stat {
  label: string; amount: number; sub: string; tone: string; icon: React.ReactNode;
  report: string; reportLabel: string;
  // The one movement worth seeing beside the figure: a share, and whether it helped.
  chip?: { text: string; kind: 'up' | 'down'; title?: string };
}

// A figure, the words that say what it counts, and the register that proves it — one shape
// for every tile so the eye can read the row straight down. The card itself is not a button:
// the whole thing would look pressable but only the footer link is, so the link is the target
// and the hairline above it is what tells the two apart.
const KpiCard: React.FC<Stat & { decimals: boolean; privacy: boolean; onOpen: (key: string) => void }> = ({
  label, amount, sub, tone, icon, report, reportLabel, chip, decimals, privacy, onOpen
}) => {
  const ink = useInk();
  return (
    <div className="card-xenith relative overflow-hidden p-3.5 lg:self-start flex flex-col">
      <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: tone }} />
      <div className="flex items-start justify-between gap-2 min-w-0">
        <span className="text-[10px] font-black uppercase tracking-[.13em] text-gray-500 leading-tight pt-1">{label}</span>
        <span className="w-8 h-8 rounded-lg grid place-items-center shrink-0" style={{ background: `${tone}1a`, color: ink(tone) }}>
          {icon}
        </span>
      </div>
      <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1">
        <Amount value={amount} decimals={decimals} privacy={privacy} className="text-[22px] text-gray-900 leading-none" />
        {chip && (
          <span title={chip.title}
            className={`inline-flex items-center text-[10px] font-black px-1.5 py-0.5 rounded whitespace-nowrap ${
              chip.kind === 'up' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
            {chip.text}
          </span>
        )}
      </div>
      <span title={sub} className="min-w-0 block text-[11px] text-gray-400 leading-snug mt-1.5 line-clamp-2 flex-1">{sub}</span>
      <button onClick={() => onOpen(report)}
        className="group mt-2.5 pt-2 border-t border-gray-100 flex items-center justify-between gap-1 text-[10px] font-black uppercase tracking-[.1em] transition-colors"
        style={{ color: ink(tone) }}>
        {reportLabel}
        <ArrowRight className="w-3 h-3 shrink-0 transition-transform duration-300 group-hover:translate-x-1" />
      </button>
    </div>
  );
};

// The comparison cards all measure the same pair against the equally long window before it;
// they differ only in how long that window is, so they read as one stack of four.
const TrendCard: React.FC<{
  card: any; tone: string; decimals: boolean; privacy: boolean; onOpen: () => void;
}> = ({ card, tone, decimals, privacy, onOpen }) => (
  <button onClick={onOpen}
    className="card-xenith p-3 text-left w-full border-t-[3px] lg:self-start" style={{ borderTopColor: tone }}>
    <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
      <span className="text-[11px] font-black uppercase tracking-wider text-gray-500">{card.label}</span>
      <Layers className="w-3.5 h-3.5 text-gray-300" />
    </div>
    <div className="mt-2 flex flex-wrap items-end justify-between gap-x-3">
      <span className="min-w-0">
        <span className="block text-[10px] font-black uppercase tracking-wider text-gray-400">Sales</span>
        <Amount value={card.sales} decimals={decimals} privacy={privacy} className="text-sm text-gray-900 block whitespace-nowrap" />
      </span>
      <span className="min-w-0 text-right">
        <span className="block text-[10px] font-black uppercase tracking-wider text-gray-400">Purchases</span>
        <Amount value={card.purchases} decimals={decimals} privacy={privacy} className="text-sm text-gray-900 block whitespace-nowrap" />
      </span>
    </div>
    <div className="mt-2 pt-2 border-t border-gray-50 flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
      <Delta pct={card.salesDelta} basis={card.against} prior={card.salesPrior} />
      <Delta pct={card.purchaseDelta} basis={card.against} prior={card.purchasesPrior} />
    </div>
  </button>
);

// A ring with its own figure beside it: the share and the money it is a share of, together.
const RingRow: React.FC<{
  pct: number; color: string; title: string; children: React.ReactNode; onOpen: () => void;
}> = ({ pct, color, title, children, onOpen }) => (
  <button onClick={onOpen}
    className="w-full flex items-center gap-3 rounded-lg px-2 py-2 -mx-2 text-left hover:bg-blue-50/40 transition-colors">
    <Ring pct={pct} color={color} size={52} />
    <span className="min-w-0 flex-1">
      <span className="block text-[10px] font-black text-gray-400 uppercase tracking-wider">{title}</span>
      {children}
    </span>
  </button>
);

const RankCard: React.FC<{
  title: string; subtitle: string; rows: any[]; tone: string; decimals: boolean; privacy: boolean;
  onViewAll?: () => void;
}> = ({ title, subtitle, rows, tone, decimals, privacy, onViewAll }) => {
  const ink = useInk();
  const total = rows.reduce((s, r) => s + (r.amount ?? 0), 0);
  return (
    <div className="card-xenith p-4 lg:self-start">
      <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-3">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4" style={{ color: ink(tone) }} />
          <div>
            <h3 className="card-title leading-tight">{title}</h3>
            <span className="text-[11px] text-gray-400">{subtitle}</span>
          </div>
        </div>
        <button onClick={onViewAll} className="group inline-flex items-center gap-1 text-xs font-bold transition-colors" style={{ color: ink(tone) }}>
          View All
          <ArrowRight className="w-3 h-3 transition-transform duration-300 group-hover:translate-x-0.5" />
        </button>
      </div>
      <div className="space-y-3">
        {rows.map((r, i) => (
          <div key={r.name} className="space-y-1 group">
            <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5 text-xs">
              <span className="flex items-center gap-2 min-w-0 max-w-full">
                <span className="text-gray-300 font-black text-[11px]">0{i + 1}</span>
                <span className="font-semibold text-gray-800 truncate">{r.name}</span>
                {r.salesQty && <span className="text-[11px] text-gray-400 shrink-0">({r.salesQty} sold)</span>}
              </span>
              <span className="flex items-center gap-3 shrink-0 ml-auto">
                <span className="text-[11px] font-bold" style={{ color: ink(tone) }}>{r.pct}%</span>
                <Amount decimals={decimals} privacy={privacy} value={r.amount} className="text-xs text-gray-900 text-right whitespace-nowrap" />
              </span>
            </div>
            {r.extra && <span className="block text-[10px] text-gray-400">{r.extra}</span>}
            <div className="w-full h-1.5 rounded-full bg-gray-100 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700 group-hover:brightness-110"
                style={{ width: `${Math.min(100, r.pct)}%`, background: tone }} />
            </div>
          </div>
        ))}
        {!rows.length && <p className="text-xs text-gray-400 py-3">No records yet.</p>}
      </div>
      <div className="mt-3 pt-2 border-t border-gray-100 flex flex-wrap items-center justify-between gap-x-2">
        <span className="text-[11px] font-black text-gray-400 uppercase tracking-wider">Total</span>
        <Amount decimals={decimals} privacy={privacy} value={total} className="text-sm text-gray-900 text-right whitespace-nowrap ml-auto" />
      </div>
    </div>
  );
};

/* ── screen ─────────────────────────────────────────────────── */

const PERIODS = ['Today', 'This Week', 'This Month', 'Last Month', 'This Quarter', 'This Year'];

// The bands this desk is built from, in the order they are drawn. Each one is a tick on the
// Roles screen (`dash-<name>:view`), so this list is only here to answer the question "is
// anything left to show at all?".
const BANDS = ['snapshot', 'quick-actions', 'alerts', 'sales-purchases', 'cash', 'profit',
  'collections', 'buyers', 'activity', 'shortcuts'];

interface Props { onNavigate: (tab: string) => void; onQuickCreate: (type: string) => void }

export const Dashboard: React.FC<Props> = ({ onNavigate, onQuickCreate }) => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  // Which bands this role's desk draws. They are the ticks listed under Setup → User Roles →
  // Dashboard, and a band nobody ticked is simply not painted — the figures behind it stay on
  // the registers that own them, which is where a number lives anyway.
  const on = (band: string) => can(`dash-${band}:view`);
  const ink = useInk();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [period, setPeriod] = useState('This Month');
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [decimals, setDecimals] = useState(false);
  const [privacy, setPrivacy] = useState(false);

  const fetchDashboard = useCallback(() => {
    // The period is part of the question the screen asks, so it goes up with the request and
    // every money, profit and chart tile is re-measured for it. One selector, one answer.
    setError('');
    fetch(`/api/${tenantSlug}/${branchId}/dashboard?period=${encodeURIComponent(period)}`)
      .then(async r => {
        const d = await r.json().catch(() => null);
        // A refusal has to look like a refusal: reading a 403 body as tiles would put PKR 0
        // where the clerk expects a number he can act on.
        if (!r.ok) throw new Error((d && d.error) || `The dashboard could not be read (${r.status})`);
        return d;
      })
      .then(d => { setData(d); setLoading(false); })
      .catch(e => { setError((e as Error).message); setLoading(false); });
  }, [tenantSlug, branchId, period]);

  useEffect(() => { fetchDashboard(); }, [fetchDashboard]);
  useScreenReload(fetchDashboard);
  useEffect(() => {
    if (!autoRefresh) return;
    const id = window.setInterval(fetchDashboard, 20000);
    return () => window.clearInterval(id);
  }, [autoRefresh, fetchDashboard]);

  const money = useMemo(() => ({ decimals, privacy }), [decimals, privacy]);
  const openReport = (key: string) => onNavigate(`report:${key}`);
  const summary = useReport(tenantSlug, branchId, 'business-summary-report');
  const agents = useReport(tenantSlug, branchId, 'sale-performance-by-sales-person-report');
  const overdue = useReport(tenantSlug, branchId, 'customer-due-list-report');
  const tax = useReport(tenantSlug, branchId, 'tax-balance');

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400 gap-2">
        <RefreshCw className="w-5 h-5 animate-spin text-[#2ec4b6]" />
        <span>Loading Xenith ERP Dashboard...</span>
      </div>
    );
  }

  // No tiles and no answer: say so and offer the retry instead of a board full of zeros.
  const failed = !!error && !data;

  const aging = data?.receivablesAging ?? {};
  const health = data?.businessHealth ?? {};
  const pl = data?.profitLoss ?? {};
  const flow = data?.moneyFlow ?? {};
  const pos = data?.position ?? {};
  const accounts = data?.cashAndBankAccounts ?? [];
  const totalLiquidity = accounts.reduce((s: number, a: any) => s + a.balance, 0);
  const revenuePct = health.revenuePrior ? (health.revenueAfterDiscount / health.revenuePrior) * 100 : 0;
  const collectionPct = health.collectionsTarget ? (health.collections / health.collectionsTarget) * 100 : 0;
  const dispatchedPct = health.totalBills ? (health.dispatchedBillsCount / health.totalBills) * 100 : 0;
  // The server decides which tiles the pipeline holds, what each one counts and the screen
  // that shows it — so a tile's number and its own register are the same measurement.
  const pipeline: any[] = data?.pipeline ?? [];
  const AGING_COLORS = ['bg-emerald-500', 'bg-lime-500', 'bg-amber-500', 'bg-orange-500', 'bg-red-600', 'bg-red-800'];
  // The buckets are the ones configured for ageing reports, so this strip and the
  // order-wise detail below it split the ledger the same way.
  const agingBands: [string, number, string, string][] = (aging.bands ?? [])
    .map((b: any, i: number) => [b.label, b.amount, AGING_COLORS[Math.min(i, AGING_COLORS.length - 1)], b.tag] as [string, number, string, string]);
  const agingTotal = Math.max(1, aging.totalDue ?? 0);
  // Approved bills only: the ageing strip, the 'Owed To You' tile and the ledger behind both
  // count papers that carry weight, so this list may not quietly widen to drafts and pending.
  const oldestDues: any[] = (overdue?.rows ?? [])
    .filter((r: any) => r.status === 'Approved' && Number(r.balance) > 0)
    .sort((a: any, b: any) => Number(b.days) - Number(a.days))
    .slice(0, 5);
  const periodCaption = `${data?.periodRange ?? ''} · ${data?.period ?? period}`;
  const netOf = (rows: any[]) => Math.round(rows.reduce((s, a) => s + a.balance, 0)).toLocaleString();
  // A movement is only a percentage against a previous window that held something; where it was
  // empty the tile says so in its caption instead of printing a flat line at 0%. Whether a
  // movement is *good* depends on which way the money went, so the caller decides the colour.
  const flowChip = (delta: number | undefined, prior: number | undefined, rising: boolean) =>
    !prior || delta === undefined ? undefined
      : { text: `${delta >= 0 ? '+' : '-'}${Math.abs(delta).toFixed(2)}%`, kind: (delta >= 0) === rising ? 'up' : 'down',
        title: `Against PKR ${Math.round(prior).toLocaleString()} ${flow.against ?? 'in the window before it'}` } as Stat['chip'];

  // The figures a business owner reads first. Each tile names what it counts, carries the one
  // movement worth seeing, and ends on the register that proves it — so nothing here is a
  // number you cannot trace.
  const stats: Stat[] = [
    {
      label: 'Money In', tone: '#2ec4b6', icon: <TrendingUp className="w-4 h-4" />,
      amount: flow.in ?? 0,
      chip: flowChip(flow.inDelta, flow.inPrior, true),
      sub: `Payments received and receipt vouchers${flow.inPrior ? '' : ` — nothing came in during ${flow.against ?? 'the window before it'}`}.`,
      report: 'receive-payment-report', reportLabel: 'Open Payments Received'
    },
    {
      label: 'Money Out', tone: '#e63946', icon: <Receipt className="w-4 h-4" />,
      amount: flow.out ?? 0,
      chip: flowChip(flow.outDelta, flow.outPrior, false),
      sub: `Vendor payments, expense vouchers and petty cash${flow.outPrior ? '' : ` — nothing went out during ${flow.against ?? 'the window before it'}`}.`,
      report: 'voucher-expense-head-report', reportLabel: 'Open Expense Vouchers'
    },
    {
      label: 'Net Cash Movement', tone: (flow.net ?? 0) < 0 ? '#e63946' : '#1e88e5', icon: <Wallet className="w-4 h-4" />,
      amount: flow.net ?? 0,
      sub: `Money in less money out: the cash and bank that really moved in ${data?.period ?? period}.`,
      report: 'amount-ledger', reportLabel: 'Open Amount Ledger'
    },
    {
      label: 'Owed To You', tone: '#ff9f1c', icon: <ShoppingBag className="w-4 h-4" />,
      amount: aging.totalDue ?? 0,
      chip: { text: `${aging.atRiskPct ?? 0}% at risk`, kind: (aging.atRiskPct ?? 0) > 0 ? 'down' : 'up',
        title: `${aging.atRiskPct ?? 0}% of the ${aging.openDocs ?? 0} open customer bills are ${aging.atRiskLabel ?? 'within their due date'}` },
      sub: `${aging.openDocs ?? 0} open customer ${aging.openDocs === 1 ? 'bill' : 'bills'}, oldest ${aging.oldestDays ?? 0} days.`,
      report: 'customer-due-list-report', reportLabel: 'Open Due List'
    },
    {
      label: 'Owed By You', tone: '#845ec2', icon: <Truck className="w-4 h-4" />,
      amount: pos.payableTotal ?? 0,
      chip: { text: `${Math.round(pos.payableOverdue ?? 0).toLocaleString()} overdue`, kind: (pos.payableOverdue ?? 0) > 0 ? 'down' : 'up',
        title: `PKR ${Math.round(pos.payableOverdue ?? 0).toLocaleString()} of this is already past its due date` },
      sub: `${pos.payableDocs ?? 0} vendor ${pos.payableDocs === 1 ? 'bill' : 'bills'} on the book.`,
      report: 'vendor-due-invoice-report', reportLabel: 'Open Vendor Dues'
    }
  ];

  if (failed) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 h-64 px-4 text-center">
        <p className="text-sm font-bold text-red-700">{error}</p>
        <p className="text-xs text-gray-500">Nothing on this page has been measured, so no tile below is a zero you can trust.</p>
        <button onClick={fetchDashboard} className="btn-xenith-outline !px-3 !py-1 text-xs">Try again</button>
      </div>
    );
  }

  return (
    <div className="space-y-3 pb-6">
      {/* Auto-refresh keeps the old tiles up when a re-read fails; the band says which read
          this board is actually from, because a stale number looks exactly like a live one. */}
      {error && data && (
        <div className="text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 rounded px-2 py-1.5">
          These figures are from the last good read — {error}
        </div>
      )}
      {/* The desk's own header. This is the one accent-filled surface on the screen, so the
          eye starts here: who is reading, the window every figure below answers for, the three
          desk tools, and the paperwork raised from this page. Everything resting on the band is
          mixed from the band's own ink, which is why it holds on all twelve themes. */}
      {(on('snapshot') || on('quick-actions')) && (
      <div className="dash-hero px-4 py-3.5">
        {on('snapshot') && (<>
        <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
          <div className="flex items-center gap-3 min-w-0">
            <span className="hero-mark"><Sparkles className="w-5 h-5" /></span>
            <div className="min-w-0">
              <span className="hero-eyebrow block">Business Snapshot</span>
              <h1 className="hero-title mt-1">{data?.userGreeting ?? 'Your desk'}</h1>
              <p className="hero-note mt-1">
                Every figure below counts Approved paper — drafts and pending wait in their own registers.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <Toggle on={autoRefresh} onClick={() => setAutoRefresh(v => !v)} label="Auto Refresh"
              icon={<RefreshCw className={`w-3 h-3 ${autoRefresh ? 'animate-spin [animation-duration:2.4s]' : ''}`} />} />
            <Toggle on={decimals} onClick={() => setDecimals(v => !v)} label="With Decimal" icon={<Percent className="w-3 h-3" />} />
            <Toggle on={privacy} onClick={() => setPrivacy(v => !v)} label="Privacy"
              icon={privacy ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />} />
            <ThemePicker divider={false} />
          </div>
        </div>

        <div className="hero-rule my-3" />

        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2">
          <div className="hero-seg" role="group" aria-label="Period for the whole dashboard">
            {PERIODS.map(p => (
              <button key={p} type="button" aria-pressed={p === period} onClick={() => setPeriod(p)}>{p}</button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 justify-end ml-auto">
            <span className="hero-glass"><CalendarDays className="w-3.5 h-3.5" />{data?.todayDate}</span>
            <span className="hero-note truncate max-w-[46ch]" title={periodCaption}>{data?.periodRange}</span>
          </div>
        </div>

        </>)}

        {on('quick-actions') && (<>
        {on('snapshot') && <div className="hero-rule my-3" />}

        {/* Six across from 1280px: these tiles hold an 11px label and a hint, so they survive a
            narrow column far better than the money tiles below, which still need 2xl. */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-2">
          <QuickAction icon={<ShoppingCart className="w-4 h-4" />} label="New Sale Invoice" hint="Bill a customer"
            onClick={() => onQuickCreate('sale-invoice')} />
          <QuickAction icon={<Wallet className="w-4 h-4" />} label="Receive Payment" hint="Adjust invoices"
            onClick={() => onQuickCreate('receive-payment')} />
          <QuickAction icon={<Receipt className="w-4 h-4" />} label="Cash Payment Voucher" hint="Pay a billhead"
            onClick={() => onQuickCreate('cash-voucher')} />
          <QuickAction icon={<Truck className="w-4 h-4" />} label="Purchase Invoice" hint="Book a vendor bill"
            onClick={() => onQuickCreate('purchase-bill')} />
          <QuickAction icon={<Contact2 className="w-4 h-4" />} label="Add Customer" hint="New party account"
            onClick={() => onNavigate('customers')} />
          <QuickAction icon={<FileBarChart className="w-4 h-4" />} label="All Reports" hint={`${data?.reportCount ?? 0} reports in the library`}
            onClick={() => onNavigate('reports')} />
        </div>
        </>)}
      </div>
      )}

      {/* ACTION REQUIRED */}
      {on('alerts') && (<>
      <Section label="Action Required" tone="#ff9f1c"
        right={<SectionLink label="Audit Log" tone="#ff9f1c" onClick={() => openReport('audit-log')} />} />
      <div className="card-xenith px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 pb-2 mb-1 border-b border-gray-50">
          <div className="flex items-center gap-2">
            <BellRing className="w-4 h-4 text-amber-500" />
            <h3 className="card-title leading-tight">Alerts &amp; Pending Actions</h3>
          </div>
          <span className={`text-[11px] font-black px-2 py-0.5 rounded-full border ${
            data?.alerts?.length ? 'bg-red-50 text-red-600 border-red-200' : 'bg-emerald-50 text-emerald-600 border-emerald-200'
          }`}>
            {data?.alerts?.length ? `${data.alerts.length} items` : 'All Clear'}
          </span>
        </div>
        {data?.alerts?.length ? (
          <ul>
            {data.alerts.map((a: any, i: number) => {
              const tone = ALERT_TONES[a.type === 'danger' ? 'red' : a.type === 'warning' ? 'amber' : 'blue'];
              return (
                <li key={i} className={i ? 'border-t border-gray-50' : ''}>
                  <button onClick={() => onNavigate(a.tab ?? 'reports')}
                    className={`group w-full flex flex-wrap items-center gap-x-3 gap-y-1 py-2 px-1.5 -mx-1.5 rounded-lg text-left transition-colors duration-200 ${tone.wash}`}>
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ background: tone.dot }} />
                    <span className="text-xs font-bold text-gray-800 shrink-0 max-w-full truncate">{a.title}</span>
                    <span title={a.sub} className="text-[11px] text-gray-500 min-w-0 flex-1 basis-40 truncate">{a.sub}</span>
                    <span className={`ml-auto shrink-0 inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-[.1em] ${tone.text}`}>
                      {a.action}
                      <ArrowRight className="w-3 h-3 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        ) : (
          <div className="py-4 text-center text-xs text-gray-500 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />All clear — no pending actions
          </div>
        )}
      </div>
      </>)}

      {/* SALES AGAINST PURCHASES — the screen opens on what the business sold, the way it always
          did; the cash deck below it answers the next question, not the first one. */}
      {on('sales-purchases') && (<>
      <Section label="Sales Against Purchases" tone="#1e88e5"
        right={<SectionLink label="Business Summary Report" onClick={() => openReport('business-summary-report')} />} />
      {/* Today's sales used to be squeezed into a 4/12 column beside the chart, which crushed the
          figures against the right edge. They get their own full-width strip now and the chart
          takes the whole page beneath them. */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {(data?.salesPurchases ?? []).map((card: any, i: number) => (
          <TrendCard key={card.label} card={card} tone={['#1e88e5', '#2ec4b6', '#ff9f1c', '#845ec2'][i % 4]}
            decimals={decimals} privacy={privacy}
            onOpen={() => openReport('business-summary-period-compare')} />
        ))}
      </div>
      <div className="card-xenith p-4">
        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-1">
          <h3 className="card-title">Revenue Against What The Business Spent</h3>
          <span className="text-[11px] font-semibold text-gray-400 whitespace-nowrap">{periodCaption}</span>
        </div>
        <div className="flex flex-wrap gap-5 mb-2 text-[11px]">
          <span className="text-gray-400">TOTAL GROSS REVENUE
            <Amount {...money} value={pl.grossRevenue ?? 0} className="block text-xs text-emerald-600" /></span>
          <span className="text-gray-400">TOTAL PURCHASES
            <Amount {...money} value={pl.purchases ?? 0} className="block text-xs text-rose-600" /></span>
          <span className="text-gray-400">PROFIT MARGIN
            <span className="block text-xs font-bold text-blue-600">{pl.marginPct ?? 0}%</span></span>
        </div>
        <XenithBarChart title="" labels={data?.incomeVsExpense?.months ?? []}
          datasets={[
            { label: 'Revenue', data: data?.incomeVsExpense?.income ?? [], color: '#1e88e5' },
            { label: 'Expense', data: data?.incomeVsExpense?.expense ?? [], color: '#e63946' }
          ]} height={300} currency="PKR" />
      </div>
      </>)}

      {/* CASH AND BALANCES */}
      {on('cash') && (<>
      <Section label={`Cash & Balances · ${data?.period ?? period}`} tone="#2ec4b6"
        right={<SectionLink label="Balance Sheet" tone="#2ec4b6" onClick={() => openReport('balance-sheet')} />} />
      {/* Six across only from 1536px up: with the 240px rail open a 1280 screen leaves each tile
          155px wide, which is not enough for a 21px figure and the words under it. */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6 gap-3 reveal">
        {stats.map(s => <KpiCard key={s.label} {...s} {...money} onOpen={openReport} />)}
        <div className="card-xenith relative overflow-hidden p-3.5 lg:self-start">
          <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: '#2ec4b6' }} />
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
            <h3 className="card-title leading-tight text-sm">Cash &amp; Bank</h3>
            <span className="flex items-center gap-1 text-[10px] font-bold text-[#178a80] whitespace-nowrap">
              <Wallet className="w-3 h-3" />Live
            </span>
          </div>
          <Amount {...money} value={totalLiquidity} className="text-[22px] text-[#178a80] block leading-none mt-3" />
          <span className="block text-[11px] text-gray-400 mt-2">
            Cash PKR {netOf(accounts.filter((a: any) => a.type !== 'Bank'))} · Bank PKR {netOf(accounts.filter((a: any) => a.type === 'Bank'))}
          </span>
          <div className="space-y-1 mt-2">
            {accounts.slice(0, 3).map((a: any) => (
              <button key={a.name} onClick={() => onNavigate(a.tab ?? 'chart-of-accounts')}
                className="w-full flex items-center justify-between gap-2 rounded-md px-1 py-0.5 -mx-1 text-left hover:bg-blue-50/40 transition-colors">
                <span className="flex items-center gap-1.5 min-w-0">
                  <span className={`text-[9px] font-black px-1 py-px rounded shrink-0 ${a.type === 'Bank' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'}`}>{a.type.toUpperCase()}</span>
                  <span className="text-[11px] text-gray-600 truncate">{a.name}</span>
                </span>
                <Amount {...money} value={a.balance} className="text-[11px] text-gray-800 whitespace-nowrap shrink-0" />
              </button>
            ))}
          </div>
          {accounts.length > 3 && (
            <button onClick={() => onNavigate('chart-of-accounts')}
              className="mt-1.5 text-[10px] font-black uppercase tracking-wider text-gray-400 hover:text-[#178a80] transition-colors">
              +{accounts.length - 3} more accounts
            </button>
          )}
        </div>
      </div>
      </>)}

      {/* PROFIT, INCOME AND TAX */}
      {on('profit') && (<>
      <Section label="Profit, Income & Tax" tone="#845ec2"
        right={<SectionLink label="Profit Loss Comparison" tone="#845ec2" onClick={() => openReport('profit-loss-comparison')} />} />
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        <div className="lg:col-span-4 card-xenith p-4 lg:self-start">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-3">
            <h3 className="card-title">Profit &amp; Loss</h3>
            <SectionLink label={data?.period ?? period} onClick={() => openReport('profit-and-loss')} />
          </div>
          <div className="space-y-2.5 text-xs">
            {[
              ['Gross Revenue', pl.grossRevenue, 'text-emerald-600', 'profit-and-loss'],
              ['Purchases', pl.purchases, 'text-rose-600', 'purchase-invoice-report'],
              ['Expenses', pl.expenses, 'text-amber-600', 'voucher-expense-head-report'],
            ].map(([label, value, cls, key]: any) => (
              <button key={label} onClick={() => openReport(key)}
                className="w-full flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5 pb-2 border-b border-gray-50 hover:bg-blue-50/40 rounded px-1 transition-colors">
                <span className="text-gray-500 min-w-0 truncate">{label}</span>
                <Amount {...money} value={value ?? 0} className={`text-right shrink-0 whitespace-nowrap ml-auto ${cls}`} />
              </button>
            ))}
            <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 rounded-lg bg-blue-50/60 border border-blue-100 px-3 py-2">
              <span className="font-bold text-gray-700">Net Profit</span>
              <Amount {...money} value={pl.netProfit ?? 0} className={`text-sm text-right shrink-0 whitespace-nowrap ml-auto ${pl.netProfit < 0 ? 'text-red-600' : 'text-blue-700'}`} />
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-gray-400 px-1">
              <span>Profit per PKR 100 of revenue: <b className="text-gray-700">{pl.marginPct ?? 0}%</b></span>
              <span>Expenses took <b className="text-gray-700">{health.operatingExpenseRatio ?? 0}%</b> of revenue</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 card-xenith p-4 lg:self-start">
          <h3 className="card-title mb-3">Where Income Came From</h3>
          <div className="space-y-2.5">
            {(data?.incomeOverview ?? []).map((row: any) => (
              <button key={row.label} onClick={() => openReport('profit-and-loss')}
                className="w-full flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-gray-100 bg-gray-50/50 px-3 py-2.5 hover:bg-white hover:shadow-sm transition-all duration-300 text-left">
                <span className="w-8 h-8 rounded-lg grid place-items-center shrink-0" style={{ background: `${row.color}1a`, color: ink(row.color) }}>
                  <BarChart2 className="w-4 h-4" />
                </span>
                <span className="min-w-0 flex-1 basis-24">
                  <span className="text-xs font-bold text-gray-800 block">{row.label}</span>
                  <span className="text-[11px] text-gray-400 line-clamp-2 block">{row.hint}</span>
                </span>
                <Amount {...money} value={row.amount}
                  className={`text-xs text-right shrink-0 whitespace-nowrap ml-auto ${row.amount < 0 ? 'text-red-600' : 'text-gray-800'}`} />
              </button>
            ))}
          </div>
          <div className="mt-3 pt-2 border-t border-gray-100">
            <RingRow pct={revenuePct} color="#1e88e5" title="Pre-tax Revenue After Discount"
              onOpen={() => openReport('discount-summary-report')}>
              <Amount {...money} value={health.revenueAfterDiscount ?? 0} className="text-xs text-gray-900 block" />
              <span className="text-[11px] text-gray-400">before discount: PKR {(health.revenuePrior ?? 0).toLocaleString()}</span>
            </RingRow>
          </div>
        </div>

        {/* The fourth card would wrap into a row of its own inside twelve columns, so expense
            and tax stack in one third and the band stays three columns tall. */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          <div className="card-xenith p-4">
            <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-1">
              <h3 className="card-title">Expense Breakdown</h3>
              <SectionLink label="Expense Heads" tone="#ff9f1c" onClick={() => openReport('voucher-expense-head-report')} />
            </div>
            <XenithDoughnutChart labels={(data?.expenseBreakdown ?? []).map((e: any) => e.label)}
              data={(data?.expenseBreakdown ?? []).map((e: any) => e.amount)}
              colors={(data?.expenseBreakdown ?? []).map((e: any) => e.color)}
              reports={(data?.expenseBreakdown ?? []).map((e: any) => e.report)}
              onReport={openReport}
              centerTitle="TOTAL SPEND" height={200} currency="PKR" />
          </div>

          <div className="card-xenith p-4">
            <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-2">
              <h3 className="card-title">Tax Position</h3>
              <SectionLink label="Filing Report" tone="#e63946" onClick={() => openReport('tax-balance-by-column')} />
            </div>
            <div className="space-y-1 text-xs">
              <div className="flex items-center px-2.5 pb-1 text-[10px] font-black uppercase tracking-wider text-gray-400">
                <span className="min-w-0 flex-1">Period</span>
                <span className="col-num">Collected</span>
                <span className="col-num">Paid</span>
                <span className="col-num">Net</span>
              </div>
              <p className="px-2.5 text-[10px] leading-snug text-gray-400">
                Thousands of PKR. Net is collected less paid — a negative figure means the book owes you.
              </p>
              {(tax?.rows ?? []).map((r: any) => (
                <div key={r.period} className="flex items-center rounded-lg px-2.5 py-1.5 bg-gray-50/70 border border-gray-100">
                  <span className="min-w-0 flex-1 text-gray-600 font-medium break-words">{r.period}</span>
                  <span className="col-num tabular-nums font-bold text-emerald-600">{(Number(r.outputTax) / 1000).toFixed(1)}</span>
                  <span className="col-num tabular-nums text-[11px] text-gray-500">{(Number(r.inputTax) / 1000).toFixed(1)}</span>
                  <span className={`col-num tabular-nums font-black ${Number(r.payable) < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                    {(Number(r.payable) / 1000).toFixed(1)}
                  </span>
                </div>
              ))}
              {!tax?.rows?.length && <p className="text-xs text-gray-400">Loading tax figures…</p>}
            </div>
          </div>
        </div>
      </div>
      </>)}

      {/* THE DAY'S WORK — money owed, money arrived, goods gone */}
      {on('collections') && (<>
      <Section label="Collections & Dispatch" tone="#e63946"
        right={<SectionLink label="Transaction List" tone="#e63946" onClick={() => openReport('transaction-list-report')} />} />
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        <div className="lg:col-span-8 card-xenith p-4 lg:self-start">
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2">
            <div className="flex items-center gap-2 min-w-0">
              <Receipt className="w-4 h-4 text-[#2ec4b6] shrink-0" />
              <div className="min-w-0">
                <h3 className="card-title leading-tight">Money Customers Owe · By Age</h3>
                <span className="block text-[11px] text-gray-400 leading-tight mt-0.5">Open bills less the returns and receipts on each account, by age</span>
              </div>
            </div>
            <div className="text-right ml-auto shrink-0">
              <span className="block text-[10px] font-black text-gray-400 uppercase tracking-wider">Open Bills</span>
              <span className="block text-sm font-black text-gray-900 tabular-nums">{aging.openDocs ?? 0} bills
                <span className="text-[11px] font-semibold text-gray-400"> · oldest {aging.oldestDays ?? 0} days</span>
              </span>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-end justify-between gap-2">
            <div className="min-w-0">
              <span className="block text-[10px] font-black text-gray-400 uppercase tracking-wider">Total Receivable</span>
              <Amount {...money} value={aging.totalDue ?? 0} className="text-2xl text-gray-900 block leading-tight" />
            </div>
            <button onClick={() => openReport('order-wise-aging-detail')}
              className="text-[11px] font-bold text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1 whitespace-nowrap hover:bg-red-100 transition-colors">
              {aging.atRiskPct ?? 0}% at risk · {aging.atRiskLabel ?? ''}
            </button>
          </div>

          <div className="mt-2 h-2 rounded-full overflow-hidden flex gap-0.5 bg-gray-100">
            {agingBands.map(([label, value, color]) => (
              <div key={label} title={`${label} · ${value}`} className={`${color} h-full rounded-sm transition-all duration-700`}
                style={{ width: `${(value / agingTotal) * 100}%` }} />
            ))}
          </div>

          <div className="mt-3 grid sm:grid-cols-2 gap-x-6 gap-y-1 text-xs">
            {agingBands.map(([label, value, color, tag]) => (
              <button key={label} onClick={() => openReport('order-wise-aging-detail')}
                className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5 py-1.5 border-b border-gray-50 hover:border-teal-200 group">
                <span className="flex items-center gap-2 min-w-0 max-w-full">
                  <span className={`w-1.5 h-3.5 rounded shrink-0 ${color}`} />
                  <span className="font-medium text-gray-700 truncate group-hover:text-[#178a80] transition-colors">{label}</span>
                  {tag && <span className={`shrink-0 text-[10px] font-bold px-1 rounded ${tag === 'Critical' ? 'text-red-600 bg-red-50' : 'text-orange-600 bg-orange-50'}`}>{tag}</span>}
                </span>
                <Amount {...money} value={value} className="text-xs text-gray-900 text-right shrink-0 whitespace-nowrap ml-auto" />
              </button>
            ))}
          </div>

          <div className="mt-3 pt-2 border-t border-gray-100">
            <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-1.5">
              <h4 className="text-[10px] font-black uppercase tracking-[.12em] text-gray-400">The oldest bills on the book</h4>
              <SectionLink label="Due List" tone="#e63946" onClick={() => openReport('customer-due-list-report')} />
            </div>
            <div className="grid sm:grid-cols-2 gap-x-6 text-xs">
              {oldestDues.map((r: any, i: number) => (
                <button key={i} onClick={() => onNavigate('sales-invoices')}
                  className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5 py-1.5 border-b border-gray-50 hover:bg-red-50/40 rounded px-1 transition-colors text-left">
                  <span className="flex items-baseline gap-2 min-w-0 max-w-full">
                    <span className="font-semibold text-gray-800 truncate">{r.partyName}</span>
                    <span className="text-[11px] text-gray-400 shrink-0">{r.number} · {r.days} days</span>
                  </span>
                  <span className="flex items-baseline gap-2 shrink-0 ml-auto">
                    <Amount {...money} value={r.balance} className="text-xs text-red-600 whitespace-nowrap" />
                    <span className="text-[10px] font-black uppercase text-gray-400">
                      {r.dueDate && r.dueDate !== '—' ? `due ${r.dueDate}` : `of ${r.date}`}
                    </span>
                  </span>
                </button>
              ))}
              {!oldestDues.length && <p className="text-xs text-gray-400">Nothing owed on approved bills.</p>}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-3">
          <div className="card-xenith p-4">
            <h3 className="card-title mb-2">Documents Waiting On You</h3>
            <div className="grid grid-cols-2 gap-2">
              {pipeline.map(p => (
                <button key={p.label} onClick={() => onNavigate(p.tab)}
                  className="rounded-lg border border-gray-100 bg-gray-50/60 px-2.5 py-2 text-left hover:bg-white hover:shadow-sm transition-all duration-300">
                  <span className="block text-lg font-black tabular-nums leading-none" style={{ color: ink(p.tone) }}>{p.value}</span>
                  <span className="block text-[11px] text-gray-500 leading-tight mt-1">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="card-xenith p-4">
            <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-1">
              <h3 className="card-title">Collected &amp; Dispatched</h3>
              <SectionLink label="Delivery Status" tone="#ff9f1c" onClick={() => openReport('sale-invoice-delivery-status-report')} />
            </div>
            <div className="space-y-1">
              <RingRow pct={collectionPct} color="#2ec4b6" title="Cash Collected Against Bills"
                onOpen={() => openReport('collected-on-sale-report')}>
                <Amount {...money} value={health.collections ?? 0} className="text-xs text-[#178a80] block" />
                <span className="text-[11px] text-gray-400">of PKR {Math.round(health.collectionsTarget ?? 0).toLocaleString()} billed</span>
              </RingRow>
              <RingRow pct={dispatchedPct} color="#ff9f1c" title="Billed Goods Dispatched"
                onOpen={() => openReport('sale-invoice-delivery-status-report')}>
                <div className="flex items-baseline gap-1">
                  <span className="text-xs font-bold text-gray-900">{health.dispatchedBillsCount ?? 0}</span>
                  <span className="text-[11px] text-gray-400">of {health.totalBills ?? 0} bills gone</span>
                </div>
                <span className="text-[11px] text-amber-600 font-bold">
                  {health.undispatchedBillsCount ?? 0} still to send · PKR {Math.round(health.undispatchedBillsAmount ?? 0).toLocaleString()}
                </span>
              </RingRow>
            </div>
          </div>
        </div>
      </div>
      </>)}

      {/* WHO IS BUYING */}
      {on('buyers') && (<>
      <Section label="Who Is Buying" tone="#2ec4b6"
        right={<SectionLink label="Sales Performance Report" tone="#2ec4b6" onClick={() => openReport('sales-performance-report')} />} />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 reveal">
        <RankCard title="Top Customers" subtitle="All time · approved bills only" rows={data?.topCustomers ?? []}
          tone="#1e88e5" onViewAll={() => onNavigate('customers')} {...money} />
        <RankCard title="Top Products" subtitle="Units sold on approved bills" rows={data?.topProducts ?? []}
          tone="#2ec4b6" onViewAll={() => openReport('product-wise-sales-report')} {...money} />
        <RankCard title="Sales Persons" subtitle="Every bill on the book, drafts included"
          rows={(agents?.rows ?? []).map((r: any) => {
            const booked = Number(r.netAfterReturn ?? r.grossDiff ?? 0);
            const all = (agents?.rows ?? []).reduce((s: number, x: any) => s + Number(x.netAfterReturn ?? x.grossDiff ?? 0), 0);
            return {
              name: r.agent, amount: booked, pct: all ? Math.round(booked / all * 100) : 0,
              extra: `${r.invoices} inv · PKR ${Number(r.avgValue ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })} average bill`
            };
          })}
          tone="#845ec2" onViewAll={() => onNavigate('sales-persons')} {...money} />
        <div className="card-xenith p-4 lg:self-start">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4" style={{ color: ink('#ff9f1c') }} />
              <div>
                <h3 className="card-title leading-tight">Stock Watch</h3>
                <span className="text-[11px] text-gray-400">Thinnest stock against its reorder level</span>
              </div>
            </div>
            <button onClick={() => openReport('low-inventory-list-report')}
              className="group inline-flex items-center gap-1 text-xs font-bold transition-colors" style={{ color: ink('#ff9f1c') }}>
              View All
              <ArrowRight className="w-3 h-3 transition-transform duration-300 group-hover:translate-x-0.5" />
            </button>
          </div>
          <div className="space-y-2">
            {(data?.stockWatch ?? []).map((s: any) => (
              <div key={s.name} className="rounded-lg border border-gray-100 px-3 py-2 hover:border-amber-200 hover:bg-amber-50/30 transition-all duration-300">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-gray-800 truncate">{s.name}</span>
                  <span className="font-black text-gray-900 tabular-nums">{s.qty} {s.unit}</span>
                </div>
                <div className="mt-1.5 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${Math.min(100, (s.qty / Math.max(1, s.reorderLevel)) * 50)}%`, background: s.qty <= s.reorderLevel ? '#e63946' : '#2ec4b6' }} />
                </div>
                <div className="mt-1 flex justify-between text-[10px] text-gray-400">
                  <span>reorder at {s.reorderLevel}</span>
                  <span>{s.qty <= s.reorderLevel ? 'Reorder now' : 'Healthy'}</span>
                </div>
              </div>
            ))}
            {!data?.stockWatch?.length && <p className="text-xs text-gray-400">No stock alerts.</p>}
          </div>
        </div>
      </div>
      </>)}

      {/* THE BOOK'S OWN RECORD */}
      {on('activity') && (<>
      <Section label="Activity & Business Summary" tone="#5f7cff"
        right={<SectionLink label="Transaction List" tone="#5f7cff" onClick={() => openReport('transaction-list-report')} />} />
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        <div className="lg:col-span-8 card-xenith p-4 lg:self-start">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-3">
            <div className="flex items-center gap-2">
              <h3 className="card-title">Business Summary</h3>
              <span className="text-[11px] text-gray-400">Every register, counted as of today</span>
            </div>
            <SectionLink label="Full Report" tone="#5f7cff" onClick={() => openReport('business-summary-report')} />
          </div>
          <div className="grid sm:grid-cols-2 gap-x-6 text-xs">
            {(summary?.rows ?? []).map((r: any) => (
              <div key={r.metric} className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5 pb-1.5 border-b border-gray-50">
                <span className="flex items-center gap-1.5 min-w-0 max-w-full text-gray-600">
                  <span className="text-[10px] font-black text-gray-400 bg-gray-100 rounded px-1 py-px tabular-nums shrink-0">{r.count}</span>
                  <span className="truncate">{r.metric}</span>
                </span>
                <Amount {...money} value={r.value} className="text-xs text-gray-900 text-right shrink-0 whitespace-nowrap ml-auto" />
              </div>
            ))}
            {!summary?.rows?.length && <p className="text-xs text-gray-400">Loading summary…</p>}
          </div>
        </div>

        <div className="lg:col-span-4 card-xenith p-4 flex flex-col lg:self-start">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-2">
            <h3 className="card-title">Recent Activity</h3>
            <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />Live
            </span>
          </div>
          <div className="space-y-2 flex-1">
            {(data?.recentActivities ?? []).slice(0, 6).map((act: any, i: number) => (
              <div key={i} className="flex flex-wrap items-start gap-x-2.5 gap-y-0.5 text-xs pb-2 border-b border-gray-50 last:border-0">
                <span className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 grid place-items-center shrink-0">
                  <FileText className="w-3.5 h-3.5" />
                </span>
                <div className="min-w-0 flex-1 basis-32">
                  <div className="font-medium text-gray-800 line-clamp-2">{act.description}</div>
                  <div className="flex items-center gap-1.5 text-[11px] text-gray-400 mt-0.5">
                    <span className="bg-indigo-50 text-indigo-700 px-1.5 rounded font-semibold">{act.source}</span>
                    <span>· {act.time}</span>
                  </div>
                </div>
                {act.amount && <span className="text-xs font-bold text-gray-900 tabular-nums text-right ml-auto shrink-0 whitespace-nowrap">PKR {act.amount}</span>}
              </div>
            ))}
          </div>
          <button onClick={() => openReport('audit-log')}
            className="mt-2 w-full py-1.5 rounded-lg bg-gray-50 hover:bg-gray-100 border border-gray-200 text-xs font-bold text-gray-600 transition-colors duration-200">
            Show More (Audit Log)
          </button>
        </div>
      </div>
      </>)}

      {/* REPORT SHORTCUTS */}
      {on('shortcuts') && (<>
      <Section label="Report Shortcuts" tone="#5f7cff"
        right={<SectionLink label="Open Report Library" tone="#5f7cff" onClick={() => onNavigate('reports')} />} />
      <div className="card-xenith p-4">
        <div className="flex flex-wrap gap-2">
          {[
            ['Sale Invoice Report', 'sale-invoice-report'], ['Customer Ledger', 'customer-ledger'],
            ['Customer Balance', 'customer-balance-report'], ['Product Sales', 'product-sales-report'],
            ['Receive Payment', 'receive-payment-report'], ['Purchase Invoice', 'purchase-invoice-report'],
            ['Vendor Balance', 'vendor-balance-report'], ['Cash Payment Vouchers', 'cash-voucher-report'],
            ['Stock Valuation', 'stock-valuation-report'], ['Stock Movement', 'stock-movement'],
            ['Balance Sheet', 'balance-sheet'], ['Profit and Loss', 'profit-and-loss'],
            ['Tax Balance', 'tax-balance'], ['Expense Heads', 'voucher-expense-head-report'],
            ['Journal Entries', 'journal-entry-report'], ['Audit Log', 'audit-log']
          ].map(([label, key]) => (
            <button key={key} onClick={() => openReport(key)}
              className="group inline-flex items-center gap-1.5 text-xs font-semibold text-gray-700 bg-gray-50 hover:bg-white border border-gray-200 hover:border-blue-200 rounded-full px-3 py-1.5 transition-all duration-300 hover:-translate-y-px hover:shadow-sm">
              <BookOpen className="w-3 h-3 text-gray-400 group-hover:text-[#5f7cff] transition-colors" />
              {label}
            </button>
          ))}
        </div>
      </div>
      </>)}

      {/* Every band cleared is a decision somebody made on the Roles screen, so the page owns
          up to it instead of reading as a build that forgot to draw itself. */}
      {BANDS.every(b => !on(b)) && (
        <div className="nb-card px-4 py-8 text-center">
          <p className="text-sm font-bold text-gray-700">This desk has no bands on it.</p>
          <p className="mt-1 text-xs text-gray-500">
            An administrator shows parts of it under Setup → User Roles → Executive Desk.
          </p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
