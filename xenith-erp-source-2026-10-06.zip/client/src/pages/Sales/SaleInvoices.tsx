import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { BulkPrintingModal } from '../../components/modals/BulkPrintingModal';
import { DateWindow, ExportPair, IconAction, ListToolbar, RegisterStat, SearchBox, StatStrip, StatusPills, TableEmpty } from '../Masters/masterUi';
import { DocForm } from '../Docs/DocForm';
import { docKind } from '../Docs/docKinds';
import { BizDoc } from '../../types';
import { deleteDoc, getDoc, getDocs, setDocStatus } from '../../services/docs.service';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { printDocsWithLetterhead } from '../../utils/printWithLetterhead';
import { Plus, FileText, Printer, CheckCircle2, Ban, Pencil, RotateCcw, Trash2, ArrowLeft, X } from 'lucide-react';
import { useScreenReload } from '../../utils/screenReload';

interface Props {
  openNewNonce?: number;
  onConsumed?: () => void;
}

const kind = docKind('sale-invoice');

// A register row whose money the book never filled in is a blank, not a crash: this formatter
// is used by the tiles, the table and the workbook, and one of them throwing takes the screen.
const money = (v: number) => (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Rupees are summed from line money that can carry more decimals than the sheet prints, so
// one shared round keeps a tile, the footer and the workbook off each other's totals.
const rd = roundMoney;

const KPI_TONES: Record<string, { bar: string; value: string }> = {
  blue: { bar: 'bg-[#1e88e5]', value: 'text-gray-800' },
  gray: { bar: 'bg-gray-300', value: 'text-gray-800' },
  emerald: { bar: 'bg-emerald-500', value: 'text-emerald-600' },
  amber: { bar: 'bg-amber-400', value: 'text-amber-600' }
};

const Kpi: React.FC<{
  label: string; value: string; prefix?: string; count?: boolean; tone: keyof typeof KPI_TONES;
  note?: string; title?: string;
}> = ({ label, value, prefix, count, tone, note, title }) => (
  <div className="nb-card px-3 py-2.5 flex flex-col min-w-0 overflow-hidden" title={title}>
    <span className={`h-1 -mx-3 -mt-2.5 mb-2 ${KPI_TONES[tone].bar}`} />
    <div className="text-[11px] font-semibold uppercase tracking-wide text-gray-500 truncate">{label}</div>
    <div className={`mt-0.5 font-bold tabular-nums leading-tight break-words ${count ? 'text-2xl' : 'text-lg'} ${KPI_TONES[tone].value}`}>
      {prefix && <span className="text-xs font-semibold text-gray-400 mr-1">{prefix}</span>}
      {value}
    </div>
    {/* The base is written where the number is read, because a figure that quietly counts
        only Approved paper is the mistake the user has asked me to hunt everywhere else. */}
    {note && <div className="mt-0.5 text-[10px] leading-snug text-gray-400">{note}</div>}
  </div>
);

export const SaleInvoices: React.FC<Props> = ({ openNewNonce = 0, onConsumed }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { user } = useAuth();
  // An invoice is approved by an administrator, never by the salesperson who raised it.
  const approvalHeldByAdmin = !!user?.salesmanScoped;
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [invoices, setInvoices] = useState<BizDoc[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox holds its own text, so remounting it is how "Clear every filter" empties the
  // box as well as the state the table answers to.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [statusFilter, setStatusFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [selected, setSelected] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [showBulkPrint, setShowBulkPrint] = useState(false);
  const [notice, setNotice] = useState('');

  // The register is fetched whole and the status is picked on the screen: asking the server
  // for one status would leave the other pills reading zero while their rows exist.
  const requestId = useRef(0);
  const refresh = useCallback(() => {
    const at = ++requestId.current;
    setLoading(true);
    getDocs(kind.resource, tenantSlug, branchId, search, '').then(r => {
      if (at === requestId.current) setInvoices(r.data);
    }).catch(e => {
      // An empty register and a register that could not be read look the same until the
      // screen says which one it is.
      if (at === requestId.current) setNotice((e as Error).message || 'The invoice register could not be read');
    }).finally(() => { if (at === requestId.current) setLoading(false); });
  }, [tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  useEffect(() => {
    if (openNewNonce > 0) {
      setEditId(null);
      setView('form');
      onConsumed?.();
    }
  }, [openNewNonce, onConsumed]);

  // In view = the register after search and the date window, before the status pill, so the
  // banner and the pills do not change when a state is picked. Money counts Approved paper
  // only — a draft or a pending challan is work in hand, not a receivable — and each figure
  // says so in its own label rather than in a tooltip the reader has to hunt for.
  const inView = useMemo(() => invoices.filter(d =>
    (!fromDate || d.date >= fromDate) && (!toDate || d.date <= toDate)
  ), [invoices, fromDate, toDate]);

  const visible = useMemo(() => (statusFilter ? inView.filter(d => d.status === statusFilter) : inView), [inView, statusFilter]);

  const approved = useMemo(() => inView.filter(d => d.status === 'Approved'), [inView]);
  const sumOver = (rows: BizDoc[], get: (d: BizDoc) => number) => rd(rows.reduce((s, d) => s + get(d), 0));
  const totals = {
    net: sumOver(approved, d => d.net),
    received: sumOver(approved, d => d.paymentAmount),
    balance: sumOver(approved, d => d.balance)
  };

  const STATUS_ORDER = ['', 'Draft', 'Pending', 'Approved', 'Void'];
  const statusCounts = STATUS_ORDER.map(value => ({
    value,
    label: value || 'All',
    count: value ? inView.filter(d => d.status === value).length : inView.length
  }));

  // The pills already wear each status count, so the chip row carries only the one number
  // the table itself answers to — the same figure twice on one screen reads as doubt.
  const stats: RegisterStat[] = [
    {
      label: 'Invoices', value: statusFilter ? `${visible.length} of ${inView.length}` : String(inView.length),
      title: 'Rows this register holds for the search and the dates in view'
    },
    ...(selected.length ? [{ label: 'Ticked', value: selected.length, tone: 'ok' as const }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    statusFilter && `status ${statusFilter}`,
    (fromDate || toDate) && `dates ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatusFilter('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const selectedDocs = visible.filter(d => selected.includes(d.id));
  // The rows the footer, the workbook and the printer all speak for: the ticked ones when
  // there are any, otherwise everything the filters left on screen. One list, three outputs.
  const exportRows = selectedDocs.length ? selectedDocs : visible;
  const shown = {
    net: sumOver(exportRows, d => d.net),
    received: sumOver(exportRows, d => d.paymentAmount),
    balance: sumOver(exportRows, d => d.balance)
  };
  const printSelected = () => {
    if (!selectedDocs.length) { setNotice('Tick at least one invoice to print.'); return; }
    printDocsWithLetterhead(selectedDocs, tenantSlug, branchId, { sheet: kind.sheet, label: 'Sale Invoice', currency })
      .catch(e => setNotice((e as Error).message || 'Those invoices could not be printed'));
  };

  const openNew = () => { setEditId(null); setView('form'); };
  const openEdit = (id: number) => { setEditId(id); setView('form'); };

  // Has any of this bill's goods physically left? The server answers with the same measure the
  // dispatch board, the dashboards and the delivery reports read — a challan counts only once it
  // is Approved, so a draft challan holding the quantity does not strike these buttons out.
  const served = (inv: BizDoc) => !!inv.dispatchState && inv.dispatchState !== 'Not Dispatched';

  // A status write is one press of paper the whole office reads, so the row is locked while
  // its own request is running: a double-tap used to send the change twice.
  const [busyId, setBusyId] = useState<number | null>(null);

  const changeStatus = (id: number, status: BizDoc['status']) => {
    if (busyId !== null) return;
    setBusyId(id);
    setNotice('');
    setDocStatus(kind.resource, tenantSlug, branchId, id, status)
      .then(() => { setNotice(`Invoice marked ${status}.`); refresh(); })
      .catch(e => setNotice((e as Error).message))
      .finally(() => setBusyId(null));
  };

  const remove = (inv: BizDoc) => {
    if (!window.confirm(`Delete invoice ${inv.number}?`)) return;
    if (busyId !== null) return;
    setBusyId(inv.id);
    setNotice('');
    deleteDoc(kind.resource, tenantSlug, branchId, inv.id)
      .then(() => { setNotice(`${inv.number} deleted.`); refresh(); })
      .catch(e => setNotice((e as Error).message))
      .finally(() => setBusyId(null));
  };

  const closeBulkPrint = (f?: {
    customer: string | null; warehouseId: string | null; status: string | null;
    filter: string; from: string; to: string; isPrintingHalfPage: boolean;
  }) => {
    setShowBulkPrint(false);
    if (!f) return;
    getDocs(kind.resource, tenantSlug, branchId, f.filter, f.status || '').then(r => {
      const docs = r.data.filter(d =>
        d.date >= f.from && d.date <= f.to &&
        (!f.customer || String(d.partyName || '').toLowerCase().includes(f.customer!.toLowerCase())) &&
        (!f.warehouseId || d.warehouseId === Number(f.warehouseId)));
      if (!docs.length) { window.alert('No invoice matches those filters.'); return; }
      return printDocsWithLetterhead(docs, tenantSlug, branchId, {
        sheet: kind.sheet, label: 'Sale Invoice', currency,
        paper: f.isPrintingHalfPage ? 'A5' : 'A4'
      });
    }).catch(e => setNotice((e as Error).message || 'Those invoices could not be printed'));
  };

  // The template set for a sale invoice under Settings decides the design, so pressing
  // print on a row puts paper on the printer instead of opening a dialogue.
  const printOne = (inv: BizDoc) => getDoc(kind.resource, tenantSlug, branchId, inv.id)
    .then(one => printDocsWithLetterhead([one], tenantSlug, branchId,
      { sheet: kind.sheet, label: 'Sale Invoice', currency }))
    .catch(e => setNotice((e as Error).message || `${inv.number} could not be printed`));

  const exportCols: ExportColumn<BizDoc>[] = [
    { label: 'Invoice Number', value: d => d.number },
    { label: 'Customer', value: d => d.partyName },
    // The permit number the bill was written with — every challan of the consignment repeats it.
    { label: 'Gate Pass', value: d => d.gatePass || '—' },
    { label: 'Date', value: d => d.date },
    { label: 'Due Date', value: d => d.dueDate },
    { label: 'Status', value: d => d.status },
    { label: `Net (${currency})`, value: d => money(d.net), align: 'right' },
    { label: `Received (${currency})`, value: d => money(d.paymentAmount), align: 'right' },
    { label: `Balance (${currency})`, value: d => money(d.balance), align: 'right' }
 ];

  if (view === 'form') {
    return (
      <div className="space-y-3">
        <button onClick={() => setView('list')} className="btn-xenith-outline">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Invoices</span>
        </button>
        <DocForm
          key={`${editId ?? 'new'}`}
          kind={kind}
          docId={editId}
          onDone={() => { refresh(); setView('list'); }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* The banner reads the register the way the ledger does — money that is actually
          booked, which is Approved paper only — and says so in each label. A draft or a
          pending challan is work in hand, not a receivable, so it never enters these four
          figures even though its row is listed below. */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi label="Invoices in view" value={String(inView.length)} count tone="blue"
          note={activeFilters.length ? `${activeFilters.length} filter${activeFilters.length === 1 ? '' : 's'} in place` : 'Every invoice on this branch'} />
        <Kpi label="Net (Approved)" value={money(totals.net)} prefix={currency} tone="gray"
          note={`${approved.length} approved paper${approved.length === 1 ? '' : 's'} in view`}
          title="Sum of the net amount on Approved invoices. Draft, Pending and Void papers are not counted." />
        <Kpi label="Received (Approved)" value={money(totals.received)} prefix={currency} tone="emerald"
          note="Tender already booked against those invoices" />
        <Kpi label="Balance Due (Approved)" value={money(totals.balance)} prefix={currency} tone="amber"
          note="Net less received, on the same Approved paper" />
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Sale Invoices</h2>
            <p className="text-xs text-gray-500">Create, approve and print customer invoices</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel={kind.addLabel} onAdd={openNew} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by number, customer, gate pass, reference or product" onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter} counts={statusCounts} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <button onClick={() => setShowBulkPrint(true)} className="btn-xenith-outline" title="Bulk print invoices on the company letterhead">
              <Printer className="w-3.5 h-3.5" />
              <span>Bulk Print / PDF</span>
            </button>
            <ExportPair title="Sale Invoices" filename="sale-invoices" columns={exportCols} rows={exportRows}
              footer={footerRow(exportCols.length, {
                0: `Total (${exportRows.length})`,
                6: money(shown.net),
                7: money(shown.received),
                8: money(shown.balance)
              })} landscape />
          </span>
        </div>

        {selected.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/70">
            <span className="text-[11px] font-bold text-gray-600">{selected.length} of {visible.length} ticked</span>
            <button type="button" onClick={printSelected} className="btn-xenith-primary">
              <Printer className="w-3.5 h-3.5" /> Print Selected / PDF
            </button>
            <button type="button" onClick={() => setSelected([])} className="btn-xenith-outline">
              <X className="w-3.5 h-3.5" /> Clear selection
            </button>
            <span className="text-[11px] text-gray-500">Print and export both follow the tickbox.</span>
          </div>
        )}

        {notice && (
          <div className="mx-4 mb-3 text-[12px] font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded px-3 py-2 flex items-center justify-between">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice('')} aria-label="Dismiss"><X className="w-3.5 h-3.5" /></button>
          </div>
        )}

        {approvalHeldByAdmin && inView.some(d => d.status === 'Pending') && (
          <div className="mx-4 mb-3 text-[12px] text-gray-500 bg-gray-50 border border-gray-200 rounded px-3 py-2">
            {inView.filter(d => d.status === 'Pending').length} of your invoice(s) is waiting for an administrator to approve it.
          </div>
        )}
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
        <table className="xenith-table">
          <thead className="sticky top-0 z-10">
            <tr>
              <th className="w-8">
                <input type="checkbox" aria-label="Select every invoice on screen"
                  checked={visible.length > 0 && selected.length === visible.length}
                  onChange={e => setSelected(e.target.checked ? visible.map(d => d.id) : [])}
                  className="accent-[#1e88e5]" />
              </th>
              <th>Invoice Number</th>
              <th>Customer</th>
              <th>Gate Pass</th>
              <th>Date</th>
              <th>Due Date</th>
              <th>Status</th>
              <th className="text-right">Net (PKR)</th>
              <th className="text-right">Received</th>
              <th className="text-right">Balance</th>
              <th className="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 6 }).map((_, i) => (
              <tr key={i}>
                <td colSpan={11}>
                  <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} />
                </td>
              </tr>
            ))}
            {!loading && !visible.length && (
              <TableEmpty colSpan={11} noun="invoices" filters={activeFilters} cleared={clearAll}
                addLabel={invoices.length ? undefined : kind.addLabel} onAdd={openNew} />
            )}
            {!loading && visible.map(inv => (
              <tr key={inv.id} className={inv.status === 'Void' ? 'opacity-50' : ''}>
                <td>
                  <input type="checkbox" aria-label={`Select ${inv.number}`} checked={selected.includes(inv.id)}
                    onChange={e => setSelected(s => (e.target.checked ? [...s, inv.id] : s.filter(x => x !== inv.id)))}
                    className="accent-[#1e88e5]" />
                </td>
                <td className="font-bold text-blue-600 whitespace-nowrap">
                  <button onClick={() => openEdit(inv.id)} className="flex items-center gap-1.5 hover:underline">
                    <FileText className="w-3.5 h-3.5 text-gray-400" />
                    <span>{inv.number}</span>
                  </button>
                </td>
                <td className="font-medium text-gray-800">{inv.partyName}</td>
                <td className="whitespace-nowrap font-bold text-emerald-700">{inv.gatePass || '—'}</td>
                <td className="whitespace-nowrap">{inv.date}</td>
                <td className="whitespace-nowrap">{inv.dueDate}</td>
                <td>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    inv.status === 'Approved' ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                    : inv.status === 'Void' ? 'bg-red-50 text-red-600 border border-red-200 line-through'
                    : inv.status === 'Pending' ? 'bg-amber-50 text-amber-600 border border-amber-200'
                    : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    {inv.status}
                  </span>
                </td>
                <td className="text-right font-bold text-gray-800">{money(inv.net)}</td>
                <td className="text-right text-emerald-600">{money(inv.paymentAmount)}</td>
                <td className={`text-right font-medium ${inv.balance > 0 ? 'text-amber-600' : 'text-gray-500'}`}>{money(inv.balance)}</td>
                <td className="text-center whitespace-nowrap">
                  <div className="flex items-center justify-center">
                    <IconAction title={`Print ${inv.number} or save as PDF`} onClick={() => printOne(inv)}>
                      <Printer className="w-4 h-4" />
                    </IconAction>
                    <IconAction title={`Edit ${inv.number}`} tone="primary" onClick={() => openEdit(inv.id)}>
                      <Pencil className="w-4 h-4" />
                    </IconAction>
                    {inv.status !== 'Approved' && inv.status !== 'Void' && !approvalHeldByAdmin && (
                      <IconAction title={`Approve ${inv.number}`} tone="success" disabled={busyId === inv.id}
                        onClick={() => changeStatus(inv.id, 'Approved')}>
                        <CheckCircle2 className="w-4 h-4" />
                      </IconAction>
                    )}
                    {/* Approved paper is booked paper, so its history stays the administrator's.
                        And a bill whose goods have already gone out on a signed challan is the
                        record of that delivery: its Void and Delete buttons stand down and say
                        why, the same measure the register itself refuses on. */}
                    {!(approvalHeldByAdmin && inv.status === 'Approved') && (inv.status !== 'Void' ? (
                      served(inv) ? (
                        <IconAction title={`${inv.number} is already delivered against ${inv.dispatchState === 'Fully Dispatched' ? 'all of it' : 'part of it'} — a bill the customer has taken goods on cannot be voided. Void its challan first, or cancel the sale with a Sales Return.`} disabled>
                          <Ban className="w-4 h-4" />
                        </IconAction>
                      ) : (
                        <IconAction title={`Void ${inv.number}`} tone="danger" disabled={busyId === inv.id} onClick={() => changeStatus(inv.id, 'Void')}>
                          <Ban className="w-4 h-4" />
                        </IconAction>
                      )
                    ) : (
                      <IconAction title={`Reopen ${inv.number} as draft`} disabled={busyId === inv.id} onClick={() => changeStatus(inv.id, 'Draft')}>
                        <RotateCcw className="w-4 h-4" />
                      </IconAction>
                    ))}
                    {!(approvalHeldByAdmin && inv.status === 'Approved') && (
                      served(inv) ? (
                        <IconAction title={`${inv.number} has goods delivered against its challans, so it cannot be deleted — the delivery would be left answering to nothing`} disabled>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ) : (
                        <IconAction title={`Delete ${inv.number}`} tone="danger" disabled={busyId === inv.id} onClick={() => remove(inv)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      )
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
          {!!visible.length && !loading && (
            <tfoot>
              <tr className="bg-gray-50/80">
                <td />
                <td colSpan={6} className="font-black text-gray-800">
                  {/* The footer sums the rows this screen is showing, whatever state they are
                      in, and says how many; the banner above deliberately counts only the
                      booked paper, and its labels say that too. */}
                  Total ({selected.length ? `${selected.length} selected` : `${visible.length} on screen`}
                  {statusFilter ? ` · ${statusFilter}` : ''})
                </td>
                <td className="text-right tabular-nums font-black text-gray-800">{money(shown.net)}</td>
                <td className="text-right tabular-nums font-black text-gray-800">{money(shown.received)}</td>
                <td className="text-right tabular-nums font-black text-gray-800">{money(shown.balance)}</td>
                <td />
              </tr>
            </tfoot>
          )}
        </table>
        </div>
      </div>

      <BulkPrintingModal isOpen={showBulkPrint} onClose={closeBulkPrint} documentType="SaleInvoice" />
    </div>
  );
};
