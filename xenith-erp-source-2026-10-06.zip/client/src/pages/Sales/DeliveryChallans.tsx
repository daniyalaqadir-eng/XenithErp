import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { SearchBox, StatStrip, RegisterStat } from '../Masters/masterUi';
import { docKind } from '../Docs/docKinds';
import { DispatchApprovalModal } from '../../components/modals/DispatchApprovalModal';
import { BoardFolder, BoardRow, getDispatchBoard, getDoc, setDocStatus } from '../../services/docs.service';
import { printDocsWithLetterhead } from '../../utils/printWithLetterhead';
import { CheckCircle2, Lock, Pencil, Printer, Truck, Warehouse, X } from 'lucide-react';
import { useScreenReload } from '../../utils/screenReload';

const challanKind = docKind('sale-delivery');

interface Props {
  // Which folder of the board is open. A folder is a warehouse: the staff of one gate work
  // the loads that leave their own gate, so the board shows only their challans under it.
  warehouseId?: number | null;
  onFolder?: (id: number | null) => void;
  onNavigate?: (tab: string) => void;
}

// Quantities are boxes and cartons, not rupees — a half carton is written as it stands.
const num = (v: number) => roundMoney(v).toLocaleString(undefined, { maximumFractionDigits: 2 });

const STATE_TONE: Record<BoardRow['state'], string> = {
  'Not Dispatched': 'bg-gray-50 text-gray-600 border-gray-200',
  'Partial Dispatched': 'bg-amber-50 text-amber-700 border-amber-200',
  'Fully Dispatched': 'bg-emerald-50 text-emerald-700 border-emerald-200'
};

const Chip: React.FC<{ label: string; value: number; tone: 'gray' | 'emerald' | 'amber' }> = ({ label, value, tone }) => (
  <span className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold whitespace-nowrap tabular-nums ${
    tone === 'emerald' ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
      : tone === 'amber' ? 'border-amber-200 bg-amber-50 text-amber-700'
        : 'border-gray-200 bg-gray-50 text-gray-700'
  }`}>
    {label}: <span className="font-black">{num(value)}</span>
  </span>
);

/**
 * The dispatch board. Its row is the customer's bill and the challans cut out of that bill
 * hang beneath it, because a keeper reads deliveries as "what does this customer still have
 * coming" rather than as a list of papers. Everything here is counted in quantities: dispatch
 * is a question about boxes, and the ledger already answers the question about rupees.
 */
export const DeliveryChallans: React.FC<Props> = ({
  warehouseId = null, onFolder, onNavigate
}) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { user } = useAuth();
  // A challan is approved by an administrator, never by the man who wrote it out.
  const approvalHeldByAdmin = !!user?.salesmanScoped;

  const [rows, setRows] = useState<BoardRow[]>([]);
  const [folders, setFolders] = useState<BoardFolder[]>([]);
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [state, setState] = useState('');
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState('');
  // The paper whose load is being counted off, or null when the verification box is closed.
  const [verifyId, setVerifyId] = useState<number | null>(null);
  const [shown, setShown] = useState(10);

  const requestId = useRef(0);
  const refresh = useCallback(() => {
    const at = ++requestId.current;
    setLoading(true);
    getDispatchBoard(tenantSlug, branchId, { q: search, warehouseId, state })
      .then(r => { if (at === requestId.current) { setRows(r.rows); setFolders(r.folders); } })
      .catch(e => { if (at === requestId.current) setNotice((e as Error).message); })
      .finally(() => { if (at === requestId.current) setLoading(false); });
  }, [tenantSlug, branchId, search, warehouseId, state]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);
  useEffect(() => { setShown(10); }, [search, state, warehouseId]);

  // The folder counts come from the whole board the keeper may see, not from the folder or
  // the filter currently picked, otherwise opening one gate would empty every other chip.
  const totals = useMemo(() => {
    const challans = rows.flatMap(r => r.challans);
    return {
      bills: rows.length,
      challans: challans.length,
      dispatched: challans.filter(c => c.status === 'Approved').length,
      orderQty: rows.reduce((s, r) => s + r.orderQty, 0),
      holdQty: rows.reduce((s, r) => s + r.holdQty, 0)
    };
  }, [rows]);

  const stats: RegisterStat[] = [
    { label: 'Bills on board', value: String(totals.bills), title: 'Approved papers this branch still owes goods against' },
    { label: 'Challans', value: String(totals.challans), title: 'Delivery papers cut out of those bills' },
    { label: 'Signed out', value: String(totals.dispatched), tone: 'ok' as const, title: 'Challans an administrator has approved — the goods have left' },
    { label: 'Units still held', value: num(totals.holdQty), tone: totals.holdQty > 0 ? 'warn' as const : 'ok' as const, title: 'Ordered on the bill less what the approved challans have already carried' }
  ];

  const approve = (id: number, number: string) => {
    setNotice('');
    setDocStatus(challanKind.resource, tenantSlug, branchId, id, 'Approved')
      .then(() => { refresh(); setNotice(`${number} is signed out and its goods now count as dispatched.`); })
      .catch(e => setNotice((e as Error).message));
  };

  // The guard's paper is printed against the load standing in front of him, so it prints the
  // challan's own gate pass, vehicle and driver rather than sending him back to the bill.
  const printGatePass = (id: number, number: string) => {
    setNotice('');
    getDoc(challanKind.resource, tenantSlug, branchId, id)
      .then(one => printDocsWithLetterhead([one], tenantSlug, branchId,
        { sheet: challanKind.gateSheet!, label: 'GATE PASS', currency }))
      .catch(e => setNotice((e as Error).message || `Could not print ${number}.`));
  };

  const activeFolder = folders.find(f => f.id === warehouseId) || null;

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title flex items-center gap-2">
              <Truck className="w-5 h-5 text-blue-500" />
              <span>{activeFolder ? `Delivery Challans · ${activeFolder.name}` : 'Delivery Challans'}</span>
            </h2>
            <p className="text-xs text-gray-500">
              {activeFolder
                ? 'The loads that leave this gate, bill by bill'
                : 'Every bill still owed goods, with the challans cut out of it beneath'}
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
        </div>

        {/* One folder per warehouse whose gate has challans waiting. A split load stands in
            both of its folders, so each gate sees the half of the load it is carrying. */}
        {folders.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/60">
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-500">Folders</span>
            <button type="button" onClick={() => onFolder?.(null)}
              title="Every gate, whole board"
              className={`px-2.5 py-1 rounded-full border text-[11px] font-bold transition-colors ${
                !warehouseId ? 'border-[#1e88e5] bg-[#1e88e5] text-white'
                  : 'border-gray-200 bg-white text-gray-600 hover:border-[#1e88e5] hover:text-[#1e88e5]'}`}>
              All warehouses
              <span className={`ml-1.5 tabular-nums ${!warehouseId ? 'text-blue-100' : 'text-gray-400'}`}>
                {folders.reduce((s, f) => s + f.challans, 0)}
              </span>
            </button>
            {folders.map(f => (
              <button key={f.id} type="button" onClick={() => onFolder?.(f.id)}
                title={`${f.bills} bill(s) drawing from ${f.name} · ${f.awaiting} challan(s) not yet signed out`}
                className={`px-2.5 py-1 rounded-full border text-[11px] font-bold transition-colors ${
                  warehouseId === f.id ? 'border-[#1e88e5] bg-[#1e88e5] text-white'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-[#1e88e5] hover:text-[#1e88e5]'}`}>
                <Warehouse className="w-3 h-3 -mt-0.5 mr-1 inline-block" />
                {f.name}
                <span className={`ml-1.5 tabular-nums ${warehouseId === f.id ? 'text-blue-100' : 'text-gray-400'}`}>{f.challans}</span>
              </button>
            ))}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by bill, challan, gate pass, customer, vehicle, driver or product"
            onSearch={setSearch} />
          <div className="seg-filter" role="group" aria-label="Filter by dispatch state">
            {[
              { value: '', label: 'All' },
              { value: 'Not Dispatched', label: 'Nothing sent' },
              { value: 'Partial Dispatched', label: 'Part sent' },
              { value: 'Fully Dispatched', label: 'Fully sent' },
              { value: 'Hold', label: 'On hold' }
            ].map(s => (
              <button key={s.value || 'all'} type="button" aria-pressed={state === s.value}
                className={state === s.value ? 'is-on' : ''} onClick={() => setState(s.value)}>
                {s.label}
              </button>
            ))}
          </div>
          {(search || state || warehouseId) && (
            <button type="button" onClick={() => {
              setSearch(''); setState(''); onFolder?.(null); setSearchEpoch(n => n + 1);
            }} className="btn-xenith-outline ml-auto">
              <X className="w-3.5 h-3.5" />
              <span>Clear filters</span>
            </button>
          )}
        </div>

        {notice && (
          <div className="mx-4 mb-3 text-[12px] font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded px-3 py-2 flex items-center justify-between">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice('')} aria-label="Dismiss"><X className="w-3.5 h-3.5" /></button>
          </div>
        )}
      </div>

      {loading && !rows.length && (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="nb-card p-4">
              <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${60 - i * 8}%` }} />
              <div className="mt-3 h-16 rounded bg-gray-100 animate-pulse" />
            </div>
          ))}
        </div>
      )}

      {!loading && !rows.length && (
        <div className="nb-card p-8 text-center">
          <Truck className="w-8 h-8 mx-auto text-gray-300" />
          <div className="mt-2 text-sm font-bold text-gray-700">
            {search || state || warehouseId ? 'No bill matches what is picked on the board.' : 'Nothing is waiting to go out.'}
          </div>
          <div className="mt-1 text-xs text-gray-500">
            {search || state || warehouseId
              ? 'Clear the filters above to see the rest of the board.'
              : 'An approved sale invoice appears here with the challans cut out of it.'}
          </div>
          {(search || state || warehouseId) && (
            <button type="button" className="btn-xenith-outline mt-3" onClick={() => {
              setSearch(''); setState(''); onFolder?.(null); setSearchEpoch(n => n + 1);
            }}>
              <span>Clear filters</span>
            </button>
          )}
        </div>
      )}

      {rows.slice(0, shown).map((r, ri) => (
        <div key={r.id} className="nb-card p-0 overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 px-4 py-3">
            <div className="flex items-start gap-3 min-w-0">
              <span className="mt-0.5 w-7 h-7 shrink-0 rounded-full bg-gray-100 border border-gray-200 text-gray-600
                text-[11px] font-black grid place-items-center tabular-nums">{ri + 1}</span>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <button type="button" onClick={() => onNavigate?.('doc:sale-invoice')}
                    title="Open the sale invoice register"
                    className="text-[15px] font-black text-blue-600 hover:underline">{r.number}</button>
                  <span className="text-gray-300">•</span>
                  <span className="font-bold text-gray-800">{r.partyName}</span>
                  <span className="text-gray-300">•</span>
                  <span className="text-[12px] font-semibold text-gray-500">{r.paymentMode}</span>
                </div>
                <div className="mt-0.5 text-[11px] text-gray-500">
                  <span className="font-bold text-gray-600">{r.date}</span>
                  <span className="mx-1.5">·</span>
                  Dispatch Source: <span className="font-bold text-gray-700">{r.warehouseName || '—'}</span>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Chip label="Total Order" value={r.orderQty} tone="gray" />
              <Chip label="Dispatched" value={r.dispatchedQty} tone="emerald" />
              {r.holdQty > 0.001 && <Chip label="Remaining Hold" value={r.holdQty} tone="amber" />}
              <span className={`px-2 py-1 rounded-lg border text-[10px] font-black uppercase tracking-wide ${STATE_TONE[r.state]}`}>
                {r.state}
              </span>
              {/* The board raises no paper of its own: approving the bill files its challan and
                  the keeper works that one. This line only says where the held goods already
                  are — and a hold no challan has written down yet is left to its chip. */}
              {r.holdQty > 0.001 && r.claimableQty <= 0.001 && (
                <span className="px-2.5 py-1 rounded-lg border border-gray-200 bg-gray-50 text-[11px] font-semibold text-gray-500">
                  {num(r.holdQty)} already on {r.challans.filter(c => c.status !== 'Approved').map(c => c.number).join(', ') || 'an unsigned challan'} — count it off below
                </span>
              )}
            </div>
          </div>

          {!r.challans.length ? (
            <div className="px-4 py-4 border-t border-gray-100 text-[12px] text-gray-500">
              No challan has been cut out of this bill yet — the whole {num(r.orderQty)} {r.orderQty === 1 ? 'unit is' : 'units are'}
              still standing in the warehouse.
            </div>
          ) : (
            <div className="overflow-x-auto app-scroll border-t border-gray-100">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="bg-gray-50/80 text-left text-[10px] uppercase tracking-wider text-gray-500">
                    <th className="px-4 py-2 font-black">Challan / Gate Pass #</th>
                    <th className="px-3 py-2 font-black">Vehicle / Driver Details</th>
                    <th className="px-3 py-2 font-black">Items / Breakdown</th>
                    <th className="px-3 py-2 font-black">Status</th>
                    <th className="px-4 py-2 font-black text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {r.challans.map(c => (
                    <tr key={c.id} className="align-top">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="font-black text-emerald-700">{c.number}</div>
                        <div className="text-[11px] font-bold text-emerald-600">GP: {c.gatePass || '—'}</div>
                        <div className="text-[11px] text-gray-500">{c.date}{c.part ? ` · part ${c.part}` : ''}</div>
                        {c.warehouseName && c.warehouseName !== r.warehouseName && (
                          <div className="text-[11px] text-gray-500">{c.warehouseName}</div>
                        )}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <div className="font-bold text-gray-800">{c.vehicle || 'No Transport'}</div>
                        <div className="text-[11px] text-gray-500">Driver: {c.driver || 'Handover at counter'}</div>
                      </td>
                      <td className="px-3 py-3">
                        <ul className="space-y-1.5">
                          {c.items.map((it, i) => (
                            <li key={`${it.sku}-${i}`}>
                              <div className="font-semibold text-gray-800">• {it.name}</div>
                              <span className={`mt-0.5 inline-block px-1.5 py-0.5 rounded border text-[10px] font-bold tabular-nums ${
                                it.sent ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                                  : 'border-gray-200 bg-gray-50 text-gray-600'}`}>
                                {num(it.qty)} {it.unit || 'units'} {it.sent ? 'Sent' : 'Ordered (Pending)'}
                              </span>
                            </li>
                          ))}
                          {!c.items.length && <li className="text-gray-400">No lines on this challan.</li>}
                        </ul>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full border text-[10px] font-black uppercase tracking-wide ${
                          c.status === 'Approved' ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                            : c.status === 'Void' ? 'border-red-200 bg-red-50 text-red-600 line-through'
                              : 'border-rose-200 bg-rose-50 text-rose-700'}`}>
                          {c.status === 'Approved' ? 'Dispatched' : c.status === 'Draft' ? 'Pending' : c.status}
                        </span>
                        <div className="mt-1 text-[10px] text-gray-400 tabular-nums">{num(c.qty)} {c.state === 'Fully Dispatched' ? 'all out' : 'on this load'}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap items-center justify-end gap-1.5">
                          {/* The load is written down here, not on a paper form: this box asks
                              how much is actually on the truck and holds the rest back on the bill. */}
                          {c.status !== 'Approved' && c.status !== 'Void' && (
                            <button type="button" onClick={() => setVerifyId(c.id)}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gray-800 text-white text-[11px] font-bold hover:bg-gray-900 transition-colors"
                              title={`Edit ${c.number}: what is on the truck, what stays behind, and the vehicle taking it`}>
                              <Pencil className="w-3 h-3" />
                              <span>Edit Dispatch</span>
                            </button>
                          )}
                          {/* Signing out is an administrator's job, done here on the board —
                              the keeper only counts the load in Verify Dispatch. */}
                          {c.status !== 'Approved' && !approvalHeldByAdmin && (
                            <button type="button" onClick={() => approve(c.id, c.number)}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[11px] font-bold hover:bg-emerald-700 transition-colors"
                              title={`Sign ${c.number} out — the goods have left the compound`}>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Approve Items</span>
                            </button>
                          )}
                          {/* An unsigned challan is not a permit yet, so the gate paper is
                              locked until the load is actually signed out. */}
                          <button type="button" disabled={c.status !== 'Approved'}
                            onClick={() => printGatePass(c.id, c.number)}
                            title={c.status === 'Approved' ? `Print the gate pass for ${c.number}`
                              : `Approve ${c.number} first — an unsigned challan is not a permit`}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-bold transition-colors ${
                              c.status === 'Approved'
                                ? 'border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                : 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed'}`}>
                            {c.status === 'Approved' ? <Printer className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                            <span>Print Gate Pass</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}

      {!!rows.length && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-[12px] text-gray-500">
          <span>
            Showing {Math.min(shown, rows.length)} of {rows.length} bill{rows.length === 1 ? '' : 's'}
            {activeFolder ? ` in ${activeFolder.name}` : ''}
          </span>
          {rows.length > shown && (
            <button type="button" onClick={() => setShown(n => n + 10)} className="btn-xenith-outline">
              <span>Show 10 more</span>
            </button>
          )}
        </div>
      )}

      {/* A bill with nothing owed on it never reaches the board, and neither does a load
          that has already gone out whole — so the count in the header is what is still
          being worked, not everything the branch has ever delivered. */}
      {!loading && !!rows.length && (
        <div className="px-1 text-[11px] text-gray-400">
          Dispatched counts only approved challans; a draft under a bill is work in hand, not a load that has left.
        </div>
      )}

      {verifyId !== null && (
        <DispatchApprovalModal
          resource={challanKind.resource}
          challanId={verifyId}
          onClose={message => {
            setVerifyId(null);
            if (message) { setNotice(message); refresh(); }
          }}
        />
      )}
    </div>
  );
};
