import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { roundMoney } from '../../utils/money';
import {
  AlertCircle, ArrowRight, BadgeCheck, Banknote, Boxes, CalendarDays, Clock3, Contact2, FileText,
  Plus, Receipt, RefreshCw, Search, ShieldCheck, ShoppingCart, TrendingUp, Truck, Users2, X
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { getSalesmanSummary, SalesmanSummary } from '../../services/salesman.service';
import { money } from '../Docs/docKinds';
import { companyNow } from '../../utils/clock';
import { ThemePicker } from '../Dashboard';
import { XenithBarChart } from '../../components/charts/XenithBarChart';
import { useScreenReload } from '../../utils/screenReload';

const ICONS: Record<string, React.ElementType> = {
  saleInvoices: Receipt, saleDeliveries: Truck, saleReturns: AlertCircle, receivePayments: Banknote
};

/** Where a pipeline card and a recent row take the salesman. */
const TAB_OF: Record<string, string> = {
  saleInvoices: 'sales-invoices',
  saleDeliveries: 'delivery-challan', saleReturns: 'doc:sale-return', receivePayments: 'doc:receive-payment'
};

const num = (v: number) => roundMoney(v).toLocaleString(undefined, { maximumFractionDigits: 2 });

// Static class strings: Tailwind cannot see an interpolated colour name.
const STATUS_STYLES: Record<string, string> = {
  Pending: 'bg-amber-50 text-amber-700 border-amber-200',
  Approved: 'bg-teal-50 text-[#25a195] border-teal-200',
  Draft: 'bg-gray-100 text-gray-600 border-gray-200',
  Void: 'bg-rose-50 text-rose-700 border-rose-200'
};

// The board's own three words, on his desk, so the bill he reads here and the bill the gate
// reads are the same bill.
const DISPATCH_TONE: Record<string, string> = {
  'Fully Dispatched': 'border-emerald-200 bg-emerald-50 text-emerald-700',
  'Partial Dispatched': 'border-amber-200 bg-amber-50 text-amber-700',
  'Not Dispatched': 'border-rose-200 bg-rose-50 text-rose-700'
};

// The board's three words are technical; on his desk the same state is read in the words the
// filter above it uses, so a chip and the button that picked it never say two different things.
const DISPATCH_WORD: Record<string, string> = {
  'Fully Dispatched': 'Fully sent',
  'Partial Dispatched': 'Part sent',
  'Not Dispatched': 'Nothing sent'
};

const KPI_TONES = {
  amber: 'bg-amber-500', emerald: 'bg-emerald-500', rose: 'bg-rose-500',
  blue: 'bg-blue-600', indigo: 'bg-indigo-600'
} as const;

const Kpi: React.FC<{ label: string; value: string; note: string; tone: keyof typeof KPI_TONES; icon: React.ReactNode; onClick?: () => void }> =
  ({ label, value, note, tone, icon, onClick }) => (
    <div className={`nb-card px-3.5 py-3 flex items-start justify-between gap-2 ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick} role={onClick ? 'button' : undefined} tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick(); } } : undefined}>
      <div className="min-w-0">
        <div className="text-[10px] font-black uppercase tracking-wider text-gray-500">{label}</div>
        <div className="mt-1 text-2xl font-black tabular-nums leading-tight text-gray-800">{value}</div>
        <div className="mt-0.5 text-[10px] leading-snug text-gray-400">{note}</div>
      </div>
      <span className={`shrink-0 grid place-items-center w-8 h-8 rounded-lg text-white ${KPI_TONES[tone]}`}>{icon}</span>
    </div>
  );

// His four papers, each one opened on the spot — the same plate of actions the gate works from.
const TILES: { key: string; title: string; note: string; icon: React.ReactNode; grad: string; create: string }[] = [
  {
    key: 'saleInvoices', title: 'New Sale Invoice', note: 'Raise the bill for a party',
    icon: <Receipt className="w-4 h-4" />, grad: 'from-blue-600 to-indigo-800', create: 'sale-invoice'
  },
  {
    key: 'saleDeliveries', title: 'New Delivery Challan', note: 'Cut a challan out of a bill',
    icon: <Truck className="w-4 h-4" />, grad: 'from-orange-500 to-amber-700', create: 'sale-delivery'
  },
  {
    key: 'saleReturns', title: 'New Sale Return', note: 'Send goods back to the store',
    icon: <AlertCircle className="w-4 h-4" />, grad: 'from-violet-600 to-purple-800', create: 'sale-return'
  },
  {
    key: 'receivePayments', title: 'Receive Payment', note: 'Book what a party has paid',
    icon: <Banknote className="w-4 h-4" />, grad: 'from-rose-600 to-red-800', create: 'receive-payment'
  }
];

// The bands of this desk, in the order the page draws them.
const BANDS = ['alerts', 'kpi', 'tiles', 'bills', 'stock', 'charts'];

export const SalesmanDashboard: React.FC<{
  onNavigate: (tab: string) => void;
  onQuickCreate: (kind: string) => void;
}> = ({ onNavigate, onQuickCreate }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { token, user, can } = useAuth();
  // A band of this desk is drawn when its tick says so — Setup → User Roles → Salesman Desk.
  const on = (band: string) => can(`dash-sm-${band}:view`);
  const [data, setData] = useState<SalesmanSummary | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [billQuery, setBillQuery] = useState('');
  const [billState, setBillState] = useState('');
  const [stockQuery, setStockQuery] = useState('');
  // An administrator may turn this page to another salesman's desk; a salesman has no such
  // choice and never sees the picker.
  const [asId, setAsId] = useState<number | null>(null);

  const load = useCallback(() => {
    if (!token) { setError('Sign in again to see your sales.'); setLoading(false); return; }
    let alive = true;
    setLoading(true);
    getSalesmanSummary(tenantSlug, branchId, token, asId)
      .then(d => { if (alive) { setData(d); setError(''); } })
      .catch(e => { if (alive) setError((e as Error).message); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [tenantSlug, branchId, token, asId]);

  useEffect(load, [load]);
  useScreenReload(load);

  const chart = useMemo(() => ({
    labels: data?.months.map(m => m.label) ?? [],
    datasets: [{ label: 'Approved sales', data: (data?.months ?? []).map(m => m.value), color: '#1e88e5', fill: true }]
  }), [data]);

  // His bills with the gate's answer written beside each one. Draft paper is on this list
  // too — he raised it, he wants to see it — but nothing on it has left a warehouse.
  const bills = useMemo(() => {
    const rows = (data?.recent ?? []).filter(r => r.resource === 'saleInvoices');
    const q = billQuery.toLowerCase().trim();
    return rows.filter(r =>
      (!billState || (r.dispatch?.state ?? 'Not Dispatched') === billState)
      && (!q || `${r.number} ${r.partyName}`.toLowerCase().includes(q)));
  }, [data, billState, billQuery]);

  const stock = useMemo(() => {
    const q = stockQuery.toLowerCase().trim();
    return (data?.stock ?? []).filter(r => !q || `${r.productName} ${r.sku}`.toLowerCase().includes(q));
  }, [data, stockQuery]);

  // A page turned to another man's desk: the figures are his, read under his name, and this
  // reader cannot raise paper for him — so the create tiles and the empty-state button step
  // aside rather than offer to do something they cannot do.
  const preview = !!data?.viewingAs;

  return (
    <div className="space-y-4">
      {/* The band greets the person, not the software: he opens this tab on the road, and the
          first line he needs is his own name with today's number of things waiting. */}
      <div className="dash-hero px-4 py-4 md:px-5">
        <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="hero-glass"><ShieldCheck className="w-3 h-3" /> {data?.user.roleName || user?.roleName || 'Salesman'}</span>
              {data?.salesPerson && (
                <span className="hero-glass"><Contact2 className="w-3 h-3" /> {data.salesPerson.name} · {data.salesPerson.branchName}</span>
              )}
              <span className="hero-glass">
                <CalendarDays className="w-3 h-3" />
                {companyNow().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </span>
              {!!data?.totals.customers && (
                <span className="hero-glass"><Users2 className="w-3 h-3" /> {data.totals.customers} customer(s) served</span>
              )}
              {!!data && data.asOptions.length > 1 && (
                <div className="hero-seg" role="group" aria-label="Whose desk this page is reading">
                  <button type="button" className={!asId ? 'is-on' : ''} onClick={() => setAsId(null)}>My own desk</button>
                  {data.asOptions.map(o => (
                    <button key={o.id} type="button" title={`${o.roleName}’s own paperwork`}
                      className={asId === o.id ? 'is-on' : ''} onClick={() => setAsId(o.id)}>
                      {o.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <h2 className="hero-title mt-2.5">
              {preview ? `${data!.viewingAs!.name}’s desk` : `Welcome back, ${(data?.user.name || user?.name || '').split(' ')[0]}!`}
            </h2>
            <p className="hero-note mt-1 max-w-[46rem]">
              Every figure here is read from the paperwork raised in my own name, from the same
              registers the books hold. {data?.approvalNote}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <ThemePicker />
            <button type="button" className="hero-glass" onClick={load}
              title="Re-read my own paperwork">
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="nb-card px-4 py-2.5 text-[12px] font-semibold text-amber-800 bg-amber-50 flex items-center justify-between gap-2">
          <span>{error}</span>
          <button type="button" onClick={load} title="Try the read again"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {!!data && on('alerts') && data.queue.pending.count > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5">
          <p className="text-[13px] text-amber-800 flex items-center gap-2 min-w-0">
            <Clock3 size={15} className="shrink-0" />
            <span>
              <b>{data.queue.pending.count}</b> document{data.queue.pending.count === 1 ? '' : 's'} worth{' '}
              <b>{currency} {money(data.queue.pending.amount)}</b> are waiting for an administrator to approve.
            </span>
          </p>
          <button type="button" onClick={() => onNavigate(TAB_OF.saleInvoices)}
            className="shrink-0 inline-flex items-center gap-1 text-[12.5px] font-semibold text-amber-800 hover:underline">
            Open my invoices <ArrowRight size={14} />
          </button>
        </div>
      )}

      {on('kpi') && (
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <Kpi label="Approved sales, this month" value={data ? `${currency} ${money(data.totals.salesThisMonth)}` : '—'}
          tone="emerald" note={`${data?.queue.approved ?? 0} of my document(s) signed`}
          icon={<TrendingUp className="w-4 h-4" />} onClick={() => onNavigate(TAB_OF.saleInvoices)} />
        <Kpi label="Collected" value={data ? `${currency} ${money(data.totals.collections)}` : '—'}
          tone="blue" note="Payments I have booked and got signed"
          icon={<Banknote className="w-4 h-4" />} onClick={() => onNavigate(TAB_OF.receivePayments)} />
        <Kpi label="Still uncollected" value={data ? `${currency} ${money(data.totals.outstanding)}` : '—'}
          tone="rose" note="My approved paper less what has been paid"
          icon={<BadgeCheck className="w-4 h-4" />} />
        <Kpi label="Awaiting approval" value={data ? num(data.queue.pending.count) : '—'}
          tone="amber" note={data ? `${currency} ${money(data.queue.pending.amount)} held by an administrator` : ' '}
          icon={<Clock3 className="w-4 h-4" />} />
        <Kpi label="Units held for dispatch" value={data ? num(data.dispatch.holdUnits) : '—'}
          tone="indigo" note={data ? `${data.dispatch.bills} bill(s) on the board · ${data.dispatch.unsigned} challan(s) unsigned` : ' '}
          icon={<Truck className="w-4 h-4" />} onClick={() => onNavigate('delivery-challan')} />
      </div>
      )}

      {on('tiles') && (<>
      {!preview && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {TILES.map(t => (
          <button key={t.key} type="button" onClick={() => onQuickCreate(t.create)}
            className={`text-left rounded-xl px-4 py-3.5 bg-gradient-to-br ${t.grad} text-white shadow-lg transition-transform hover:-translate-y-0.5`}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-[13px] font-black uppercase tracking-wide">
                  <Plus className="w-3.5 h-3.5" /> {t.title}
                </div>
                <div className="mt-0.5 text-[11px] font-semibold text-white/85">{t.note}</div>
              </div>
              <span className="shrink-0 grid place-items-center w-8 h-8 rounded-lg bg-white/15">{t.icon}</span>
            </div>
          </button>
        ))}
        </div>
      )}

      {/* One line for the four registers he works, with the count of his own paper in each —
          the tiles above raise the paper, these chips open the book it lands in. */}
      <div className="flex flex-wrap items-center gap-2">
        {(data?.pipeline ?? []).map(p => {
          const Icon = ICONS[p.key] || FileText;
          return (
            <button key={p.key} type="button" onClick={() => onNavigate(TAB_OF[p.key])}
              title={`${currency} ${money(p.amount)} raised by me`}
              className="stat-chip inline-flex items-center gap-2">
              <Icon className="w-3.5 h-3.5" />
              <span className="font-bold">{p.label}</span>
              <span className="tabular-nums">{p.count}</span>
            </button>
          );
        })}
      </div>
      </>)}

      {/* The two questions a salesman actually asks: what has my party been sent, and can I
          promise the next one. Both are read from the same papers the registers hold. */}
      {(on('bills') || on('stock')) && (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {on('bills') && (
        <div className={`${on('stock') ? 'lg:col-span-7' : 'lg:col-span-12'} nb-card p-0 overflow-hidden`}>
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 py-3.5">
            <div className="min-w-0">
              <h3 className="flex items-center gap-2 text-[15px] font-black text-gray-800">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>My Recent Sale Invoices</span>
              </h3>
              <p className="text-[11px] text-gray-500">
                Bills I raised, with what a gate has signed out against each one
              </p>
            </div>
            <div className="seg-filter" role="group" aria-label="Filter my bills by dispatch state">
              {[
                { v: '', l: 'All' },
                { v: 'Not Dispatched', l: 'Nothing sent' },
                { v: 'Partial Dispatched', l: 'Part sent' },
                { v: 'Fully Dispatched', l: 'Fully sent' }
              ].map(s => (
                <button key={s.v || 'all'} type="button" aria-pressed={billState === s.v}
                  className={billState === s.v ? 'is-on' : ''} onClick={() => setBillState(s.v)}>
                  {s.l}
                </button>
              ))}
            </div>
          </div>

          <div className="px-4 pb-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={billQuery} onChange={e => setBillQuery(e.target.value)}
                placeholder="Search a bill number or a customer"
                className="w-full pl-8 pr-8 py-2 rounded-lg border border-gray-200 bg-white text-[12px] focus:outline-none focus:border-[#1e88e5]" />
              {billQuery && (
                <button type="button" onClick={() => setBillQuery('')} aria-label="Clear the bill search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="border-t border-gray-100 overflow-x-auto app-scroll">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="bg-gray-50/80 text-left text-[10px] uppercase tracking-wider text-gray-500">
                  <th className="px-4 py-2 font-black">Invoice #</th>
                  <th className="px-3 py-2 font-black">Date</th>
                  <th className="px-3 py-2 font-black">Customer</th>
                  <th className="px-3 py-2 font-black text-right">Amount</th>
                  <th className="px-3 py-2 font-black text-right">Order / Sent / Held</th>
                  <th className="px-4 py-2 font-black">State</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {loading && !data && Array.from({ length: 3 }).map((_, i) => (
                  <tr key={i}><td colSpan={6}><div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${88 - i * 12}%` }} /></td></tr>
                ))}
                {!!data && !bills.length && (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-[12px] text-gray-500">
                      {(data.recent ?? []).some(r => r.resource === 'saleInvoices')
                        ? 'No bill of mine matches the search or the state picked.'
                        : 'You have not raised a sale invoice yet.'}
                    </td>
                  </tr>
                )}
                {bills.map(d => (
                  <tr key={d.number}>
                    <td className="px-4 py-2.5">
                      <button type="button" onClick={() => onNavigate(TAB_OF.saleInvoices)}
                        className="font-black text-blue-700 hover:underline">{d.number}</button>
                      <div className={`inline-flex mt-1 px-1.5 py-0.5 rounded border text-[9px] font-black uppercase tracking-wide ${STATUS_STYLES[d.status]}`}>
                        {d.status === 'Pending' ? 'Awaiting approval' : d.status === 'Approved' ? `Signed · ${d.approvedByName}` : d.status}
                      </div>
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap text-gray-600">{d.date}</td>
                    <td className="px-3 py-2.5 font-semibold text-gray-800 truncate max-w-[11rem]">{d.partyName}</td>
                    <td className="px-3 py-2.5 text-right tabular-nums font-bold text-gray-800">{money(d.net)}</td>
                    <td className="px-3 py-2.5 text-right tabular-nums text-gray-700">
                      {d.dispatch ? `${num(d.dispatch.orderQty)} / ${num(d.dispatch.dispatchedQty)} / ${num(d.dispatch.holdQty)}` : '—'}
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-black uppercase tracking-wide ${
                        DISPATCH_TONE[d.dispatch?.state ?? 'Not Dispatched']}`}>
                        {DISPATCH_WORD[d.dispatch?.state ?? 'Not Dispatched']}
                      </span>
                      {!!d.dispatch && !!d.dispatch.challans.length && (
                        <div className="mt-1 text-[10px] text-gray-400">
                          {d.dispatch.challans.map(c => c.number).join(', ')}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 flex flex-wrap items-center justify-end gap-4">
            {!!data && !preview && !bills.length && !(data.recent ?? []).some(r => r.resource === 'saleInvoices') && (
              <button type="button" onClick={() => onQuickCreate('sale-invoice')}
                className="inline-flex items-center gap-1 text-[12px] font-bold text-blue-700 hover:underline">
                <Plus className="w-3.5 h-3.5" /> Raise my first sale invoice
              </button>
            )}
            <button type="button" onClick={() => onNavigate('delivery-challan')}
              className="inline-flex items-center gap-1 text-[12px] font-bold text-orange-600 hover:underline">
              <span>Open my dispatch board</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        )}

        {on('stock') && (
        <div className={`${on('bills') ? 'lg:col-span-5' : 'lg:col-span-12'} nb-card p-0 overflow-hidden`}>
          <div className="flex items-start justify-between gap-3 px-4 py-3.5">
            <div className="min-w-0">
              <h3 className="flex items-center gap-2 text-[15px] font-black text-gray-800">
                <Boxes className="w-4 h-4 text-amber-500" />
                <span>Live Stock Checker</span>
              </h3>
              <p className="text-[11px] text-gray-500">What stands in every warehouse, read from the stock ledger</p>
            </div>
            <span className="shrink-0 px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-[10px] font-black text-amber-700">
              {data?.stock.length ?? 0} SKU{data?.stock.length === 1 ? '' : 'S'}
            </span>
          </div>

          <div className="px-4 pb-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={stockQuery} onChange={e => setStockQuery(e.target.value)}
                placeholder="Search an item name or code"
                className="w-full pl-8 pr-8 py-2 rounded-lg border border-gray-200 bg-white text-[12px] focus:outline-none focus:border-[#1e88e5]" />
              {stockQuery && (
                <button type="button" onClick={() => setStockQuery('')} aria-label="Clear the item search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Capped inside the card so a long item list scrolls here instead of pushing the
              page out beneath it. */}
          <div className="px-4 pb-3 max-h-[26rem] overflow-y-auto app-scroll space-y-1.5">
            {loading && Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-11 rounded-lg bg-gray-100 animate-pulse" />
            ))}
            {!loading && !stock.length && (
              <div className="py-6 text-center text-[12px] text-gray-500">
                {data?.stock.length
                  ? 'No item matches that search.'
                  : 'No stock is set up on this branch yet.'}
              </div>
            )}
            {!loading && stock.map(r => (
              <div key={r.sku} className="flex items-center justify-between gap-3 px-3 py-2 rounded-lg border border-gray-100 bg-gray-50/70">
                <div className="min-w-0">
                  <div className="text-[12px] font-bold text-gray-800 truncate">{r.productName}</div>
                  <div className="text-[10px] text-gray-400 truncate">
                    {r.sku}
                    {r.places.length
                      ? ` · ${r.places.map(p => `${p.warehouseName.replace(/\s*\(.*\)$/, '')} ${num(p.qty)}`).join(' · ')}`
                      : ' · nothing on any shelf'}
                  </div>
                </div>
                <span className={`shrink-0 px-2 py-0.5 rounded-full border text-[11px] font-black tabular-nums ${
                  r.total <= 0 ? 'border-rose-200 bg-rose-50 text-rose-700'
                    : r.total <= 5 ? 'border-amber-200 bg-amber-50 text-amber-700'
                      : 'border-emerald-200 bg-emerald-50 text-emerald-700'}`}>
                  {r.total <= 0 ? 'Nil' : `${num(r.total)} ${r.unit}`}
                </span>
              </div>
            ))}
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 text-right">
            <button type="button" onClick={() => onNavigate('products')}
              className="inline-flex items-center gap-1 text-[12px] font-bold text-amber-700 hover:underline">
              <span>Open the product master</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        )}
      </div>
      )}

      {on('charts') && (
      <div className="grid gap-3 lg:grid-cols-3">
        <div className="nb-card p-4 lg:col-span-2">
          <div className="flex items-center justify-between gap-3 mb-2">
            <h2 className="card-title">Approved invoicing, last six months</h2>
            <span className="inline-flex items-center gap-1.5 text-[11.5px] text-gray-500">
              <ShoppingCart size={13} /> {data?.queue.approved ?? 0} approved document(s)
            </span>
          </div>
          <XenithBarChart labels={chart.labels} datasets={chart.datasets} currency={currency} height={230} showTrendline />
        </div>

        <div className="nb-card p-4">
          <h2 className="card-title mb-2">What I sell most</h2>
          {!data?.topProducts.length && <p className="text-[13px] text-gray-400">Nothing approved yet.</p>}
          <ul className="space-y-2.5">
            {(data?.topProducts ?? []).map((p, i) => {
              const top = data!.topProducts[0].amount || 1;
              return (
                <li key={p.name}>
                  <div className="flex items-baseline justify-between gap-2 text-[12.5px]">
                    <span className="truncate text-gray-600">{i + 1}. {p.name}</span>
                    <span className="shrink-0 tabular-nums text-gray-500">{money(p.amount)}</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                    <div className="h-full rounded-full bg-[#1e88e5] transition-[width] duration-700"
                      style={{ width: `${Math.max(4, (p.amount / top) * 100)}%` }} />
                  </div>
                  <p className="mt-0.5 text-[11px] text-gray-400 tabular-nums">{p.qty} sold</p>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
      )}

      {BANDS.every(b => !on(b)) && (
        <div className="nb-card px-4 py-8 text-center">
          <p className="text-sm font-bold text-gray-700">This desk has no bands on it.</p>
          <p className="mt-1 text-xs text-gray-500">
            An administrator shows parts of it under Setup → User Roles → Salesman Desk.
          </p>
        </div>
      )}
    </div>
  );
};
