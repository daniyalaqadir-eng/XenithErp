import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Plus, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { LedgerAccount, NumberSeries, SalesPerson } from '../../types';
import { getLedgerAccounts } from '../../services/accounts.service';
import { getUsers } from '../../services/access.service';
import { deleteSalesPerson, getNumberSeries, getSalesPersons, saveNumberSeries, saveSalesPerson, updateSalesPerson } from '../../services/masters.service';
import { Check, ExportPair, Field, FormFooter, IconAction, ListToolbar, Pick, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TabStrip, TableEmpty, Text } from './masterUi';
import { ExportColumn } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const blank = (branchId: number, branchName: string): SalesPerson => ({
  id: 0, name: '', isSalesman: true, isOrderBooker: false, isDeliveryPerson: false,
  cashAccountId: null, cashAccountName: '',
  receivePaymentSeriesId: null, receivePaymentSeriesName: '',
  canChangePrice: false, canAddDiscount: false, isManager: false, managerId: null, managerName: '',
  applicationUserId: null, applicationUserEmail: '', branchId, branchName, isActive: true,
});

const typesOf = (s: SalesPerson) => [
  s.isSalesman && 'Salesman', s.isOrderBooker && 'Order Booker', s.isDeliveryPerson && 'Delivery Person'
].filter(Boolean).join(', ') || '—';

const columns: ExportColumn<SalesPerson>[] = [
  { label: 'Name', value: (s) => s.name },
  { label: 'Status', value: (s) => (s.isActive ? 'Active' : 'Inactive') },
  { label: 'Type', value: (s) => typesOf(s) },
  { label: 'Series', value: (s) => s.receivePaymentSeriesName || '—' },
  { label: 'Cash Account', value: (s) => s.cashAccountName || '-' },
  { label: 'Manager', value: (s) => s.managerName || '-' },
  { label: 'Application User', value: (s) => s.applicationUserEmail || '-' },
  { label: 'Branch', value: (s) => s.branchName || '-' },
];

const TABS = ['General', 'Application User'];

// ─── Form ──────────────────────────────────────────────────────────────────
interface FormProps {
  person: SalesPerson;
  onCreated: () => void;
  onDone: () => void;
}

const SeriesPicker: React.FC<{
  label: string; kind: NumberSeries['kind']; value: number | null;
  rows: NumberSeries[]; onChange: (id: number | null) => void;
  onCreate: (kind: NumberSeries['kind'], name: string, prefix: string, nextNumber: number) => Promise<NumberSeries | null>;
}> = ({ label, kind, value, rows, onChange, onCreate }) => {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  const [prefix, setPrefix] = useState('');
  const [start, setStart] = useState('1');
  const [busy, setBusy] = useState(false);
  const options = rows.filter(r => r.kind === kind);

  const create = async () => {
    setBusy(true);
    const row = await onCreate(kind, name.trim(), prefix.trim().toUpperCase(), Number(start) || 1);
    setBusy(false);
    if (!row) return;
    setName(''); setPrefix(''); setStart('1'); setAdding(false);
    onChange(row.id);
  };

  return (
    <Field label={label}>
      <div className="flex items-stretch gap-1">
        <Pick value={String(value ?? '')} onChange={e => onChange(e.target.value ? Number(e.target.value) : null)} className="rounded-r-none">
          <option value="">-Choose-</option>
          {options.map(o => <option key={o.id} value={String(o.id)}>{o.name} ({o.prefix}-{String(o.nextNumber).padStart(6, '0')})</option>)}
        </Pick>
        <button
          type="button" title={`Add ${label}`} onClick={() => setAdding(a => !a)}
          className="px-2 rounded bg-[#2ec4b6] hover:bg-[#25a195] text-white text-xs font-semibold whitespace-nowrap"
        >
          +Add
        </button>
      </div>
      {adding && (
        <div className="mt-2 p-2 bg-gray-50 border border-gray-200 rounded grid grid-cols-2 sm:grid-cols-4 gap-2 items-end animate-[fadeUp_.2s_ease-out_backwards]">
          <Field label="Name" className="col-span-2">
            <Text value={name} onChange={e => setName(e.target.value)} placeholder="Field Sales Series" />
          </Field>
          <Field label="Prefix">
            <Text value={prefix} onChange={e => setPrefix(e.target.value)} placeholder="FS" maxLength={6} />
          </Field>
          <Field label="Starts at">
            <Text type="number" value={start} onChange={e => setStart(e.target.value)} />
          </Field>
          <div className="col-span-2 flex gap-2 sm:col-span-4">
            <button type="button" disabled={!name.trim() || !prefix.trim() || busy} onClick={create} className="btn-xenith-success disabled:opacity-40">
              {busy ? 'Adding...' : 'Add Series'}
            </button>
            <button type="button" onClick={() => setAdding(false)} className="btn-xenith-outline">
              <X className="w-3.5 h-3.5" /> Cancel
            </button>
          </div>
        </div>
      )}
    </Field>
  );
};

export const SalesPersonForm: React.FC<FormProps> = ({ person, onCreated, onDone }) => {
  const { tenantSlug, branchId, branches } = useTenant();
  const [tab, setTab] = useState('General');
  const [form, setForm] = useState<SalesPerson>({ ...person });
  const [series, setSeries] = useState<NumberSeries[]>([]);
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]);
  const [users, setUsers] = useState<{ id: number; name: string; email: string; isActive: boolean }[]>([]);
  const [team, setTeam] = useState<SalesPerson[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const loadSeries = useCallback(() => {
    getNumberSeries(tenantSlug, branchId).then(setSeries).catch(() => setSeries([]));
  }, [tenantSlug, branchId]);

  useEffect(() => { loadSeries(); }, [loadSeries]);
  useEffect(() => {
    getLedgerAccounts(tenantSlug, branchId).then(d => setAccounts(d.data.filter(a => a.isActive && a.type === 'Asset')));
    getUsers(tenantSlug, branchId).then(d => setUsers(d.data.map(u => ({ id: u.id, name: u.name, email: u.email, isActive: u.isActive })))).catch(() => setUsers([]));
    getSalesPersons(tenantSlug, branchId).then(d => setTeam(d.data));
  }, [tenantSlug, branchId]);

  const set = <K extends keyof SalesPerson>(key: K, value: SalesPerson[K]) => setForm(f => ({ ...f, [key]: value }));
  const canSave = form.name.trim().length > 0 && !saving && (!form.isOrderBooker || !!form.cashAccountId);
  const managers = team.filter(s => s.isManager && s.id !== form.id);

  const onSave = async (statusOverride?: string) => {
    if (!canSave) return;
    setSaving(true);
    setError('');
    const body: Partial<SalesPerson> = {
      ...form,
      ...(statusOverride === 'inactive' ? { isActive: false } : statusOverride === 'active' ? { isActive: true } : {}),
    };
    try {
      const isNew = form.id === 0;
      if (isNew) await saveSalesPerson(tenantSlug, branchId, body);
      else await updateSalesPerson(tenantSlug, branchId, form.id, body);
      if (!isNew) { onDone(); return; }
      // "Save and New" keeps the screen open for the next person in the batch.
      const branch = branches.find(b => b.id === branchId);
      onCreated();
      setForm(blank(branchId, branch?.name ?? ''));
      setTab('General');
      setSaving(false);
    } catch (e: any) {
      setError(e.message || String(e));
      setSaving(false);
    }
  };

  const createSeries = async (kind: NumberSeries['kind'], name: string, prefix: string, nextNumber: number) => {
    try {
      const row = await saveNumberSeries(tenantSlug, branchId, { kind, name, prefix, nextNumber });
      setSeries(s => [...s, row]);
      return row;
    } catch (e: any) {
      setError(e.message || String(e));
      return null;
    }
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span>Sales Person - {form.id === 0 ? 'Add' : 'Edit'}</span>
        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-500">
          {form.isActive ? 'Active' : 'Inactive'}
        </span>
      </div>

      <TabStrip tabs={TABS} active={tab} onChange={setTab} />

      {error && <div className="mx-4 mt-3 text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div>}

      <div className="nb-card-body">
        {tab === 'General' && (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Field label="Sales Person Name" required>
                <Text value={form.name} onChange={e => set('name', e.target.value)} placeholder="Sales Person Name" />
              </Field>
              <Field label="Type" required>
                <div className="flex flex-wrap items-center gap-x-5 gap-y-2 pt-1.5">
                  <Check checked={form.isSalesman} onChange={v => set('isSalesman', v)} label="Salesman" />
                  <Check checked={form.isOrderBooker} onChange={v => set('isOrderBooker', v)} label="Order Booker" />
                  <Check checked={form.isDeliveryPerson} onChange={v => set('isDeliveryPerson', v)} label="Delivery Person" />
                </div>
              </Field>
              <Field label="Cash Account" required={form.isOrderBooker} hint="(Only applicable for Order Booker App.)">
                <Pick value={String(form.cashAccountId ?? '')} onChange={e => {
                  const id = e.target.value ? Number(e.target.value) : null;
                  setForm(f => ({ ...f, cashAccountId: id, cashAccountName: accounts.find(a => a.id === id)?.name ?? '' }));
                }}>
                  <option value="">-Choose-</option>
                  {accounts.map(a => <option key={a.id} value={String(a.id)}>{a.name} ({a.code})</option>)}
                </Pick>
                {form.isOrderBooker && !form.cashAccountId && (
                  <p className="mt-1 text-[10px] text-red-500">An order booker collects cash in the field, so a cash account is required.</p>
                )}
              </Field>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
              <SeriesPicker
                label="Receive Payment Series" kind="receivePayment" value={form.receivePaymentSeriesId} rows={series}
                onChange={id => set('receivePaymentSeriesId', id)} onCreate={createSeries}
              />
            </div>

            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 mt-4">
              <Check checked={form.canChangePrice} onChange={v => set('canChangePrice', v)} label="Can change price" />
              <Check checked={form.canAddDiscount} onChange={v => set('canAddDiscount', v)} label="Can Add Discount" />
              <Check checked={form.isManager} onChange={v => set('isManager', v)} label="Is Manager" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
              <Field label="Manager">
                <Pick
                  value={String(form.managerId ?? '')}
                  disabled={!form.isManager && !form.managerId}
                  onChange={e => {
                    const id = e.target.value ? Number(e.target.value) : null;
                    setForm(f => ({ ...f, managerId: id, managerName: team.find(s => s.id === id)?.name ?? '' }));
                  }}
                >
                  <option value="">-Choose-</option>
                  {managers.map(s => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
                </Pick>
              </Field>
              <Field label="Branch">
                <Text value={form.branchName} className="bg-gray-50 text-gray-500" readOnly />
              </Field>
            </div>
          </>
        )}

        {tab === 'Application User' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Field label="Application User" hint="Links this sales person to a login">
              <Pick value={String(form.applicationUserId ?? '')} onChange={e => {
                const id = e.target.value ? Number(e.target.value) : null;
                setForm(f => ({ ...f, applicationUserId: id, applicationUserEmail: users.find(u => u.id === id)?.email ?? '' }));
              }}>
                <option value="">-Choose-</option>
                {users.filter(u => u.isActive).map(u => <option key={u.id} value={String(u.id)}>{u.name} ({u.email})</option>)}
              </Pick>
            </Field>
            <Field label="Application User Email">
              <Text value={form.applicationUserEmail} className="bg-gray-50 text-gray-500" readOnly />
            </Field>
          </div>
        )}
      </div>

      <FormFooter
        onSave={() => onSave()}
        onClose={onDone}
        saving={saving}
        disabled={!canSave}
        saveLabel={form.id === 0 ? 'Save and New' : 'Save'}
        statusOptions={[
          { label: 'Save as Active', value: 'active' },
          { label: 'Save as Inactive', value: 'inactive' },
        ]}
      />
    </div>
  );
};

// ─── List ──────────────────────────────────────────────────────────────────
export const SalesPersonsPage: React.FC = () => {
  const { tenantSlug, branchId, branches } = useTenant();
  const [rows, setRows] = useState<SalesPerson[]>([]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'name', dir: 'asc' });
  const [editing, setEditing] = useState<SalesPerson | null>(null);
  const [loading, setLoading] = useState(true);
  // The search box holds its own text, so clearing it from the table means a fresh one.
  const [searchEpoch, setSearchEpoch] = useState(0);

  const requestId = useRef(0);
  const refresh = useCallback(() => {
    const at = ++requestId.current;
    setLoading(true);
    getSalesPersons(tenantSlug, branchId, search).then(d => {
      if (at !== requestId.current) return;
      setRows(d.data);
    }).finally(() => { if (at === requestId.current) setLoading(false); });
  }, [tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((a: any, b: any) => String(a[sort.key] ?? '').localeCompare(String(b[sort.key] ?? ''), undefined, { numeric: true }) * dir);
  }, [rows, sort]);

  const filtered = useMemo(() => sorted.filter(r => {
    if (typeFilter === 'salesman') return r.isSalesman;
    if (typeFilter === 'orderBooker') return r.isOrderBooker;
    if (typeFilter === 'deliveryPerson') return r.isDeliveryPerson;
    if (typeFilter === 'manager') return r.isManager;
    return true;
  }), [sorted, typeFilter]);

  const typeCounts = [
    { value: 'salesman', label: 'Salesman', count: rows.filter(r => r.isSalesman).length },
    { value: 'orderBooker', label: 'Order Booker', count: rows.filter(r => r.isOrderBooker).length },
    { value: 'deliveryPerson', label: 'Delivery Person', count: rows.filter(r => r.isDeliveryPerson).length },
    { value: 'manager', label: 'Manager', count: rows.filter(r => r.isManager).length }
  ];
  const activeCount = rows.filter(r => r.isActive).length;
  const inactiveCount = rows.length - activeCount;

  const activeFilters = [
    search && `search “${search}”`,
    typeFilter && `type ${typeCounts.find(t => t.value === typeFilter)?.label ?? typeFilter}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setTypeFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const onSort = (key: string) => setSort(s => (s?.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));

  const openNew = () => {
    const branch = branches.find(b => b.id === branchId);
    setEditing(blank(branchId, branch?.name ?? ''));
  };

  if (editing) {
    return (
      <SalesPersonForm
        key={editing.id}
        person={editing}
        onCreated={refresh}
        onDone={() => { refresh(); setEditing(null); }}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Sales Persons</h2>
            <div className="mt-2">
              <StatStrip stats={[
                { label: 'Sales Persons', value: String(filtered.length), title: 'People this branch lists' },
                { label: 'Active', value: activeCount, tone: 'ok' },
                ...(inactiveCount ? [{ label: 'Inactive', value: inactiveCount, tone: 'warn' as const }] : [])
              ]} />
            </div>
          </div>
          <ListToolbar addLabel="ADD SALES PERSON" onAdd={openNew} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search sales persons..." onSearch={setSearch} />
          <StatusPills value={typeFilter} onChange={setTypeFilter}
            counts={[{ value: '', label: 'All', count: rows.length }, ...typeCounts]} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Sales Persons" filename="sales-persons" columns={columns} rows={filtered} landscape={columns.length > 6} />
          </span>
        </div>
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th>Type</th>
                <th>Series</th>
                <th>Cash Account</th>
                <SortHeader label="Manager" sortKey="managerName" sort={sort} onSort={onSort} />
                <SortHeader label="Application User" sortKey="applicationUserEmail" sort={sort} onSort={onSort} />
                <SortHeader label="Branch" sortKey="branchName" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}><td colSpan={9}><div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} /></td></tr>
              ))}
              {!loading && !filtered.length && (
                <TableEmpty colSpan={9} noun="sales persons" filters={activeFilters}
                  cleared={clearAll} addLabel="ADD SALES PERSON" onAdd={openNew} />
              )}
              {!loading && filtered.map(s => (
                <tr key={s.id} className={s.isActive ? '' : 'opacity-60'}>
                  <td className="font-medium">
                    {s.name}
                    <div className="flex items-center gap-2 mt-0.5 text-[10px] text-gray-400">
                      {s.canChangePrice && <span>Price</span>}
                      {s.canAddDiscount && <span>Discount</span>}
                    </div>
                  </td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${s.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {s.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>{typesOf(s)}</td>
                  <td className="text-xs text-gray-500">
                    {s.receivePaymentSeriesName || '—'}
                  </td>
                  <td>{s.cashAccountName || <span className="text-gray-400">-</span>}</td>
                  <td>{s.managerName || <span className="text-gray-400">-</span>}</td>
                  <td>{s.applicationUserEmail || <span className="text-gray-400">-</span>}</td>
                  <td>{s.branchName || <span className="text-gray-400">-</span>}</td>
                  <td>
                    <div className="flex items-center">
                      <IconAction title={`Edit ${s.name}`} tone="primary" onClick={() => setEditing(s)}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>
                      <IconAction title={`Delete ${s.name}`} tone="danger"
                        onClick={async () => { await deleteSalesPerson(tenantSlug, branchId, s.id); refresh(); }}>
                        <Trash2 className="w-4 h-4" />
                      </IconAction>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SalesPersonsPage;
