import React, { useRef, useState } from 'react';
import { ArrowUpDown, ChevronDown, Upload, X } from 'lucide-react';
import { DocAttachment } from '../../types';
import { useTenant } from '../../context/TenantContext';
import { ExportColumn } from '../../utils/exportTable';
import { ComboSelect, ComboOption } from '../../components/common/ComboSelect';
import { isoDay, monthStart } from '../../utils/dateRange';
import { ExcelMenuButton, PrintMenuButton } from '../../components/print/PrintTemplateModal';
import { printTableWithLetterhead } from '../../utils/printWithLetterhead';

export const Field: React.FC<{ label: string; required?: boolean; hint?: string; children: React.ReactNode; className?: string }> = ({
  label, required, hint, children, className = ''
}) => (
  <div className={className}>
    <label className="block text-xs font-semibold text-gray-600 mb-1">
      {label} {required && <span className="text-red-500">*</span>}
      {hint && <span className="ml-1 font-normal text-gray-400">{hint}</span>}
    </label>
    {children}
  </div>
);

export const Text: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input {...props} className={`input-xenith ${props.className || ''}`} />
);

export const Area: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
  <textarea {...props} className={`input-xenith ${props.className || ''}`} />
);

// A dropdown of records — customers, accounts, warehouses — is a search now, because a book
// with a few hundred rows cannot be scrolled to the one name someone came for. A short choice
// list (a yes/no, a period, three sort orders) has nothing to search, so it keeps the native
// select. The children are read back off the <option> elements, so every call site that already
// builds a <Pick> gains this without changing a line.
// `search` settles the question for one field instead of leaving it to the count: a record list
// that happens to hold three names today still searches, because counting rows is what makes a
// customer dropdown stop being one. Two choices or fewer are not a list to search, so even a
// forced pick waits until there are three to read.
const SEARCHABLE_FROM = 5;
const SEARCH_MIN = 3;

const readChoices = (children: React.ReactNode): ComboOption[] | null => {
  const out: ComboOption[] = [];
  for (const child of React.Children.toArray(children)) {
    if (!React.isValidElement(child) || child.type !== 'option') return null;
    const { value, children: label } = child.props as { value?: unknown; children?: React.ReactNode };
    const text = React.Children.toArray(label).map(x =>
      typeof x === 'string' || typeof x === 'number' ? String(x) : ''
    ).join('').trim();
    // A label built out of JSX is not ours to read — leave that field alone.
    if (!text) return null;
    out.push({ value: value === undefined ? text : String(value), label: text });
  }
  return out.length ? out : null;
};

export const Pick: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { search?: boolean }> = (props) => {
  const { children, value, onChange, disabled, title, className = '', search, ...rest } = props;
  const choices = typeof value === 'string' || typeof value === 'number' ? readChoices(children) : null;
  if (!choices || choices.length < (search ? SEARCH_MIN : SEARCHABLE_FROM) || rest.multiple || rest.size) {
    return (
      <select {...rest} value={value} onChange={onChange} disabled={disabled} title={title}
        className={`input-xenith ${className}`}>{children}</select>
    );
  }
  return (
    <ComboSelect options={choices} value={String(value)} disabled={!!disabled} title={title}
      ariaLabel={props['aria-label']}
      placeholder={choices[0]?.label ?? '—'} searchPlaceholder={`Search ${choices.length} options...`}
      className={className}
      onPick={v => (onChange as unknown as ((e: unknown) => void) | undefined)?.({
        target: { value: v }, currentTarget: { value: v },
        preventDefault: () => {}, stopPropagation: () => {}
      })} />
  );
};

// A box that names a range is a promise about the number it hands back. min/max only colour
// the native control, so a Terminal Count of 1 used to accept a typed 0 and send it off —
// the clamp arrives on blur, because clamping mid-keystroke would fight the person typing.
export const NumCell: React.FC<Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value'> & { value: number }> = ({
  value, min, max, onChange, ...rest
}) => {
  const clip = (n: number) => Math.min(Math.max(n, min === undefined ? -Infinity : Number(min)), max === undefined ? Infinity : Number(max));
  return (
    <input
      {...rest}
      min={min}
      max={max}
      type="number"
      value={value ? String(value) : ''}
      placeholder={rest.placeholder ?? '0'}
      onChange={onChange}
      onBlur={e => {
        const n = Number.isFinite(Number(value)) ? Number(value) : 0;
        const want = clip(n);
        if (want !== n) (onChange as unknown as ((e: unknown) => void) | undefined)?.({
          target: { value: String(want) }, currentTarget: { value: String(want) },
          preventDefault: () => {}, stopPropagation: () => {}
        });
        rest.onBlur?.(e);
      }}
      className={`input-xenith text-right ${rest.className || ''}`}
    />
  );
};

export const Check: React.FC<{ checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }> = ({
  checked, onChange, label, disabled
}) => (
  <label className={`flex items-start gap-1.5 text-xs ${disabled ? 'text-gray-400' : 'text-gray-700 cursor-pointer'}`}>
    <input
      type="checkbox"
      checked={checked}
      disabled={disabled}
      onChange={e => onChange(e.target.checked)}
      className="mt-0.5 accent-[#1e88e5]"
    />
    <span>{label}</span>
  </label>
);

export const TabStrip: React.FC<{ tabs: string[]; active: string; onChange: (t: string) => void }> = ({ tabs, active, onChange }) => (
  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-gray-200 px-4 pt-3 bg-white">
    {tabs.map(t => (
      <button
        key={t}
        type="button"
        onClick={() => onChange(t)}
        className={`pb-2 text-xs font-semibold border-b-2 -mb-px transition-colors ${
          active === t ? 'border-[#1e88e5] text-[#1e88e5]' : 'border-transparent text-gray-500 hover:text-gray-700'
        }`}
      >
        {t}
      </button>
    ))}
  </div>
);

export const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-3">{children}</div>
);

export interface PickOption { id: number; label: string; sub?: string }

// Charts of accounts run into hundreds of rows, so every account box in the app is a
// search that narrows as you type rather than a long dropdown to scroll.
export const SearchPick: React.FC<{
  options: PickOption[];
  valueId: number | null;
  valueLabel?: string;
  onPick: (opt: PickOption | null) => void;
  placeholder?: string;
  emptyText?: string;
  required?: boolean;
}> = ({ options, valueId, valueLabel, onPick, placeholder = 'Type to search...', emptyText = 'No match', required }) => {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const chosen = options.find(o => o.id === valueId);
  const text = open ? query : (chosen?.label ?? valueLabel ?? '');
  const matches = options.filter(o =>
    `${o.label} ${o.sub ?? ''}`.toLowerCase().includes(query.trim().toLowerCase())
  ).slice(0, 10);
  return (
    <div className="relative">
      <input
        className="input-xenith"
        value={text}
        placeholder={placeholder}
        onFocus={() => { setOpen(true); setQuery(''); }}
        onChange={e => { setQuery(e.target.value); setOpen(true); }}
        onBlur={() => window.setTimeout(() => setOpen(false), 150)}
      />
      {open && (
        <ul className="absolute z-30 left-0 right-0 top-full mt-1 max-h-56 overflow-auto bg-white border border-gray-200 rounded shadow-lg text-xs">
          {matches.map(o => (
            <li key={o.id}>
              <button
                type="button"
                // The list must survive the click, or the blur handler closes it first.
                onMouseDown={e => {
                  e.preventDefault();
                  onPick(o);
                  setQuery('');
                  setOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-50"
              >
                <span className="font-semibold text-gray-800">{o.label}</span>
                {o.sub && <span className="text-gray-500"> · {o.sub}</span>}
              </button>
            </li>
          ))}
          {matches.length === 0 && <li className="px-3 py-2 text-gray-400">{emptyText}</li>}
        </ul>
      )}
      {!open && !chosen && !valueLabel && required && (
        <p className="text-[11px] text-red-500 mt-1">Pick one of the listed accounts.</p>
      )}
    </div>
  );
};

export interface SortState { key: string; dir: 'asc' | 'desc' }

export const SortHeader: React.FC<{ label: string; sortKey?: string; sort: SortState | null; onSort: (k: string) => void }> = ({
  label, sortKey, sort, onSort
}) => (
  <th className="whitespace-nowrap">
    {sortKey ? (
      <button
        type="button"
        onClick={() => onSort(sortKey)}
        className="inline-flex items-center gap-1 hover:text-[#1e88e5]"
      >
        {label}
        <ArrowUpDown className={`w-3 h-3 ${sort?.key === sortKey ? 'text-[#1e88e5]' : 'text-gray-400'}`} />
      </button>
    ) : label}
  </th>
);

export const ListToolbar: React.FC<{ addLabel: string; onAdd: () => void; children?: React.ReactNode }> = ({ addLabel, onAdd, children }) => (
  <div className="flex flex-wrap items-center gap-2">
    <button type="button" onClick={onAdd} className="btn-xenith-success">
      <span className="font-semibold">+</span> {addLabel}
    </button>
    {children}
  </div>
);

// The date range still applies while the FILTERS panel is shut, so the window it is cutting
// the list down to has to be stated in the open — with a way to drop it in one click.
export const DateRangeChip: React.FC<{ from: string; to: string; onClear: () => void }> = ({ from, to, onClear }) => {
  if (!from && !to) return null;
  return (
    <button type="button" onClick={onClear} title="Clear the date range and show every record"
      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-semibold border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors">
      {from || 'start'} → {to || 'today'}
      <X className="w-3 h-3" />
    </button>
  );
};

export interface RegisterStat {
  label: string;
  value: string | number;
  // The chip's figure is the thing a reader acts on, so it may carry the same intent
  // colours the rest of the workspace uses. Omit it for a plain count.
  tone?: 'ok' | 'warn' | 'bad';
  title?: string;
}

// What a register is holding, stated above the rows instead of making the reader add the
// column up by hand. A screen builds these from the rows it is actually painting, which is
// the same set the table's own totals line adds, so the headline can never disagree with it.
export const StatStrip: React.FC<{ stats: RegisterStat[] }> = ({ stats }) => (
  <div className="flex flex-wrap items-center gap-1.5">
    {stats.map(s => (
      <span key={s.label} title={s.title}
        className={`stat-chip${s.tone ? ` is-${s.tone}` : ''}`}>
        {s.label}
        <strong>{s.value}</strong>
      </span>
    ))}
  </div>
);

// The paper states as one click each, with the number each one holds written on it.
// A state the register does not hold is left out rather than offered: clicking it could
// only ever produce an empty table.
export const StatusPills: React.FC<{
  value: string;
  onChange: (v: string) => void;
  counts: { value: string; label: string; count: number }[];
}> = ({ value, onChange, counts }) => {
  const shown = counts.filter(c => c.count > 0 || c.value === value || !c.value);
  return (
    <div className="seg-filter" role="group" aria-label="Filter by status">
      {shown.map(c => (
        <button key={c.value || 'all'} type="button"
          aria-pressed={value === c.value}
          className={value === c.value ? 'is-on' : ''}
          onClick={() => onChange(c.value)}>
          {c.label}
          {c.value && <em>{c.count}</em>}
        </button>
      ))}
    </div>
  );
};

const PRESETS: { label: string; from: () => string; to: () => string }[] = [
  { label: 'This month', from: monthStart, to: isoDay },
  { label: 'Last month', from: () => {
    const n = new Date();
    return isoDay(new Date(n.getFullYear(), n.getMonth() - 1, 1));
  }, to: () => {
    const n = new Date();
    return isoDay(new Date(n.getFullYear(), n.getMonth(), 0));
  } },
  { label: 'This year', from: () => {
    const n = new Date();
    return isoDay(new Date(n.getFullYear(), 0, 1));
  }, to: isoDay },
  { label: 'All time', from: () => '', to: () => '' }
];

// One plate for the date window: the two endpoints answer a single question, and the
// presets underneath it are why a register no longer needs a FILTERS panel to open.
export const DateWindow: React.FC<{
  from: string; to: string;
  onChange: (from: string, to: string) => void;
}> = ({ from, to, onChange }) => {
  const preset = PRESETS.find(p => p.from() === from && p.to() === to)?.label ?? '';
  return (
    <span className="filter-plate">
      <select
        aria-label="Period"
        value={preset}
        onChange={e => {
          const p = PRESETS.find(x => x.label === e.target.value);
          if (p) onChange(p.from(), p.to());
        }}
      >
        <option value="">Period</option>
        {PRESETS.map(p => <option key={p.label} value={p.label}>{p.label}</option>)}
      </select>
      <input type="date" aria-label="From date" value={from} onChange={e => onChange(e.target.value, to)} />
      <span aria-hidden>→</span>
      <input type="date" aria-label="To date" value={to} onChange={e => onChange(from, e.target.value)} />
      {(from || to) && (
        <button type="button" title="Show every date" onClick={() => onChange('', '')}
          className="text-gray-400 hover:text-gray-600">
          <X className="w-3 h-3" />
        </button>
      )}
    </span>
  );
};

// An empty register says which filter emptied it and hands it back, instead of printing
// "No record found" and leaving the reader to hunt for the box they typed in.
export const TableEmpty: React.FC<{
  colSpan: number;
  // A name for what the screen lists, e.g. "sale invoices" — the sentence reads
  // differently when nothing exists yet and when a filter is hiding something.
  noun: string;
  // The filters the reader can still see, written out so the register names what it
  // is doing rather than claiming there is nothing to show.
  filters?: string[];
  cleared: () => void;
  addLabel?: string;
  onAdd?: () => void;
}> = ({ colSpan, noun, filters = [], cleared, addLabel, onAdd }) => {
  // Written as a list plus one sentence, so the copy cannot ask a plural to take a
  // singular verb when only one filter is set.
  const list = filters.length < 2 ? filters[0] ?? ''
    : `${filters.slice(0, -1).join(', ')} and ${filters[filters.length - 1]}`;
  return (
    <tr>
      <td colSpan={colSpan}>
        <div className="table-empty">
          {filters.length ? (
            <>
              <p>No {noun} match these filters</p>
              <span>
                Filters in place: {list}. Nothing on the register answers to{' '}
                {filters.length === 1 ? 'it.' : 'all of them together.'}
              </span>
              <button type="button" onClick={cleared} className="btn-xenith-outline">Clear every filter</button>
            </>
          ) : (
            <>
              <p>No {noun} on the book yet</p>
              <span>{addLabel ? `Press ${addLabel} to put the first one on the book.` : 'Records will appear here as they are saved.'}</span>
              {addLabel && onAdd && (
                <button type="button" onClick={onAdd} className="btn-xenith-success">
                  <span className="font-semibold">+</span> {addLabel}
                </button>
              )}
            </>
          )}
        </div>
      </td>
    </tr>
  );
};

// One search box for every list screen: it waits for typing to settle before asking
// the server, and can be cleared without selecting the text.
export { SearchBox } from '../../components/common/SearchBox';

// Every table row action looks and behaves the same: fixed hit area, colour that matches
// what it does, and a label screen readers and hover tooltips can both read.
export const IconAction: React.FC<{
  title: string; onClick?: () => void; children: React.ReactNode;
  tone?: 'default' | 'primary' | 'success' | 'danger' | 'muted'; disabled?: boolean
}> = ({ title, onClick, children, tone = 'default', disabled }) => {
  const tones: Record<string, string> = {
    default: 'text-gray-500 hover:text-blue-600',
    primary: 'text-blue-500 hover:text-blue-700',
    success: 'text-emerald-600 hover:text-emerald-800',
    danger: 'text-gray-400 hover:text-red-600',
    muted: 'text-gray-300'
  };
  return (
    <button
      type="button" title={title} aria-label={title} disabled={disabled || !onClick} onClick={onClick}
      className={`inline-flex items-center justify-center w-7 h-7 rounded transition-colors ${
        disabled ? `${tones.muted} cursor-not-allowed` : `${tones[tone]} hover:bg-gray-100`}`}
    >
      {children}
    </button>
  );
};

// Arming a delete has to be walkable back from: one button finishes the row, the other puts
// it straight back the way it was without reloading the screen.
export const DeleteConfirm: React.FC<{
  onConfirm: () => void; onCancel: () => void;
  confirmLabel?: string; keepLabel?: string;
}> = ({ onConfirm, onCancel, confirmLabel = 'Confirm', keepLabel = 'Keep this record' }) => (
  <>
    <button type="button" onClick={onConfirm}
      className="text-[10px] font-bold text-white bg-red-500 rounded px-2 py-1">{confirmLabel}</button>
    <IconAction title={keepLabel} tone="muted" onClick={onCancel}>
      <X className="w-4 h-4" />
    </IconAction>
  </>
);

// Every list screen prints and exports the rows it is showing. Keeping the pair in one
// place means the two buttons can never disagree about which columns they carry — and both
// read the design the company saved for the surface, so a screen's paper and its workbook
// share one look.
export function ExportPair<T>({ title, subtitle, org, filename, columns, rows, footer, landscape }: {
  title: string;
  subtitle?: string;
  org?: string;
  filename: string;
  columns: ExportColumn<T>[];
  rows: T[];
  footer?: (string | undefined)[];
  landscape?: boolean;
}) {
  const { tenantName, tenantSlug, branchId } = useTenant();
  return (
    <>
      <PrintMenuButton document={title} title={title} subtitle={subtitle}
        onPrint={design => printTableWithLetterhead(tenantSlug, branchId,
          { title, subtitle, org: org ?? tenantName, columns, rows, footer, landscape, design })} />
      <ExcelMenuButton title={title} subtitle={subtitle} org={org ?? tenantName}
        filename={filename} columns={columns} rows={rows} footer={footer} landscape={landscape} />
    </>
  );
}

export const FormFooter: React.FC<{
  onSave: (status?: string) => void;
  onClose: () => void;
  saving?: boolean;
  disabled?: boolean;
  saveLabel?: string;
  statusOptions?: { label: string; value: string }[];
}> = ({ onSave, onClose, saving, disabled, saveLabel = 'Save and Close', statusOptions }) => (
  <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-gray-100 bg-white">
    <div className="flex items-stretch">
      <button
        type="button"
        disabled={saving || disabled}
        onClick={() => onSave()}
        className="btn-xenith-success rounded-r-none disabled:opacity-50"
      >
        {saving ? 'Saving...' : saveLabel}
      </button>
      {statusOptions && (
        <details className="relative group">
          <summary className="list-none cursor-pointer bg-[#25a195] hover:bg-[#1f8c82] text-white px-1.5 rounded-r inline-flex items-center">
            <ChevronDown className="w-3.5 h-3.5" />
          </summary>
          <ul className="absolute bottom-full right-0 mb-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-40 text-xs">
            {statusOptions.map(o => (
              <li key={o.value}>
                <button
                  type="button"
                  disabled={saving || disabled}
                  className="w-full text-left px-3 py-2 hover:bg-blue-50 text-gray-700 disabled:opacity-50 disabled:hover:bg-transparent"
                  onClick={() => onSave(o.value)}
                >
                  {o.label}
                </button>
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
    <button type="button" onClick={onClose} className="btn-xenith-warning">
      <X className="w-3.5 h-3.5" /> Close
    </button>
  </div>
);

export const AttachmentBox: React.FC<{
  items: DocAttachment[];
  onChange: (items: DocAttachment[]) => void;
  label?: string;
}> = ({ items, onChange, label = 'Click or drag files to upload' }) => {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [skipped, setSkipped] = useState<string[]>([]);
  // The bytes are read into the record so a saved attachment can be opened again after a
  // restart. Anything past 2 MB is refused out loud instead of stored as a bare name.
  const MAX_MB = 2;
  const read = (f: File) => new Promise<DocAttachment | null>(resolve => {
    const r = new FileReader();
    r.onload = () => resolve({ name: f.name, size: f.size, data: String(r.result) });
    r.onerror = () => resolve(null);
    r.readAsDataURL(f);
  });
  const add = (files: FileList | null) => {
    if (!files) return;
    const fresh = Array.from(files).filter(f => !items.some(a => a.name === f.name));
    const tooBig = fresh.filter(f => f.size > MAX_MB * 1024 * 1024)
      .map(f => `${f.name} (over ${MAX_MB} MB)`);
    Promise.all(fresh.filter(f => f.size <= MAX_MB * 1024 * 1024).map(async f => {
      const a = await read(f);
      return a ?? `${f.name} (could not be read)`;
    })).then(results => {
      const good = results.filter((r): r is DocAttachment => typeof r !== 'string');
      const bad = results.filter((r): r is string => typeof r === 'string');
      if (good.length) onChange([...items, ...good]);
      setSkipped([...tooBig, ...bad]);
    });
  };
  return (
    <div>
      <div
        onDragOver={e => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={e => { e.preventDefault(); setOver(false); add(e.dataTransfer.files); }}
        className={`border-2 border-dashed rounded px-3 py-4 flex items-center justify-between gap-3 ${
          over ? 'border-[#1e88e5] bg-blue-50/40' : 'border-gray-300 bg-gray-50'
        }`}
      >
        <span className="flex items-center gap-2 text-xs text-gray-500">
          <Upload className="w-4 h-4" /> {label}
        </span>
        <button type="button" onClick={() => input.current?.click()} className="btn-xenith-primary">
          Browse Files
        </button>
        <input ref={input} type="file" multiple className="hidden" onChange={e => add(e.target.files)} />
      </div>
      {items.length > 0 && (
        <ul className="mt-2 space-y-1">
          {items.map((a, i) => (
            <li key={a.name} className="flex items-center justify-between text-xs text-gray-600 bg-gray-50 border border-gray-200 rounded px-2 py-1">
              {a.data
                ? <a href={a.data} download={a.name} className="truncate text-[#1e88e5] hover:underline">{a.name}</a>
                : <span className="truncate">{a.name}</span>}
              <span className="flex items-center gap-2">
                <span className="text-gray-400">{a.size < 1024 ? `${a.size} B` : `${(a.size / 1024).toFixed(a.size < 102400 ? 1 : 0)} KB`}</span>
                <button type="button" onClick={() => onChange(items.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-500">
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}
      {skipped.length > 0 && (
        <p className="mt-2 text-[11px] text-red-600">Not stored: {skipped.join(', ')}</p>
      )}
    </div>
  );
};

export const ImagePicker: React.FC<{ value: string; onChange: (v: string) => void; round?: boolean }> = ({ value, onChange, round }) => {
  const input = useRef<HTMLInputElement>(null);
  return (
    <div className="flex items-center gap-3">
      <div className={`${round ? 'w-20 h-20 rounded-full' : 'w-20 h-20'} bg-gray-100 border border-gray-200 flex items-center justify-center overflow-hidden`}>
        {value ? <img src={value} alt="" className="w-full h-full object-cover" /> : <span className="text-[10px] text-gray-400">No image</span>}
      </div>
      <div>
        <button type="button" onClick={() => input.current?.click()} className="btn-xenith-outline">Choose Image</button>
        <input
          ref={input} type="file" accept="image/*" className="hidden"
          onChange={e => {
            const f = e.target.files?.[0];
            if (!f) return;
            const r = new FileReader();
            r.onload = () => onChange(String(r.result));
            r.readAsDataURL(f);
          }}
        />
      </div>
    </div>
  );
};
