import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { Category, CategoryType } from '../../types';
import { addCategory, deleteCategory, getCategories } from '../../services/masters.service';
import { ExportPair, IconAction, ListToolbar, Pick, StatStrip, StatusPills, TableEmpty, Text } from './masterUi';
import { SearchBox } from '../../components/common/SearchBox';
import { ExportColumn } from '../../utils/exportTable';
import { CATEGORY_MAX_LEVEL, levelOf, trailOf } from '../../utils/categoryTree';
import { useScreenReload } from '../../utils/screenReload';

interface Props {
  type: CategoryType;
  title: string;
}

// The category registers this build has a screen for. `CategoryType` is wider than this on
// purpose: a saved book may hold rows of the older kinds, and reading them back must never
// fail. But a kind no form opens has no register to edit it, so it is not offered here either
// as a menu entry or as an address — /cat/tax answers "this screen does not exist", which is
// the truth, instead of a permission wall for a screen nobody owns.
export const CATEGORY_TITLES: Partial<Record<CategoryType, string>> = {
  customer: 'Customer Categories',
  vendor: 'Vendor Categories',
  product: 'Product Categories',
  brand: 'Brands',
  warehouse: 'Warehouses',
  department: 'Departments',
  designation: 'Designations',
};

// A register filed three deep has to say which shelf a name sits on, on paper as well as on
// screen; a flat one has nothing to place, so it keeps the two columns it always had.
const LEVEL_TITLES = ['', 'Parent Category', 'Sub Category', 'Category'];

const exportColumns = (nested: boolean, all: Category[]): ExportColumn<Category>[] => [
  { label: 'Name', value: (r: Category) => r.name },
  ...(nested ? [
    { label: 'Level', value: (r: Category) => LEVEL_TITLES[levelOf(all, r.id)] ?? '' },
    { label: 'Filed Under', value: (r: Category) => trailOf(all, r.id).slice(0, -1).map(c => c.name).join(' › ') || '—' },
  ] : []),
  { label: 'Status', value: (r: Category) => (r.isActive ? 'Active' : 'Inactive') },
];

export const CategoryPage: React.FC<Props> = ({ type, title }) => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<Category[]>([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  // Which shelf a new row goes under. Only a register that actually has shelves offers it.
  const [parentId, setParentId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  // The search box holds its own text, so clearing it from the table means a fresh one.
  const [searchEpoch, setSearchEpoch] = useState(0);

  const refresh = useCallback(() => {
    setLoading(true);
    getCategories(tenantSlug, branchId, type, search).then(d => setRows(d.data)).finally(() => setLoading(false));
  }, [tenantSlug, branchId, type, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  // The product register is a tree; every other master is a flat list. Rather than trusting
  // a name, the page reads the data: a register where nothing has a parent stays two columns.
  const nested = type === 'product' || rows.some(r => r.parentId != null);
  // A shelf is one column wider than a flat list.
  const bodyCols = nested ? 4 : 3;

  const shown = useMemo(
    () => rows.filter(r => !status || (status === 'Active' ? r.isActive : !r.isActive)),
    [rows, status]
  );

  // Depth-first over the whole register, then narrowed to what is on screen — so a search
  // that matches a sub-category but not its parent still puts the sub-category on screen
  // instead of dropping it for want of a branch to hang it from.
  const flow = useMemo(() => {
    if (!nested) return shown;
    const keep = new Set(shown.map(r => r.id));
    const out: Category[] = [];
    const seen = new Set<number>();
    const walk = (under: number | null) => {
      rows.filter(c => (c.parentId ?? null) === under).forEach(c => {
        if (seen.has(c.id)) return;
        seen.add(c.id);
        if (keep.has(c.id)) out.push(c);
        walk(c.id);
      });
    };
    walk(null);
    return out;
  }, [nested, rows, shown]);

  // A row can only open a shelf beneath one that already exists, and nothing hangs below the
  // deepest level, so the picker offers the register minus its leaves.
  const shelfOptions = useMemo(
    () => rows.filter(r => levelOf(rows, r.id) < CATEGORY_MAX_LEVEL)
      .sort((a, b) => trailOf(rows, a.id).map(c => c.name).join('›').localeCompare(trailOf(rows, b.id).map(c => c.name).join('›'))),
    [rows]
  );

  const activeCount = rows.filter(r => r.isActive).length;
  const inactiveCount = rows.length - activeCount;

  const activeFilters = [
    search && `search “${search}”`,
    status && `status ${status}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const submit = async () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (rows.some(r => (r.parentId ?? null) === (parentId ?? null) && r.name.toLowerCase() === trimmed.toLowerCase())) {
      setError('Something is already filed here under this name.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await addCategory(tenantSlug, branchId, trimmed, type, parentId);
      setName('');
      setAdding(false);
      refresh();
    } catch (e: any) {
      setError(e.message || String(e));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (r: Category) => {
    setError('');
    try {
      await deleteCategory(tenantSlug, branchId, r.id);
      refresh();
    } catch (e: any) {
      // The register refused for a reason the reader has to see: a shelf that holds rows, or
      // a category a product is standing on, cannot simply be taken away.
      setError(e.message || String(e));
    }
  };

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">{title}</h2>
            <div className="mt-2">
              <StatStrip stats={[
                { label: title, value: String(shown.length), title: `${title} this branch holds` },
                { label: 'Active', value: activeCount, tone: 'ok' },
                ...(inactiveCount ? [{ label: 'Inactive', value: inactiveCount, tone: 'warn' as const }] : [])
              ]} />
            </div>
          </div>
          <ListToolbar addLabel="ADD NEW" onAdd={() => setAdding(true)} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} className="w-56 max-w-full"
            placeholder={`Search ${title.toLowerCase()}...`} onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={[
            { value: '', label: 'All', count: rows.length },
            { value: 'Active', label: 'Active', count: activeCount },
            { value: 'Inactive', label: 'Inactive', count: inactiveCount }
          ]} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={title} filename={title.toLowerCase().replace(/\s+/g, '-')}
              columns={exportColumns(nested, rows)} rows={flow} />
          </span>
        </div>

        {error && (
          <div className="mx-4 mb-3 text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div>
        )}

        {adding && (
          <div className="flex flex-wrap items-end gap-2 px-4 py-3 border-t border-gray-100 bg-gray-50/70">
            <div className="flex-1 max-w-xs">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Name <span className="text-red-500">*</span></label>
              <Text
                autoFocus
                value={name}
                onChange={e => setName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') submit(); }}
                placeholder="Enter name"
              />
            </div>
            {/* Left alone, a new row is a shelf of its own; choosing a place under one files it
                a level deeper, which is how the product register reaches three. */}
            {nested && (
              <div className="w-56 max-w-full">
                <label className="block text-xs font-semibold text-gray-600 mb-1">Filed Under</label>
                <Pick value={parentId ?? ''} onChange={e => setParentId(e.target.value === '' ? null : Number(e.target.value))}>
                  <option value="">Top level (a category of its own)</option>
                  {shelfOptions.map(r => (
                    <option key={r.id} value={r.id}>
                      {trailOf(rows, r.id).map(c => c.name).join(' › ')}
                    </option>
                  ))}
                </Pick>
              </div>
            )}
            <button type="button" onClick={() => { setAdding(false); setName(''); setParentId(null); setError(''); }} className="btn-xenith-outline"><X className="w-3.5 h-3.5" /> Cancel</button>
            <button type="button" disabled={saving || !name.trim()} onClick={submit} className="btn-xenith-success disabled:opacity-50">
              <Plus className="w-3.5 h-3.5" /> {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        )}
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th>Name</th>
                {nested && <th className="w-36">Level</th>}
                <th className="w-24">Status</th>
                <th className="w-24">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}><td colSpan={bodyCols}><div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 9}%` }} /></td></tr>
              ))}
              {!loading && !flow.length && (
                <TableEmpty colSpan={bodyCols} noun={title.toLowerCase()} filters={activeFilters} cleared={clearAll} />
              )}
              {!loading && flow.map(r => {
                const lvl = levelOf(rows, r.id);
                return (
                <tr key={r.id} className={r.isActive ? '' : 'opacity-60'}>
                  {/* Indented by how deep the row hangs, so the tree reads on the page the way
                      the product card files it. */}
                  <td className="font-medium" style={{ paddingLeft: `${12 + (nested ? (lvl - 1) * 16 : 0)}px` }}>
                    {r.name}
                    {nested && lvl > 1 && (
                      <span className="ml-1.5 font-normal text-[10px] text-gray-500">
                        under {trailOf(rows, r.id).slice(0, -1).map(c => c.name).join(' › ')}
                      </span>
                    )}
                  </td>
                  {nested && (
                    <td>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        lvl === 1 ? 'bg-[#e8f2fd] text-[#1565c0]' : lvl === 2 ? 'bg-violet-50 text-violet-700' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {LEVEL_TITLES[lvl] ?? ''}
                      </span>
                    </td>
                  )}
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${r.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {r.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <IconAction title={`Delete ${r.name}`} tone="danger" onClick={() => remove(r)}>
                      <Trash2 className="w-4 h-4" />
                    </IconAction>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
