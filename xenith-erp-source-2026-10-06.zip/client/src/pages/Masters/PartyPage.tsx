import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Plus, RefreshCw, X, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { Category, CategoryType, CustomFieldValue, Party, SalesPerson } from '../../types';
import { PartyResource, getCategories, getParties, getParty, getPartyProposedNumber, getSalesPersons, saveParty, updateParty, deleteParty } from '../../services/masters.service';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import {
  AttachmentBox, Check, ExportPair, Field, FormFooter, IconAction, ImagePicker, ListToolbar, Pick,
  RegisterStat, SearchBox, SectionTitle, SortHeader, SortState, StatStrip, TabStrip, TableEmpty, Text, Area
} from './masterUi';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const COUNTRIES = ['Pakistan', 'United Arab Emirates', 'Saudi Arabia', 'United Kingdom', 'United States', 'China', 'Turkey', 'India', 'Bangladesh'];

const KIND_META: Record<PartyResource, { label: string; categoryType: CategoryType }> = {
  customers: { label: 'Customer', categoryType: 'customer' },
  vendors: { label: 'Vendor', categoryType: 'vendor' },
};

const columns: ExportColumn<Party>[] = [
  { label: 'Code', value: (r) => r.code },
  { label: 'Name', value: (r) => r.name },
  { label: 'Category', value: (r) => r.categoryName || '-' },
  { label: 'Contact Person', value: (r) => r.contactPerson || '-' },
  { label: 'Email', value: (r) => r.email1 || '-' },
  { label: 'Phone', value: (r) => r.phone1 || '-' },
  { label: 'Balance', value: (r) => money(r.currentBalance), align: 'right' },
];

const columnsOf = (kind: PartyResource) =>
  kind === 'customers' ? columns.filter(c => c.label !== 'Balance') : columns;

const money = (n: number | undefined) => (Number(n || 0)).toLocaleString();

const blankParty = (code: string): Party => ({
  id: 0, code, name: '', printName: '', displayName: '', categoryId: null, categoryName: '',
  contactPerson: '', careOf: '', salesPersonId: null, salesPersonName: '',
  email1: '', email2: '', email3: '', phone1: '', phone2: '', phone3: '',
  address1: '', address2: '', city: '', state: '', zip: '', country: 'Pakistan', fax: '', ntn: '', cnic: '',
  openingBalance: 0, creditLimitAmount: 0, creditLimitDays: 0, discountPercent: 0, withholdingTaxPercent: 0,
  isCashCustomer: false, isSalesTaxRegistered: false, isTaxFiler: false, isTaxAgent: false, isPrincipal: false,
  imageUrl: '', isActive: true, attachments: [], customFields: [],
});

// ─── Form ──────────────────────────────────────────────────────────────────
const TABS = ['General', 'Address', 'Custom Fields'];

interface FormProps {
  kind: PartyResource;
  partyId: number | null;
  proposed: string;
  onDone: () => void;
}

export const PartyForm: React.FC<FormProps> = ({ kind, partyId, proposed, onDone }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const label = KIND_META[kind].label;

  const [tab, setTab] = useState('General');
  const [form, setForm] = useState<Party>({ ...blankParty(proposed) });
  const [categories, setCategories] = useState<Category[]>([]);
  const [salesPersons, setSalesPersons] = useState<SalesPerson[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [newField, setNewField] = useState('');
  const [fields, setFields] = useState<CustomFieldValue[]>([]);

  useEffect(() => {
    getCategories(tenantSlug, branchId, KIND_META[kind].categoryType).then(d => setCategories(d.data));
    // Only people flagged as a salesman can own a customer account.
    if (kind === 'customers') getSalesPersons(tenantSlug, branchId).then(d => setSalesPersons(d.data.filter(s => s.isSalesman && s.isActive)));
  }, [tenantSlug, branchId, kind]);

  useEffect(() => {
    if (partyId == null) return;
    getParty(kind, tenantSlug, branchId, partyId).then(p => { setForm(p); setFields(p.customFields || []); });
  }, [kind, tenantSlug, branchId, partyId]);

  const set = <K extends keyof Party>(key: K, value: Party[K]) => setForm(f => ({ ...f, [key]: value }));

  const categoryOptions: SelectOption[] = categories.map(c => ({ id: c.id, label: c.name }));
  const canSave = form.name.trim().length > 0 && !saving;

  const onSave = async (statusOverride?: string) => {
    if (!canSave) return;
    setSaving(true);
    setError('');
    const body: Partial<Party> = { ...form, customFields: fields.filter(f => f.field.trim()), ...(statusOverride === 'inactive' ? { isActive: false } : {}) };
    try {
      if (partyId == null) await saveParty(kind, tenantSlug, branchId, body);
      else await updateParty(kind, tenantSlug, branchId, partyId, body);
      onDone();
    } catch (e: any) {
      setError(e.message || String(e));
      setSaving(false);
    }
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span>{label}s - {form.code}</span>
        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-500">
          {form.isActive ? 'Active' : 'Inactive'}
        </span>
      </div>

      <TabStrip tabs={TABS} active={tab} onChange={setTab} />

      {error && <div className="mx-4 mt-3 text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div>}

      <div className="nb-card-body">
        {tab === 'General' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label={`${label} Code`} required>
                  <div className="flex items-stretch gap-1">
                    <Text value={form.code} onChange={e => set('code', e.target.value)} className="rounded-r-none" />
                    <button
                      type="button"
                      title="Get next number"
                      onClick={async () => set('code', await getPartyProposedNumber(kind, tenantSlug, branchId))}
                      className="px-2 rounded border border-gray-300 bg-[#2ec4b6] hover:bg-[#25a195] text-white"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </Field>
                <Field label={`${label} Name`} required>
                  <Text value={form.name} onChange={e => set('name', e.target.value)} placeholder="Enter name" />
                </Field>
                <Field label="Print Name">
                  <Text value={form.printName} onChange={e => set('printName', e.target.value)} />
                </Field>
                <Field label="Display Name">
                  <Text value={form.displayName} onChange={e => set('displayName', e.target.value)} />
                </Field>
                <Field label="Email 1"><Text type="email" value={form.email1} onChange={e => set('email1', e.target.value)} /></Field>
                <Field label="Email 2"><Text type="email" value={form.email2} onChange={e => set('email2', e.target.value)} /></Field>
                <Field label="Email 3"><Text type="email" value={form.email3} onChange={e => set('email3', e.target.value)} /></Field>
                <Field label="Phone 1"><Text value={form.phone1} onChange={e => set('phone1', e.target.value)} /></Field>
                <Field label="Phone 2"><Text value={form.phone2} onChange={e => set('phone2', e.target.value)} /></Field>
                <Field label="Phone 3"><Text value={form.phone3} onChange={e => set('phone3', e.target.value)} /></Field>
                <Field label={`${label} Category`}>
                  <SearchSelect
                    options={categoryOptions}
                    value={form.categoryId}
                    onChange={id => {
                      const c = categories.find(x => x.id === id) || null;
                      setForm(f => ({ ...f, categoryId: id, categoryName: c ? c.name : '' }));
                    }}
                    placeholder="-Choose-"
                  />
                </Field>
                {kind === 'customers' && (
                  <Field label="Sales Person" hint="Salesman who owns this account">
                    <Pick
                      value={form.salesPersonId === null ? '' : String(form.salesPersonId)}
                      onChange={e => {
                        const id = e.target.value === '' ? null : Number(e.target.value);
                        const sp = salesPersons.find(x => x.id === id) || null;
                        setForm(f => ({ ...f, salesPersonId: id, salesPersonName: sp ? sp.name : '' }));
                      }}>
                      <option value="">-Choose-</option>
                      {salesPersons.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </Pick>
                  </Field>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 mt-4">
                {kind === 'customers' ? (
                  <>
                    <Check checked={form.isCashCustomer} onChange={v => set('isCashCustomer', v)} label="Is Cash Customer" />
                    <Check checked={form.isSalesTaxRegistered} onChange={v => set('isSalesTaxRegistered', v)} label="Is Sales Tax Registered" />
                    <Check checked={form.isTaxFiler} onChange={v => set('isTaxFiler', v)} label="Is Tax Filer" />
                    <Check checked={form.isTaxAgent} onChange={v => set('isTaxAgent', v)} label="Is Tax Agent" />
                  </>
                ) : kind === 'vendors' ? (
                  <Check
                    checked={form.isPrincipal}
                    onChange={v => set('isPrincipal', v)}
                    label="Is this vendor your principal? (Principal can be associated with products for reporting.)"
                  />
                ) : null}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                <Field label={`Opening (${currency})`}>
                  <Text type="number" value={form.openingBalance || ''} onChange={e => set('openingBalance', Number(e.target.value) || 0)} />
                </Field>
                <Field label={`Credit Limit Amount (${currency})`}>
                  <Text type="number" value={form.creditLimitAmount || ''} onChange={e => set('creditLimitAmount', Number(e.target.value) || 0)} />
                </Field>
                <Field label="Credit Limit Days">
                  <Text type="number" value={form.creditLimitDays || ''} onChange={e => set('creditLimitDays', Number(e.target.value) || 0)} />
                </Field>
                <Field label="Discount (%)">
                  <Text type="number" value={form.discountPercent || ''} onChange={e => set('discountPercent', Number(e.target.value) || 0)} />
                </Field>
                <Field label="Withholding Tax (%)">
                  <Text type="number" value={form.withholdingTaxPercent || ''} onChange={e => set('withholdingTaxPercent', Number(e.target.value) || 0)} />
                </Field>
              </div>
            </div>

            <div className="space-y-4">
              <ImagePicker round value={form.imageUrl} onChange={v => set('imageUrl', v)} />
              <div>
                <SectionTitle>Attachments</SectionTitle>
                <AttachmentBox items={form.attachments} onChange={a => set('attachments', a)} />
              </div>
            </div>
          </div>
        )}

        {tab === 'Address' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 gap-3">
                <Field label="Address Line 1"><Area rows={2} value={form.address1} onChange={e => set('address1', e.target.value)} /></Field>
                <Field label="Address Line 2"><Area rows={2} value={form.address2} onChange={e => set('address2', e.target.value)} /></Field>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
                <Field label="City"><Text value={form.city} onChange={e => set('city', e.target.value)} /></Field>
                <Field label="State"><Text value={form.state} onChange={e => set('state', e.target.value)} /></Field>
                <Field label="Zip"><Text value={form.zip} onChange={e => set('zip', e.target.value)} /></Field>
                <Field label="Country">
                  <Pick value={form.country} onChange={e => set('country', e.target.value)}>
                    <option value="">-Choose-</option>
                    {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </Pick>
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <Field label="Contact Person"><Text value={form.contactPerson} onChange={e => set('contactPerson', e.target.value)} /></Field>
                <Field label="C/O (Care Of)" hint="Delivered on behalf of, printed above the address">
                  <Text value={form.careOf} onChange={e => set('careOf', e.target.value)} placeholder="e.g. Bilal Ahmed (Proprietor)" />
                </Field>
                <Field label="Fax"><Text value={form.fax} onChange={e => set('fax', e.target.value)} /></Field>
              </div>
            </div>
            <div className="space-y-3">
              <Field label="NTN"><Text value={form.ntn} onChange={e => set('ntn', e.target.value)} placeholder="0000000-0" /></Field>
              <Field label="CNIC"><Text value={form.cnic} onChange={e => set('cnic', e.target.value)} placeholder="00000-0000000-0" /></Field>
            </div>
          </div>
        )}

        {tab === 'Custom Fields' && (
          <div className="nb-card">
            <div className="nb-card-header">Add Fields</div>
            <div className="nb-card-body">
              <div className="flex items-end gap-2">
                <Field label="Field" className="flex-1 max-w-xs">
                  <Text value={newField} onChange={e => setNewField(e.target.value)} placeholder="Field name" />
                </Field>
                <button
                  type="button"
                  disabled={!newField.trim()}
                  onClick={() => {
                    const name = newField.trim();
                    if (!name || fields.some(f => f.field.toLowerCase() === name.toLowerCase())) return;
                    setFields(fs => [...fs, { id: Date.now(), field: name, value: '' }]);
                    setNewField('');
                  }}
                  className="btn-xenith-success disabled:opacity-40"
                >
                  <Plus className="w-3.5 h-3.5" /> Add
                </button>
                <button type="button" onClick={() => setNewField('')} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Cancel
                </button>
              </div>

              {fields.length > 0 && (
                <table className="xenith-table mt-4">
                  <thead><tr><th>Field</th><th>Value</th><th className="w-16">Action</th></tr></thead>
                  <tbody>
                    {fields.map((f, i) => (
                      <tr key={f.id}>
                        <td className="font-medium text-gray-700">{f.field}</td>
                        <td>
                          <Text
                            value={f.value}
                            onChange={e => setFields(fs => fs.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))}
                          />
                        </td>
                        <td>
                          <button type="button" onClick={() => setFields(fs => fs.filter((_, j) => j !== i))} className="btn-xenith-danger">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}
      </div>

      <FormFooter
        onSave={() => onSave()}
        onClose={onDone}
        saving={saving}
        disabled={!canSave}
        statusOptions={[
          { label: 'Save as Active', value: 'active' },
          { label: 'Save as Inactive', value: 'inactive' },
        ]}
      />
    </div>
  );
};

// ─── List ──────────────────────────────────────────────────────────────────
interface PageProps {
  kind: PartyResource;
  openNewNonce?: number;
  onConsumed?: () => void;
}

export const PartyPage: React.FC<PageProps> = ({ kind, openNewNonce = 0, onConsumed }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const label = KIND_META[kind].label;
  const plural = `${label}s`;
  const addLabel = `ADD ${label.toUpperCase()}`;

  const [view, setView] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [proposed, setProposed] = useState('');
  const [rows, setRows] = useState<Party[]>([]);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [selected, setSelected] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  // The search box holds its own text, so emptying it from the table's clear button means
  // mounting a fresh one.
  const [searchEpoch, setSearchEpoch] = useState(0);

  // Only the newest request may paint the table, so a slow response cannot overwrite
  // the results the user already sees while typing.
  const requestId = useRef(0);
  const refresh = useCallback(() => {
    setLoading(true);
    const at = ++requestId.current;
    getParties(kind, tenantSlug, branchId, search)
      .then(d => { if (at === requestId.current) setRows(d.data); })
      .finally(() => { if (at === requestId.current) setLoading(false); });
  }, [kind, tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);
  useEffect(() => {
    getCategories(tenantSlug, branchId, KIND_META[kind].categoryType).then(d => setCategories(d.data));
  }, [tenantSlug, branchId, kind]);

  useEffect(() => {
    if (openNewNonce > 0) {
      getPartyProposedNumber(kind, tenantSlug, branchId).then(setProposed);
      setEditId(null);
      setView('form');
      onConsumed?.();
    }
  }, [openNewNonce, kind, tenantSlug, branchId, onConsumed]);

  const openNew = () => {
    getPartyProposedNumber(kind, tenantSlug, branchId).then(setProposed);
    setEditId(null);
    setView('form');
  };
  const openEdit = (id: number) => { setEditId(id); setView('form'); };

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((a: any, b: any) => String(a[sort.key] ?? '').localeCompare(String(b[sort.key] ?? ''), undefined, { numeric: true }) * dir);
  }, [rows, sort]);

  const filtered = useMemo(
    () => (categoryFilter ? sorted.filter(r => String(r.categoryId) === categoryFilter) : sorted),
    [sorted, categoryFilter]
  );

  const onSort = (key: string) => setSort(s => (s?.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));
  const allSelected = filtered.length > 0 && selected.length === filtered.length;
  const exportRows = selected.length ? filtered.filter(r => selected.includes(r.id)) : filtered;
  const balanceTotal = exportRows.reduce((s, r) => s + Number(r.currentBalance || 0), 0);
  const inactive = filtered.filter(r => !r.isActive).length;
  const cols = columnsOf(kind);
  const showBalance = kind !== 'customers';

  const stats: RegisterStat[] = [
    {
      label: plural, value: String(filtered.length),
      title: search ? `Matching the search “${search}”` : `Every ${plural.toLowerCase()} on this branch`
    },
    {
      label: 'Balance', value: `${currency} ${balanceTotal.toLocaleString()}`, tone: 'ok',
      title: `Added over the ${exportRows.length} ${plural.toLowerCase()} the table is showing` +
        // The register's own foot carries this figure as a column; where the column is not
        // printed, the chip is the only place it stands, so it must not point at a foot line.
        (showBalance ? ' — the same line its foot prints' : ''),
    },
    ...(inactive ? [{
      label: 'Inactive', value: inactive, tone: 'warn' as const,
      title: `${inactive} of them are marked Inactive, so a new paper will not offer them`
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    categoryFilter && `category ${categories.find(c => String(c.id) === categoryFilter)?.name ?? categoryFilter}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setCategoryFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  if (view === 'form') {
    return (
      <PartyForm
        key={`${kind}-${editId ?? proposed}`}
        kind={kind}
        partyId={editId}
        proposed={proposed}
        onDone={() => { refresh(); setView('list'); }}
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Head: what the master list is and what it holds. Filters: the levers. Table: the
          records, closing with the same total the printed sheet and the workbook carry. */}
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">{plural}</h2>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel={addLabel} onAdd={openNew} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder={`Search ${plural.toLowerCase()}...`} onSearch={setSearch} />
          <span className="filter-plate">
            <Pick aria-label="Filter by category" value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}>
              <option value="">Category</option>
              {categories.map(c => <option key={c.id} value={String(c.id)}>{c.name}</option>)}
            </Pick>
            {categoryFilter && (
              <button type="button" title="Show every category" onClick={() => setCategoryFilter('')}
                className="text-gray-400 hover:text-gray-600">
                <X className="w-3 h-3" />
              </button>
            )}
          </span>
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={plural} filename={plural.toLowerCase().replace(/\s+/g, '-')} columns={cols} rows={exportRows}
              footer={showBalance ? footerRow(cols.length, { 0: 'Total', [cols.length - 1]: balanceTotal.toLocaleString() }) : undefined}
              landscape={cols.length > 6} />
          </span>
        </div>

        {selected.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/70">
            <span className="text-[11px] font-bold text-gray-600">{selected.length} of {filtered.length} ticked</span>
            <button type="button" className="btn-xenith-danger"
              onClick={async () => { await Promise.all(selected.map(id => deleteParty(kind, tenantSlug, branchId, id))); setSelected([]); refresh(); }}>
              <Trash2 className="w-3.5 h-3.5" /> Delete Selected
            </button>
            <button type="button" onClick={() => setSelected([])} className="btn-xenith-outline">
              <X className="w-3.5 h-3.5" /> Clear selection
            </button>
            <span className="text-[11px] text-gray-500">Print and export both follow the tickbox.</span>
          </div>
        )}
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-8">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={e => setSelected(e.target.checked ? filtered.map(r => r.id) : [])}
                    className="accent-[#1e88e5]"
                  />
                </th>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Category" sortKey="categoryName" sort={sort} onSort={onSort} />
                <SortHeader label="Contact Person" sortKey="contactPerson" sort={sort} onSort={onSort} />
                <SortHeader label="Email" sortKey="email1" sort={sort} onSort={onSort} />
                <SortHeader label="Phone" sortKey="phone1" sort={sort} onSort={onSort} />
                {showBalance && <SortHeader label="Balance" sortKey="currentBalance" sort={sort} onSort={onSort} />}
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={cols.length + 2}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !filtered.length && (
                <TableEmpty colSpan={cols.length + 2} noun={plural.toLowerCase()} filters={activeFilters}
                  cleared={clearAll} addLabel={rows.length ? undefined : addLabel} onAdd={openNew} />
              )}
              {!loading && filtered.map(r => (
                <tr key={r.id} className={r.isActive ? '' : 'opacity-60'}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selected.includes(r.id)}
                      onChange={e => setSelected(s => (e.target.checked ? [...s, r.id] : s.filter(x => x !== r.id)))}
                      className="accent-[#1e88e5]"
                    />
                  </td>
                  <td className="font-medium">{r.code}</td>
                  <td>
                    {r.name}
                    {/* An inactive account is still on the list but no new paper offers it,
                        so the row has to say so rather than look like any other. */}
                    {!r.isActive && (
                      <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold border border-gray-200 bg-gray-50 text-gray-500">
                        Inactive
                      </span>
                    )}
                  </td>
                  <td>{r.categoryName || <span className="text-gray-400">-</span>}</td>
                  <td>{r.contactPerson || <span className="text-gray-400">-</span>}</td>
                  <td>{r.email1 || <span className="text-gray-400">-</span>}</td>
                  <td>{r.phone1 || <span className="text-gray-400">-</span>}</td>
                  {showBalance && <td className="text-right tabular-nums">{money(r.currentBalance)}</td>}
                  <td>
                    <div className="flex items-center">
                      <IconAction title={`Edit ${r.name}`} tone="primary" onClick={() => openEdit(r.id)}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>
                      <IconAction title={`Delete ${r.name}`} tone="danger"
                        onClick={async () => { await deleteParty(kind, tenantSlug, branchId, r.id); refresh(); }}>
                        <Trash2 className="w-4 h-4" />
                      </IconAction>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* The foot closes the one figure this register carries; with the column gone
                there is nothing left for a Total line to add up. */}
            {showBalance && !loading && !!filtered.length && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td />
                  <td colSpan={6} className="font-black text-gray-800">
                    {selected.length ? `Total (${exportRows.length} selected)` : 'Total'}
                  </td>
                  <td className="text-right font-black text-gray-800 tabular-nums">{balanceTotal.toLocaleString()}</td>
                  <td />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
