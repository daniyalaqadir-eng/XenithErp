import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Download, FileUp, Loader2, RefreshCw, Upload, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import {
  BulkAnswer, BulkTemplate, getProductBulkTemplate, uploadProductBulk
} from '../../services/masters.service';
import { downloadExcel } from '../../utils/exportExcel';

// A shop's price list lives in a spreadsheet, and typing four hundred products by hand is how a
// book ends up with the wrong codes on its shelves. So this screen hands out the sheet in this
// company's own columns, reads whatever comes back, and answers row by row with what it will
// file — before a single product exists. Every verdict on this screen is the server's own; the
// screen only paints them.

const readAsUrl = (file: File) => new Promise<string>((resolve, reject) => {
  const r = new FileReader();
  r.onload = () => resolve(String(r.result || ''));
  r.onerror = () => reject(new Error('The file could not be read from disk.'));
  r.readAsDataURL(file);
});

const Chip: React.FC<{ label: string; value: number; tone: string }> = ({ label, value, tone }) => (
  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-bold border ${tone}`}>
    {value} <span className="font-semibold">{label}</span>
  </span>
);

const Step: React.FC<{ n: string; title: string; children: React.ReactNode }> = ({ n, title, children }) => (
  <section className="space-y-2">
    <h3 className="text-[12px] font-bold text-gray-800 uppercase tracking-wide">{n} · {title}</h3>
    {children}
  </section>
);

export const ProductBulkUpload: React.FC<{ onClose: () => void; onImported: () => void }> = ({ onClose, onImported }) => {
  const { tenantSlug, branchId } = useTenant();
  const [template, setTemplate] = useState<BulkTemplate | null>(null);
  const [answer, setAnswer] = useState<BulkAnswer | null>(null);
  const [fileName, setFileName] = useState('');
  const [bytes, setBytes] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<'check' | 'import' | ''>('');
  const [imported, setImported] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getProductBulkTemplate(tenantSlug, branchId).then(setTemplate).catch(e => setError((e as Error).message));
  }, [tenantSlug, branchId]);

  // The sample is written by the same exporter every other register on this product uses, from
  // the headings and the two example rows the server just read out of this company's own masters.
  const downloadSample = () => {
    if (!template) return;
    const rows = template.examples;
    downloadExcel('products-to-upload', {
      title: 'Products to upload',
      subtitle: 'Fill the rows under these headings, then bring the file back here. The two example rows may be overwritten or deleted.',
      columns: template.columns.map(c => ({
        label: c.label,
        value: (r: typeof rows[number]) => String(r[c.label] ?? ''),
        wrap: true
      })),
      rows,
      style: 'plain'
    });
  };

  const pick = async (f: File | null | undefined) => {
    if (!f) return;
    setError(''); setAnswer(null); setImported(false);
    setBusy('check'); setFileName(f.name);
    try {
      const url = await readAsUrl(f);
      setBytes(url);
      setAnswer(await uploadProductBulk(tenantSlug, branchId, url, f.name, false));
    } catch (e) {
      setError((e as Error).message);
      setBytes('');
    } finally {
      setBusy('');
    }
  };

  const runImport = async () => {
    if (!bytes) return;
    setBusy('import'); setError('');
    try {
      const r = await uploadProductBulk(tenantSlug, branchId, bytes, fileName, true);
      setAnswer(r);
      setImported(true);
      onImported();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy('');
    }
  };

  const bad = useMemo(() => (answer?.rows || []).filter(r => r.problems.length), [answer]);
  // The rows as they were read, so a clerk sees the sheet the server saw rather than a tally.
  const shown = useMemo(() => (answer?.rows || []).slice(0, 120), [answer]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 animate-[fadeUp_.2s_ease-out_backwards]" onClick={onClose}>
      <div
        className="bg-white rounded-xl shadow-xl w-full max-w-5xl max-h-[calc(100vh-2rem)] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 px-5 py-3 border-b border-gray-100">
          <div>
            <h2 className="card-title">Bulk upload products</h2>
            <p className="text-[11px] text-gray-500">
              Bring a whole price list onto the shelf at once. Nothing is written until you press Import.
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="w-4 h-4" /></button>
        </div>

        <div className="flex-1 overflow-y-auto app-scroll p-5 space-y-5">
          <Step n="1" title="Take the sample file">
            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={downloadSample} disabled={!template} className="btn-xenith-primary">
                <Download className="w-3.5 h-3.5" /> Download sample (.xlsx)
              </button>
              <span className="text-[11px] text-gray-500">
                Opens in Excel. Save it back as .xlsx, or as “CSV UTF-8” if you would rather work in text.
              </span>
            </div>
            {template && (
              <ul className="text-[11px] text-gray-600 list-disc pl-4 space-y-0.5">
                {template.tips.map(t => <li key={t}>{t}</li>)}
              </ul>
            )}
            {template && (
              <div className="grid gap-1.5 text-[11px] text-gray-600">
                <div><span className="font-bold text-gray-800">Units this company holds:</span> {template.units.map(u => u.code).join(', ')}</div>
                <div><span className="font-bold text-gray-800">Categories:</span> {template.categories.join(', ') || '— none yet, add them under Classification → Product Categories'}</div>
                <div><span className="font-bold text-gray-800">Brands:</span> {template.brands.join(', ') || '— none yet, add them under Classification → Brands'}</div>
              </div>
            )}
          </Step>

          <Step n="2" title="Pick your file and let it be read">
            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={() => input.current?.click()} disabled={!!busy} className="btn-xenith-outline">
                <FileUp className="w-3.5 h-3.5" /> Choose file (.xlsx / .csv)
              </button>
              <input ref={input} type="file" accept=".xlsx,.csv,.txt" className="hidden"
                onChange={e => pick(e.target.files?.[0])} />
              {fileName && <span className="text-[11px] font-semibold text-gray-700">{fileName}</span>}
              {busy === 'check' && (
                <span className="inline-flex items-center gap-1.5 text-[11px] text-gray-500">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Reading the sheet…
                </span>
              )}
            </div>
          </Step>

          {error && (
            <div className="rounded border border-red-200 bg-red-50 px-3 py-2 text-[11px] font-semibold text-red-700">{error}</div>
          )}

          {answer && (
            <Step n="3" title={imported ? 'What the book took' : 'What the sheet says'}>
              <div className="flex flex-wrap items-center gap-1.5">
                <Chip label="row(s) read" value={answer.read} tone="border-gray-200 text-gray-700" />
                <Chip label={imported ? 'filed' : 'ready to import'} value={answer.ready} tone="border-emerald-200 bg-emerald-50 text-emerald-700" />
                <Chip label="left out" value={answer.bad}
                  tone={answer.bad ? 'border-red-200 bg-red-50 text-red-700' : 'border-gray-200 text-gray-600'} />
                {answer.ignored.length > 0 && (
                  <span className="inline-flex items-center px-2.5 py-1.5 rounded text-[11px] font-semibold border border-amber-200 bg-amber-50 text-amber-800">
                    Column(s) not used: {answer.ignored.join(', ')}
                  </span>
                )}
              </div>

              {!imported && answer.ready > 0 && (
                <p className="text-[11px] text-gray-600">
                  The {answer.ready} ready row{answer.ready === 1 ? '' : 's'} will be filed through the same door the ADD
                  PRODUCT form uses: a code is given to any row without one, the unit is switched to this company's own
                  name, and a row the sheet cannot vouch for stays out with its reason said out loud.
                </p>
              )}

              {imported && (
                <div className="rounded border border-emerald-200 bg-emerald-50 px-3 py-2 text-[11px] font-semibold text-emerald-800">
                  {answer.created?.length || 0} product(s) added to the book
                  {(answer.skipped?.length || 0) > 0 ? `, ${answer.skipped!.length} row(s) left out.` : '.'}
                  {' '}The list behind this window has been refreshed.
                </div>
              )}

              {!imported && bad.length > 0 && (
                <div className="rounded border border-red-200 overflow-hidden">
                  <div className="px-3 py-2 bg-red-50 text-[11px] font-bold text-red-700">
                    {bad.length} row{bad.length === 1 ? '' : 's'} will not be filed — fix these, then pick the file again
                  </div>
                  <table className="xenith-table">
                    <thead>
                      <tr><th className="w-14">Line</th><th>Product Name</th><th>Why it is stopped</th></tr>
                    </thead>
                    <tbody>
                      {bad.slice(0, 40).map(r => (
                        <tr key={r.line}>
                          <td className="text-gray-500">{r.line}</td>
                          <td>{r.values['Product Name'] || <span className="text-gray-400">— blank —</span>}</td>
                          <td className="text-red-700 font-semibold">{r.problems.join(' ')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {bad.length > 40 && <div className="px-3 py-2 text-[11px] text-gray-500">…and {bad.length - 40} more.</div>}
                </div>
              )}

              {imported && (answer.skipped?.length || 0) > 0 && (
                <div className="rounded border border-red-200 overflow-hidden">
                  <table className="xenith-table">
                    <thead>
                      <tr><th className="w-14">Line</th><th>Product Name</th><th>Why it was left out</th></tr>
                    </thead>
                    <tbody>
                      {answer.skipped!.slice(0, 40).map(s => (
                        <tr key={s.line}>
                          <td className="text-gray-500">{s.line}</td>
                          <td>{s.name || <span className="text-gray-400">— blank —</span>}</td>
                          <td className="text-red-700 font-semibold">{s.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="rounded border border-gray-200 overflow-hidden">
                <div className="px-3 py-2 bg-gray-50 text-[11px] font-bold text-gray-700">Every row as it was read</div>
                <div className="overflow-auto max-h-[34vh] app-scroll">
                  <table className="xenith-table">
                    <thead>
                      <tr>
                        <th className="w-14">Line</th>
                        {answer.columns.map(c => <th key={c}>{c}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {shown.map(r => (
                        <tr key={r.line} className={r.problems.length ? 'bg-red-50/60' : ''}>
                          <td className="text-gray-500">{r.line}</td>
                          {answer.columns.map(c => <td key={c} className="whitespace-nowrap">{r.values[c] || ''}</td>)}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {answer.more > 0 && (
                  <div className="px-3 py-2 text-[11px] text-gray-500">
                    The first {answer.rows.length} of {answer.read} rows are on screen; the rest were read the same way and
                    are counted in the figures above.
                  </div>
                )}
              </div>
            </Step>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2 px-5 py-3 border-t border-gray-100">
          {answer && !imported && (
            <button type="button" onClick={() => input.current?.click()} disabled={!!busy} className="btn-xenith-outline">
              <RefreshCw className="w-3.5 h-3.5" /> Pick another file
            </button>
          )}
          <button type="button" onClick={onClose} className="btn-xenith-soft">{imported ? 'Close' : 'Cancel'}</button>
          {answer && !imported && (
            <button type="button" onClick={runImport} disabled={busy === 'import' || answer.ready === 0} className="btn-xenith-success">
              {busy === 'import' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
              {busy === 'import' ? 'Importing…' : `Import ${answer.ready} product(s)`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
