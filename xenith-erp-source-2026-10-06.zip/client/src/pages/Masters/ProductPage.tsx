import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Plus, RefreshCw, X, Trash2, Pencil, AlertTriangle, FileUp } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { Category, CustomFieldValue, Product, ProductType, ProductTax, Uom } from '../../types';
import {
  getCategories, getProduct, getProducts, getProductProposedNumber, getUoms,
  saveProduct, updateProduct, deleteProduct
} from '../../services/masters.service';
import { getWarehouses } from '../../services/warehouses.service';
import { StockBreakdownModal } from '../../components/modals/StockBreakdownModal';
import { ProductBulkUpload } from './ProductBulkUpload';
import { SearchSelect, SelectOption } from '../../components/common/SearchSelect';
import {
  Area, AttachmentBox, Check, ExportPair, Field, FormFooter, IconAction, ImagePicker, ListToolbar, Pick,
  SearchBox, SectionTitle, SortHeader, SortState, StatStrip, RegisterStat, StatusPills, TabStrip, TableEmpty, Text
} from './masterUi';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { filingLevels, levelOf, rootsOf, shelfOf, trailOf } from '../../utils/categoryTree';
import { useScreenReload } from '../../utils/screenReload';

const PRODUCT_TYPES: ProductType[] = ['Product', 'Services', 'Product Variant', 'Grouped'];
const ACCOUNTS = ['Inventory', 'Stock in Hand', 'Cost of Goods Sold', 'Discounts Received', 'Discounts Given', 'Sales', 'Sales Return', 'Purchase'];

const TABS = ['General', 'Detail', 'Custom Fields', 'Multiple Packings/SKUs', 'Related Products', 'Catalog', 'Stock Level', 'Taxes'];

const blankProduct = (code: string): Product => ({
  id: 0, code, name: '', type: 'Product', unit: '', isFractionalUnit: false, fractionalUnitMode: 'price',
  isCalculationField: false, isThirdSchedule: false, trackInventory: true, enableBatch: false, enableSerial: false,
  enablePackaging: false, enableAssemble: false, enableAddOn: false, inventoryAccountName: 'Inventory',
  isPurchased: true, purchasePrice: 0, expenseAccountName: 'Cost of Goods Sold', purchaseDiscountAccountName: 'Discounts Received', purchaseTaxes: [],
  isSold: true, allowPublicAccess: true, salePrice: 0, salesAccountName: 'Sales', salesDiscountAccountName: 'Discounts Given', saleTaxes: [],
  salePriceInclusiveOfTax: false, maximumRetailPrice: 0, salesReturnAccountName: 'Sales Return', retailPriceExclusiveOfTax: false,
  categoryId: null, categoryName: '', brandId: null, brandName: '', principal: '', shortName: '', sku: '', barcode: '',
  weight: 0, height: 0, width: 0, length: 0, modelNumber: '', hsCode: '', shortDescription: '', description: '', tags: '', imageUrl: '',
  stockQty: 0, reorderLevel: 0, isActive: true, attachments: [], customFields: [], packings: [], relatedProducts: [], stockLevels: [],
});

// The sheet names the whole shelf a product sits on, not just the leaf, so an exported
// register reads like the reports do: parent, sub, category.
const exportColumns = (cats: Category[]): ExportColumn<Product>[] => {
  const shelf = (p: Product, at: number) => {
    const t = trailOf(cats, p.categoryId);
    return t[at]?.name || '-';
  };
  return [
    { label: 'Code', value: (p) => p.code },
    { label: 'Name', value: (p) => p.name },
    { label: 'Type', value: (p) => p.type },
    { label: 'Parent Category', value: (p) => shelf(p, 0) },
    { label: 'Sub Category', value: (p) => shelf(p, 1) },
    { label: 'Category', value: (p) => p.categoryName || '-' },
    { label: 'Brand', value: (p) => p.brandName || '-' },
    { label: 'Unit', value: (p) => p.unit },
    { label: 'Sales Price', value: (p) => p.salePrice.toLocaleString(), align: 'right' },
    { label: 'Available Stock', value: (p) => (p.trackInventory ? p.stockQty : 'n/a'), align: 'right' },
    { label: 'Status', value: (p) => (p.isActive ? 'Active' : 'Inactive') },
  ];
};

let rowSeq = 1;

// ─── Form ──────────────────────────────────────────────────────────────────
interface FormProps {
  productId: number | null;
  proposed: string;
  onDone: () => void;
}

export const ProductForm: React.FC<FormProps> = ({ productId, proposed, onDone }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const [tab, setTab] = useState('General');
  const [form, setForm] = useState<Product>(blankProduct(proposed));
  const [cats, setCats] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [newField, setNewField] = useState('');
  const [fields, setFields] = useState<CustomFieldValue[]>([]);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [warehouses, setWarehouses] = useState<string[]>([]);
  const [relPick, setRelPick] = useState<number | null>(null);
  // Units come off the switchboard rather than from a typed word, so the product card and
  // the board cannot end up calling the same thing by two names.
  const [uoms, setUoms] = useState<Uom[]>([]);

  useEffect(() => {
    Promise.all([
      getCategories(tenantSlug, branchId, 'product'),
      getCategories(tenantSlug, branchId, 'brand'),
      getWarehouses(tenantSlug, branchId),
      getProducts(tenantSlug, branchId),
      getUoms(tenantSlug, branchId),
    ]).then(([c, b, w, p, u]) => {
      setCats(c.data); setBrands(b.data); setAllProducts(p.data); setUoms(u.data);
      if (w.data.length) setWarehouses(w.data.map(x => x.name));
    });
  }, [tenantSlug, branchId]);

  useEffect(() => {
    if (productId == null) return;
    getProduct(tenantSlug, branchId, productId).then(p => { setForm(p); setFields(p.customFields || []); });
  }, [tenantSlug, branchId, productId]);

  const set = <K extends keyof Product>(key: K, value: Product[K]) => setForm(f => ({ ...f, [key]: value }));
  const canSave = form.name.trim().length > 0 && form.unit.trim().length > 0 && !saving;

  // The board's switched-on units are the choices. A unit this product already carries stays
  // visible even when it has been switched off — dropping it would quietly rewrite the card
  // the moment anything else on the form is saved.
  const boardUnit = uoms.find(u => u.code === form.unit || u.name === form.unit);
  const unitOptions = boardUnit && !boardUnit.isActive
    ? [boardUnit, ...uoms.filter(u => u.isActive && u.id !== boardUnit.id)]
    : uoms.filter(u => u.isActive);
  const unitNote = !uoms.length ? ''
    : !boardUnit ? ' — not on the switchboard'
    : boardUnit.isActive ? '' : ' — switched off';

  const onSave = async () => {
    if (!canSave) return;
    setSaving(true);
    setError('');
    const body: Partial<Product> = { ...form, customFields: fields.filter(f => f.field.trim()) };
    try {
      if (productId == null) await saveProduct(tenantSlug, branchId, body);
      else await updateProduct(tenantSlug, branchId, productId, body);
      onDone();
    } catch (e: any) {
      setError(e.message || String(e));
      setSaving(false);
    }
  };

  // The card is filed by three boxes: the parent groups the trade, the sub groups the range
  // inside it, and the product category is the leaf. A product carries whichever of the three
  // it was taken to, so the boxes read that row's own trail back — and picking a level above
  // leaves the boxes below it empty until something is chosen under it.
  const levels = filingLevels(cats, form.categoryId);
  const atLevel = (n: number) => cats.filter(c => levelOf(cats, c.id) === n);
  const inBranch = (n: number, under: number | null) =>
    under == null ? atLevel(n) : atLevel(n).filter(c => trailOf(cats, c.id).some(x => x.id === under));
  const fileBy = (id: number | null) => {
    const c = id == null ? null : cats.find(x => x.id === id) || null;
    setForm(f => ({ ...f, categoryId: id, categoryName: c ? c.name : '' }));
  };
  const parentOptions: SelectOption[] = rootsOf(cats).map(c => ({ id: c.id, label: c.name }));
  const subOptions: SelectOption[] = inBranch(2, levels.parentId)
    .map(c => ({ id: c.id, label: c.name, hint: c.parentName }));
  const leafOptions: SelectOption[] = inBranch(3, levels.subId ?? levels.parentId)
    .map(c => ({ id: c.id, label: c.name, hint: c.parentName }));
  const brandOptions: SelectOption[] = brands.map(b => ({ id: b.id, label: b.name }));
  const relatedOptions: SelectOption[] = allProducts
    .filter(p => p.id !== form.id && !form.relatedProducts.some(r => r.productId === p.id))
    .map(p => ({ id: p.id, label: p.name, hint: p.code }));
  const saved = productId != null;

  const setTax = (side: 'saleTaxes' | 'purchaseTaxes', idx: number, patch: Partial<ProductTax>) => {
    setForm(f => ({ ...f, [side]: f[side].map((t, i) => (i === idx ? { ...t, ...patch } : t)) }));
  };
  const addTax = (side: 'saleTaxes' | 'purchaseTaxes') => {
    setForm(f => ({ ...f, [side]: [...f[side], { id: Date.now() + Math.random(), name: '', rate: 0 }] }));
  };

  return (
    <div className="nb-card">
      <div className="nb-card-header page-head">
        <span>Products - {form.code}</span>
        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-500">{form.type}</span>
      </div>

      <TabStrip tabs={TABS} active={tab} onChange={setTab} />

      {error && <div className="mx-4 mt-3 text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div>}

      <div className="nb-card-body">
        {tab === 'General' && (
          <div className="space-y-4">
            <div>
              <div className="flex flex-wrap items-center gap-4 mb-1">
                {PRODUCT_TYPES.map(t => (
                  <label key={t} className={`flex items-center gap-1.5 text-xs ${productId != null ? 'text-gray-400' : 'text-gray-700 cursor-pointer'}`}>
                    <input
                      type="radio" name="ptype" checked={form.type === t} disabled={productId != null}
                      onChange={() => set('type', t)} className="accent-[#1e88e5]"
                    />
                    {t}
                  </label>
                ))}
              </div>
              <p className="text-[11px] text-gray-400">Type cannot be changed once the product is created.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <Field label="Code" required>
                <div className="flex items-stretch gap-1">
                  <Text value={form.code} onChange={e => set('code', e.target.value)} className="rounded-r-none" />
                  <button
                    type="button" title="Get next number"
                    onClick={async () => set('code', await getProductProposedNumber(tenantSlug, branchId))}
                    className="px-2 rounded border border-gray-300 bg-[#2ec4b6] hover:bg-[#25a195] text-white"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Field>
              <Field label="Name" required>
                <Text value={form.name} onChange={e => set('name', e.target.value)} placeholder="Product name" />
              </Field>
              <Field label="Unit Of Measurement" required hint="Units are switched on under Classification → Units of Measurement">
                <Pick value={form.unit} onChange={e => set('unit', e.target.value)}>
                  {!form.unit && <option value="">Select a unit</option>}
                  {form.unit && !unitOptions.some(u => u.code === form.unit) && (
                    <option value={form.unit}>{form.unit}{unitNote}</option>
                  )}
                  {unitOptions.map(u => <option key={u.id} value={u.code}>{u.code} — {u.name}</option>)}
                </Pick>
                {unitNote && (
                  <p className="text-[11px] font-semibold text-amber-700 mt-1 leading-snug">
                    {form.unit}{unitNote}. Switch it on on the board to keep it, or pick another unit.
                  </p>
                )}
              </Field>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Check checked={form.isFractionalUnit} onChange={v => set('isFractionalUnit', v)} label="Fractional unit?" />
                {form.isFractionalUnit && (
                  <div className="pl-6 space-y-1">
                    {([['price', 'Change price on transaction documents'], ['quantity', 'Change quantity on transaction documents']] as const).map(([v, l]) => (
                      <label key={v} className="flex items-center gap-1.5 text-xs text-gray-600 cursor-pointer">
                        <input type="radio" name="frac" checked={form.fractionalUnitMode === v} onChange={() => set('fractionalUnitMode', v)} className="accent-[#1e88e5]" />
                        {l}
                      </label>
                    ))}
                  </div>
                )}
                <Check checked={form.isCalculationField} onChange={v => set('isCalculationField', v)} label="This is a calculation field" />
                <Check checked={form.isThirdSchedule} onChange={v => set('isThirdSchedule', v)} label="Does your product fall under 3rd Schedule Category?" />
                {/* Whether stock is tracked is fixed when the product is created — the server
                    keeps the stored value, so this is stated rather than ticked. */}
                <p className="text-[11px] text-gray-500">
                  {form.trackInventory ? 'Inventory is tracked for this product.' : 'Inventory is not tracked for this product.'}
                </p>
                <div className="flex flex-wrap gap-x-5 gap-y-1 pt-1">
                  <Check checked={form.enableBatch} onChange={v => set('enableBatch', v)} label="Batch" />
                  <Check checked={form.enableSerial} onChange={v => set('enableSerial', v)} label="Serial number" />
                  <Check checked={form.enablePackaging} onChange={v => set('enablePackaging', v)} label="Packaging" />
                  <Check checked={form.enableAssemble} onChange={v => set('enableAssemble', v)} label="Assemble items" />
                  <Check checked={form.enableAddOn} onChange={v => set('enableAddOn', v)} label="Add-on items" />
                </div>
                <Field label="Inventory Account">
                  <Pick value={form.inventoryAccountName} onChange={e => set('inventoryAccountName', e.target.value)}>
                    {['Inventory', 'Stock in Hand'].map(a => <option key={a}>{a}</option>)}
                  </Pick>
                </Field>
                <p className="text-[11px] text-gray-400 pt-1">
                  To add product openings, please create a Stock Adjustment and select adjustment type 'Openings'.
                </p>
              </div>

              <div className="space-y-3">
                <div className="border border-gray-200 rounded p-3">
                  <Check checked={form.isPurchased} onChange={v => set('isPurchased', v)} label="Do you purchase this product?" />
                  {form.isPurchased && (
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      <Field label={`Purchase Price (${currency})`}>
                        <Text type="number" value={form.purchasePrice || ''} onChange={e => set('purchasePrice', Number(e.target.value) || 0)} />
                      </Field>
                      <Field label="Expense Account">
                        <Pick value={form.expenseAccountName} onChange={e => set('expenseAccountName', e.target.value)}>{ACCOUNTS.map(a => <option key={a}>{a}</option>)}</Pick>
                      </Field>
                      <Field label="Purchase Discount Account">
                        <Pick value={form.purchaseDiscountAccountName} onChange={e => set('purchaseDiscountAccountName', e.target.value)}>{ACCOUNTS.map(a => <option key={a}>{a}</option>)}</Pick>
                      </Field>
                      <button type="button" onClick={() => setTab('Taxes')} className="text-[#2ec4b6] hover:text-[#25a195] text-xs font-semibold text-left">
                        Purchase Taxes / Manage Taxes
                      </button>
                    </div>
                  )}
                </div>

                <div className="border border-gray-200 rounded p-3">
                  <Check checked={form.isSold} onChange={v => set('isSold', v)} label="Do you sell this product?" />
                  {form.isSold && (
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      <Check checked={!form.allowPublicAccess} onChange={v => set('allowPublicAccess', !v)} label="Don't allow public access" />
                      <Field label={`Sales Price (${currency})`}>
                        <Text type="number" value={form.salePrice || ''} onChange={e => set('salePrice', Number(e.target.value) || 0)} />
                      </Field>
                      <Field label="Sales Account">
                        <Pick value={form.salesAccountName} onChange={e => set('salesAccountName', e.target.value)}>{ACCOUNTS.map(a => <option key={a}>{a}</option>)}</Pick>
                      </Field>
                      <Field label="Sales Discount Account">
                        <Pick value={form.salesDiscountAccountName} onChange={e => set('salesDiscountAccountName', e.target.value)}>{ACCOUNTS.map(a => <option key={a}>{a}</option>)}</Pick>
                      </Field>
                      <button type="button" onClick={() => setTab('Taxes')} className="text-[#2ec4b6] hover:text-[#25a195] text-xs font-semibold text-left">
                        Sales Taxes / Manage Taxes
                      </button>
                      <Check checked={form.salePriceInclusiveOfTax} onChange={v => set('salePriceInclusiveOfTax', v)} label="Is sales price inclusive of tax?" />
                      <Field label={`Maximum Retail Price (${currency})`}>
                        <Text type="number" value={form.maximumRetailPrice || ''} onChange={e => set('maximumRetailPrice', Number(e.target.value) || 0)} />
                      </Field>
                      <Field label="Sales Return Account">
                        <Pick value={form.salesReturnAccountName} onChange={e => set('salesReturnAccountName', e.target.value)}>{ACCOUNTS.map(a => <option key={a}>{a}</option>)}</Pick>
                      </Field>
                      <Check checked={form.retailPriceExclusiveOfTax} onChange={v => set('retailPriceExclusiveOfTax', v)} label="Is retail price exclusive of tax?" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'Detail' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Field label="Parent Category">
                <SearchSelect options={parentOptions} value={levels.parentId} onChange={fileBy} placeholder="-Choose-" />
              </Field>
              <Field label="Sub Category">
                <SearchSelect options={subOptions} value={levels.subId} onChange={fileBy} placeholder="-Choose-"
                  emptyMessage={subOptions.length ? 'No matches found' : 'No sub category is filed under this parent yet'} />
              </Field>
              <Field label="Product Category">
                <SearchSelect options={leafOptions} value={levels.leafId} onChange={fileBy} placeholder="-Choose-"
                  emptyMessage={leafOptions.length ? 'No matches found' : 'File a category under the sub first'} />
              </Field>
              <Field label="Brand">
                <SearchSelect options={brandOptions} value={form.brandId} onChange={id => {
                  const b = brands.find(x => x.id === id) || null;
                  setForm(f => ({ ...f, brandId: id, brandName: b ? b.name : '' }));
                }} placeholder="-Choose-" />
              </Field>
              <Field label="Principal"><Text value={form.principal} onChange={e => set('principal', e.target.value)} /></Field>
              <Field label="Product Short Name"><Text value={form.shortName} onChange={e => set('shortName', e.target.value)} /></Field>
              <Field label="SKU"><Text value={form.sku} onChange={e => set('sku', e.target.value)} /></Field>
              <Field label="Product Barcode"><Text value={form.barcode} onChange={e => set('barcode', e.target.value)} /></Field>
              <Field label="Weight (kg)"><Text type="number" value={form.weight || ''} onChange={e => set('weight', Number(e.target.value) || 0)} /></Field>
              <Field label="Model Number"><Text value={form.modelNumber} onChange={e => set('modelNumber', e.target.value)} /></Field>
              <Field label="Height (inches)"><Text type="number" value={form.height || ''} onChange={e => set('height', Number(e.target.value) || 0)} /></Field>
              <Field label="Width (inches)"><Text type="number" value={form.width || ''} onChange={e => set('width', Number(e.target.value) || 0)} /></Field>
              <Field label="Length (inches)"><Text type="number" value={form.length || ''} onChange={e => set('length', Number(e.target.value) || 0)} /></Field>
              <Field label="HS Code"><Text value={form.hsCode} onChange={e => set('hsCode', e.target.value)} /></Field>
              <Field label="Short Description" className="sm:col-span-2">
                <Area rows={2} value={form.shortDescription} onChange={e => set('shortDescription', e.target.value)} />
              </Field>
              <Field label="Description" className="sm:col-span-2">
                <Area rows={4} value={form.description} onChange={e => set('description', e.target.value)} />
              </Field>
              <Field label="Tags" className="sm:col-span-2" hint="comma separated">
                <Text value={form.tags} onChange={e => set('tags', e.target.value)} />
              </Field>
            </div>
            <div>
              <SectionTitle>Product Image</SectionTitle>
              <ImagePicker value={form.imageUrl} onChange={v => set('imageUrl', v)} />
              <div className="mt-4">
                <SectionTitle>Attachments</SectionTitle>
                <AttachmentBox items={form.attachments} onChange={a => set('attachments', a)} />
              </div>
            </div>
          </div>
        )}

        {tab === 'Custom Fields' && (
          <div className="nb-card">
            <div className="nb-card-header">Add Fields</div>
            <div className="nb-card-body">
              <div className="flex items-end gap-2">
                <Field label="Field" className="flex-1 max-w-xs">
                  <Text value={newField} onChange={e => setNewField(e.target.value)} placeholder="Field name" />
                </Field>
                <button
                  type="button" disabled={!newField.trim()}
                  onClick={() => {
                    const name = newField.trim();
                    if (fields.some(f => f.field.toLowerCase() === name.toLowerCase())) return;
                    setFields(fs => [...fs, { id: Date.now(), field: name, value: '' }]);
                    setNewField('');
                  }}
                  className="btn-xenith-success disabled:opacity-40"
                >
                  <Plus className="w-3.5 h-3.5" /> Add
                </button>
                <button type="button" onClick={() => setNewField('')} className="btn-xenith-warning">
                  <X className="w-3.5 h-3.5" /> Cancel
                </button>
              </div>
              {fields.length > 0 && (
                <table className="xenith-table mt-4">
                  <thead><tr><th>Field</th><th>Value</th><th className="w-16">Action</th></tr></thead>
                  <tbody>
                    {fields.map((f, i) => (
                      <tr key={f.id}>
                        <td className="font-medium">{f.field}</td>
                        <td><Text value={f.value} onChange={e => setFields(fs => fs.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))} /></td>
                        <td><button type="button" onClick={() => setFields(fs => fs.filter((_, j) => j !== i))} className="btn-xenith-danger"><X className="w-3.5 h-3.5" /></button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}

        {tab === 'Multiple Packings/SKUs' && (
          saved ? (
            <div>
              <table className="xenith-table">
                <thead>
                  <tr><th>Packaging</th><th>Qty</th><th>SKU</th><th>Barcode</th><th>Sale Price</th><th>Purchase Price</th><th className="w-16">Action</th></tr>
                </thead>
                <tbody>
                  {form.packings.map((p, i) => {
                    const patch = (fields: Partial<Product['packings'][number]>) =>
                      setForm(f => ({ ...f, packings: f.packings.map((x, j) => (j === i ? { ...x, ...fields } : x)) }));
                    return (
                      <tr key={p.id}>
                        <td><Text value={p.packaging} onChange={e => patch({ packaging: e.target.value })} /></td>
                        <td><Text type="number" value={p.qty || ''} onChange={e => patch({ qty: Number(e.target.value) || 0 })} /></td>
                        <td><Text value={p.sku} onChange={e => patch({ sku: e.target.value })} /></td>
                        <td><Text value={p.barcode} onChange={e => patch({ barcode: e.target.value })} /></td>
                        <td><Text type="number" value={p.salePrice || ''} onChange={e => patch({ salePrice: Number(e.target.value) || 0 })} /></td>
                        <td><Text type="number" value={p.purchasePrice || ''} onChange={e => patch({ purchasePrice: Number(e.target.value) || 0 })} /></td>
                        <td>
                          <button type="button" onClick={() => setForm(f => ({ ...f, packings: f.packings.filter((_, j) => j !== i) }))} className="btn-xenith-danger">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <button
                type="button" className="btn-xenith-success mt-3"
                onClick={() => setForm(f => ({ ...f, packings: [...f.packings, { id: rowSeq++, packaging: '', qty: 1, sku: '', barcode: '', salePrice: f.salePrice, purchasePrice: f.purchasePrice }] }))}
              >
                <Plus className="w-3.5 h-3.5" /> Add Packing
              </button>
            </div>
          ) : <EmptyTab text="Please save product to add packings / SKUs." />
        )}

        {tab === 'Related Products' && (
          saved ? (
            <div>
              {form.relatedProducts.length === 0 && <p className="text-xs text-gray-500 mb-3">No related products added yet.</p>}
              <div className="flex items-end gap-2 mb-3">
                <Field label="Product" className="flex-1 max-w-sm">
                  <SearchSelect options={relatedOptions} value={relPick} onChange={setRelPick} placeholder="-Choose product-" />
                </Field>
                <button
                  type="button" disabled={relPick == null}
                  onClick={() => {
                    const p = allProducts.find(x => x.id === relPick);
                    if (!p || form.relatedProducts.some(r => r.productId === p.id)) return;
                    setForm(f => ({ ...f, relatedProducts: [...f.relatedProducts, { id: rowSeq++, productId: p.id, productName: p.name, type: p.type }] }));
                    setRelPick(null);
                  }}
                  className="btn-xenith-success disabled:opacity-40"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Related Product
                </button>
              </div>
              <table className="xenith-table">
                <thead><tr><th>Product</th><th>Type</th><th className="w-16">Action</th></tr></thead>
                <tbody>
                  {form.relatedProducts.map((r, i) => (
                    <tr key={r.id}>
                      <td>{r.productName}</td>
                      <td>{r.type}</td>
                      <td><button type="button" onClick={() => setForm(f => ({ ...f, relatedProducts: f.relatedProducts.filter((_, j) => j !== i) }))} className="btn-xenith-danger"><Trash2 className="w-3.5 h-3.5" /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <EmptyTab text="Please save product to add related products." />
        )}

        {tab === 'Catalog' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <SectionTitle>Catalog Description</SectionTitle>
              <Area
                rows={8}
                value={form.description}
                onChange={e => set('description', e.target.value)}
                placeholder="Write the catalog description for this product..."
              />
            </div>
            <div>
              <SectionTitle>Gallery Image</SectionTitle>
              {/* A product stores one picture (Product → imageUrl). A multi-image gallery has
                  nowhere to save, so this edits the real field instead of listing names. */}
              <ImagePicker value={form.imageUrl} onChange={v => set('imageUrl', v)} />
            </div>
          </div>
        )}

        {tab === 'Stock Level' && (
          saved ? (
            <div>
              <table className="xenith-table">
                <thead><tr><th>Warehouse</th><th>Qty</th><th>Reorder Level</th><th className="w-16">Action</th></tr></thead>
                <tbody>
                  {form.stockLevels.map((sl, i) => (
                    <tr key={sl.id}>
                      <td>
                        <Pick value={sl.warehouse} onChange={e => setForm(f => ({ ...f, stockLevels: f.stockLevels.map((x, j) => (j === i ? { ...x, warehouse: e.target.value } : x)) }))}>
                          {warehouses.map(w => <option key={w}>{w}</option>)}
                        </Pick>
                      </td>
                      <td><Text type="number" value={sl.qty || ''} onChange={e => setForm(f => ({ ...f, stockLevels: f.stockLevels.map((x, j) => (j === i ? { ...x, qty: Number(e.target.value) || 0 } : x)) }))} /></td>
                      <td><Text type="number" value={sl.reorderLevel || ''} onChange={e => setForm(f => ({ ...f, stockLevels: f.stockLevels.map((x, j) => (j === i ? { ...x, reorderLevel: Number(e.target.value) || 0 } : x)) }))} /></td>
                      <td><button type="button" onClick={() => setForm(f => ({ ...f, stockLevels: f.stockLevels.filter((_, j) => j !== i) }))} className="btn-xenith-danger"><Trash2 className="w-3.5 h-3.5" /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button
                type="button" className="btn-xenith-success mt-3"
                onClick={() => setForm(f => ({ ...f, stockLevels: [...f.stockLevels, { id: rowSeq++, warehouse: warehouses[0], qty: 0, reorderLevel: 0 }] }))}
              >
                <Plus className="w-3.5 h-3.5" /> Add Warehouse
              </button>
            </div>
          ) : <EmptyTab text="Please save product to add stock levels." />
        )}

        {tab === 'Taxes' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {([['saleTaxes', 'Taxes On Sales'], ['purchaseTaxes', 'Taxes On Purchase']] as const).map(([side, title]) => (
              <div key={side} className="nb-card mb-0">
                <div className="nb-card-header">{title}</div>
                <div className="nb-card-body">
                  {form[side].length === 0 && <p className="text-xs text-gray-400 mb-2">No taxes added.</p>}
                  <div className="space-y-2">
                    {form[side].map((t, i) => (
                      <div key={t.id} className="flex items-center gap-2">
                        <Text value={t.name} onChange={e => setTax(side, i, { name: e.target.value })} placeholder="Tax name" className="flex-1" />
                        <Text type="number" value={t.rate || ''} onChange={e => setTax(side, i, { rate: Number(e.target.value) || 0 })} className="w-24" />
                        <span className="text-xs text-gray-500">%</span>
                        <button type="button" onClick={() => setForm(f => ({ ...f, [side]: f[side].filter((_, j) => j !== i) }))} className="text-gray-400 hover:text-red-500">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <button type="button" onClick={() => addTax(side)} className="btn-xenith-success mt-3">
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <FormFooter onSave={onSave} onClose={onDone} saving={saving} disabled={!canSave} />
    </div>
  );
};

const EmptyTab: React.FC<{ text: string }> = ({ text }) => (
  <div className="py-10 text-center text-xs text-gray-400">{text}</div>
);

// ─── List ──────────────────────────────────────────────────────────────────
interface PageProps { openNewNonce?: number; onConsumed?: () => void }

export const ProductsPage: React.FC<PageProps> = ({ openNewNonce = 0, onConsumed }) => {
  const { tenantSlug, branchId, currency } = useTenant();
  const { can } = useAuth();
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [proposed, setProposed] = useState('');
  const [rows, setRows] = useState<Product[]>([]);
  // The category register, so the list can spell out the branch a product was filed under
  // rather than leaving the reader to open the card to find which level a name sits at.
  const [cats, setCats] = useState<Category[]>([]);
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text, so remounting it is the only way to empty the box when
  // "Clear every filter" resets the search the table is already answering to.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [typeFilter, setTypeFilter] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [selected, setSelected] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  // Which product's stock card is open on the screen. The breakdown is read from the ledger
  // when the box opens, never carried over from the row, so it cannot show a stale figure.
  const [breakdownId, setBreakdownId] = useState<number | null>(null);
  // The spreadsheet door: open it, and the whole price list comes in at once.
  const [bulkOpen, setBulkOpen] = useState(false);

  // Only the newest search may paint the table, otherwise a slow earlier response can
  // replace the results the user is already looking at.
  const requestId = useRef(0);
  const refresh = useCallback(() => {
    const at = ++requestId.current;
    setLoading(true);
    getProducts(tenantSlug, branchId, search).then(d => {
      if (at !== requestId.current) return;
      setRows(d.data);
    }).finally(() => { if (at === requestId.current) setLoading(false); });
  }, [tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  useEffect(() => {
    getCategories(tenantSlug, branchId, 'product').then(d => setCats(d.data));
  }, [tenantSlug, branchId]);

  const openForm = (id: number | null) => {
    if (id == null) getProductProposedNumber(tenantSlug, branchId).then(setProposed);
    setEditId(id);
    setView('form');
  };

  useEffect(() => {
    if (openNewNonce > 0) { openForm(null); onConsumed?.(); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openNewNonce]);

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((a: any, b: any) => {
      const x = a[sort.key], y = b[sort.key];
      if (typeof x === 'number' && typeof y === 'number') return (x - y) * dir;
      return String(x ?? '').localeCompare(String(y ?? '')) * dir;
    });
  }, [rows, sort]);

  const filtered = useMemo(() => (typeFilter ? sorted.filter(r => r.type === typeFilter) : sorted), [sorted, typeFilter]);
  const onSort = (key: string) => setSort(s => (s?.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));
  const allSelected = filtered.length > 0 && selected.length === filtered.length;
  const exportRows = selected.length ? filtered.filter(p => selected.includes(p.id)) : filtered;

  // The pills count against the whole master, not the type already picked, so a pill never
  // reads zero beside the rows it could still show. A type with nothing in it is left off.
  const typeCounts = useMemo(() => [
    { value: '', label: 'All', count: sorted.length },
    ...PRODUCT_TYPES
      .map(t => ({ value: t, label: t, count: sorted.filter(r => r.type === t).length }))
      .filter(c => c.count > 0)
  ], [sorted]);

  const inactive = sorted.filter(r => !r.isActive).length;
  // Only items that track stock hold units; a service row would add a phantom zero-sum.
  const stockTotal = filtered.reduce((s, p) => s + (p.trackInventory ? Number(p.stockQty) || 0 : 0), 0);

  // Printed from the same three levels the on-screen column spells out, so paper and screen
  // cannot file a product under different shelves.
  const columns = useMemo(() => exportColumns(cats), [cats]);
  // Stock sits in the tenth column once the two shelves above the category join the sheet.
  const STOCK_COL = 9;

  const stats: RegisterStat[] = [
    { label: 'Products', value: typeFilter ? `${filtered.length} of ${sorted.length}` : String(sorted.length) },
    { label: 'Stock in hand', value: stockTotal.toLocaleString(), title: `Units across the ${filtered.length} row${filtered.length === 1 ? '' : 's'} on screen, counting only items that track stock` },
    ...(inactive ? [{
      label: 'Inactive', value: inactive, tone: 'warn' as const,
      title: `${inactive} of them are marked Inactive, so a new paper will not offer them`
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    typeFilter && `type ${typeFilter}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setTypeFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  if (view === 'form') {
    return <ProductForm key={editId ?? proposed} productId={editId} proposed={proposed} onDone={() => { refresh(); setView('list'); }} />;
  }

  return (
    <div className="space-y-4">
      {/* Head: what the master holds. Filters: the levers, each one a control you can see
          and read at once. Table: the rows, closing with the same stock figure the chip
          above and the exported workbook carry. */}
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Products</h2>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD PRODUCT" onAdd={() => openForm(null)}>
            {can('products:add') && (
              <button type="button" onClick={() => setBulkOpen(true)} className="btn-xenith-primary">
                <FileUp className="w-3.5 h-3.5" /> BULK UPLOAD
              </button>
            )}
          </ListToolbar>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search products..." onSearch={setSearch} />
          <StatusPills value={typeFilter} onChange={setTypeFilter} counts={typeCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Products" filename="products" columns={columns} rows={exportRows}
              footer={footerRow(columns.length, { 0: 'Total', [STOCK_COL]: stockTotal.toLocaleString() })}
              landscape={columns.length > 6} />
          </span>
        </div>

        {selected.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-t border-gray-100 bg-gray-50/70">
            <span className="text-[11px] font-bold text-gray-600">{selected.length} of {filtered.length} ticked</span>
            <button
              type="button"
              onClick={async () => { await Promise.all(selected.map(id => deleteProduct(tenantSlug, branchId, id))); setSelected([]); refresh(); }}
              className="btn-xenith-danger"
            >
              <Trash2 className="w-3.5 h-3.5" /> Delete Selected
            </button>
            <button type="button" onClick={() => setSelected([])} className="btn-xenith-outline">
              <X className="w-3.5 h-3.5" /> Clear selection
            </button>
            <span className="text-[11px] text-gray-500">Print and export both follow the tickbox.</span>
          </div>
        )}
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-8">
                  <input type="checkbox" checked={allSelected} onChange={e => setSelected(e.target.checked ? filtered.map(r => r.id) : [])} className="accent-[#1e88e5]" />
                </th>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Type" sortKey="type" sort={sort} onSort={onSort} />
                <SortHeader label="Category" sortKey="categoryName" sort={sort} onSort={onSort} />
                <SortHeader label="Brand" sortKey="brandName" sort={sort} onSort={onSort} />
                <SortHeader label="Unit" sortKey="unit" sort={sort} onSort={onSort} />
                <SortHeader label={`Sales Price (${currency})`} sortKey="salePrice" sort={sort} onSort={onSort} />
                <SortHeader label="Available Stock" sortKey="stockQty" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-28">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={11}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !filtered.length && (
                <TableEmpty colSpan={11} noun="products" filters={activeFilters}
                  cleared={clearAll} addLabel={rows.length ? undefined : 'ADD PRODUCT'} onAdd={() => openForm(null)} />
              )}
              {!loading && filtered.map(p => (
                <tr key={p.id} className={p.isActive ? '' : 'opacity-60'}>
                  <td>
                    <input type="checkbox" checked={selected.includes(p.id)} onChange={e => setSelected(s => (e.target.checked ? [...s, p.id] : s.filter(x => x !== p.id)))} className="accent-[#1e88e5]" />
                  </td>
                  <td className="font-medium">{p.code}</td>
                  <td>
                    {p.name}
                    {!p.isActive && (
                      <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold border border-gray-200 bg-gray-50 text-gray-500">
                        Inactive
                      </span>
                    )}
                  </td>
                  <td>{p.type}</td>
                  {/* The leaf is what the product card carries; the shelf above it is read off
                      the tree so the row says which branch it belongs to without opening it. */}
                  <td>
                    {p.categoryName ? (
                      <>
                        <div>{p.categoryName}</div>
                        {shelfOf(cats, p.categoryId).length > 0 && (
                          <div className="text-[10px] text-gray-500">{shelfOf(cats, p.categoryId).join(' › ')}</div>
                        )}
                      </>
                    ) : <span className="text-gray-400">-</span>}
                  </td>
                  <td>{p.brandName || <span className="text-gray-400">-</span>}</td>
                  <td>{p.unit}</td>
                  <td className="text-right tabular-nums">{p.salePrice.toLocaleString()}</td>
                  {/* The quantity in the pill is the same figure the chip above and the total
                      below carry; the link under it opens where those units actually sit. */}
                  <td className="text-right">
                    {p.trackInventory ? (
                      <>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-black tabular-nums ${
                          p.stockQty > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
                        }`}>
                          {p.stockQty.toLocaleString()} {(p.unit || '').toUpperCase()}
                          {p.stockQty <= 0 && <AlertTriangle className="w-3 h-3" />}
                        </span>
                        <button
                          type="button"
                          onClick={() => setBreakdownId(p.id)}
                          title={`Where the stock of ${p.name} sits`}
                          className="block ml-auto mt-0.5 text-[10px] font-bold text-[#1f8c82] hover:underline"
                        >
                          View Breakdown
                        </button>
                      </>
                    ) : <span className="text-gray-400">n/a</span>}
                  </td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${p.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {p.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center">
                      <IconAction title={`Edit ${p.name}`} tone="primary" onClick={() => openForm(p.id)}>
                        <Pencil className="w-4 h-4" />
                      </IconAction>
                      <IconAction title={`Delete ${p.name}`} tone="danger"
                        onClick={async () => { await deleteProduct(tenantSlug, branchId, p.id); refresh(); }}>
                        <Trash2 className="w-4 h-4" />
                      </IconAction>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!filtered.length && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td colSpan={8} className="font-black text-gray-800">
                    {selected.length ? `Total (${selected.length} selected)` : `Total (${filtered.length})`}
                  </td>
                  {/* The same figure the "Stock in hand" chip wears, so the tile above and the
                      line below cannot tell two different stories about the book. */}
                  <td className="text-right tabular-nums font-black text-gray-800">{stockTotal.toLocaleString()}</td>
                  <td />
                  <td />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      <StockBreakdownModal productId={breakdownId} onClose={() => setBreakdownId(null)} />
      {bulkOpen && <ProductBulkUpload onClose={() => setBulkOpen(false)} onImported={refresh} />}
    </div>
  );
};
