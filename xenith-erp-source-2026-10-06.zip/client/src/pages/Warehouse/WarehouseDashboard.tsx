import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { useTenant } from '../../context/TenantContext';
import { useAuth } from '../../context/AuthContext';
import { WarehouseDash, getWarehouseDashboard } from '../../services/warehouses.service';
import { Boxes, CheckCircle2, ChevronRight, MapPin, PackageCheck, RefreshCw, RotateCcw, Search, Truck, UserRound, Warehouse, X } from 'lucide-react';
import { useScreenReload } from '../../utils/screenReload';

interface Props {
  // Which location this terminal is standing at. A keeper posted to one warehouse gets that
  // one; an owner or administrator picks from the switcher on the band.
  warehouseId?: number | null;
  onFolder?: (id: number | null) => void;
  onNavigate?: (tab: string) => void;
  // Rendered as one of the dashboard desks rather than as the terminal in its own right.
  // Only a desk answers to the band ticks on the Roles screen: the terminal the sidebar opens
  // is where the keeper works, and it always shows everything it can read.
  deck?: boolean;
}

const num = (v: number) => roundMoney(v).toLocaleString(undefined, { maximumFractionDigits: 2 });

// A fixed warehouse is a storage point; a van or a stall that travels is a sale point. The
// master carries no other kind, so the terminal says which of the two it is standing at.
const kindOf = (isMoveable: boolean) => (isMoveable ? 'Sale Point' : 'Storage Point');

const KPI_TONES: Record<string, { plate: string; value: string }> = {
  amber: { plate: 'bg-amber-500', value: 'text-gray-800' },
  emerald: { plate: 'bg-emerald-500', value: 'text-gray-800' },
  rose: { plate: 'bg-rose-500', value: 'text-gray-800' },
  blue: { plate: 'bg-blue-600', value: 'text-gray-800' }
};

const Kpi: React.FC<{ label: string; value: string; note: string; tone: keyof typeof KPI_TONES; icon: React.ReactNode }> =
  ({ label, value, note, tone, icon }) => (
    <div className="nb-card px-3.5 py-3 flex items-start justify-between gap-2">
      <div className="min-w-0">
        <div className="text-[10px] font-black uppercase tracking-wider text-gray-500">{label}</div>
        <div className={`mt-1 text-2xl font-black tabular-nums leading-tight ${KPI_TONES[tone].value}`}>{value}</div>
        <div className="mt-0.5 text-[10px] leading-snug text-gray-400">{note}</div>
      </div>
      <span className={`shrink-0 grid place-items-center w-9 h-9 rounded-xl text-white ${KPI_TONES[tone].plate}`}>{icon}</span>
    </div>
  );

// The four doors of the terminal. Each one is a screen that already works, opened at this
// same location, so a keeper never lands on a register showing somebody else's gate.
const ACTIONS: {
  key: string; title: string; note: string; icon: React.ReactNode; grad: string; tab: (id: number) => string;
}[] = [
  {
    key: 'dispatch', title: 'Warehouse Dispatch', note: 'Outward delivery challans',
    icon: <Truck className="w-4 h-4" />, grad: 'from-orange-500 to-amber-700',
    tab: id => `delivery-challan:${id}`
  },
  {
    key: 'inward', title: 'Inward Challan', note: 'Receive goods from suppliers / GRN',
    icon: <PackageCheck className="w-4 h-4" />, grad: 'from-blue-600 to-indigo-800',
    tab: () => 'doc:good-receiving'
  },
  {
    key: 'transfer', title: 'Stock Transfer', note: 'Move stock to another location',
    icon: <Boxes className="w-4 h-4" />, grad: 'from-violet-600 to-purple-800',
    tab: () => 'doc:stock-movement'
  },
  {
    key: 'return', title: 'Return Challan', note: 'Process return verification',
    icon: <RotateCcw className="w-4 h-4" />, grad: 'from-rose-600 to-red-800',
    tab: () => 'doc:sale-return'
  }
];

// The bands a deck of this terminal answers to, in the order the page draws them.
const BANDS = ['kpi', 'actions', 'challans', 'stock'];

/**
 * One warehouse's own terminal: what stands here, what has left it, and what is still
 * waiting to be signed out. Every figure is read from the same papers the registers hold —
 * the stock is derived from the ledger and the challans are the rows the dispatch board
 * lists — so a tile here and a line there can never tell two different stories.
 */
export const WarehouseDashboard: React.FC<Props> = ({ warehouseId = null, onFolder, onNavigate, deck = false }) => {
  const { tenantSlug, branchId } = useTenant();
  const { can } = useAuth();
  // A band of the warehouse desk is drawn when the tick says so — and on the terminal, where
  // no tick was ever offered, always.
  const on = (band: string) => !deck || can(`dash-wh-${band}:view`);
  const [dash, setDash] = useState<WarehouseDash | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [outwardQuery, setOutwardQuery] = useState('');
  const [outwardState, setOutwardState] = useState('');
  const [stockQuery, setStockQuery] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    getWarehouseDashboard(tenantSlug, branchId, warehouseId)
      .then(d => { setDash(d); if (!d) setError('No warehouse is set up on this branch yet.'); })
      .catch(e => setError((e as Error).message))
      .finally(() => setLoading(false));
  }, [tenantSlug, branchId, warehouseId]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const outward = useMemo(() => {
    const rows = dash?.outward ?? [];
    const q = outwardQuery.toLowerCase().trim();
    return rows.filter(r =>
      (!outwardState || (outwardState === 'Dispatched' ? r.status === 'Approved' : r.status !== 'Approved'))
      && (!q || [r.number, r.partyName, r.vehicle, r.driver, r.gatePass].join(' ').toLowerCase().includes(q)));
  }, [dash, outwardState, outwardQuery]);

  const stock = useMemo(() => {
    const q = stockQuery.toLowerCase().trim();
    return (dash?.stock ?? []).filter(r => !q || `${r.productName} ${r.sku}`.toLowerCase().includes(q));
  }, [dash, stockQuery]);

  if (!dash) {
    return (
      <div className="nb-card p-6">
        <div className="text-sm font-bold text-gray-700">Warehouse terminal</div>
        <div className="mt-1 text-xs text-gray-500">
          {loading ? 'Reading this location’s stock and challans…' : error}
        </div>
      </div>
    );
  }

  const { warehouse: w, kpis, folders } = dash;

  return (
    <div className="space-y-4">
      {/* The band names the gate, not the software: a keeper who opens this tab should know
          within a second which building's numbers he is looking at. */}
      <div className="dash-hero px-4 py-4 md:px-5">
        <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="hero-glass"><Warehouse className="w-3 h-3" /> {w.code} · {kindOf(w.isMoveable)}</span>
              {(w.address || w.city) && (
                <span className="hero-glass"><MapPin className="w-3 h-3" /> {[w.address, w.city].filter(Boolean).join(', ')}</span>
              )}
            </div>
            <h2 className="hero-title mt-2.5">{w.name} Operations Terminal</h2>
            <p className="hero-note mt-1 max-w-[46rem]">
              Bulk holding, inward verification, outward delivery challans and transfers.
              {w.keeperName ? ` Worked by ${w.keeperName}.` : w.managerName ? ` Managed by ${w.managerName}.` : ''}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {folders.length > 1 && (
              <div className="hero-seg" role="group" aria-label="Choose a location">
                {folders.map(f => (
                  <button key={f.id} type="button" aria-pressed={f.id === w.id}
                    onClick={() => onFolder?.(f.id)}
                    title={`${num(f.stock)} units standing here · ${f.pending} challan(s) not yet signed out`}>
                    {f.code || f.name}
                  </button>
                ))}
              </div>
            )}
            <button type="button" className="hero-glass" onClick={load}
              title="Re-read this location's stock and papers">
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </button>
          </div>
        </div>
      </div>

      {on('kpi') && (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Kpi label={`${w.code} total storage`} value={num(kpis.stockUnits)} tone="amber"
          note={`${kpis.skus} item${kpis.skus === 1 ? '' : 's'} standing here, from the stock ledger`}
          icon={<Boxes className="w-4 h-4" />} />
        <Kpi label="Dispatched challans" value={num(kpis.dispatched)} tone="emerald"
          note="Signed out from this gate — stock has left"
          icon={<CheckCircle2 className="w-4 h-4" />} />
        <Kpi label="Pending dispatches" value={num(kpis.pending)} tone="rose"
          note="Cut out but not signed — the goods are still here"
          icon={<Truck className="w-4 h-4" />} />
        <Kpi label="Transfers out" value={num(kpis.transfersOut)} tone="blue"
          note={kpis.inward ? `${kpis.inward} inward challan(s) received here too` : 'Papers moving this location’s stock elsewhere'}
          icon={<UserRound className="w-4 h-4" />} />
      </div>
      )}

      {on('actions') && (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {ACTIONS.map(a => (
          <button key={a.key} type="button" onClick={() => onNavigate?.(a.tab(w.id))}
            className={`text-left rounded-xl px-4 py-3.5 bg-gradient-to-br ${a.grad} text-white shadow-lg transition-transform hover:-translate-y-0.5`}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[13px] font-black uppercase tracking-wide">{a.title}</div>
                <div className="mt-0.5 text-[11px] font-semibold text-white/85">{a.note}</div>
              </div>
              <span className="shrink-0 grid place-items-center w-8 h-8 rounded-lg bg-white/15">{a.icon}</span>
            </div>
          </button>
        ))}
      </div>
      )}

      {(on('challans') || on('stock')) && (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {on('challans') && (
        <div className={`${on('stock') ? 'lg:col-span-7' : 'lg:col-span-12'} nb-card p-0 overflow-hidden`}>
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 py-3.5">
            <div className="min-w-0">
              <h3 className="flex items-center gap-2 text-[15px] font-black text-gray-800">
                <Truck className="w-4 h-4 text-orange-500" />
                <span>{w.code} Outward Delivery Challans</span>
              </h3>
              <p className="text-[11px] text-gray-500">
                {dash.outward.length} challan{dash.outward.length === 1 ? '' : 's'} cut out of this gate, newest first
              </p>
            </div>
            <div className="seg-filter" role="group" aria-label="Filter challans by state">
              {[{ v: '', l: 'All' }, { v: 'Dispatched', l: 'Dispatched' }, { v: 'Pending', l: 'Pending' }].map(s => (
                <button key={s.v || 'all'} type="button" aria-pressed={outwardState === s.v}
                  className={outwardState === s.v ? 'is-on' : ''} onClick={() => setOutwardState(s.v)}>
                  {s.l}
                </button>
              ))}
            </div>
          </div>

          <div className="px-4 pb-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={outwardQuery} onChange={e => setOutwardQuery(e.target.value)}
                placeholder={`Search challan #, customer, vehicle or gate pass in ${w.code}`}
                className="w-full pl-8 pr-8 py-2 rounded-lg border border-gray-200 bg-white text-[12px] focus:outline-none focus:border-[#1e88e5]" />
              {outwardQuery && (
                <button type="button" onClick={() => setOutwardQuery('')} aria-label="Clear the challan search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="border-t border-gray-100 overflow-x-auto app-scroll">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="bg-gray-50/80 text-left text-[10px] uppercase tracking-wider text-gray-500">
                  <th className="px-4 py-2 font-black">Challan #</th>
                  <th className="px-3 py-2 font-black">Date</th>
                  <th className="px-3 py-2 font-black">Customer</th>
                  <th className="px-3 py-2 font-black">Transport / Driver</th>
                  <th className="px-3 py-2 font-black text-right">Total Qty</th>
                  <th className="px-4 py-2 font-black">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {loading && Array.from({ length: 3 }).map((_, i) => (
                  <tr key={i}><td colSpan={6}><div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${88 - i * 12}%` }} /></td></tr>
                ))}
                {!loading && !outward.length && (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-[12px] text-gray-500">
                      {dash.outward.length
                        ? 'No challan here matches the search or the state picked.'
                        : `No delivery challan has been cut out of ${w.name} yet.`}
                    </td>
                  </tr>
                )}
                {!loading && outward.map(c => (
                  <tr key={c.id}>
                    <td className="px-4 py-2.5">
                      <button type="button" onClick={() => onNavigate?.(`delivery-challan:${w.id}`)}
                        className="font-black text-emerald-700 hover:underline" title="Open this gate's dispatch board">
                        {c.number}
                      </button>
                      {c.gatePass && <div className="text-[10px] font-bold text-emerald-600">GP: {c.gatePass}</div>}
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap text-gray-600">{c.date}</td>
                    <td className="px-3 py-2.5 font-semibold text-gray-800">{c.partyName}</td>
                    <td className="px-3 py-2.5">
                      <div className="text-gray-700">{c.vehicle || 'No transport'}</div>
                      <div className="text-[10px] text-gray-400">{c.driver || 'Handover at counter'}</div>
                    </td>
                    <td className="px-3 py-2.5 text-right tabular-nums font-bold text-gray-800">{num(c.qty)}</td>
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-black uppercase tracking-wide ${
                        c.status === 'Approved' ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border-rose-200 bg-rose-50 text-rose-700'}`}>
                        {c.status === 'Approved' ? 'Dispatched' : 'Pending'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 text-right">
            <button type="button" onClick={() => onNavigate?.(`delivery-challan:${w.id}`)}
              className="inline-flex items-center gap-1 text-[12px] font-bold text-orange-600 hover:underline">
              <span>Go to {w.code}’s full dispatch board</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        )}

        {on('stock') && (
        <div className={`${on('challans') ? 'lg:col-span-5' : 'lg:col-span-12'} nb-card p-0 overflow-hidden`}>
          <div className="flex items-start justify-between gap-3 px-4 py-3.5">
            <div className="min-w-0">
              <h3 className="flex items-center gap-2 text-[15px] font-black text-gray-800">
                <Boxes className="w-4 h-4 text-amber-500" />
                <span>{w.code} Stock Balances</span>
              </h3>
              <p className="text-[11px] text-gray-500">Units standing in this location, from the stock ledger</p>
            </div>
            <span className="shrink-0 px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-[10px] font-black text-amber-700">
              {kpis.skus} SKU{kpis.skus === 1 ? '' : 'S'}
            </span>
          </div>

          <div className="px-4 pb-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={stockQuery} onChange={e => setStockQuery(e.target.value)}
                placeholder="Search an item name or code"
                className="w-full pl-8 pr-8 py-2 rounded-lg border border-gray-200 bg-white text-[12px] focus:outline-none focus:border-[#1e88e5]" />
              {stockQuery && (
                <button type="button" onClick={() => setStockQuery('')} aria-label="Clear the item search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Capped inside the card so a long stock list scrolls here rather than pushing the
              page out beneath it. */}
          <div className="px-4 pb-3 max-h-[26rem] overflow-y-auto app-scroll space-y-1.5">
            {loading && Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-9 rounded-lg bg-gray-100 animate-pulse" />
            ))}
            {!loading && !stock.length && (
              <div className="py-6 text-center text-[12px] text-gray-500">
                {dash.stock.length
                  ? 'No item here matches that search.'
                  : `Nothing is standing in ${w.name} right now.`}
              </div>
            )}
            {!loading && stock.map(r => (
              <div key={r.sku} className="flex items-center justify-between gap-3 px-3 py-2 rounded-lg border border-gray-100 bg-gray-50/70">
                <div className="min-w-0">
                  <div className="text-[12px] font-bold text-gray-800 truncate">{r.productName}</div>
                  <div className="text-[10px] text-gray-400">{w.code} · {r.sku}</div>
                </div>
                <span className={`shrink-0 px-2 py-0.5 rounded-full border text-[11px] font-black tabular-nums ${
                  r.qty <= 5 ? 'border-rose-200 bg-rose-50 text-rose-700' : 'border-amber-200 bg-amber-50 text-amber-700'}`}>
                  {num(r.qty)} {r.unit}
                </span>
              </div>
            ))}
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 text-right">
            <button type="button" onClick={() => onNavigate?.('item-master')}
              className="inline-flex items-center gap-1 text-[12px] font-bold text-amber-700 hover:underline">
              <span>Open the full stock breakdown</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        )}
      </div>
      )}

      {deck && BANDS.every(b => !on(b)) && (
        <div className="nb-card px-4 py-8 text-center">
          <p className="text-sm font-bold text-gray-700">This desk has no bands on it.</p>
          <p className="mt-1 text-xs text-gray-500">
            An administrator shows parts of it under Setup → User Roles → Warehouse Desk.
          </p>
        </div>
      )}

      {error && (
        <div className="nb-card px-4 py-2.5 text-[12px] font-semibold text-amber-800 bg-amber-50 flex items-center justify-between gap-2">
          <span>{error}</span>
          <button type="button" onClick={load} title="Try the read again"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      )}
    </div>
  );
};
