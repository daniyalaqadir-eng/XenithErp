import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, SlidersHorizontal, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { StockMovement } from '../../types';
import { getMovements } from '../../services/inventory.service';
import { DateWindow, ExportPair, ListToolbar, Pick, RegisterStat, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty } from '../Masters/masterUi';
import { footerRow } from '../../utils/exportTable';
import { isoDay, monthStart } from '../../utils/dateRange';
import { useScreenReload } from '../../utils/screenReload';

// Nothing is typed on this screen. Every row here is written by a stock movement,
// an adjustment or a goods document, so the ledger stays the single honest trail.
const typeBadge: Record<string, string> = {
  In: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Out: 'bg-red-50 text-red-600 border-red-200',
  Adjustment: 'bg-amber-50 text-amber-700 border-amber-200',
  Transfer: 'bg-blue-50 text-blue-700 border-blue-200'
};

export const StockLedger: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<StockMovement[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('');
  const [warehouseFilter, setWarehouseFilter] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [fromDate, setFromDate] = useState(monthStart());
  const [toDate, setToDate] = useState(isoDay());
  const [sort, setSort] = useState<SortState | null>({ key: 'date', dir: 'desc' });

  const refresh = useCallback(() => {
    setLoading(true);
    getMovements(tenantSlug, branchId, search).then(r => setRows(r.data)).finally(() => setLoading(false));
  }, [tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  const warehouses = useMemo(() => Array.from(new Set(rows.map(m => m.warehouse).filter(Boolean))).sort(), [rows]);

  // An issue is stored as a positive quantity but always leaves the warehouse, so the
  // ledger reads it with a minus sign like the item card does.
  const signed = (m: StockMovement) => (m.type === 'Out' ? -Math.abs(m.quantity) : m.quantity);

  // Everything but the type pill. The number written on a pill has to answer to the
  // search, window and warehouse the reader is already inside, otherwise clicking the
  // pill would promise rows the pill never counted.
  const inScope = useMemo(() => rows.filter(m =>
    (!warehouseFilter || m.warehouse === warehouseFilter) &&
    (!fromDate || m.date >= fromDate) && (!toDate || m.date <= toDate)),
  [rows, warehouseFilter, fromDate, toDate]);

  const visible = useMemo(() => {
    const picked = typeFilter ? inScope.filter(m => m.type === typeFilter) : inScope;
    if (!sort) return picked;
    return [...picked].sort((a, b) => {
      const pick = (m: StockMovement) => sort.key === 'quantity' ? m.quantity : sort.key === 'balance' ? m.balanceAfter
        : sort.key === 'product' ? m.itemName : sort.key === 'type' ? m.type : sort.key === 'warehouse' ? m.warehouse : m.date;
      const av = pick(a), bv = pick(b);
      const cmp = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv));
      return sort.dir === 'asc' ? cmp : -cmp;
    });
  }, [inScope, sort, typeFilter]);

  const onSort = (key: string) =>
    setSort(s => (s && s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));

  const qtyIn = visible.filter(m => m.type === 'In').reduce((s, m) => s + m.quantity, 0);
  const qtyOut = visible.filter(m => m.type === 'Out').reduce((s, m) => s + Math.abs(m.quantity), 0);
  const netQty = visible.reduce((s, m) => s + signed(m), 0);

  const typeCounts = [
    { value: '', label: 'All', count: inScope.length },
    ...['In', 'Out', 'Adjustment', 'Transfer'].map(t => ({ value: t, label: t, count: inScope.filter(m => m.type === t).length }))
  ];

  const stats: RegisterStat[] = [
    {
      label: 'Movements',
      value: typeFilter ? `${visible.length} of ${inScope.length}` : String(inScope.length),
      title: 'Rows the search, the window, the warehouse and the type pill leave on screen'
    },
    { label: 'Units in', value: qtyIn.toLocaleString(), tone: 'ok', title: `Received across the ${visible.length} movements listed below` },
    { label: 'Units out', value: qtyOut.toLocaleString(), tone: 'bad', title: `Issued across the same rows. The Quantity column writes these with a minus sign` },
    {
      label: 'Net change',
      value: netQty > 0 ? `+${netQty.toLocaleString()}` : netQty.toLocaleString(),
      title: 'The Quantity column added up exactly as displayed, so adjustments and transfers count at the sign they carry. This is the figure the totals line, the print sheet and the workbook all repeat'
    }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    typeFilter && `type ${typeFilter}`,
    warehouseFilter && `warehouse ${warehouseFilter}`,
    (fromDate || toDate) && `dates ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setTypeFilter('');
    setWarehouseFilter('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns = [
    { label: 'Date', value: (m: StockMovement) => m.date },
    { label: 'Product', value: (m: StockMovement) => `${m.itemName} ${m.sku}` },
    { label: 'Type', value: (m: StockMovement) => m.type },
    { label: 'Quantity', value: (m: StockMovement) => (signed(m) > 0 ? `+${signed(m)}` : `${signed(m)}`), align: 'right' as const },
    { label: 'Balance', value: (m: StockMovement) => m.balanceAfter, align: 'right' as const },
    { label: 'Reference', value: (m: StockMovement) => m.reference },
    { label: 'Warehouse', value: (m: StockMovement) => m.warehouse }
  ];

  const subtitle = activeFilters.length ? activeFilters.join(' · ') : 'Every movement in the register';

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Stock Ledger</h2>
            <p className="text-xs text-gray-500 mt-0.5">Every movement, adjustment and transfer the books have posted. Nothing is typed here.</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD STOCK MOVEMENT" onAdd={() => onNavigate?.('doc:stock-movement')} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by product, warehouse, reference or document" onSearch={setSearch} />
          <StatusPills value={typeFilter} onChange={setTypeFilter} counts={typeCounts} />
          {warehouses.length > 1 && (
            <span className="filter-plate">
              <Pick aria-label="Filter by warehouse" value={warehouseFilter} onChange={e => setWarehouseFilter(e.target.value)}>
                <option value="">Warehouse</option>
                {warehouses.map(w => <option key={w} value={w}>{w}</option>)}
              </Pick>
              {warehouseFilter && (
                <button type="button" title="Show every warehouse" onClick={() => setWarehouseFilter('')}
                  className="text-gray-400 hover:text-gray-600">
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          )}
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Stock Ledger" subtitle={subtitle} filename="stock-ledger" columns={columns} rows={visible}
              footer={footerRow(columns.length, { 0: `Total (${visible.length})`, 3: netQty > 0 ? `+${netQty}` : `${netQty}` })} landscape />
          </span>
        </div>
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Date" sortKey="date" sort={sort} onSort={onSort} />
                <SortHeader label="Product" sortKey="product" sort={sort} onSort={onSort} />
                <SortHeader label="Type" sortKey="type" sort={sort} onSort={onSort} />
                <SortHeader label="Quantity" sortKey="quantity" sort={sort} onSort={onSort} />
                <SortHeader label="Balance" sortKey="balance" sort={sort} onSort={onSort} />
                <th>Reference</th>
                <SortHeader label="Warehouse" sortKey="warehouse" sort={sort} onSort={onSort} />
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={7}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={7} noun="stock movements" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'ADD STOCK MOVEMENT'} onAdd={() => onNavigate?.('doc:stock-movement')} />
              )}
              {!loading && visible.map(m => (
              <tr key={`${m.docRef ?? ''}-${m.id}`}>
                <td className="whitespace-nowrap">{m.date}</td>
                <td>
                  <span className="flex items-center gap-2">
                    {m.type === 'In' ? <ArrowDownToLine size={14} className="text-emerald-600" />
                      : m.type === 'Adjustment' ? <SlidersHorizontal size={14} className="text-amber-500" />
                        : <ArrowUpFromLine size={14} className="text-red-500" />}
                    <span className="font-semibold text-gray-800">{m.itemName}</span>
                    <span className="text-[10px] text-gray-400 font-mono">{m.sku}</span>
                  </span>
                </td>
                <td>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${typeBadge[m.type] ?? 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                    {m.type}
                  </span>
                </td>
                <td className={`text-right font-medium ${signed(m) >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {signed(m) > 0 ? `+${signed(m)}` : signed(m)}
                </td>
                <td className="text-right font-medium text-gray-800 tabular-nums">{m.balanceAfter}</td>
                <td className="font-mono text-xs text-gray-600">{m.reference}</td>
                <td className="text-xs text-gray-500">{m.warehouse}</td>
              </tr>
            ))}
            </tbody>
            {!!visible.length && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td colSpan={3} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right font-black text-gray-800 tabular-nums">{netQty > 0 ? `+${netQty}` : netQty}</td>
                  <td colSpan={3} className="text-[11px] text-gray-500">
                    In {qtyIn.toLocaleString()} · Out {qtyOut.toLocaleString()} · adjustments and transfers count at the sign the Quantity column shows
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default StockLedger;
