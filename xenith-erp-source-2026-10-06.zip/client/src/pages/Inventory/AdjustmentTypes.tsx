import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Pencil, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { AdjustmentType, LedgerAccount } from '../../types';
import { deleteAdjustmentType, getAdjustmentTypes, saveAdjustmentType, updateAdjustmentType } from '../../services/inventory.service';
import { getLedgerAccounts } from '../../services/accounts.service';
import { Check, ExportPair, Field, FormFooter, IconAction, ListToolbar, Pick, RegisterStat, SearchBox, StatStrip, StatusPills, TableEmpty, Text } from '../Masters/masterUi';
import { useScreenReload } from '../../utils/screenReload';

const blank = { name: '', accountId: null as number | null, accountName: '', direction: 'Subtract' as AdjustmentType['direction'], description: '', isActive: true };

export const AdjustmentTypes: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<AdjustmentType[]>([]);
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [f, setF] = useState(blank);
  const [accountQuery, setAccountQuery] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const refresh = useCallback(() => {
    setLoading(true);
    getAdjustmentTypes(tenantSlug, branchId, search).then(r => setRows(r.data)).finally(() => setLoading(false));
  }, [tenantSlug, branchId, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);
  useEffect(() => { getLedgerAccounts(tenantSlug, branchId).then(r => setAccounts(r.data)); }, [tenantSlug, branchId]);

  // The account box is a search, not a long dropdown to scroll through.
  const matches = accounts.filter(a => `${a.code} ${a.name}`.toLowerCase().includes(accountQuery.toLowerCase())).slice(0, 8);

  const openForm = (t?: AdjustmentType) => {
    setEditId(t?.id ?? null);
    setF(t ? { name: t.name, accountId: t.accountId, accountName: t.accountName, direction: t.direction, description: t.description, isActive: t.isActive } : blank);
    setAccountQuery(t?.accountName ?? '');
    setError('');
    setAdding(true);
  };

  const submit = async () => {
    if (!f.name.trim()) { setError('A name is required.'); return; }
    setSaving(true);
    setError('');
    const body = { ...f, name: f.name.trim() };
    const res = editId === null
      ? await saveAdjustmentType(tenantSlug, branchId, body)
      : await updateAdjustmentType(tenantSlug, branchId, editId, body);
    setSaving(false);
    if ((res as any)?.error) { setError((res as any).error); return; }
    setAdding(false);
    refresh();
  };

  const remove = async (t: AdjustmentType) => {
    if (!window.confirm(`Delete ${t.name}?`)) return;
    setError('');
    const problem = await deleteAdjustmentType(tenantSlug, branchId, t.id);
    if (problem) setError(problem);
    refresh();
  };

  const columns = [
    { label: 'Name', value: (t: AdjustmentType) => t.name },
    { label: 'Inventory', value: (t: AdjustmentType) => (t.direction === 'Add' ? 'INVENTORY ADD' : 'INVENTORY SUBTRACT') },
    { label: 'Account', value: (t: AdjustmentType) => t.accountName || '—' },
    { label: 'Description', value: (t: AdjustmentType) => t.description },
    { label: 'Status', value: (t: AdjustmentType) => (t.isActive ? 'Active' : 'Inactive') }
  ];

  const visible = useMemo(() => (statusFilter
    ? rows.filter(t => (statusFilter === 'active' ? t.isActive : !t.isActive))
    : rows), [rows, statusFilter]);

  const inactive = rows.filter(t => !t.isActive).length;

  const statusCounts = [
    { value: '', label: 'All', count: rows.length },
    { value: 'active', label: 'Active', count: rows.length - inactive },
    { value: 'inactive', label: 'Inactive', count: inactive }
  ];

  const stats: RegisterStat[] = [
    {
      label: 'Types',
      value: statusFilter ? `${visible.length} of ${rows.length}` : String(rows.length),
      title: 'Reasons the search and the status pill leave on screen'
    },
    ...(inactive ? [{
      label: 'Inactive', value: inactive, tone: 'warn' as const,
      title: `${inactive} of them are marked Inactive, so a new stock adjustment will not offer them`
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    statusFilter && `status ${statusFilter === 'active' ? 'Active' : 'Inactive'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatusFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  if (adding) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <button onClick={() => setAdding(false)} className="btn-xenith-outline">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Adjustment Types</span>
          </button>
          <span className="text-[11px] text-gray-500">{editId === null ? 'NEW' : 'EDIT'} ADJUSTMENT TYPE</span>
        </div>
        <div className="nb-card p-0">
          <div className="px-4 py-3 border-b border-gray-100">
            <h2 className="page-title">Adjustment Type</h2>
            <p className="text-xs text-gray-500">Why a warehouse balance may change, and which way it moves.</p>
          </div>
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="Name" required>
              <Text autoFocus value={f.name} onChange={e => setF(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Damaged Stock" />
            </Field>
            <Field label="Inventory" required hint="Add increases stock, Subtract reduces it.">
              <Pick value={f.direction} onChange={e => setF(p => ({ ...p, direction: e.target.value as AdjustmentType['direction'] }))}>
                <option value="Subtract">Subtract</option>
                <option value="Add">Add</option>
              </Pick>
            </Field>
            <Field label="Account" hint="Type to search account.">
              <Text value={accountQuery} onChange={e => { setAccountQuery(e.target.value); setF(p => ({ ...p, accountId: null, accountName: '' })); }} placeholder="Type to search account..." />
              {accountQuery && !f.accountId && matches.length > 0 && (
                <ul className="mt-1 border border-gray-200 rounded bg-white max-h-40 overflow-y-auto shadow-sm">
                  {matches.map(a => (
                    <li key={a.id}>
                      <button type="button" className="w-full text-left px-2 py-1.5 text-xs hover:bg-blue-50"
                        onClick={() => { setF(p => ({ ...p, accountId: a.id, accountName: a.name })); setAccountQuery(`${a.code} · ${a.name}`); }}>
                        <span className="font-mono text-gray-400">{a.code}</span>{' '}
                        <span className="font-semibold text-gray-700">{a.name}</span>
                        <span className="text-gray-400"> · {a.type}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </Field>
            <Field label="Description">
              <Text value={f.description} onChange={e => setF(p => ({ ...p, description: e.target.value }))} placeholder="Shown on the adjustment form" />
            </Field>
            <div className="md:col-span-2">
              <Check checked={f.isActive} onChange={v => setF(p => ({ ...p, isActive: v }))} label="Active (selectable on new stock adjustments)" />
            </div>
          </div>
          {(error || rows.length > 0) && (
            <div className="px-4 pb-3 text-xs">
              {error && <p className="text-red-600">{error}</p>}
            </div>
          )}
          <FormFooter onSave={submit} onClose={() => setAdding(false)} saving={saving} disabled={!f.name.trim()}
            saveLabel={editId === null ? 'ADD ADJUSTMENT TYPE' : 'SAVE ADJUSTMENT TYPE'} />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Adjustment Types</h2>
            <p className="text-xs text-gray-500 mt-0.5">The reasons a warehouse balance may change, and which way each one moves it.</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD ADJUSTMENT TYPE" onAdd={() => openForm()} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by name, account or description" onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Adjustment Types" subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="adjustment-types" columns={columns} rows={visible} />
          </span>
        </div>
      </div>

      {error && (
        <div className="nb-card px-4 py-2.5 flex items-start justify-between gap-3 text-xs text-red-600">
          <span>{error}</span>
          <button type="button" onClick={() => setError('')} className="font-bold hover:underline">Dismiss</button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-[22%]">Name</th>
                <th className="w-[12%]">Inventory</th>
                <th className="w-[22%]">Account</th>
                <th>Description</th>
                <th className="w-[10%]">Status</th>
                <th className="text-center w-[8%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={6}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 9}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={6} noun="adjustment types" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'ADD ADJUSTMENT TYPE'} onAdd={() => openForm()} />
              )}
              {!loading && visible.map(t => (
              <tr key={t.id} className={t.isActive ? '' : 'opacity-60'}>
                <td className="font-bold text-gray-800">{t.name}</td>
                <td>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${t.direction === 'Add' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-600 border-red-200'}`}>
                    {t.direction === 'Add' ? 'INVENTORY ADD' : 'INVENTORY SUBTRACT'}
                  </span>
                </td>
                <td className="text-gray-600">{t.accountName || '—'}</td>
                <td className="text-xs text-gray-500">{t.description}</td>
                <td>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${t.isActive ? 'bg-gray-50 text-gray-600 border-gray-200' : 'bg-gray-100 text-gray-400 border-gray-200'}`}>
                    {t.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="text-center">
                  <div className="flex items-center justify-center">
                    <IconAction title={`Edit ${t.name}`} tone="primary" onClick={() => openForm(t)}>
                      <Pencil className="w-4 h-4" />
                    </IconAction>
                    <IconAction title={`Delete ${t.name}`} tone="danger" onClick={() => remove(t)}>
                      <Trash2 className="w-4 h-4" />
                    </IconAction>
                  </div>
                </td>
              </tr>
            ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdjustmentTypes;
