import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useTenant } from '../../context/TenantContext';
import { InventoryItem, Uom } from '../../types';
import { getItems, addItem, updateItem, deleteItem, getStockMap, StockMapRow } from '../../services/inventory.service';
import { getUoms } from '../../services/masters.service';
import { RefreshCw, Trash2, Edit2, Boxes, ChevronDown } from 'lucide-react';
import { ExportPair, ListToolbar, RegisterStat, SearchBox, StatStrip, StatusPills, TableEmpty } from '../Masters/masterUi';
import { useScreenReload } from '../../utils/screenReload';

const EMPTY_FORM: Partial<InventoryItem> = {
  name: '', sku: '', category: '', unit: '', salePrice: 0, purchasePrice: 0, stockQty: 0, reorderLevel: 0, isActive: true
};

export const ItemMaster: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<Partial<InventoryItem>>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  // One product can sit in several warehouses, so the card shows a total and the
  // breakdown expands underneath it on request.
  const [stockMap, setStockMap] = useState<Record<string, StockMapRow[]>>({});
  const [expanded, setExpanded] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  // The same switched-on units the Products form offers, so an item and a product cannot
  // be counted in two spellings of one unit.
  const [uoms, setUoms] = useState<Uom[]>([]);

  useEffect(() => {
    getUoms(tenantSlug, branchId).then(b => setUoms(b.data));
  }, [tenantSlug, branchId]);

  const unitChoices = useMemo(() => {
    const on = uoms.filter(u => u.isActive);
    const cur = uoms.find(u => u.code === form.unit);
    return cur && !cur.isActive ? [cur, ...on.filter(u => u.id !== cur.id)] : on;
  }, [uoms, form.unit]);

  const load = useCallback(async () => {
    setLoading(true);
    const [res, map] = await Promise.all([getItems(tenantSlug, branchId, search), getStockMap(tenantSlug, branchId)]);
    setItems(res.data);
    const bySku: Record<string, StockMapRow[]> = {};
    map.data.forEach(r => { (bySku[r.sku] = bySku[r.sku] ?? []).push(r); });
    setStockMap(bySku);
    setLoading(false);
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const openNew = () => { setForm({ ...EMPTY_FORM, unit: uoms.find(u => u.isActive)?.code ?? '' }); setEditId(null); setShowModal(true); };
  const openEdit = (i: InventoryItem) => { setForm(i); setEditId(i.id); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    if (editId) await updateItem(tenantSlug, branchId, editId, form);
    else await addItem(tenantSlug, branchId, form);
    setSaving(false); setShowModal(false); load();
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this item?')) return;
    await deleteItem(tenantSlug, branchId, id); load();
  };

  const columns = [
    { label: 'Item Name', value: (i: InventoryItem) => i.name },
    { label: 'SKU', value: (i: InventoryItem) => i.sku },
    { label: 'Category', value: (i: InventoryItem) => i.category },
    { label: 'Stock', value: (i: InventoryItem) => `${i.stockQty} ${i.unit}` },
    { label: 'Locations', value: (i: InventoryItem) => {
      const places = stockMap[i.sku] ?? [];
      return places.length ? `${places.length} location${places.length === 1 ? '' : 's'}` : 'No movements yet';
    } },
    { label: 'Sale Price', value: (i: InventoryItem) => `PKR ${i.salePrice.toLocaleString()}`, align: 'right' as const },
    { label: 'Status', value: (i: InventoryItem) => (i.isActive ? 'Active' : 'Inactive') }
  ];

  const visible = useMemo(() => (statusFilter
    ? items.filter(i => (statusFilter === 'active' ? i.isActive : !i.isActive))
    : items), [items, statusFilter]);

  // Items sit in mixed units (Pcs, Kg, Box), so a summed "stock" figure across the whole
  // list would add unlike quantities together. The register counts instead, and each row
  // carries its own unit.
  const low = items.filter(i => i.stockQty <= i.reorderLevel).length;
  const inactive = items.filter(i => !i.isActive).length;

  const statusCounts = [
    { value: '', label: 'All', count: items.length },
    { value: 'active', label: 'Active', count: items.filter(i => i.isActive).length },
    { value: 'inactive', label: 'Inactive', count: inactive }
  ];

  const stats: RegisterStat[] = [
    {
      label: 'Items',
      value: statusFilter ? `${visible.length} of ${items.length}` : String(items.length),
      title: 'Catalogue cards the search and the status pill leave on screen'
    },
    ...(low ? [{
      label: 'At or below reorder', value: low, tone: 'warn' as const,
      title: `Counted across every ${items.length} card loaded, not just the ones on screen. A card reads red when its stock has reached the level set on it`
    }] : []),
    ...(inactive && !statusFilter ? [{
      label: 'Inactive', value: inactive, tone: 'warn' as const,
      title: `Marked Inactive, so a new paper will not offer them. Use the Inactive pill to list them`
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    statusFilter && `status ${statusFilter === 'active' ? 'Active' : 'Inactive'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatusFilter('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const subtitle = activeFilters.length ? activeFilters.join(' · ') : 'The whole catalogue';

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h1 className="page-title">Item Master</h1>
            <p className="text-xs text-gray-500 mt-0.5">Every stocked card, its balance and the warehouses that hold it.</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="ADD ITEM" onAdd={openNew}>
            <button className="btn-xenith-outline" onClick={load}><RefreshCw size={13} />Refresh</button>
          </ListToolbar>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by name, SKU or category" onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Item Master" subtitle={subtitle} filename="item-master" columns={columns} rows={visible} landscape />
          </span>
        </div>
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th>Item Name</th>
                <th>SKU</th>
                <th>Category</th>
                <th>Stock</th>
                <th>Locations</th>
                <th>Sale Price</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={8}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 7}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={8} noun="items" filters={activeFilters} cleared={clearAll}
                  addLabel={items.length ? undefined : 'ADD ITEM'} onAdd={openNew} />
              )}
              {!loading && visible.map(i => (
                <ItemRows key={i.id} item={i} places={stockMap[i.sku] ?? []}
                  open={expanded === i.id} onToggle={() => setExpanded(e => (e === i.id ? null : i.id))}
                  onEdit={() => openEdit(i)} onDelete={() => handleDelete(i.id)} />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[calc(100vh-2rem)] overflow-y-auto">
            <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
              <h2 className="card-title">{editId ? 'Edit Item' : 'New Item'}</h2>
              <button className="text-gray-400 hover:text-gray-700 text-lg leading-none" onClick={() => setShowModal(false)}>×</button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Item Name *</label>
                <input className="input-xenith" value={form.name||''} onChange={e => setForm(f => ({...f, name: e.target.value}))}/>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">SKU *</label>
                  <input className="input-xenith" value={form.sku||''} onChange={e => setForm(f => ({...f, sku: e.target.value}))}/>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Category</label>
                  <input className="input-xenith" value={form.category||''} onChange={e => setForm(f => ({...f, category: e.target.value}))}/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Unit</label>
                  <select className="input-xenith" value={form.unit || ''} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))}>
                    {!form.unit && <option value="">Select a unit</option>}
                    {form.unit && !unitChoices.some(u => u.code === form.unit) && <option value={form.unit}>{form.unit}</option>}
                    {unitChoices.map(u => <option key={u.id} value={u.code}>{u.code} — {u.name}</option>)}
                  </select>
                  <p className="text-[10px] text-gray-400 mt-1">Units are switched on under Classification → Units of Measurement.</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Opening Stock</label>
                  <input type="number" className="input-xenith" value={form.stockQty||0} onChange={e => setForm(f => ({...f, stockQty: Number(e.target.value)}))}/>
                  <p className="text-[10px] text-gray-400 mt-1">Re-anchors the item balance. Movements already on the ledger are replayed on top of this figure.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Sale Price (PKR)</label>
                  <input type="number" className="input-xenith" value={form.salePrice||0} onChange={e => setForm(f => ({...f, salePrice: Number(e.target.value)}))}/>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Purchase Price (PKR)</label>
                  <input type="number" className="input-xenith" value={form.purchasePrice||0} onChange={e => setForm(f => ({...f, purchasePrice: Number(e.target.value)}))}/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Reorder Level</label>
                  <input type="number" className="input-xenith" value={form.reorderLevel||0} onChange={e => setForm(f => ({...f, reorderLevel: Number(e.target.value)}))}/>
                </div>
                <div className="flex items-end pb-1">
                  <label className="flex items-center gap-2 text-xs text-gray-700">
                    <input type="checkbox" checked={form.isActive ?? true} onChange={e => setForm(f => ({...f, isActive: e.target.checked}))}/>
                    Active
                  </label>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 px-5 py-3 border-t border-gray-100">
              <button className="btn-xenith-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn-xenith-primary" onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Item'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ItemRows: React.FC<{
  item: InventoryItem; places: StockMapRow[]; open: boolean;
  onToggle: () => void; onEdit: () => void; onDelete: () => void;
}> = ({ item, places, open, onToggle, onEdit, onDelete }) => (
  <>
    <tr className={item.isActive ? '' : 'opacity-60'}>
      <td>
        <div className="flex items-center gap-2">
          <Boxes size={14} className="text-blue-500" />
          <span className="font-semibold text-gray-800">{item.name}</span>
        </div>
      </td>
      <td className="font-mono text-xs">{item.sku}</td>
      <td>{item.category}</td>
      <td className={`font-semibold ${item.stockQty <= item.reorderLevel ? 'text-red-600' : 'text-green-600'}`}>
        {item.stockQty} {item.unit}
      </td>
      <td>
        {places.length === 0 ? (
          <span className="text-xs text-gray-400">No movements yet</span>
        ) : (
          <button onClick={onToggle} className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:underline">
            <ChevronDown size={13} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
            {places.length} location{places.length === 1 ? '' : 's'}
          </button>
        )}
      </td>
      <td className="text-right tabular-nums">PKR {item.salePrice.toLocaleString()}</td>
      <td>
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${item.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
          {item.isActive ? 'Active' : 'Inactive'}
        </span>
      </td>
      <td>
        <div className="flex items-center gap-1">
          <button className="btn-xenith-outline !px-1.5 !py-1" onClick={onEdit}><Edit2 size={12} /></button>
          <button className="btn-xenith-danger !px-1.5 !py-1" onClick={onDelete}><Trash2 size={12} /></button>
        </div>
      </td>
    </tr>
    {open && places.length > 0 && (
      <tr className="bg-gray-50/60">
        <td colSpan={8} className="py-2">
          <div className="flex flex-wrap gap-2 pl-6">
            {places.map(p => (
              <span key={p.warehouseName} className="inline-flex items-center gap-1.5 text-xs bg-white border border-gray-200 rounded px-2 py-1">
                <span className="text-gray-500">{p.warehouseName}</span>
                <span className={`font-semibold ${p.qty < 0 ? 'text-red-600' : 'text-gray-800'}`}>{p.qty} {item.unit}</span>
              </span>
            ))}
          </div>
        </td>
      </tr>
    )}
  </>
);
