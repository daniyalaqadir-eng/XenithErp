import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { isoDay, monthStart } from '../../utils/dateRange';
import { ArrowLeft, Trash2 } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { StockValuation } from '../../types';
import { deleteStockValuation, getStockValuations, saveStockValuation } from '../../services/inventory.service';
import { getWarehouses } from '../../services/warehouses.service';
import { DateWindow, ExportPair, Field, FormFooter, IconAction, ListToolbar, Pick, RegisterStat, SearchBox, StatStrip, StatusPills, TableEmpty, Text } from '../Masters/masterUi';
import { useScreenReload } from '../../utils/screenReload';

const statusClass: Record<string, string> = {
  Scheduled: 'bg-blue-50 text-blue-600 border-blue-200',
  Completed: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  Skipped: 'bg-gray-50 text-gray-500 border-gray-200'
};

export const ScheduledValuations: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [rows, setRows] = useState<StockValuation[]>([]);
  const [warehouses, setWarehouses] = useState<{ id: number; name: string }[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [fromDate, setFromDate] = useState(monthStart());
  const [toDate, setToDate] = useState(isoDay());
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [f, setF] = useState({ date: isoDay(), narration: '', status: 'Scheduled' as StockValuation['status'], warehouseName: '' });

  const refresh = useCallback(() => {
    setLoading(true);
    getStockValuations(tenantSlug, branchId).then(r => setRows(r.data)).finally(() => setLoading(false));
  }, [tenantSlug, branchId]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);
  useEffect(() => {
    getWarehouses(tenantSlug, branchId).then(r => setWarehouses(r.data.map(w => ({ id: w.id, name: w.name }))));
  }, [tenantSlug, branchId]);

  // Everything but the status pill, so the count written on a pill is the count clicking
  // it produces inside the window and search already chosen.
  const inScope = useMemo(() => rows.filter(v =>
    (!fromDate || v.date >= fromDate) && (!toDate || v.date <= toDate) &&
    (!search || [v.narration, v.date, v.warehouseName, v.status].some(x => String(x).toLowerCase().includes(search.toLowerCase())))),
  [rows, fromDate, toDate, search]);

  const visible = useMemo(() => statusFilter ? inScope.filter(v => v.status === statusFilter) : inScope,
    [inScope, statusFilter]);

  const statusCounts = [
    { value: '', label: 'All', count: inScope.length },
    ...['Scheduled', 'Completed', 'Skipped'].map(s => ({ value: s, label: s, count: inScope.filter(v => v.status === s).length }))
  ];

  // The one date worth naming above the register: what the schedule still owes. It reads
  // the whole schedule, not the window on screen, because an overdue run is overdue
  // however far the reader has filtered the list.
  const nextUp = useMemo(() => {
    const today = isoDay();
    const pending = rows.filter(v => v.status === 'Scheduled').map(v => v.date).sort();
    return pending.find(d => d >= today) ?? pending[0];
  }, [rows]);

  const stats: RegisterStat[] = [
    {
      label: 'Valuations',
      value: statusFilter ? `${visible.length} of ${inScope.length}` : String(inScope.length),
      title: 'Runs the search and the date window leave on screen, before the status pill'
    },
    ...(nextUp ? [{
      label: 'Next due', value: nextUp, tone: 'ok' as const,
      title: 'The earliest run still marked Scheduled across the whole schedule, not just the rows on screen'
    }] : [])
  ];

  const activeFilters = [
    search && `search “${search}”`,
    statusFilter && `status ${statusFilter}`,
    (fromDate || toDate) && `dates ${fromDate || 'the beginning'} → ${toDate || 'today'}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatusFilter('');
    setFromDate('');
    setToDate('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const submit = async () => {
    if (!f.date) { setError('Pick the date the valuation should run.'); return; }
    setSaving(true);
    setError('');
    const res = await saveStockValuation(tenantSlug, branchId, f);
    setSaving(false);
    if ((res as { error?: string })?.error) { setError((res as { error?: string }).error!); return; }
    setAdding(false);
    refresh();
  };

  const remove = (v: StockValuation) => {
    if (!window.confirm(`Delete the valuation scheduled for ${v.date}?`)) return;
    deleteStockValuation(tenantSlug, branchId, v.id).then(refresh);
  };

  const columns = [
    { label: 'Date', value: (v: StockValuation) => v.date },
    { label: 'Narration', value: (v: StockValuation) => v.narration || '—' },
    { label: 'Warehouse', value: (v: StockValuation) => v.warehouseName },
    { label: 'Status', value: (v: StockValuation) => v.status }
  ];

  // The sheet carries the rows on screen, so it has to say what was filtered out to get
  // them — the same sentence the empty register uses.
  const subtitle = activeFilters.length ? activeFilters.join(' · ') : 'The whole schedule';

  if (adding) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <button onClick={() => setAdding(false)} className="btn-xenith-outline">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Scheduled Valuations</span>
          </button>
          <span className="text-[11px] text-gray-500">NEW VALUATION</span>
        </div>
        <div className="nb-card p-0">
          <div className="px-4 py-3 border-b border-gray-100">
            <h2 className="page-title">Schedule Stock Valuation</h2>
            <p className="text-xs text-gray-500">Stock is priced as at the chosen date when the schedule runs.</p>
          </div>
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="Date" required>
              <Text type="date" value={f.date} onChange={e => setF(p => ({ ...p, date: e.target.value }))} />
            </Field>
            <Field label="Warehouse" hint="Leave blank to value every location.">
              <Pick value={f.warehouseName} onChange={e => setF(p => ({ ...p, warehouseName: e.target.value }))}>
                <option value="">All warehouses</option>
                {warehouses.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
              </Pick>
            </Field>
            <Field label="Narration">
              <Text value={f.narration} onChange={e => setF(p => ({ ...p, narration: e.target.value }))} placeholder="e.g. Half year stock valuation" />
            </Field>
            <Field label="Status">
              <Pick value={f.status} onChange={e => setF(p => ({ ...p, status: e.target.value as StockValuation['status'] }))}>
                <option value="Scheduled">Scheduled</option>
                <option value="Completed">Completed</option>
                <option value="Skipped">Skipped</option>
              </Pick>
            </Field>
          </div>
          {error && <p className="px-4 pb-3 text-xs text-red-600">{error}</p>}
          <FormFooter onSave={submit} onClose={() => setAdding(false)} saving={saving} disabled={!f.date} saveLabel="SCHEDULE VALUATION" />
        </div>
      </div>
    );
  }

  const openAdd = () => { setF(p => ({ ...p, warehouseName: warehouses[0]?.name ?? '' })); setError(''); setAdding(true); };

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Scheduled Stock Valuations</h2>
            <p className="text-xs text-gray-500 mt-0.5">Dates the stock is priced at. A run posts its own valuation when the schedule reaches it.</p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          <ListToolbar addLabel="SCHEDULE VALUATION" onAdd={openAdd} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by narration, date or warehouse" onSearch={setSearch} />
          <StatusPills value={statusFilter} onChange={setStatusFilter} counts={statusCounts} />
          <DateWindow from={fromDate} to={toDate} onChange={(f, t) => { setFromDate(f); setToDate(t); }} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Scheduled Stock Valuations" subtitle={subtitle} filename="scheduled-valuations" columns={columns} rows={visible} />
          </span>
        </div>
      </div>

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-[16%]">Date</th>
                <th>Narration</th>
                <th className="w-[24%]">Warehouse</th>
                <th className="w-[16%]">Status</th>
                <th className="text-center w-[8%]">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={5}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 9}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={5} noun="scheduled valuations" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length ? undefined : 'SCHEDULE VALUATION'} onAdd={openAdd} />
              )}
              {!loading && visible.map(v => (
                <tr key={v.id}>
                  <td className="font-semibold text-gray-800 whitespace-nowrap">{v.date}</td>
                  <td>{v.narration || <span className="text-gray-400">—</span>}</td>
                  <td className="text-gray-600">{v.warehouseName}</td>
                  <td>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${statusClass[v.status]}`}>{v.status}</span>
                  </td>
                  <td className="text-center">
                    <IconAction title={`Delete ${v.date} valuation`} tone="danger" onClick={() => remove(v)}>
                      <Trash2 className="w-4 h-4" />
                    </IconAction>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ScheduledValuations;
