import React, { useState } from 'react';
import { Check, Copy, Gift, HandCoins, Linkedin, Share2, Sparkles, Trophy, Users } from 'lucide-react';
import { useTenant } from '../context/TenantContext';
import { getReferral, PointLog, redeemPoints, ReferralInfo } from '../services/settings.service';
import { TabStrip } from './Masters/masterUi';
import { useHub } from './Setup/useHub';

const STEPS = [
  { icon: <Users className="w-5 h-5" />, tint: 'bg-[#2ec4b6]/10 text-[#1ba396]' },
  { icon: <Sparkles className="w-5 h-5" />, tint: 'bg-blue-50 text-[#1e88e5]' },
  { icon: <HandCoins className="w-5 h-5" />, tint: 'bg-amber-50 text-[#c77700]' }
];

const TYPE_PILL: Record<PointLog['type'], string> = {
  Earned: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Bonus: 'bg-blue-50 text-blue-700 border-blue-200',
  Redeemed: 'bg-red-50 text-red-700 border-red-200'
};

export const ReferAndEarn: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [tab, setTab] = useState('Refer And Earn');
  const [copied, setCopied] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [tier, setTier] = useState(0);
  const { value: info, loading, reload } = useHub<ReferralInfo>(() => getReferral(tenantSlug, branchId), [tenantSlug, branchId]);

  if (loading || !info) return <p className="py-10 text-center text-xs text-gray-400">{error || 'Loading your referral account…'}</p>;

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(info.url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setError('Your browser blocked the clipboard — select the link and copy it manually.');
    }
  };

  const redeem = async () => {
    setError(''); setNotice('');
    try {
      const res = await redeemPoints(tenantSlug, branchId, tier);
      setNotice(`${tier} points redeemed. Balance is now ${res.points}.`);
      reload();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-3">
        <div className="min-w-0">
          <h1 className="page-title flex items-center gap-2">
            <Gift className="w-4 h-4 text-[#2ec4b6]" /> Refer And Earn
          </h1>
          <p className="text-[11px] text-gray-400">Every referral voucher is worth Rs. {info.voucher}</p>
        </div>
      </div>

      <div className="nb-card">
        <TabStrip tabs={['Refer And Earn', 'Points History']} active={tab} onChange={setTab} />

        {tab === 'Refer And Earn' ? (
          <div className="nb-card-body animate-[fadeUp_.3s_ease-out_backwards]">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
              <div className="panel-xenith p-4">
                <p className="text-sm font-black text-gray-800 leading-snug">{info.headline}</p>
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {info.steps.map((s, i) => (
                    <div key={s.title} className="reveal text-center" style={{ animationDelay: `${i * 90}ms` }}>
                      <div className={`mx-auto w-11 h-11 rounded-full flex items-center justify-center ${STEPS[i].tint}`}>{STEPS[i].icon}</div>
                      <p className="mt-2 text-[11px] font-black text-gray-700 leading-tight">{i + 1}. {s.title}</p>
                      <p className="mt-1 text-[10px] text-gray-500 leading-snug">{s.text}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-gray-100 pt-3">
                  <div>
                    <span className="param-label">Your current points</span>
                    <span className="text-2xl font-black text-[#1ba396] tabular-nums leading-none">{info.points}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="param-label">Your referral code url</span>
                    <p className="text-[11px] font-mono text-gray-600 break-all leading-snug">{info.url}</p>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button type="button" onClick={copyCode} className="btn-xenith-success">
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />} COPY REFERRAL CODE
                  </button>
                  <a href={info.shareUrl} target="_blank" rel="noopener noreferrer"
                    className="btn-xenith-primary inline-flex items-center gap-1.5">
                    <Linkedin className="w-3.5 h-3.5" /> <Share2 className="w-3 h-3" /> Share on LinkedIn
                  </a>
                  {copied && <span className="text-[11px] font-bold text-[#25a195]">Link copied</span>}
                </div>
                {error && <p className="mt-2 text-[11px] font-semibold text-red-600">{error}</p>}
                {notice && <p className="mt-2 text-[11px] font-semibold text-[#25a195]">{notice}</p>}
              </div>

              <div className="panel-xenith p-4">
                <h2 className="section-title mb-3">How the vouchers work</h2>
                <ul className="space-y-2.5 text-xs text-gray-600">
                  {[
                    `Your friend gets Rs. ${info.voucher} off their first invoice the moment they sign up with your link.`,
                    `The moment their first payment clears, Rs. ${info.voucher} in points lands in your account.`,
                    'Points never expire while the subscription stays active, and there is no cap on referrals.',
                    'Redeem points against any upcoming invoice from this screen.'
                  ].map(line => (
                    <li key={line} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#2ec4b6] mt-0.5 shrink-0" />
                      <span className="leading-snug">{line}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-4 border-t border-gray-100 pt-3">
                  <span className="param-label">Redeem points</span>
                  <div className="flex flex-wrap items-end gap-2">
                    <select className="input-xenith w-auto min-w-0" value={tier} onChange={e => setTier(Number(e.target.value))}>
                      <option value={0}>Select an amount</option>
                      {info.redeemTiers.map(t => <option key={t} value={t}>{t} points</option>)}
                    </select>
                    <button type="button" onClick={redeem} disabled={!tier} className="btn-xenith-primary disabled:opacity-40">
                      <Trophy className="w-3.5 h-3.5" /> REDEEM
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="nb-card-body animate-[fadeUp_.3s_ease-out_backwards]">
            <div className="panel-xenith overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-2">
                <h2 className="section-title">User Points Logs</h2>
                <span className="text-[11px] text-gray-500 tabular-nums">Balance {info.points}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="xenith-table">
                  <thead><tr><th>Date</th><th className="text-right">Points</th><th>Description</th><th>Type</th><th>Action</th></tr></thead>
                  <tbody>
                    {info.logs.length === 0 && <tr><td colSpan={5} className="text-center py-8 text-gray-400">No points recorded yet</td></tr>}
                    {info.logs.map(l => (
                      <tr key={l.id}>
                        <td className="whitespace-nowrap text-gray-600">{l.date}</td>
                        <td className={`text-right font-black tabular-nums whitespace-nowrap ${l.points < 0 ? 'text-red-600' : 'text-[#1ba396]'}`}>
                          {l.points > 0 ? `+${l.points}` : l.points}
                        </td>
                        <td className="text-gray-700">{l.description}</td>
                        <td>
                          <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${TYPE_PILL[l.type]}`}>{l.type}</span>
                        </td>
                        <td className="text-gray-500">{l.action}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReferAndEarn;
