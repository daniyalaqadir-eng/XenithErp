import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Barcode, Edit2, Printer, QrCode, Trash2, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { deletePosTemplate, getPosTemplates, savePosTemplate, updatePosTemplate, PosTemplate } from '../../services/pos.service';
import {
  Check, DeleteConfirm, ExportPair, Field, FormFooter, IconAction, ListToolbar, NumCell, Pick,
  RegisterStat, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { barsOf, printLabels } from '../../utils/printLabels';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const blank = (): Partial<PosTemplate> => ({
  name: '', kind: 'Barcode', symbology: 'Code 128', paperWidth: 50, paperHeight: 30, margin: 2, fontSize: 8,
  showName: true, showSku: true, showPrice: true, showTax: false, showCompany: false, showExpiry: false,
  prefix: '', suffix: '', priceLabel: 'Sale Price', copies: 1, headerText: '', footerText: '', isActive: true
});

const fieldsOf = (t: PosTemplate) =>
  [t.showName && 'Name', t.showSku && 'SKU', t.showPrice && 'Price', t.showTax && 'Tax',
    t.showCompany && 'Company', t.showExpiry && 'Expiry'].filter(Boolean).join(', ') || 'Code only';

const columns: ExportColumn<PosTemplate>[] = [
  { label: 'Code', value: t => t.code },
  { label: 'Template Name', value: t => t.name },
  { label: 'Type', value: t => t.kind },
  { label: 'Symbology', value: t => t.symbology },
  { label: 'Size (mm)', value: t => `${t.paperWidth} × ${t.paperHeight}` },
  { label: 'Copies', value: t => t.copies, align: 'right' },
  { label: 'Fields', value: fieldsOf },
  { label: 'Status', value: t => t.isActive ? 'Active' : 'Inactive' }
];

const SYMBOLOGIES: Record<'Barcode' | 'QR Code', string[]> = {
  Barcode: ['Code 128', 'Code 39', 'Code 93', 'EAN 8', 'EAN 13', 'UPC-A', 'Codabar', 'ITF 2/5'],
  'QR Code': ['QR Alphanumeric', 'QR Numeric', 'QR Binary', 'QR URL']
};

const SAMPLE = { name: 'Barcode Scanner USB', sku: 'BCS-USB-004', price: 3500, taxPct: 18, expiry: '2027-09' };

const Preview: React.FC<{ t: PosTemplate }> = ({ t }) => {
  const px = 3.78; // 1mm at 96dpi-ish, purely for on-screen proportion
  const w = Math.max(28, t.paperWidth) * px;
  const h = Math.max(16, t.paperHeight) * px;
  const m = t.margin * px;
  const fs = Math.max(5, t.fontSize);
  const code = `${t.prefix}${SAMPLE.sku}${t.suffix}`;
  const price = t.priceLabel === 'Gross Price' ? SAMPLE.price * 1.18 : SAMPLE.price;

  return (
    <div className="inline-flex flex-col items-center gap-2">
      <div
        className="bg-white border border-gray-300 shadow-inner flex"
        style={{ width: w * t.copies, minHeight: h, padding: m, gap: m }}
      >
        {Array.from({ length: t.copies }).map((_, i) => (
          <div key={i} className="flex-1 flex flex-col justify-between text-gray-900 overflow-hidden" style={{ fontSize: fs }}>
            {t.headerText && <div className="font-bold text-center truncate leading-tight">{t.headerText}</div>}
            {t.showCompany && <div className="text-center truncate leading-tight">Xenith ERP</div>}
            {t.kind === 'Barcode' ? (
              <svg viewBox="0 0 100 26" preserveAspectRatio="none" className="w-full" style={{ height: Math.max(14, h * 0.34) }}>
                {(() => {
                  const bars = barsOf(code, 42);
                  let x = 0;
                  return bars.map((bw, i) => {
                    const el = i % 2 === 0 ? <rect key={i} x={x} y={0} width={bw} height={26} fill="#111" /> : null;
                    x += bw + 0.6;
                    return el;
                  });
                })()}
              </svg>
            ) : (
              <svg viewBox="0 0 21 21" className="w-full self-center" style={{ height: Math.max(14, h * 0.34) }}>
                {barsOf(code, 21 * 21).map((v, i) => (v % 2 === 0
                  ? <rect key={i} x={i % 21} y={Math.floor(i / 21)} width={1} height={1} fill="#111" /> : null))}
              </svg>
            )}
            <div className="text-center font-mono tracking-tight truncate">{code}</div>
            {t.showName && <div className="truncate leading-tight">{SAMPLE.name}</div>}
            {t.showSku && <div className="truncate leading-tight opacity-70">SKU: {SAMPLE.sku}</div>}
            {t.showPrice && <div className="font-bold leading-tight">PKR {price.toLocaleString()}</div>}
            {t.showTax && <div className="leading-tight opacity-70">Incl. tax {SAMPLE.taxPct}%</div>}
            {t.showExpiry && <div className="leading-tight opacity-70">EXP {SAMPLE.expiry}</div>}
            {t.footerText && <div className="text-center truncate leading-tight">{t.footerText}</div>}
          </div>
        ))}
      </div>
      <div className="text-[10px] text-gray-400 whitespace-nowrap">
        {t.paperWidth} × {t.paperHeight} mm · {t.symbology} · {t.copies} {t.copies === 1 ? 'copy' : 'copies'} per label
      </div>
    </div>
  );
};

export const BarcodeTemplates: React.FC = () => {
  const { tenantSlug, branchId, tenantName } = useTenant();
  const { can } = useAuth();
  const [rows, setRows] = useState<PosTemplate[]>([]);
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [kind, setKind] = useState('');
  const [sort, setSort] = useState<SortState>({ key: 'code', dir: 'asc' });
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<Partial<PosTemplate>>(blank());
  const [saving, setSaving] = useState(false);
  const [selected, setSelected] = useState<number[]>([]);

  // The type pills write counts, so the register pulls the whole search result and cuts
  // the type out of it here rather than asking the server for one type at a time.
  const requestId = useRef(0);
  const load = useCallback(async () => {
    const at = ++requestId.current;
    setLoading(true);
    setError('');
    try {
      const res = await getPosTemplates(tenantSlug, branchId, search, '');
      if (at === requestId.current) setRows(res.data);
    } catch (e: any) {
      if (at === requestId.current) setError(e?.message || 'The barcode templates could not be read');
    } finally {
      if (at === requestId.current) setLoading(false);
    }
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const openNew = () => { setForm(blank()); setEditId(null); setError(''); setNotice(''); setMode('form'); };
  const openEdit = (t: PosTemplate) => { setForm(t); setEditId(t.id); setError(''); setNotice(''); setMode('form'); };
  const set = <K extends keyof PosTemplate>(k: K, v: PosTemplate[K]) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name?.trim()) return;
    setSaving(true);
    setError('');
    try {
      if (editId) await updatePosTemplate(tenantSlug, branchId, editId, form);
      else await savePosTemplate(tenantSlug, branchId, form);
      setNotice(`${form.name} is on the POS setup.`);
      setMode('list');
      load();
    } catch (e: any) {
      setError(e?.message || 'This template could not be saved');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (t: PosTemplate) => {
    setConfirmId(null); setError(''); setNotice('');
    try {
      await deletePosTemplate(tenantSlug, branchId, t.id);
      setSelected(s => s.filter(x => x !== t.id));
      setNotice(`${t.name} has been taken off the POS setup.`);
      load();
    } catch (e) { setError((e as Error).message); }
  };

  const onSort = (key: string) => setSort(s => ({ key, dir: s.key === key && s.dir === 'asc' ? 'desc' : 'asc' }));

  const visible = rows.filter(t => !kind || t.kind === kind)
    .sort((a, b) => {
      const val = (t: PosTemplate): string | number =>
        sort.key === 'copies' ? t.copies
          : sort.key === 'status' ? (t.isActive ? 1 : 0)
            : String((t as any)[sort.key] ?? '');
      const x = val(a), y = val(b);
      const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y));
      return sort.dir === 'asc' ? r : -r;
    });

  const shown = {
    copies: visible.reduce((s, t) => s + t.copies, 0),
    active: visible.filter(t => t.isActive).length,
    proofs: selected.length
  };

  const stats: RegisterStat[] = [
    { label: 'Templates', value: kind ? `${visible.length} of ${rows.length}` : visible.length },
    { label: 'Copies per sheet', value: shown.copies, title: 'Sum of the copies each template on this register prints' },
    { label: 'Active', value: shown.active, tone: shown.active ? 'ok' : 'bad',
      title: shown.active ? 'An inactive template stays saved but cannot be picked at the till' : 'No template here is active, so label printing has nothing to pick' },
    { label: 'Ticked for proof', value: shown.proofs, tone: shown.proofs ? 'warn' : undefined,
      title: 'Templates the PRINT SELECTED button will put on paper' }
  ];

  const statusCounts = [
    { value: '', label: 'All types', count: rows.length },
    { value: 'Barcode', label: 'Barcode', count: rows.filter(t => t.kind === 'Barcode').length },
    { value: 'QR Code', label: 'QR Code', count: rows.filter(t => t.kind === 'QR Code').length }
  ];

  const activeFilters = [
    ...(search.trim() ? [`search “${search.trim()}”`] : []),
    ...(kind ? [`type ${kind}`] : [])
  ];
  const clearAll = () => { setSearch(''); setSearchEpoch(e => e + 1); setKind(''); };
  const subtitle = activeFilters.length ? activeFilters.join(' · ')
    : `Every barcode / QR template in ${tenantName} (${rows.length})`;

  // The box in the head works on the rows the register is showing, so a ticked set can never
  // quietly carry a template the reader has filtered out of sight.
  const allSelected = visible.length > 0 && visible.every(t => selected.includes(t.id));
  const toggleAll = () => setSelected(s => {
    const ids = visible.map(t => t.id);
    return allSelected ? s.filter(id => !ids.includes(id)) : [...new Set([...s, ...ids])];
  });
  const toggleOne = (id: number) =>
    setSelected(s => (s.includes(id) ? s.filter(x => x !== id) : [...s, id]));

  // Each ticked template prints one proof page at its own sticker size. The sheet follows the
  // rows on screen, so a template filtered out of sight cannot print from a stale tick.
  const printSelected = () => printLabels(
    visible.filter(t => selected.includes(t.id)).map(t => ({ tpl: t, items: [SAMPLE] })), tenantName);

  const previewTpl = useMemo(() => ({ ...blank(), ...form, id: 0, code: 'PREVIEW' } as PosTemplate), [form]);

  // A proof sheet is what the shop checks before loading the label printer, so the sample
  // product prints at the template's real millimetres.
  const printProof = (t: PosTemplate) => printLabels([{ tpl: t, items: [SAMPLE] }], tenantName);

  if (mode === 'form') {
    const k = form.kind || 'Barcode';
    return (
      <div className="animate-[fadeUp_.3s_ease-out_backwards]">
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button type="button" onClick={() => setMode('list')} className="btn-xenith-outline !px-2">
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
            <span className="w-8 h-8 rounded-lg bg-[#845ec2]/10 text-[#845ec2] flex items-center justify-center shrink-0">
              {k === 'QR Code' ? <QrCode className="w-4 h-4" /> : <Barcode className="w-4 h-4" />}
            </span>
            <div className="min-w-0">
              <h1 className="page-title">
                {editId ? 'Edit Barcode Template' : 'Add Barcode Template'}
              </h1>
              <p className="text-[11px] text-gray-400 truncate">{form.code || 'Number will be assigned on save'}</p>
            </div>
          </div>
          <button type="button" onClick={() => printProof(previewTpl)} className="btn-xenith-outline"
            title="Print a proof sheet of these labels at full size">
            <Printer className="w-3.5 h-3.5" />
            <span>PRINT LABELS</span>
          </button>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <div className="xl:col-span-2 space-y-4">
            <div className="panel-xenith">
              <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
                <h2 className="section-title">Template Details</h2>
              </div>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                <Field label="Template Name" required><Text value={form.name || ''} onChange={e => set('name', e.target.value)} placeholder="e.g. Retail Shelf Label" /></Field>
                <Field label="Code"><Text value={form.code || '(auto)'} readOnly className="bg-gray-50 text-gray-500" /></Field>
                <Field label="Label Type">
                  <Pick value={k} onChange={e => {
                    const nk = e.target.value as 'Barcode' | 'QR Code';
                    setForm(f => ({ ...f, kind: nk, symbology: SYMBOLOGIES[nk][0] }));
                  }}>
                    <option value="Barcode">Barcode</option>
                    <option value="QR Code">QR Code</option>
                  </Pick>
                </Field>
                <Field label="Symbology">
                  <Pick value={form.symbology || ''} onChange={e => set('symbology', e.target.value)}>
                    {SYMBOLOGIES[k].map(s => <option key={s} value={s}>{s}</option>)}
                  </Pick>
                </Field>
                <Field label="Prefix Text"><Text value={form.prefix || ''} onChange={e => set('prefix', e.target.value)} placeholder="BATCH-" /></Field>
                <Field label="Suffix Text"><Text value={form.suffix || ''} onChange={e => set('suffix', e.target.value)} placeholder="-PK" /></Field>
                <Field label="Price Source">
                  <Pick value={form.priceLabel || 'Sale Price'} onChange={e => set('priceLabel', e.target.value as PosTemplate['priceLabel'])}>
                    {['Sale Price', 'Retail Price', 'Gross Price'].map(p => <option key={p} value={p}>{p}</option>)}
                  </Pick>
                </Field>
                <Field label="Copies per Sheet"><NumCell value={form.copies || 1} min={1} max={24} onChange={e => set('copies', Number(e.target.value))} /></Field>
              </div>
            </div>

            <div className="panel-xenith">
              <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
                <h2 className="section-title">Paper &amp; Typography</h2>
              </div>
              <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-3">
                <Field label="Width (mm)"><NumCell value={form.paperWidth || 0} onChange={e => set('paperWidth', Number(e.target.value))} /></Field>
                <Field label="Height (mm)"><NumCell value={form.paperHeight || 0} onChange={e => set('paperHeight', Number(e.target.value))} /></Field>
                <Field label="Margin (mm)"><NumCell value={form.margin || 0} step={0.5} onChange={e => set('margin', Number(e.target.value))} /></Field>
                <Field label="Font Size (pt)"><NumCell value={form.fontSize || 0} onChange={e => set('fontSize', Number(e.target.value))} /></Field>
              </div>
              <div className="px-4 pb-4 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                <Check checked={!!form.showName} onChange={v => set('showName', v)} label="Product Name" />
                <Check checked={!!form.showSku} onChange={v => set('showSku', v)} label="SKU / Code" />
                <Check checked={!!form.showPrice} onChange={v => set('showPrice', v)} label="Price" />
                <Check checked={!!form.showTax} onChange={v => set('showTax', v)} label="Tax Included" />
                <Check checked={!!form.showCompany} onChange={v => set('showCompany', v)} label="Company Name" />
                <Check checked={!!form.showExpiry} onChange={v => set('showExpiry', v)} label="Expiry Date" />
              </div>
            </div>

            <div className="panel-xenith">
              <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
                <h2 className="section-title">Header &amp; Footer</h2>
              </div>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                <Field label="Header Text"><Text value={form.headerText || ''} onChange={e => set('headerText', e.target.value)} placeholder="Xenith ERP Store" /></Field>
                <Field label="Footer Text"><Text value={form.footerText || ''} onChange={e => set('footerText', e.target.value)} placeholder="Incl. of all taxes" /></Field>
                <div className="sm:col-span-2"><Check checked={form.isActive !== false} onChange={v => set('isActive', v)} label="Template Active" /></div>
              </div>
            </div>
          </div>

          <div className="panel-xenith h-fit sticky top-16">
            <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
              <h2 className="section-title">Live Preview</h2>
            </div>
            <div className="p-4 flex justify-center bg-[repeating-conic-gradient(#f8fafc_0_25%,#fff_0_50%)] bg-[length:16px_16px] overflow-x-auto">
              <Preview t={previewTpl} />
            </div>
            <p className="px-4 py-3 text-[11px] text-gray-400 leading-snug">
              Preview uses sample product <span className="font-semibold text-gray-500">{SAMPLE.name}</span>. Actual labels pull
              name, SKU and price from the product master at print time.
            </p>
          </div>
        </div>

        <div className="panel-xenith mt-4">
          {/* The refusal has to be read where the typing happened, or a save that never
              landed looks exactly like one that did. */}
          {(error || notice) && (
            <div className={`mx-4 mt-4 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between gap-2 ${
              error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
              <span>{error || notice}</span>
              <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
            </div>
          )}
          <FormFooter onSave={() => handleSave()} onClose={() => setMode('list')} saving={saving}
            disabled={!form.name?.trim()} saveLabel="Save and Close" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Barcode / QR Code Templates</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              The sticker sizes the shop prints from: symbology, millimetres of paper, which product fields go on the
              label and how many copies sit on a sheet. Tick the ones to check and one proof page per template comes
              out at the real size, which is how a printer gets loaded without guesswork.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {can('pos-barcode-templates:add') && (
            <ListToolbar addLabel="ADD BARCODE TEMPLATE" onAdd={openNew}>
              <button type="button" onClick={printSelected} disabled={!selected.length} className="btn-xenith-outline"
                title="Print one proof page per selected template">
                <Printer className="w-3.5 h-3.5" />
                <span>PRINT SELECTED{selected.length ? ` (${selected.length})` : ''}</span>
              </button>
            </ListToolbar>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by name, code or symbology" onSearch={setSearch} />
          <StatusPills value={kind} onChange={setKind} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Barcode / QR Code Templates" subtitle={subtitle} filename="barcode-templates"
              columns={columns} rows={visible}
              footer={footerRow(columns.length, { 0: `Total (${visible.length})`, 5: String(shown.copies) })} />
          </span>
        </div>
      </div>

      {(error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-8 text-center">
                  <input type="checkbox" checked={allSelected} onChange={toggleAll} title="Select every template showing" />
                </th>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Template Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Type" sortKey="kind" sort={sort} onSort={onSort} />
                <SortHeader label="Symbology" sortKey="symbology" sort={sort} onSort={onSort} />
                <th className="text-right">Size (mm)</th>
                <SortHeader label="Copies" sortKey="copies" sort={sort} onSort={onSort} />
                <th>Fields</th>
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={10}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={10} noun="barcode templates" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length || !can('pos-barcode-templates:add') ? undefined : 'ADD BARCODE TEMPLATE'}
                  onAdd={openNew} />
              )}
              {!loading && visible.map(t => (
                <tr key={t.id}>
                  <td className="text-center">
                    <input type="checkbox" checked={selected.includes(t.id)} onChange={() => toggleOne(t.id)}
                      aria-label={`Select ${t.name} for a proof sheet`} />
                  </td>
                  <td className="font-mono text-[11px] text-gray-500">{t.code}</td>
                  <td className="font-bold text-gray-800">{t.name}</td>
                  <td>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${t.kind === 'QR Code' ? 'bg-purple-50 text-[#845ec2] border border-purple-100' : 'bg-blue-50 text-[#1e88e5] border border-blue-100'}`}>
                      {t.kind === 'QR Code' ? <QrCode className="w-3 h-3" /> : <Barcode className="w-3 h-3" />}{t.kind}
                    </span>
                  </td>
                  <td className="text-gray-600 whitespace-nowrap">{t.symbology}</td>
                  <td className="text-right tabular-nums whitespace-nowrap">{t.paperWidth} × {t.paperHeight}</td>
                  <td className="text-right tabular-nums">{t.copies}</td>
                  <td className="text-[11px] text-gray-500 max-w-40"><span className="line-clamp-2">{fieldsOf(t)}</span></td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${t.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {t.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      <IconAction title={`Print a proof of ${t.name}`} onClick={() => printProof(t)}>
                        <Printer className="w-4 h-4" />
                      </IconAction>
                      {can('pos-barcode-templates:edit') && (
                        <IconAction title={`Edit ${t.name}`} tone="primary" onClick={() => openEdit(t)}>
                          <Edit2 className="w-4 h-4" />
                        </IconAction>
                      )}
                      {can('pos-barcode-templates:delete') && (confirmId === t.id ? (
                        <DeleteConfirm onConfirm={() => handleDelete(t)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${t.name}`} />
                      ) : (
                        <IconAction title={`Delete ${t.name}`} tone="danger" onClick={() => setConfirmId(t.id)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td></td>
                  <td colSpan={3} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right text-[11px] text-gray-500" colSpan={2}>Copies per sheet →</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{shown.copies}</td>
                  <td colSpan={3} className="text-[11px] text-gray-500">
                    One proof page per ticked template{kind ? ` · printed rows are ${kind} only` : ''}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default BarcodeTemplates;
