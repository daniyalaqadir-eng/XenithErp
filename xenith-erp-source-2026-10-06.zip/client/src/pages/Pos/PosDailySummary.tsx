import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AlertTriangle, Banknote, CreditCard, FileText, RefreshCw, RotateCcw, Store, TrendingUp, Wallet } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { getPosBills, getPosCounters, getPosDailySummary, PosBill, PosCounter, PosDailySummary as Summary } from '../../services/pos.service';
import { ExportPair, Pick } from '../Masters/masterUi';
import { ExportColumn } from '../../utils/exportTable';
import { isoDay } from '../../utils/dateRange';
import { useScreenReload } from '../../utils/screenReload';

// Read when a screen asks, not when this module loads: a terminal left open over midnight
// would otherwise keep calling yesterday "today", and a UTC cut would drop an hour of bills.
const today = () => isoDay();
const monthStart = () => `${isoDay().slice(0, 8)}01`;

// A figure the book has not filled in is zero, not a crash: this screen reads whatever the
// register returns, and a row missing a total used to take the whole page down.
const num = (v: unknown) => Number(v) || 0;
const moneyText = (value: number) =>
  `PKR ${num(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const Money: React.FC<{ value: number; className?: string }> = ({ value, className = '' }) => (
  <div className={`tabular-nums whitespace-nowrap ${className}`}>{moneyText(value)}</div>
);

type SummaryMetric = { label: string; value: number };

const columns: ExportColumn<SummaryMetric>[] = [
  { label: 'Metric', value: m => m.label },
  { label: 'Amount', value: m => moneyText(m.value), align: 'right' }
];

const Kpi: React.FC<{ label: string; value: number; icon: React.ReactNode; tone: string; money?: boolean; sub?: string }> = ({
  label, value, icon, tone, money = true, sub
}) => (
  <div className="panel-xenith p-3 flex items-start gap-3">
    <span className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${tone}`}>{icon}</span>
    <div className="min-w-0">
      <div className="text-[10px] font-black uppercase tracking-[.12em] text-gray-400">{label}</div>
      {money
        ? <Money value={value} className="text-sm font-black text-gray-800" />
        : <div className="text-sm font-black text-gray-800 tabular-nums">{num(value).toLocaleString()}</div>}
      {sub && <div className="text-[11px] text-gray-400 truncate">{sub}</div>}
    </div>
  </div>
);

export const PosDailySummary: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { tenantSlug, branchId } = useTenant();
  const [from, setFrom] = useState(monthStart());
  const [to, setTo] = useState(today());
  const [counters, setCounters] = useState<PosCounter[]>([]);
  const [counterId, setCounterId] = useState('All');
  const [data, setData] = useState<Summary | null>(null);
  const [bills, setBills] = useState<PosBill[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // A new date range is asked for while the last one is still on its way, so the reads are
  // numbered: only the newest pair is allowed to paint the day, and a failure says so on the
  // screen instead of leaving an empty table under a header that describes another range.
  const requestId = useRef(0);
  const load = useCallback(async () => {
    const at = ++requestId.current;
    setLoading(true);
    setError('');
    try {
      const [s, b] = await Promise.all([
        getPosDailySummary(tenantSlug, branchId, from, to, counterId),
        getPosBills(tenantSlug, branchId, { from, to, counterId })
      ]);
      if (at !== requestId.current) return;
      setData(s);
      setBills(b.data.slice().reverse());
    } catch (e: any) {
      if (at === requestId.current) {
        setData(null);
        setBills([]);
        setError(e?.message || 'The day could not be read from the register');
      }
    } finally {
      if (at === requestId.current) setLoading(false);
    }
  }, [tenantSlug, branchId, from, to, counterId]);

  useEffect(() => {
    let live = true;
    getPosCounters(tenantSlug, branchId)
      .then(r => { if (live) setCounters(r.data); })
      .catch(() => { if (live) setCounters([]); });
    return () => { live = false; };
  }, [tenantSlug, branchId]);
  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const t = data?.totals;

  const metrics: SummaryMetric[] = [
    { label: 'Net Sales', value: t?.netSales ?? 0 },
    { label: 'Cash Collected', value: t?.cash ?? 0 },
    { label: 'Card / Wallet', value: (t?.card ?? 0) + (t?.wallet ?? 0) },
    { label: 'Discounts Given', value: t?.discounts ?? 0 }
  ];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-4">
        <div className="min-w-0">
          <h1 className="page-title flex items-center gap-2">
            <Store className="w-4 h-4 text-[#2ec4b6]" /> POS Daily Summary
          </h1>
          <p className="text-[11px] text-gray-400">
            {from} to {to} · {counterId === 'All'
              ? 'all counters'
              : counters.find(c => String(c.id) === counterId)?.name || `counter #${counterId}`}
            {' · '}{data?.openedShifts ?? 0} shift(s) open of {data?.activeCounters ?? 0} active counter(s)
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <button type="button" onClick={() => onNavigate?.('pos-terminal')} className="btn-xenith-success">
            <CreditCard className="w-3.5 h-3.5" /> OPEN POS TERMINAL
          </button>
          <ExportPair title="POS Daily Summary" subtitle={`${from} to ${to} · ${counterId === 'All' ? 'all counters' : counters.find(c => String(c.id) === counterId)?.name || `counter #${counterId}`}`} filename="pos-daily-summary" columns={columns} rows={metrics} />
        </div>
      </div>

      <div className="panel-xenith p-3 mb-4 flex flex-wrap items-end gap-x-3 gap-y-2">
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wide text-gray-500 mb-1">From</label>
          <input type="date" value={from} onChange={e => setFrom(e.target.value)} className="input-xenith !w-auto whitespace-nowrap" />
        </div>
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wide text-gray-500 mb-1">To</label>
          <input type="date" value={to} onChange={e => setTo(e.target.value)} className="input-xenith !w-auto whitespace-nowrap" />
        </div>
        <div className="min-w-36 flex-1">
          <label className="block text-[10px] font-bold uppercase tracking-wide text-gray-500 mb-1">Checkout Counter</label>
          <Pick value={counterId} onChange={e => setCounterId(e.target.value)}>
            <option value="All">All counters</option>
            {counters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Pick>
        </div>
        <button className="btn-xenith-outline" onClick={load}><RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Apply</button>
        <button className="btn-xenith-outline" onClick={() => { setCounterId('All'); setFrom(monthStart()); setTo(today()); }}>
          <RotateCcw size={13} /> Reset
        </button>
      </div>

      {error && (
        <div className="mb-4 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between gap-2 text-red-600 bg-red-50 border border-red-100">
          <span>{error}</span>
          <button type="button" onClick={load} className="underline whitespace-nowrap">try again</button>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4 reveal">
        <Kpi label="Net Sales" value={t?.netSales ?? 0} icon={<TrendingUp className="w-4 h-4 text-[#25a195]" />} tone="bg-teal-50" sub={`${t?.bills ?? 0} bills settled`} />
        <Kpi label="Cash Collected" value={t?.cash ?? 0} icon={<Banknote className="w-4 h-4 text-[#1e88e5]" />} tone="bg-blue-50" sub="Drawer balance + bank drop" />
        <Kpi label="Card / Wallet" value={(t?.card ?? 0) + (t?.wallet ?? 0)} icon={<Wallet className="w-4 h-4 text-[#845ec2]" />} tone="bg-purple-50" sub={`Card ${(num(t?.card) / Math.max(1, num(t?.netSales)) * 100).toFixed(0)}% of mix`} />
        <Kpi label="Discounts Given" value={t?.discounts ?? 0} icon={<AlertTriangle className="w-4 h-4 text-[#f08c00]" />} tone="bg-amber-50" sub={`Output tax ${(num(t?.tax) / Math.max(1, num(t?.netSales)) * 100).toFixed(1)}% of net sales`} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="panel-xenith overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
            <h2 className="section-title">Day / Wise Summary</h2>
            <span className="text-[11px] text-gray-400">{data?.datewise?.length ?? 0} trading day(s)</span>
          </div>
          <div className="overflow-x-auto">
            <table className="xenith-table">
              <thead>
                <tr>
                  <th>Date</th><th className="text-right">Bills</th><th className="text-right">Gross</th>
                  <th className="text-right">Returns</th><th className="text-right">Disc</th>
                  <th className="text-right">Tax</th><th className="text-right">Net Sales</th>
                </tr>
              </thead>
              <tbody>
                {(data?.datewise ?? []).map(d => (
                  <tr key={d.date}>
                    <td className="font-semibold whitespace-nowrap">{d.date}{d.date === today() && <span className="ml-1.5 text-[10px] font-bold text-[#2ec4b6]">TODAY</span>}</td>
                    <td className="text-right tabular-nums">{num(d.bills)}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(d.grossSales).toLocaleString()}</td>
                    <td className={`text-right tabular-nums whitespace-nowrap ${d.returns ? 'text-red-600' : ''}`}>{d.returns ? `-${num(d.returns).toLocaleString()}` : '—'}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(d.discounts).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(d.tax).toLocaleString()}</td>
                    <td className="text-right font-bold tabular-nums whitespace-nowrap">{num(d.netSales).toLocaleString()}</td>
                  </tr>
                ))}
                {!loading && !(data?.datewise?.length) && (
                  <tr><td colSpan={7} className="text-center py-8 text-gray-400">No bills in this range</td></tr>
                )}
              </tbody>
              {!!data?.datewise?.length && (
                <tfoot>
                  <tr className="bg-blue-50/40 font-bold">
                    <td>Total</td>
                    <td className="text-right tabular-nums">{num(t?.bills)}</td>
                    <td colSpan={2} className="text-right text-[11px] text-gray-500 whitespace-nowrap">
                      incl. returns {((data?.datewise ?? []).reduce((s, d) => s + num(d.returns), 0)).toLocaleString()}
                    </td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(t?.discounts).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(t?.tax).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(t?.netSales).toLocaleString()}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        <div className="panel-xenith overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
            <h2 className="section-title">Counter / Wise Summary</h2>
            <span className="text-[11px] text-gray-400">{data?.counterwise?.length ?? 0} counter(s) billed</span>
          </div>
          <div className="overflow-x-auto">
            <table className="xenith-table">
              <thead>
                <tr>
                  <th>Counter</th><th className="text-right">Bills</th><th className="text-right">Items</th>
                  <th className="text-right">Avg Bill</th><th className="text-right">Cash</th>
                  <th className="text-right">Card</th><th className="text-right">Wallet</th><th className="text-right">Net Sales</th>
                </tr>
              </thead>
              <tbody>
                {(data?.counterwise ?? []).map(c => (
                  <tr key={c.counterId}>
                    <td className="font-semibold">
                      <span className="line-clamp-2">{c.counterName}</span>
                      {num(c.voided) > 0 && <span className="block text-[10px] font-bold text-red-500">{num(c.voided)} voided</span>}
                    </td>
                    <td className="text-right tabular-nums">{num(c.bills)}</td>
                    <td className="text-right tabular-nums">{num(c.items)}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(c.averageBill).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(c.cash).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(c.card).toLocaleString()}</td>
                    <td className="text-right tabular-nums whitespace-nowrap">{num(c.wallet).toLocaleString()}</td>
                    <td className="text-right font-bold tabular-nums whitespace-nowrap">{num(c.netSales).toLocaleString()}</td>
                  </tr>
                ))}
                {!loading && !(data?.counterwise?.length) && (
                  <tr><td colSpan={8} className="text-center py-8 text-gray-400">No activity in this range</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="panel-xenith mt-4 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
          <h2 className="section-title">Bills in Range</h2>
          <span className="text-[11px] text-gray-400 flex items-center gap-1"><FileText className="w-3 h-3" />{bills.length} recent first</span>
        </div>
        <div className="overflow-x-auto">
          <table className="xenith-table">
            <thead>
              <tr>
                <th>Bill #</th><th>Date / Time</th><th>Counter</th><th>Customer</th>
                <th>Payment</th><th className="text-right">Items</th><th className="text-right">Tax</th>
                <th className="text-right">Grand Total</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {bills.map(b => (
                <tr key={b.id}>
                  <td className={`font-mono text-[11px] font-bold ${b.type === 'Return' ? 'text-red-600' : 'text-gray-700'}`}>{b.number}</td>
                  <td className="whitespace-nowrap tabular-nums">{b.date} <span className="text-gray-400">{b.time}</span></td>
                  <td className="text-gray-600"><span className="line-clamp-2 max-w-40">{b.counterName}</span></td>
                  <td className="text-gray-600">{b.customerName}</td>
                  <td className="whitespace-nowrap">
                    {(b.payments ?? []).map(p => p.mode).join(' + ')}
                    {num(b.change) > 0 && <span className="text-[10px] text-gray-400"> · change {num(b.change).toLocaleString()}</span>}
                  </td>
                  <td className="text-right tabular-nums">{(b.lines ?? []).reduce((s, l) => s + num(l.quantity), 0)}</td>
                  <td className="text-right tabular-nums whitespace-nowrap">{num(b.tax).toLocaleString()}</td>
                  <td className={`text-right font-bold tabular-nums whitespace-nowrap ${b.type === 'Return' ? 'text-red-600' : 'text-gray-800'}`}>
                    {b.type === 'Return' ? '-' : ''}{num(b.grandTotal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${
                      b.status === 'Settled' ? 'bg-green-100 text-green-700' : b.status === 'Void' ? 'bg-gray-100 text-gray-500' : 'bg-amber-100 text-amber-700'
                    }`}>{b.status}</span>
                  </td>
                </tr>
              ))}
              {!loading && !bills.length && (
                <tr><td colSpan={9} className="text-center py-8 text-gray-400">No bills posted in this range</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PosDailySummary;
