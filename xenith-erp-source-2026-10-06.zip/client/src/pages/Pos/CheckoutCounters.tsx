import React, { useCallback, useEffect, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import { ArrowLeft, CreditCard, Edit2, Printer, Trash2, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { deletePosCounter, getPosCounters, savePosCounter, updatePosCounter, PosBill, PosCounter } from '../../services/pos.service';
import { getWarehouses } from '../../services/warehouses.service';
import { printReceiptWithLetterhead } from '../../utils/printWithLetterhead';
import {
  Check, DeleteConfirm, ExportPair, Field, FormFooter, IconAction, ListToolbar, NumCell, Pick,
  RegisterStat, SearchBox, SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { ExportColumn, footerRow } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const columns: ExportColumn<PosCounter>[] = [
  { label: 'Code', value: c => c.code },
  { label: 'Counter Name', value: c => c.name },
  { label: 'Warehouse', value: c => c.warehouseName || '—' },
  { label: 'Terminals', value: c => Number(c.terminalCount) || 0, align: 'right' },
  { label: 'Shift', value: c => c.shiftTiming || '—' },
  { label: 'Drawer Limit', value: c => `PKR ${money(c.cashDrawerLimit)}`, align: 'right' },
  { label: 'Printer', value: c => c.printerName || 'No printer' },
  { label: 'Receipt Template', value: c => c.receiptTemplate },
  { label: 'Status', value: c => c.isActive ? 'Active' : 'Inactive' }
];

const money = (n: number) => Math.round(Number(n || 0)).toLocaleString();

const blank = (): Partial<PosCounter> => ({
  name: '', warehouseId: null, warehouseName: '', terminalCount: 1, printerName: '',
  receiptTemplate: 'POS Thermal 80mm', cashDrawerLimit: 0, autoPrint: true, allowDiscount: false,
  maxDiscountPercent: 0, openShift: false, shiftTiming: '09:00 - 21:00', isActive: true, address: '', remarks: ''
});

const r2 = roundMoney;

// A proof slip has to show every row the paper can carry, so the sample mixes a plain
// priced item, one the cashier discounted, and a service with no stock behind it.
const demoBill = (c: Partial<PosCounter>, cashier: string): PosBill => {
  const sample: [string, string, string, number, number, number][] = [
    ['Barcode Scanner USB', 'BCS-USB-004', 'Pcs', 2, 3500, 0],
    ['Thermal Paper Rolls (Box 50)', 'TPR-BOX-050', 'Box', 4, 500, 5],
    ['Annual Maintenance Contract', 'AMC-STD-01', 'Service', 1, 6000, 10]
  ];
  const lines = sample.map(([productName, sku, unit, quantity, price, discountPercent], i) => ({
    id: i + 1, productId: null, productName, sku, unit, quantity, price, discountPercent,
    amount: r2(quantity * price * (1 - discountPercent / 100))
  }));
  const subtotal = r2(lines.reduce((s, l) => s + l.quantity * l.price, 0));
  const net = r2(lines.reduce((s, l) => s + l.amount, 0));
  const tax = r2(net * 0.17);
  const grandTotal = r2(net + tax);
  // Note the change from a round note, the way a till actually settles in cash.
  const cashReceived = Math.ceil(grandTotal / 50) * 50;
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return {
    id: 0, number: 'POS-000000',
    date: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
    time: now.toTimeString().slice(0, 5),
    counterId: c.id ?? 0, counterName: c.name || 'Checkout counter', cashier,
    customerName: 'Walk-in Customer', type: 'Sale', status: 'Settled', lines,
    subtotal, discount: r2(subtotal - net), tax, grandTotal,
    payments: [{ mode: 'Cash', amount: cashReceived }], cashReceived, change: r2(cashReceived - grandTotal)
  };
};

const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void; label: string }> = ({ checked, onChange, label }) => (
  <button type="button" onClick={() => onChange(!checked)}
    className={`flex items-center gap-2 text-xs font-semibold ${checked ? 'text-[#25a195]' : 'text-gray-400'}`}>
    <span className={`relative w-9 h-5 rounded-full overflow-hidden transition-colors duration-200 ${checked ? 'bg-[#2ec4b6]' : 'bg-gray-200'}`}>
      <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform duration-200 ${checked ? 'translate-x-4' : 'translate-x-0.5'}`} />
    </span>
    {label}
  </button>
);

export const CheckoutCounters: React.FC = () => {
  const { tenantSlug, branchId, tenantName } = useTenant();
  const { user, can } = useAuth();
  const [rows, setRows] = useState<PosCounter[]>([]);
  const [search, setSearch] = useState('');
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState<SortState>({ key: 'code', dir: 'asc' });
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'list' | 'form'>('list');
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<Partial<PosCounter>>(blank());
  const [saving, setSaving] = useState(false);
  const [warehouses, setWarehouses] = useState<{ id: number; name: string }[]>([]);

  useEffect(() => {
    let live = true;
    getWarehouses(tenantSlug, branchId)
      .then(r => { if (live) setWarehouses(r.data.map(w => ({ id: w.id, name: w.name }))); })
      .catch(() => { if (live) setWarehouses([]); });
    return () => { live = false; };
  }, [tenantSlug, branchId]);

  // A search box types faster than the book answers, so the register is numbered: only the
  // newest read is allowed to paint the rows, and a failure says so instead of spinning.
  const requestId = useRef(0);
  const load = useCallback(async () => {
    const at = ++requestId.current;
    setLoading(true);
    setError('');
    try {
      const res = await getPosCounters(tenantSlug, branchId, search);
      if (at === requestId.current) setRows(res.data);
    } catch (e: any) {
      if (at === requestId.current) setError(e?.message || 'The checkout counters could not be read');
    } finally {
      if (at === requestId.current) setLoading(false);
    }
  }, [tenantSlug, branchId, search]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const openNew = () => { setForm(blank()); setEditId(null); setMode('form'); };
  const openEdit = (c: PosCounter) => { setForm(c); setEditId(c.id); setMode('form'); };

  const set = <K extends keyof PosCounter>(k: K, v: PosCounter[K]) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name?.trim()) return;
    setSaving(true);
    setError('');
    try {
      if (editId) await updatePosCounter(tenantSlug, branchId, editId, form);
      else await savePosCounter(tenantSlug, branchId, form);
      setNotice(`${form.name} is on the POS setup.`);
      setMode('list');
      load();
    } catch (e: any) {
      // The counter stays on the form with the refusal on screen: a setup that was not
      // written looks identical to one that was.
      setError(e?.message || 'This counter could not be saved');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (c: PosCounter) => {
    setConfirmId(null); setError(''); setNotice('');
    try {
      await deletePosCounter(tenantSlug, branchId, c.id);
      setNotice(`${c.name} has been taken off the POS setup.`);
      load();
    } catch (e) { setError((e as Error).message); }
  };

  const onSort = (key: string) => setSort(s => ({ key, dir: s.key === key && s.dir === 'asc' ? 'desc' : 'asc' }));

  // The search runs on the server, so the register below counts the rows that search left.
  const visible = rows.filter(c => !status
    || (status === 'Open shift' ? c.openShift : status === 'Active' ? c.isActive : !c.isActive))
    .sort((a, b) => {
      const val = (c: PosCounter): string | number =>
        sort.key === 'terminals' ? Number(c.terminalCount) || 0
          : sort.key === 'drawer' ? Number(c.cashDrawerLimit) || 0
            : sort.key === 'warehouse' ? (c.warehouseName || '')
              : sort.key === 'status' ? (c.isActive ? 1 : 0)
                : String((c as any)[sort.key] ?? '');
      const x = val(a), y = val(b);
      const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y));
      return sort.dir === 'asc' ? r : -r;
    });

  const shown = {
    terminals: visible.reduce((s, c) => s + (Number(c.terminalCount) || 0), 0),
    drawer: visible.reduce((s, c) => s + (Number(c.cashDrawerLimit) || 0), 0),
    open: visible.filter(c => c.openShift).length,
    active: visible.filter(c => c.isActive).length
  };

  const stats: RegisterStat[] = [
    { label: 'Counters', value: status ? `${visible.length} of ${rows.length}` : visible.length },
    { label: 'Terminals', value: shown.terminals, title: 'Devices counted across the rows showing' },
    { label: 'Drawer float', value: `PKR ${money(shown.drawer)}` },
    { label: 'Shifts open', value: shown.open, tone: shown.open ? 'ok' : 'warn',
      title: shown.open ? 'The terminal opens on one of these' : 'No counter is flagged as running a shift, so the till opens on any active one and the slip shows shift closed' },
    { label: 'Active', value: shown.active, tone: shown.active ? 'ok' : 'bad' }
  ];

  const statusCounts = [
    { value: '', label: 'All', count: rows.length },
    { value: 'Active', label: 'Active', count: rows.filter(c => c.isActive).length },
    { value: 'Inactive', label: 'Inactive', count: rows.filter(c => !c.isActive).length },
    { value: 'Open shift', label: 'Shift open', count: rows.filter(c => c.openShift).length }
  ];

  const activeFilters = [
    ...(search.trim() ? [`search “${search.trim()}”`] : []),
    ...(status ? [`status ${status}`] : [])
  ];
  const clearAll = () => { setSearch(''); setSearchEpoch(e => e + 1); setStatus(''); };
  const subtitle = activeFilters.length ? activeFilters.join(' · ')
    : `Every checkout counter in ${tenantName} (${rows.length})`;

  // The template is picked on this form, so the proof has to come off the printer with the
  // choices as they stand unsaved — otherwise setup staff tune the paper blind.
  const previewReceipt = () => {
    setError(''); setNotice('');
    printReceiptWithLetterhead(demoBill(form, user?.name || 'Cashier'), tenantSlug, branchId, {
      template: form.receiptTemplate, outletAddress: form.address,
      cashier: user?.name || 'Cashier', stamp: `PREVIEW · ${form.receiptTemplate || 'POS Thermal 80mm'}`
    }).catch((e: any) => setError(e?.message || 'The proof could not be printed'));
  };

  if (mode === 'form') {
    return (
      <div className="animate-[fadeUp_.3s_ease-out_backwards]">
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button type="button" onClick={() => setMode('list')} className="btn-xenith-outline !px-2">
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
            <span className="w-8 h-8 rounded-lg bg-[#2ec4b6]/10 text-[#1ba396] flex items-center justify-center shrink-0">
              <CreditCard className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <h1 className="page-title">{editId ? 'Edit Checkout Counter' : 'Add Checkout Counter'}</h1>
              <p className="text-[11px] text-gray-400 truncate">{form.code || 'Number will be assigned on save'}</p>
            </div>
          </div>
          <button type="button" onClick={previewReceipt} className="btn-xenith-outline"
            title="Print a proof of this counter's receipt on the selected template">
            <Printer className="w-3.5 h-3.5" /> PRINT PREVIEW
          </button>
        </div>

        <div className="panel-xenith">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
            <h2 className="section-title">Counter Identity</h2>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
            <Field label="Code"><Text value={form.code || '(auto)'} readOnly className="bg-gray-50 text-gray-500" /></Field>
            <Field label="Counter Name" required><Text value={form.name || ''} onChange={e => set('name', e.target.value)} placeholder="e.g. Main Counter - Head Office" /></Field>
            <Field label="Warehouse">
              <Pick value={String(form.warehouseId ?? '')} onChange={e => {
                const id = Number(e.target.value) || null;
                setForm(f => ({ ...f, warehouseId: id, warehouseName: warehouses.find(w => w.id === id)?.name || '' }));
              }}>
                <option value="">Select warehouse</option>
                {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
              </Pick>
            </Field>
            <Field label="Terminal Count" hint="devices on this counter"><NumCell value={form.terminalCount || 0} min={1} onChange={e => set('terminalCount', Math.max(1, Number(e.target.value) || 0))} /></Field>
            <Field label="Shift Timing"><Text value={form.shiftTiming || ''} onChange={e => set('shiftTiming', e.target.value)} placeholder="09:00 - 21:00" /></Field>
            <Field label="Receipt Printer"><Text value={form.printerName || ''} onChange={e => set('printerName', e.target.value)} placeholder="Epson TM-T82 (80mm)" /></Field>
          </div>

          <div className="px-4 py-3 border-y border-gray-100 bg-gray-50/60">
            <h2 className="section-title">Billing Rules</h2>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-4 gap-y-3">
            <Field label="Receipt Template">
              <Pick value={form.receiptTemplate || ''} onChange={e => set('receiptTemplate', e.target.value)}>
                {['POS Thermal 80mm', 'POS Thermal 58mm', 'POS A4 Invoice', 'POS A5 Invoice'].map(t => <option key={t} value={t}>{t}</option>)}
              </Pick>
            </Field>
            <Field label="Cash Drawer Limit (PKR)" hint="float held in drawer"><NumCell value={form.cashDrawerLimit || 0} min={0} onChange={e => set('cashDrawerLimit', Math.max(0, Number(e.target.value) || 0))} /></Field>
            <Field label="Max Discount %" required={false}><NumCell value={form.maxDiscountPercent || 0} min={0} max={100} onChange={e => set('maxDiscountPercent', Math.max(0, Math.min(100, Number(e.target.value) || 0)))} /></Field>
            <div className="flex flex-wrap items-end gap-x-5 gap-y-2 sm:col-span-2 xl:col-span-3">
              <Toggle checked={!!form.autoPrint} onChange={v => set('autoPrint', v)} label="Auto print receipt" />
              <Toggle checked={!!form.allowDiscount} onChange={v => set('allowDiscount', v)} label="Allow cashier discount" />
              <Toggle checked={!!form.openShift} onChange={v => set('openShift', v)} label="Shift currently open" />
              <Toggle checked={form.isActive !== false} onChange={v => set('isActive', v)} label="Active" />
            </div>
          </div>

          <div className="px-4 py-3 border-y border-gray-100 bg-gray-50/60">
            <h2 className="section-title">Location &amp; Remarks</h2>
          </div>
          <div className="p-4 grid grid-cols-1 gap-3">
            <Field label="Address"><Text value={form.address || ''} onChange={e => set('address', e.target.value)} placeholder="Shop / outlet address printed on the receipt" /></Field>
            <Field label="Remarks"><Text value={form.remarks || ''} onChange={e => set('remarks', e.target.value)} placeholder="Internal note for the counter" /></Field>
          </div>

          {/* The refusal has to be read where the typing happened: a save that failed while
              the form is still open would otherwise leave no trace on the screen at all. */}
          {(error || notice) && (
            <div className={`mx-4 mb-3 text-xs font-semibold rounded px-3 py-2 flex items-center justify-between gap-2 ${
              error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
              <span>{error || notice}</span>
              <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
            </div>
          )}

          <FormFooter onSave={() => handleSave()} onClose={() => setMode('list')} saving={saving}
            disabled={!form.name?.trim()} saveLabel="Save and Close" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Checkout Counters</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Every till the shop bills from lives here: the warehouse it draws stock from, the printer its receipts
              go to and the float its drawer opens with. The POS terminal only lists counters that are active, and it
              opens on the one whose shift is flagged as running.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {can('pos-counters:add') && <ListToolbar addLabel="ADD CHECKOUT COUNTER" onAdd={openNew} />}
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder="Search by name, code or warehouse" onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title="Checkout Counters" subtitle={subtitle} filename="checkout-counters"
              columns={columns} rows={visible}
              footer={footerRow(columns.length, {
                0: `Total (${visible.length})`, 3: String(shown.terminals), 5: money(shown.drawer)
              })} />
          </span>
        </div>
      </div>

      {(error || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label="Counter Name" sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Warehouse" sortKey="warehouse" sort={sort} onSort={onSort} />
                <SortHeader label="Terminals" sortKey="terminals" sort={sort} onSort={onSort} />
                <SortHeader label="Shift" sortKey="shiftTiming" sort={sort} onSort={onSort} />
                <SortHeader label="Drawer Limit" sortKey="drawer" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="status" sort={sort} onSort={onSort} />
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={8}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={8} noun="checkout counters" filters={activeFilters} cleared={clearAll}
                  addLabel={rows.length || !can('pos-counters:add') ? undefined : 'ADD CHECKOUT COUNTER'} onAdd={openNew} />
              )}
              {!loading && visible.map(c => (
                <tr key={c.id}>
                  <td className="font-mono text-[11px] text-gray-500">{c.code}</td>
                  <td>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                      <span className="font-bold text-gray-800">{c.name}</span>
                      {c.openShift && <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-full px-1.5">SHIFT OPEN</span>}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-gray-400"><Printer className="w-3 h-3" />{c.printerName || 'No printer'} · {c.receiptTemplate}</div>
                  </td>
                  <td className="text-gray-600">{c.warehouseName || '—'}</td>
                  <td className="text-right tabular-nums">{c.terminalCount}</td>
                  <td className="whitespace-nowrap text-gray-600">{c.shiftTiming || '—'}</td>
                  <td className="text-right tabular-nums whitespace-nowrap">PKR {money(c.cashDrawerLimit)}</td>
                  <td>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${c.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {c.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      {can('pos-counters:edit') && (
                        <IconAction title={`Edit ${c.name}`} tone="primary" onClick={() => openEdit(c)}>
                          <Edit2 className="w-4 h-4" />
                        </IconAction>
                      )}
                      {can('pos-counters:delete') && (confirmId === c.id ? (
                        <DeleteConfirm onConfirm={() => handleDelete(c)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${c.name}`} />
                      ) : (
                        <IconAction title={`Delete ${c.name}`} tone="danger" onClick={() => setConfirmId(c.id)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {!!visible.length && !loading && (
              <tfoot>
                <tr className="bg-gray-50/80">
                  <td colSpan={3} className="font-black text-gray-800">Total ({visible.length})</td>
                  <td className="text-right tabular-nums font-black text-gray-800">{shown.terminals}</td>
                  <td></td>
                  <td className="text-right tabular-nums font-black text-gray-800">{money(shown.drawer)}</td>
                  <td colSpan={2} className="text-[11px] text-gray-500">
                    Float the drawers hold across the rows showing{status ? ` · printed rows include ${status.toLowerCase()}` : ''}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default CheckoutCounters;
