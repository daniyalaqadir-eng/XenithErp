import React from 'react';
import {
  ArrowRight, BadgeCheck, CloudOff, CreditCard, Keyboard, Loader, RefreshCcw,
  ScanLine, ShieldCheck, Store, Wallet, Wifi
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';

const FEATURES: { icon: React.ReactNode; title: string; body: string; tone: string }[] = [
  { icon: <CloudOff className="w-4 h-4" />, title: 'Billing never stops', body: 'The terminal keeps selling when the internet drops. Bills are written to the device and queued locally.', tone: 'bg-[#2ec4b6]/10 text-[#1ba396]' },
  { icon: <RefreshCcw className="w-4 h-4" />, title: 'Auto-sync on reconnect', body: 'As soon as the link is back, held bills post themselves in the exact order they were taken — no re-keying.', tone: 'bg-[#1e88e5]/10 text-[#1e88e5]' },
  { icon: <Keyboard className="w-4 h-4" />, title: 'Built for the counter', body: 'Barcode-first search, touch keypad, hot-key settlement and 58/80mm receipt templates.', tone: 'bg-[#845ec2]/10 text-[#845ec2]' },
  { icon: <ShieldCheck className="w-4 h-4" />, title: 'Balances stay true', body: 'Stock, customer ledger and drawer totals reconcile centrally after sync, so reports never double-count.', tone: 'bg-[#ff9f1c]/10 text-[#c77700]' }
];

const MODES = [
  { label: 'Cash drawer', icon: <Wallet className="w-4 h-4" /> },
  { label: 'Card machine', icon: <CreditCard className="w-4 h-4" /> },
  { label: 'Wallet rails', icon: <ScanLine className="w-4 h-4" /> }
];

export const PosOffline: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { currency } = useTenant();
  return (
    <div className="animate-[fadeUp_.45s_ease-out_backwards] space-y-4">
      <div className="panel-xenith overflow-hidden">
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0f3057] via-[#1e5f8a] to-[#2ec4b6] text-white px-5 py-8 sm:px-8 sm:py-10">
          <span className="absolute -top-16 -right-10 w-56 h-56 rounded-full bg-white/10 blur-2xl pointer-events-none" />
          <span className="absolute -bottom-20 left-10 w-64 h-64 rounded-full bg-[#2ec4b6]/25 blur-3xl pointer-events-none" />
          <div className="relative">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 border border-white/25 px-2.5 py-1 text-[10px] font-black uppercase tracking-[.14em]">
              <Wifi className="w-3 h-3" /> Offline ready
            </span>
            <h1 className="mt-3 text-2xl sm:text-3xl font-black leading-tight">POS Offline</h1>
            <p className="mt-2 max-w-2xl text-sm text-white/80 leading-relaxed">
              Counter sales continue even when the line goes down. Bills taken offline are held on the device,
              then synced into {`Xenith ERP`} — invoices, payments, stock movement and drawer totals — the moment
              the connection returns.
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-2">
              <button type="button" onClick={() => onNavigate?.('pos-terminal')}
                className="inline-flex items-center gap-2 rounded-lg bg-white text-[#0f3057] px-4 py-2 text-xs font-black shadow-lg transition-transform duration-200 hover:-translate-y-0.5">
                <Store className="w-4 h-4" /> OPEN POS TERMINAL <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button type="button" onClick={() => onNavigate?.('pos-daily-summary')}
                className="inline-flex items-center gap-2 rounded-lg border border-white/35 px-4 py-2 text-xs font-bold text-white transition-colors duration-200 hover:bg-white/10">
                View daily summary
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 reveal">
        {FEATURES.map(f => (
          <div key={f.title} className="card-xenith p-4">
            <span className={`w-9 h-9 rounded-lg flex items-center justify-center ${f.tone}`}>{f.icon}</span>
            <h3 className="mt-2.5 text-xs font-black text-gray-800 leading-snug">{f.title}</h3>
            <p className="mt-1 text-[11px] text-gray-500 leading-relaxed">{f.body}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="panel-xenith p-4">
          <h2 className="section-title mb-3">How a held bill returns</h2>
          <ol className="space-y-2.5">
            {[
              ['Connection lost', 'The terminal switches to offline mode and keeps a local sequence number per counter.'],
              ['Bill taken', 'Line items, discounts and the payment mode are stored on the device with the cashier stamp.'],
              ['Link restored', 'Queued bills upload in order; duplicates are rejected on the server by counter sequence.'],
              ['Ledgers updated', `Sale invoices, ${currency} payments and stock movements post under the original bill date.`]
            ].map(([title, body], i) => (
              <li key={title} className="flex gap-3">
                <span className="w-6 h-6 shrink-0 rounded-full bg-[#2ec4b6] text-white text-[11px] font-black flex items-center justify-center">{i + 1}</span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-gray-800">{title}</div>
                  <p className="text-[11px] text-gray-500 leading-relaxed">{body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div className="panel-xenith p-4">
          <h2 className="section-title mb-3">Settlement modes available offline</h2>
          <div className="flex flex-wrap gap-2">
            {MODES.map(m => (
              <span key={m.label} className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-gray-50 px-2.5 py-1.5 text-[11px] font-bold text-gray-700">
                {m.icon}{m.label}
              </span>
            ))}
          </div>
          <div className="mt-4 rounded-lg border border-amber-100 bg-amber-50/70 px-3 py-2.5">
            <div className="flex items-center gap-1.5 text-[11px] font-black text-amber-700 uppercase tracking-wide">
              <Loader className="w-3 h-3" /> Sync queue
            </div>
            <p className="mt-1 text-[11px] text-amber-700/90 leading-relaxed">
              This build runs the terminal against the live API, so the queue is always empty. Nothing is held back —
              every bill you settle posts immediately.
            </p>
            <div className="mt-2 flex items-center gap-2 text-[11px] font-bold text-emerald-700">
              <BadgeCheck className="w-3.5 h-3.5" /> 0 bills pending · counter in sync
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PosOffline;
