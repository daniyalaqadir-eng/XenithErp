import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { roundMoney } from '../../utils/money';
import {
  Banknote, CheckCircle2, CreditCard, Eye, Minus, PauseCircle, Plus, Printer, RotateCcw,
  ScanLine, Search, ShoppingCart, SquareUser, Trash2, User, Wallet, XCircle
} from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { getPosCounters, getPosProducts, savePosBill, PosBill, PosCounter, PosProduct } from '../../services/pos.service';
import { getParties } from '../../services/masters.service';
import { SearchSelect } from '../../components/common/SearchSelect';
import { printReceiptWithLetterhead } from '../../utils/printWithLetterhead';

type Slot = 'Invoice 1' | 'Invoice 2' | 'Sales Return';
const SLOTS: Slot[] = ['Invoice 1', 'Invoice 2', 'Sales Return'];

interface CartLine { key: number; product: PosProduct; qty: number; price: number; discountPercent: number }
interface BillState { lines: CartLine[]; discount: number; customer: string; payments: { mode: string; amount: number }[] }
interface HeldBill { id: number; slot: Slot; bill: BillState; at: string }

const emptyBill = (): BillState => ({ lines: [], discount: 0, customer: 'Walk-in Customer', payments: [] });

const MODES: { mode: string; icon: React.ReactNode; tone: string }[] = [
  { mode: 'Cash', icon: <Banknote className="w-3.5 h-3.5" />, tone: 'bg-[#2ec4b6] text-white' },
  { mode: 'Card', icon: <CreditCard className="w-3.5 h-3.5" />, tone: 'bg-[#1e88e5] text-white' },
  { mode: 'EasyPaisa', icon: <Wallet className="w-3.5 h-3.5" />, tone: 'bg-[#25a195] text-white' },
  { mode: 'JazzCash', icon: <Wallet className="w-3.5 h-3.5" />, tone: 'bg-[#845ec2] text-white' },
  { mode: 'Bank Transfer', icon: <Banknote className="w-3.5 h-3.5" />, tone: 'bg-[#5f7cff] text-white' }
];

const KEYS = ['7', '8', '9', '-', '4', '5', '6', '+', '1', '2', '3', '×', '0', '00', '.', '÷'];
const r2 = roundMoney;
const money = (n: number) => n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const PosTerminal: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { tenantSlug, branchId } = useTenant();
  const [slot, setSlot] = useState<Slot>('Invoice 1');
  const [bills, setBills] = useState<Record<Slot, BillState>>({ 'Invoice 1': emptyBill(), 'Invoice 2': emptyBill(), 'Sales Return': emptyBill() });
  const [products, setProducts] = useState<PosProduct[]>([]);
  const [counters, setCounters] = useState<PosCounter[]>([]);
  const [counterId, setCounterId] = useState<number | ''>('');
  const [customers, setCustomers] = useState<{ id: number; name: string }[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [lineKey, setLineKey] = useState<number | null>(null);
  const [target, setTarget] = useState<'qty' | 'tender'>('qty');
  const [entry, setEntry] = useState('');
  const [paid, setPaid] = useState('');
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState('');
  const [clock, setClock] = useState(() => new Date());
  // The last bill settled on each slot, so a customer who left their slip on the counter
  // can be given a reprint without going looking for it in the daily summary.
  const [lastBills, setLastBills] = useState<Partial<Record<Slot, PosBill>>>({});
  // A held bill is parked whole — lines, customer, discount, tenders — because the queue
  // logic that makes a cashier hold is exactly the logic that expects it back intact.
  const [held, setHeld] = useState<HeldBill[]>([]);
  const scanRef = useRef<HTMLInputElement>(null);
  // keystroke, a slow response used to land after a fast one and paint the older list.
  const reqId = useRef(0);

  useEffect(() => {
    const id = window.setInterval(() => setClock(new Date()), 30000);
    return () => window.clearInterval(id);
  }, []);

  // Counters and customers belong to the branch, not to the search box, so they load once
  // per branch. They used to ride the per-keystroke product reload and never re-seated the
  // selected counter, so a cashier who changed branch rang up the old branch's counter.
  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const [c, cust] = await Promise.all([
          getPosCounters(tenantSlug, branchId),
          getParties('customers', tenantSlug, branchId)
        ]);
        if (!live) return;
        setCounters(c.data.filter(x => x.isActive));
        setCounterId((c.data.find(x => x.openShift && x.isActive) || c.data.find(x => x.isActive))?.id ?? '');
        setCustomers(cust.data.map(x => ({ id: x.id, name: x.name })));
      } catch { /* the terminal still works from the products alone */ }
    })();
    return () => { live = false; };
  }, [tenantSlug, branchId]);

  const fetchProducts = useCallback(async (term: string) => {
    const id = ++reqId.current;
    try {
      const p = await getPosProducts(tenantSlug, branchId, term);
      if (id === reqId.current) setProducts(p.data);
    } catch { /* keep the last good grid on screen */ }
  }, [tenantSlug, branchId]);

  // A scanner types the whole code in well under the debounce; a human typing gets one
  // request per pause rather than one per keystroke.
  useEffect(() => {
    const id = window.setTimeout(() => { fetchProducts(search); }, 180);
    return () => window.clearTimeout(id);
  }, [search, fetchProducts]);

  useEffect(() => { scanRef.current?.focus(); }, []);

  const bill = bills[slot];
  const patch = (fn: (b: BillState) => BillState) => setBills(prev => ({ ...prev, [slot]: fn(prev[slot]) }));

  const counter = counters.find(c => c.id === counterId);
  const isReturn = slot === 'Sales Return';
  const categories = useMemo(() => ['All', ...new Set(products.map(p => p.categoryName))], [products]);
  const visible = useMemo(
    () => products.filter(p => category === 'All' || p.categoryName === category),
    [products, category]
  );

  // A line's value after its own discount, worked the way the counter's bill works it: the
  // gross first, then the discount off that gross, each kept to the paisa.
  const lineNet = (l: CartLine) => {
    const gross = r2(l.qty * l.price);
    return r2(gross - gross * l.discountPercent / 100);
  };
  const subtotal = r2(bill.lines.reduce((s, l) => s + r2(l.qty * l.price), 0));
  const afterLineDisc = r2(bill.lines.reduce((s, l) => s + lineNet(l), 0));
  const lineDisc = r2(subtotal - afterLineDisc);
  const billDisc = Math.min(afterLineDisc, bill.discount);
  const taxable = r2(afterLineDisc - billDisc);
  // Tax is measured on each line at the rate its own card carries, on the value that line is
  // charged after its share of a discount taken on the whole bill — which is the arithmetic
  // the bill is posted with. One blended percentage over the whole cart used to charge tax on
  // an untaxed item sitting beside a taxed one, and it was worked out before the bill discount
  // came off.
  const lineTaxed = (l: CartLine) => (afterLineDisc
    ? r2(lineNet(l) - billDisc * lineNet(l) / afterLineDisc) : 0);
  const tax = r2(bill.lines.reduce((s, l) => s + r2(lineTaxed(l) * l.product.taxPercent / 100), 0));
  const taxPercent = taxable ? r2(tax / taxable * 100) : 0;
  const grandTotal = r2(taxable + tax);
  const discountTotal = r2(lineDisc + billDisc);
  // The Tendered box and the payment chips state the same thing two ways, and a cashier can
  // edit either. Trust the higher of them: a box left below the chips would otherwise let a
  // mode tap re-tender money the bill has already taken, and the change shown would then
  // disagree with the tender the sale posts with.
  const committed = r2(bill.payments.reduce((s, p) => s + Number(p.amount || 0), 0));
  const tender = Math.max(Number(paid) || 0, committed);
  const change = r2(Math.max(0, tender - grandTotal));
  const shortfall = r2(Math.max(0, grandTotal - tender));

  const maxDiscount = counter?.allowDiscount ? counter.maxDiscountPercent : 0;

  // The till's limit is on everything given away — the discounts typed on the lines and the
  // amount taken off the whole bill, together, against the gross — which is how the server works
  // it out too. Measuring only the bill line let a 10%-off tile beside a 10% bill discount look
  // fine on the till and come back refused at settle.
  const giveAway = (next: number) => {
    const wanted = Math.max(0, r2(next));
    if (!maxDiscount || !subtotal) return wanted;
    const allowed = r2(subtotal * maxDiscount / 100);
    const fit = r2(Math.min(wanted, Math.max(0, allowed - lineDisc)));
    if (fit !== wanted) {
      say(`Counter limit is ${maxDiscount}% — PKR ${money(allowed)} off a PKR ${money(subtotal)} bill,`
        + ` and PKR ${money(lineDisc)} of it is already given on the lines`);
    }
    return fit;
  };

  const say = (msg: string) => {
    setFlash(msg);
    window.setTimeout(() => setFlash(''), 2400);
  };

  const addProduct = (p: PosProduct) => {
    if (!isReturn && p.trackStock && p.stockQty <= 0) {
      say(`${p.name} is out of stock`);
      return;
    }
    patch(b => {
      const hit = b.lines.find(l => l.product.id === p.id);
      // Tapping the same tile twice is still the one edit a till must refuse on the shelf, so
      // it goes through the same clamp a typed quantity does — otherwise the second tap quietly
      // sells stock the branch does not have and the server turns the bill back at settle.
      if (hit) return { ...b, lines: b.lines.map(l => (l.key === hit.key ? { ...l, qty: clampQty(l, r2(l.qty + 1)) } : l)) };
      const key = Date.now() + Math.floor(Math.random() * 1000);
      return { ...b, lines: [...b.lines, { key, product: p, qty: 1, price: p.price, discountPercent: 0 }] };
    });
    setLineKey(null);
  };

  const updateLine = (key: number, changes: Partial<CartLine>) =>
    patch(b => ({ ...b, lines: b.lines.map(l => (l.key === key ? { ...l, ...changes } : l)) }));

  // Enter means "this is a scan", and the item a scanner just named is decided by its code,
  // not by whatever the filtered grid happens to show first.
  const ringUpScan = () => {
    const term = search.trim().toLowerCase();
    if (!term) return;
    const exact = products.filter(p =>
      String(p.barcode || '').toLowerCase() === term || String(p.sku || '').toLowerCase() === term);
    if (exact.length > 1) return say(`${search} matches ${exact.length} products — pick one from the grid`);
    if (exact.length === 1) { addProduct(exact[0]); setSearch(''); return; }
    if (visible.length === 1) { addProduct(visible[0]); setSearch(''); return; }
    say(`No product carries the code “${search}”`);
  };

  const removeLine = (key: number) => patch(b => ({ ...b, lines: b.lines.filter(l => l.key !== key) }));

  // Selling more than the shelf holds is the one edit a till must refuse, because the
  // movement it books would leave the stock ledger negative for the whole branch.
  const clampQty = (l: CartLine, qty: number) => {
    if (qty < 0) return 0;
    if (!isReturn && l.product.trackStock && qty > l.product.stockQty) {
      say(`Only ${l.product.stockQty} ${l.product.unit} of ${l.product.name} in stock`);
      return Math.max(0.001, l.product.stockQty);
    }
    return r2(qty);
  };

  const press = (k: string) => {
    if (k === '×' || k === '÷' || k === '-' || k === '+') {
      if (!entry) return;
      setEntry(e => e + k);
      return;
    }
    setEntry(e => (e === '' ? (k === '.' ? '0.' : k) : e + k));
  };

  // Keypad input is digits plus at most four operators; fold it by hand rather than evaluating strings.
  const evaluated = useMemo(() => {
    if (!entry) return 0;
    const tokens = entry.split(/([+×÷\-])/).filter(Boolean);
    let acc = Number(tokens[0]);
    if (!Number.isFinite(acc)) return 0;
    for (let i = 1; i + 1 < tokens.length; i += 2) {
      const rhs = Number(tokens[i + 1]);
      if (!Number.isFinite(rhs)) return r2(acc);
      acc = tokens[i] === '×' ? acc * rhs : tokens[i] === '÷' ? (rhs === 0 ? acc : acc / rhs)
        : tokens[i] === '-' ? acc - rhs : acc + rhs;
    }
    return Number.isFinite(acc) ? r2(acc) : 0;
  }, [entry]);

  const applyEntry = () => {
    if (target === 'tender') {
      setPaid(String(r2((Number(paid) || 0) + evaluated)));
    } else if (lineKey !== null) {
      const l = bill.lines.find(x => x.key === lineKey);
      updateLine(lineKey, { qty: l ? clampQty(l, evaluated) : Math.max(0.001, evaluated) });
    } else {
      patch(b => ({ ...b, discount: giveAway((b.discount || 0) + evaluated) }));
    }
    clearEntry();
  };

  const clearEntry = () => { setEntry(''); };

  const holdBill = () => {
    if (!bill.lines.length) return say('Nothing to hold on this bill');
    const parked = bill;
    setHeld(prev => [...prev, { id: Date.now(), slot, bill: parked, at: new Date().toTimeString().slice(0, 5) }]);
    setBills(prev => ({ ...prev, [slot]: emptyBill() }));
    setPaid('');
    clearEntry();
    say(`${slot} held — ${parked.lines.length} line(s) parked`);
  };

  const recallBill = (h: HeldBill) => {
    setHeld(prev => prev.filter(x => x.id !== h.id));
    setBills(prev => ({ ...prev, [h.slot]: h.bill }));
    setSlot(h.slot);
    setPaid(String(r2(h.bill.payments.reduce((s, p) => s + Number(p.amount || 0), 0))));
    setLineKey(null);
    clearEntry();
    say(`${h.slot} recalled — ${h.bill.lines.length} line(s) back on the till`);
  };

  const discardHeld = (h: HeldBill) => {
    setHeld(prev => prev.filter(x => x.id !== h.id));
    say(`Held bill from ${h.at} discarded`);
  };

  const voidBill = () => {
    setBills(prev => ({ ...prev, [slot]: emptyBill() }));
    setPaid('');
    clearEntry();
    say(`${slot} cleared`);
  };

  // A reprint goes on the paper the bill was sold on, not whatever counter happens to be
  // selected now, so the slip's own counter decides the template.
  const printSlip = async (b: PosBill) => {
    const c = counters.find(x => x.id === b.counterId);
    await printReceiptWithLetterhead(b, tenantSlug, branchId, {
      template: c?.receiptTemplate, outletAddress: c?.address, cashier: b.cashier
    });
  };

  // What goes to the server must be what the cashier saw. Everything tendered that no named
  // mode answers for is cash — including the surplus the tender box carries over the bill —
  // because the slip's change line is the server's tender minus the bill, so a bill that
  // arrives tendered to the rupee prints no change at all.
  const settlePayments = () => {
    const listed = bill.payments.filter(p => Number(p.amount) > 0);
    const named = r2(listed.reduce((s, p) => s + Number(p.amount || 0), 0));
    const cashTop = r2(tender - named);
    if (!cashTop) return listed;
    const cash = listed.find(p => p.mode === 'Cash');
    if (cash) return listed.map(p => (p === cash ? { ...p, amount: r2(Number(p.amount) + cashTop) } : p));
    return [...listed, { mode: 'Cash', amount: cashTop }];
  };

  const settle = async () => {
    if (!bill.lines.length) return say('Add at least one product');
    if (!counterId) return say('Select a checkout counter');
    if (tender < grandTotal) return say(`Short by PKR ${money(shortfall)} — collect the full amount`);
    setBusy(true);
    try {
      const saved = await savePosBill(tenantSlug, branchId, {
        counterId,
        customerName: bill.customer,
        type: isReturn ? 'Return' : 'Sale',
        discount: billDisc,
        taxPercent,
        lines: bill.lines.map(l => ({ productId: l.product.id, productName: l.product.name, quantity: l.qty, price: l.price, discountPercent: l.discountPercent })),
        payments: settlePayments()
      });
      setBills(prev => ({ ...prev, [slot]: emptyBill() }));
      setPaid('');
      setLastBills(prev => ({ ...prev, [slot]: saved }));
      // The counter owns its printer: a till with auto print off is a shop that hands the
      // slip out on request, so printing here would fight the setup rather than follow it.
      // A dry printer is bad news for the note, not for the sale — the bill is already saved.
      let note = `${saved.number} ${isReturn ? 'return' : 'bill'} settled · PKR ${money(saved.grandTotal)}`
        + (saved.change ? ` · change ${money(saved.change)}` : '');
      if (counter?.autoPrint) {
        try { await printSlip(saved); note += ' · sent to the printer'; }
        catch { note += ' · printer busy, use PRINT SLIP to hand one over'; }
      } else {
        note += ' · use PRINT SLIP to hand one over';
      }
      // The sale just took goods off the shelf, so the grid the next customer is
      // chosen from has to catch up before the cashier taps it again.
      fetchProducts(search);
      scanRef.current?.focus();
      say(note);
    } catch (e) {
      say((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const addPaymentMode = (mode: string) => {
    const rest = r2(Math.max(0, grandTotal - tender));
    if (!rest) return say('The bill is fully tendered — remove a payment to change the split');
    const amount = rest;
    setPaid(String(r2(tender + amount)));
    patch(b => ({ ...b, payments: [...b.payments, { mode, amount }] }));
  };

  return (
    <div className="relative">
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 mb-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-[#2ec4b6]/10 text-[#1ba396] flex items-center justify-center shrink-0">
            <ScanLine className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <h1 className="page-title">POS Terminal</h1>
            <p className="text-[11px] text-gray-400 leading-snug">
              {counter ? counter.name : 'No counter selected'} · {clock.toLocaleDateString()} {clock.toTimeString().slice(0, 5)}
              {counter?.openShift ? ' · shift open' : ' · shift closed'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <select value={counterId} onChange={e => setCounterId(Number(e.target.value) || '')}
            className="input-xenith !w-auto min-w-40 whitespace-nowrap">
            <option value="">Select counter</option>
            {counters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button type="button" onClick={() => {
            const b = lastBills[slot];
            if (!b) return say(`Nothing settled on ${slot} yet`);
            printSlip(b).then(() => say(`${b.number} sent to ${counter?.printerName || 'the counter printer'}`))
              .catch(() => say(`Printer busy — ${b.number} was not sent`));
          }} disabled={!lastBills[slot]} className="btn-xenith-outline disabled:opacity-40"
            title="Print the last bill settled on this slot">
            <Printer className="w-3.5 h-3.5" /> PRINT SLIP
          </button>
          <button type="button" onClick={() => onNavigate?.('pos-daily-summary')} className="btn-xenith-outline">
            <Eye className="w-3.5 h-3.5" /> Daily Summary
          </button>
        </div>
      </div>

      {flash && (
        <div className="mb-3 px-3 py-2 rounded-lg bg-gray-800 text-white text-xs font-semibold animate-[popIn_.2s_ease-out_backwards]">{flash}</div>
      )}

      <div className="flex flex-wrap items-center gap-1 mb-3">
        {SLOTS.map(s => {
          const b = bills[s];
          const total = r2(b.lines.reduce((sum, l) => sum + lineNet(l), 0));
          const active = s === slot;
          return (
            <button key={s} type="button" onClick={() => { setSlot(s); setLineKey(null); clearEntry(); }}
              className={`relative px-3 py-1.5 rounded-t-lg text-xs font-bold transition-all duration-200 border-b-2
                ${active ? 'bg-white text-[#1e88e5] border-[#1e88e5] shadow-sm' : 'bg-gray-100 text-gray-500 border-transparent hover:bg-gray-200/70'}`}>
              <span className="flex items-center gap-1.5">
                {s === 'Sales Return' ? <RotateCcw className="w-3 h-3" /> : <ShoppingCart className="w-3 h-3" />}
                {s}
                {b.lines.length > 0 && <span className="text-[10px] font-black text-white bg-[#2ec4b6] rounded-full px-1.5">{b.lines.length}</span>}
              </span>
              {total > 0 && <span className="block text-[10px] font-normal text-gray-400 tabular-nums">PKR {money(total)}</span>}
            </button>
          );
        })}
      </div>

      {held.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 mb-3">
          <span className="text-[10px] font-bold uppercase tracking-wide text-gray-400 whitespace-nowrap">Held</span>
          {held.map(h => (
            <span key={h.id} className="flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-full border border-amber-200 bg-amber-50 text-[11px] font-bold text-amber-800">
              {/* Clicking puts the bill back exactly as it was parked, because the reason it
                  was held was that someone else needed this slot first. */}
              <button type="button" onClick={() => recallBill(h)} className="hover:underline" title="Recall this bill">
                {h.slot} · {h.bill.lines.length} line(s) · {h.at}
              </button>
              <button type="button" onClick={() => discardHeld(h)} className="text-amber-400 hover:text-red-500" title="Discard">
                <XCircle className="w-3.5 h-3.5" />
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4 items-start">
        {/* Product picker */}
        <div className="panel-xenith overflow-hidden">
          <div className="p-3 border-b border-gray-100 space-y-2">
            <div className="flex items-center gap-2">
              <Search size={14} className="text-gray-400 shrink-0" />
              <input ref={scanRef} value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Scan barcode or type product name / SKU…"
                onKeyDown={e => { if (e.key === 'Enter') ringUpScan(); }}
                className="input-xenith" />
              {search && <button type="button" onClick={() => setSearch('')} className="text-gray-400 hover:text-gray-600"><XCircle className="w-4 h-4" /></button>}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {categories.map(c => (
                <button key={c} type="button" onClick={() => setCategory(c)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-colors ${
                    category === c ? 'bg-[#1e88e5] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3 grid gap-2 max-h-[62vh] overflow-y-auto app-scroll" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))' }}>
            {visible.map(p => (
              <button key={p.id} type="button" onClick={() => addProduct(p)}
                className={`group text-left rounded-lg border p-2.5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md
                  ${isReturn ? 'border-red-100 bg-red-50/30 hover:border-red-300' : 'border-gray-200 bg-white hover:border-[#2ec4b6]'}`}>
                <div className="text-xs font-bold text-gray-800 leading-snug line-clamp-2 min-h-8">{p.name}</div>
                <div className="text-[10px] text-gray-400 font-mono truncate">{p.barcode}</div>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2 mt-1">
                  <span className={`text-sm font-black tabular-nums ${isReturn ? 'text-red-600' : 'text-[#1ba396]'}`}>PKR {money(p.price)}</span>
                  <span className={`text-[10px] font-bold tabular-nums ${p.trackStock && p.stockQty <= 0 ? 'text-red-500' : 'text-gray-400'}`}>
                    {p.trackStock ? `${p.stockQty} ${p.unit}` : `Service · ${p.unit}`}
                  </span>
                </div>
                <div className={`mt-1.5 h-0.5 rounded-full origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-200 ${isReturn ? 'bg-red-400' : 'bg-[#2ec4b6]'}`} />
              </button>
            ))}
            {!visible.length && (
              <div className="col-span-full py-10 text-center text-gray-400 text-xs">No products match “{search || category}”</div>
            )}
          </div>
        </div>

        {/* Cart + payment */}
        <div className="space-y-3">
          <div className="panel-xenith overflow-hidden">
            <div className="px-3 py-2 border-b border-gray-100 bg-gray-50/60 flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
              <span className="section-title">{slot} · Cart</span>
              {isReturn && <span className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-100 rounded-full px-1.5 whitespace-nowrap">RETURN BILL</span>}
            </div>

            <div className="px-3 py-2 border-b border-gray-100 flex flex-wrap items-center gap-2">
              <User className="w-3.5 h-3.5 text-gray-400 shrink-0" />
              {/* The counter names a customer while a queue forms, so this has to search:
                  a plain list is a scroll to the right name. */}
              <div className="flex-1 min-w-24">
                <SearchSelect
                  options={[{ id: 0, label: 'Walk-in Customer' }, ...customers.map(c => ({ id: c.id, label: c.name }))]}
                  value={customers.find(c => c.name === bill.customer)?.id ?? (bill.customer === 'Walk-in Customer' ? 0 : null)}
                  onChange={id => patch(b => ({
                    ...b,
                    customer: id ? customers.find(c => c.id === id)?.name ?? b.customer : 'Walk-in Customer'
                  }))}
                  placeholder="Walk-in Customer"
                />
              </div>
            </div>

            <div className="max-h-56 overflow-y-auto app-scroll">
              {bill.lines.length ? bill.lines.map(l => (
                <div key={l.key} onClick={() => { setLineKey(l.key); setTarget('qty'); }}
                  className={`px-3 py-2 border-b border-gray-50 cursor-pointer transition-colors ${lineKey === l.key ? 'bg-blue-50/70' : 'hover:bg-gray-50'}`}>
                  <div className="flex flex-wrap items-start gap-x-2 gap-y-0.5">
                    <span className="min-w-0 flex-1 basis-28">
                      <span className="block text-xs font-bold text-gray-800 leading-snug line-clamp-2">{l.product.name}</span>
                      <span className="block text-[10px] text-gray-400 truncate">{l.product.sku} · {l.product.unit}</span>
                    </span>
                    <span className="text-xs font-black tabular-nums text-gray-800 ml-auto shrink-0 whitespace-nowrap">
                      {money(lineNet(l))}
                    </span>
                    <button type="button" onClick={e => { e.stopPropagation(); removeLine(l.key); }}
                      className="text-gray-300 hover:text-red-500 shrink-0"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                    <button type="button" onClick={e => { e.stopPropagation(); updateLine(l.key, { qty: clampQty(l, l.qty - 1) }); }}
                      className="w-6 h-6 rounded border border-gray-200 flex items-center justify-center text-gray-500 hover:bg-gray-50"><Minus className="w-3 h-3" /></button>
                    <input type="number" value={l.qty || ''} min={0} onClick={e => e.stopPropagation()}
                      onChange={e => updateLine(l.key, { qty: Number(e.target.value) || 0 })}
                      onBlur={e => updateLine(l.key, { qty: clampQty(l, Number(e.target.value) || 0) })}
                      className="input-xenith !w-14 text-center !py-0.5 tabular-nums" />
                    <button type="button" onClick={e => { e.stopPropagation(); updateLine(l.key, { qty: clampQty(l, l.qty + 1) }); }}
                      className="w-6 h-6 rounded border border-gray-200 flex items-center justify-center text-gray-500 hover:bg-gray-50"><Plus className="w-3 h-3" /></button>
                    <span className="text-[10px] text-gray-400 whitespace-nowrap">@ PKR {money(l.price)}</span>
                    <input type="number" value={l.discountPercent || ''} min={0} max={100} placeholder="D%" onClick={e => e.stopPropagation()}
                      onChange={e => updateLine(l.key, { discountPercent: Math.max(0, Math.min(100, Number(e.target.value) || 0)) })}
                      className="input-xenith !w-14 text-center !py-0.5 tabular-nums" title="Line discount %" />
                  </div>
                </div>
              )) : (
                <div className="px-3 py-8 text-center">
                  <SquareUser className="w-7 h-7 text-gray-200 mx-auto mb-2" />
                  <p className="text-xs text-gray-400">Tap a product to start {isReturn ? 'a return' : 'billing'}</p>
                </div>
              )}
            </div>

            <div className="px-3 py-2 border-t border-gray-100 space-y-1 bg-gray-50/40">
              {([
                ['Subtotal', subtotal, false],
                ['Line Discount', -lineDisc, false],
                ['Bill Discount', -billDisc, false],
                [`Tax (${taxPercent.toFixed(1)}%)`, tax, false],
                ['Grand Total', grandTotal, true]
              ] as [string, number, boolean][]).map(([label, value, big]) => (
                <div key={label} className={`flex flex-wrap items-baseline justify-between gap-x-2 ${big ? 'pt-1.5 mt-1 border-t border-gray-200' : ''}`}>
                  <span className={`text-[11px] ${big ? 'font-black text-gray-700' : 'text-gray-500'}`}>{label}</span>
                  <span className={`ml-auto shrink-0 whitespace-nowrap tabular-nums text-right ${
                    big ? 'text-base font-black text-[#1ba396]' : value < 0 ? 'text-red-500 text-xs' : 'text-xs text-gray-700'}`}>
                    {value < 0 ? `-${money(-value)}` : money(value)}
                  </span>
                </div>
              ))}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5">
                <label className="text-[11px] text-gray-500 whitespace-nowrap">Bill discount</label>
                {/* This box holds rupees, so it is capped by the bill and by the counter's
                    percent limit — never by 100, which made a discount over a hundred rupees
                    impossible to type. */}
                <input type="number" value={bill.discount || ''} placeholder="0" min={0}
                  onChange={e => patch(b => ({ ...b, discount: Math.max(0, Number(e.target.value) || 0) }))}
                  onBlur={() => {
                    const v = Number(bill.discount) || 0;
                    const byBill = Math.min(v, afterLineDisc);
                    if (byBill !== v) {
                      patch(b => ({ ...b, discount: r2(byBill) }));
                      say(`Discount cannot exceed the bill of PKR ${money(afterLineDisc)}`);
                      return;
                    }
                    if (maxDiscount && afterLineDisc) {
                      const capped = giveAway(v);
                      if (capped !== v) patch(b => ({ ...b, discount: capped }));
                    }
                  }}
                  className="input-xenith !w-20 text-right tabular-nums" />
              </div>
            </div>
          </div>

          {/* Payment */}
          <div className="panel-xenith overflow-hidden">
            <div className="px-3 py-2 border-b border-gray-100 bg-gray-50/60">
              <h2 className="section-title">Payment</h2>
            </div>
            <div className="p-3 space-y-2">
              <div className="grid gap-1.5" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(96px, 1fr))' }}>
                {MODES.map(m => (
                  <button key={m.mode} type="button" onClick={() => addPaymentMode(m.mode)} disabled={!grandTotal}
                    className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-md text-[11px] font-bold transition-all duration-200 hover:brightness-110 disabled:opacity-40 ${m.tone}`}>
                    {m.icon}{m.mode}
                  </button>
                ))}
              </div>
              {bill.payments.length > 0 && (
                <ul className="space-y-1">
                  {bill.payments.map((p, i) => (
                    <li key={i} className="flex flex-wrap items-center gap-x-2 text-[11px] text-gray-600 bg-gray-50 border border-gray-100 rounded px-2 py-1">
                      <span className="font-semibold">{p.mode}</span>
                      <span className="ml-auto tabular-nums whitespace-nowrap">PKR {money(p.amount)}</span>
                      <button type="button" onClick={() => {
                        patch(b => ({ ...b, payments: b.payments.filter((_, j) => j !== i) }));
                        setPaid(String(r2(Math.max(0, tender - p.amount))));
                      }} className="text-gray-300 hover:text-red-500"><XCircle className="w-3.5 h-3.5" /></button>
                    </li>
                  ))}
                </ul>
              )}
              <div className="flex flex-wrap items-end justify-between gap-x-2 gap-y-1">
                <span className="text-[11px] text-gray-500">Tendered</span>
                <div className="flex items-center gap-1.5 ml-auto">
                  <button type="button" onClick={() => setTarget('tender')}
                    className={`px-2 py-1 rounded text-[10px] font-bold transition-colors ${target === 'tender' ? 'bg-[#1e88e5] text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                    KEYPAD
                  </button>
                  <input type="number" value={paid} placeholder="0.00" min={0}
                    onChange={e => setPaid(e.target.value)}
                    onBlur={() => setPaid(String(r2(Math.max(Number(paid) || 0, committed))))}
                    className="input-xenith !w-24 text-right tabular-nums" />
                </div>
              </div>
              <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                <span className="text-[11px] whitespace-nowrap text-gray-500">{shortfall ? 'Balance Due' : 'Change Due'}</span>
                <span className={`ml-auto text-sm font-black tabular-nums whitespace-nowrap ${shortfall ? 'text-red-600' : 'text-[#25a195]'}`}>
                  PKR {money(shortfall || change)}
                </span>
              </div>
            </div>

            {/* Keypad */}
            <div className="px-3 pb-3">
              <div className="flex items-center gap-1.5 mb-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wide text-gray-400 whitespace-nowrap">
                  {target === 'tender' ? 'Tender' : lineKey !== null ? 'Line qty' : 'Bill discount'}
                </span>
                <span className="ml-auto text-right text-sm font-black tabular-nums text-gray-800 truncate">{entry || '0'}</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {KEYS.map(k => (
                  <button key={k} type="button" onClick={() => press(k)}
                    className="h-8 rounded-md bg-gray-100 hover:bg-gray-200 active:scale-95 text-xs font-bold text-gray-700 transition-all duration-150">{k}</button>
                ))}
                <button type="button" onClick={() => setEntry(e => e.slice(0, -1))}
                  className="h-8 rounded-md bg-gray-100 hover:bg-gray-200 text-xs font-bold text-gray-500 transition-all">⌫</button>
                <button type="button" onClick={clearEntry}
                  className="h-8 rounded-md bg-red-50 hover:bg-red-100 text-xs font-black text-red-500 transition-all">C</button>
                <button type="button" onClick={() => setTarget(t => (t === 'tender' ? 'qty' : 'tender'))}
                  className="h-8 rounded-md bg-blue-50 hover:bg-blue-100 text-[10px] font-black text-[#1e88e5] transition-all">⇄</button>
                <button type="button" onClick={applyEntry}
                  className="h-8 rounded-md bg-[#2ec4b6] hover:bg-[#25a195] text-white text-xs font-black transition-all">=</button>
              </div>
            </div>

            <div className="p-3 border-t border-gray-100 grid grid-cols-2 gap-1.5">
              <button type="button" onClick={holdBill} className="btn-xenith-outline justify-center"><PauseCircle className="w-3.5 h-3.5" /> Hold</button>
              <button type="button" onClick={voidBill} className="btn-xenith-warning justify-center"><XCircle className="w-3.5 h-3.5" /> Clear</button>
              <button type="button" onClick={settle} disabled={busy || !bill.lines.length}
                className="btn-xenith-success justify-center col-span-2 py-2 disabled:opacity-40">
                <CheckCircle2 className="w-4 h-4" /> {busy ? 'Saving…' : `${counter?.autoPrint ? 'SETTLE & PRINT' : 'SETTLE'} · PKR ${money(grandTotal)}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PosTerminal;
