import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, Globe, Pencil, Trash2, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { MasterGroup } from '../../types';
import {
  deleteMasterGroup, getMasterGroups, markMasterGroupDefault, saveMasterGroup, updateMasterGroup
} from '../../services/groups.service';
import {
  Check as TickBox, DeleteConfirm, ExportPair, Field, IconAction, ListToolbar, RegisterStat, SearchBox,
  SortHeader, SortState, StatStrip, StatusPills, TableEmpty, Text
} from '../Masters/masterUi';
import { ExportColumn } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

// The captions the original book uses for this register. One company calls these Regions,
// another would call the same rows Channels.
const CAPTION = 'Regions';
const SINGULAR = 'Region';

type Draft = { id?: number; name: string; code: string; isDefault: boolean; isActive: boolean };

const blankRegion = (): Draft => ({ name: '', code: '', isDefault: false, isActive: true });

export const MasterGroupList: React.FC = () => {
  const { tenantSlug } = useTenant();
  const { can } = useAuth();
  const [groups, setGroups] = useState<MasterGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [search, setSearch] = useState('');
  // SearchBox keeps its own text; remounting it is how the clear-all empties the box too.
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [state, setState] = useState('');
  const [sort, setSort] = useState<SortState | null>({ key: 'code', dir: 'asc' });
  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const load = useCallback(() => {
    setLoading(true); setLoadError('');
    getMasterGroups(tenantSlug)
      .then(list => setGroups(Array.isArray(list) ? list : []))
      .catch(e => setLoadError((e as Error).message))
      .finally(() => setLoading(false));
  }, [tenantSlug]);

  useEffect(() => { load(); }, [load]);
  useScreenReload(load);

  const editable = can('master-groups:edit');

  // The state pill counts are written over the search result without the pill's own filter,
  // so ticking one never changes the number it is claiming.
  const searched = useMemo(() => {
    const term = search.trim().toLowerCase();
    return groups.filter(g => !term || `${g.name} ${g.code || ''}`.toLowerCase().includes(term));
  }, [groups, search]);

  const visible = useMemo(() => {
    const list = searched.filter(g => !state
      || (state === 'Active' ? g.isActive && !g.isDefault : state === 'Default' ? g.isDefault : !g.isActive));
    if (!sort) return list;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...list].sort((a: any, b: any) => {
      const av = a[sort.key], bv = b[sort.key];
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }, [searched, state, sort]);

  const onSort = (k: string) => setSort(s => (s?.key === k ? { key: k, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: k, dir: 'asc' }));

  const stats: RegisterStat[] = [
    {
      label: CAPTION,
      value: (search || state) ? `${visible.length} of ${groups.length}` : String(groups.length),
      title: 'Territories the search and the state pill leave on screen'
    },
    {
      label: 'Open', value: groups.filter(g => g.isActive).length, tone: 'ok',
      title: `${CAPTION} a document can still be filed under. A closed one stays on the papers already stamped with it.`
    },
    ...(groups.some(g => !g.isActive) ? [{
      label: 'Closed', value: groups.filter(g => !g.isActive).length, tone: 'warn' as const,
      title: `Closed ${CAPTION.toLowerCase()} cannot be picked on a new document`
    }] : [])
  ];

  const statusCounts = [
    { value: '', label: 'All', count: searched.length },
    { value: 'Active', label: 'Open', count: searched.filter(g => g.isActive && !g.isDefault).length },
    { value: 'Default', label: 'Default', count: searched.filter(g => g.isDefault).length },
    { value: 'Closed', label: 'Closed', count: searched.filter(g => !g.isActive).length }
  ];

  const activeFilters = [
    search && `search “${search}”`,
    state && `state ${state === 'Active' ? 'open' : state.toLowerCase()}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setState('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const columns: ExportColumn<MasterGroup>[] = [
    { label: 'Code', value: g => g.code || '-' },
    { label: `${SINGULAR} Name`, value: g => g.name },
    { label: 'Default', value: g => g.isDefault ? 'Yes' : 'No' },
    { label: 'Status', value: g => g.isActive ? 'Open' : 'Closed' }
  ];

  const submit = async () => {
    if (!draft) return;
    setSaving(true); setError(''); setNotice('');
    try {
      const body = {
        name: draft.name.trim(), code: draft.code.trim().toUpperCase(),
        isDefault: draft.isDefault, isActive: draft.isActive
      };
      if (draft.id) {
        await updateMasterGroup(tenantSlug, draft.id, body);
        setNotice(`${body.name} has been updated.`);
      } else {
        const created = await saveMasterGroup(tenantSlug, body);
        setNotice(`${created.name} has been added to the ${CAPTION.toLowerCase()} register.`);
      }
      setDraft(null);
      load();
    } catch (e) { setError((e as Error).message); }
    setSaving(false);
  };

  const makeDefault = async (g: MasterGroup) => {
    setError(''); setNotice('');
    try {
      await markMasterGroupDefault(tenantSlug, g.id);
      setNotice(`${g.name} is now the default ${SINGULAR.toLowerCase()}.`);
      load();
    } catch (e) { setError((e as Error).message); }
  };

  const remove = async (g: MasterGroup) => {
    setError(''); setNotice('');
    try {
      await deleteMasterGroup(tenantSlug, g.id);
      setNotice(`${g.name} has been deleted.`);
      load();
    } catch (e) { setError((e as Error).message); }
    setConfirmId(null);
  };

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Master Groups ({CAPTION})</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              The high-level territories the business is cut into. One of them is the default a new
              record opens on, and a closed one stays on the papers already filed under it while
              dropping out of every picker.
            </p>
            <div className="mt-2"><StatStrip stats={stats} /></div>
          </div>
          {can('master-groups:add') && (
            <ListToolbar addLabel={`ADD ${SINGULAR.toUpperCase()}`}
              onAdd={() => { setDraft(blankRegion()); setError(''); setNotice(''); }} />
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} placeholder={`Search by ${SINGULAR.toLowerCase()} name or code`} onSearch={setSearch} />
          <StatusPills value={state} onChange={setState} counts={statusCounts} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <ExportPair title={`Master Groups (${CAPTION})`}
              subtitle={activeFilters.length ? activeFilters.join(' · ') : undefined}
              filename="master-groups" columns={columns} rows={visible} />
          </span>
        </div>
      </div>

      {(error || loadError || notice) && (
        <div className={`text-xs font-semibold rounded px-3 py-2 flex items-center justify-between ${
          error || loadError ? 'text-red-600 bg-red-50 border border-red-100' : 'text-green-700 bg-green-50 border border-green-100'}`}>
          <span>{error || loadError || notice}</span>
          <button type="button" onClick={() => { setError(''); setNotice(''); }}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {draft && (
        <div className="nb-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="card-title">{draft.id ? `Edit ${SINGULAR} - [${draft.name || 'untitled'}]` : `Create ${SINGULAR}`}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <Field label={`${SINGULAR} Name`} required>
              <Text value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })}
                placeholder={`e.g. Central ${CAPTION === 'Regions' ? 'Punjab' : 'Channel'}`} />
            </Field>
            <Field label="Code" hint="short tag, e.g. REG-CENTRAL">
              <Text value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value.toUpperCase() })} />
            </Field>
            <div className="flex items-end gap-4 pb-1.5">
              <TickBox checked={draft.isActive} onChange={v => setDraft({ ...draft, isActive: v })} label="Open for new records" />
              {/* One row is default at a time, so the box can be ticked onto this one but never
                  unticked from it — unticking would leave the register without a default. */}
              <TickBox checked={draft.isDefault} disabled={draft.isDefault}
                onChange={v => v && setDraft({ ...draft, isDefault: true })} label={`Make default ${SINGULAR.toLowerCase()}`} />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 mt-4">
            <button type="button" onClick={() => setDraft(null)} className="btn-xenith-warning">
              <X className="w-3.5 h-3.5" /> Close
            </button>
            <button type="button" onClick={submit} disabled={saving || !draft.name.trim()}
              className="btn-xenith-success disabled:opacity-50">
              {saving ? 'Saving...' : 'SAVE'}
            </button>
          </div>
        </div>
      )}

      <div className="nb-card p-0 overflow-hidden">
        <div className="overflow-auto max-h-[64vh] app-scroll">
          <table className="xenith-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <SortHeader label="Code" sortKey="code" sort={sort} onSort={onSort} />
                <SortHeader label={`${SINGULAR} Name`} sortKey="name" sort={sort} onSort={onSort} />
                <SortHeader label="Status" sortKey="isActive" sort={sort} onSort={onSort} />
                <th className="w-32 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={4}>
                    <div className="h-4 rounded bg-gray-100 animate-pulse" style={{ width: `${100 - i * 8}%` }} />
                  </td>
                </tr>
              ))}
              {!loading && !visible.length && (
                <TableEmpty colSpan={4} noun={`${CAPTION.toLowerCase()}`} filters={activeFilters} cleared={clearAll}
                  addLabel={groups.length || !can('master-groups:add') ? undefined : `ADD ${SINGULAR.toUpperCase()}`}
                  onAdd={() => { setDraft(blankRegion()); setError(''); setNotice(''); }} />
              )}
              {!loading && visible.map(g => (
                <tr key={g.id}>
                  <td className="font-mono text-[11px] text-gray-500">{g.code || <span className="text-gray-300">no code</span>}</td>
                  <td>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                      <span className="flex items-center gap-2 font-bold text-gray-800">
                        <Globe className="w-4 h-4 text-blue-500" />
                        <span>{g.name}</span>
                      </span>
                      {g.isDefault && (
                        <span className="text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-full px-1.5">
                          Default {SINGULAR}
                        </span>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${g.isActive ? 'bg-teal-50 text-[#25a195]' : 'bg-gray-100 text-gray-500'}`}>
                      {g.isActive ? 'Open' : 'Closed'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 justify-end">
                      {!g.isDefault && editable && (
                        <IconAction title={`Make ${g.name} the default ${SINGULAR.toLowerCase()}`} tone="success"
                          onClick={() => makeDefault(g)}><Check className="w-4 h-4" /></IconAction>
                      )}
                      {editable && (
                        <IconAction title={`Edit ${g.name}`} tone="primary"
                          onClick={() => {
                            setDraft({ id: g.id, name: g.name, code: g.code || '', isDefault: g.isDefault, isActive: g.isActive });
                            setError(''); setNotice('');
                          }}><Pencil className="w-4 h-4" /></IconAction>
                      )}
                      {can('master-groups:delete') && (g.isDefault ? (
                        <IconAction title={`The default ${SINGULAR.toLowerCase()} cannot be deleted — make another one default first`} disabled>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ) : confirmId === g.id ? (
                        <DeleteConfirm onConfirm={() => remove(g)} onCancel={() => setConfirmId(null)}
                          keepLabel={`Keep ${g.name} on the register`} />
                      ) : (
                        <IconAction title={`Delete ${SINGULAR.toLowerCase()}`} tone="danger" onClick={() => setConfirmId(g.id)}>
                          <Trash2 className="w-4 h-4" />
                        </IconAction>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* Nothing here adds up to a figure — a register of territories carries no money or
                quantity — so neither the table nor the export closes with a totals line. */}
          </table>
        </div>
      </div>
    </div>
  );
};

export default MasterGroupList;
