import React from 'react';
import { FileQuestion } from 'lucide-react';

/** A retired or mistyped address used to draw an empty page; this says so in words instead. */
export const ScreenNotFound: React.FC<{ address: string; onHome: () => void }> = ({ address, onHome }) => (
  <div className="nb-card">
    <div className="nb-card-body">
      <div className="max-w-md mx-auto text-center py-12">
        <div className="w-14 h-14 mx-auto rounded-full bg-gray-100 text-gray-400 flex items-center justify-center mb-3">
          <FileQuestion className="w-7 h-7" />
        </div>
        <h2 className="card-title">This screen does not exist</h2>
        <p className="text-xs text-gray-500 mt-1">
          <span className="font-mono text-gray-600">{address}</span> is not part of this build — the screen was
          renamed or removed. Open what you need from the sidebar, or start again from Home.
        </p>
        <button type="button" onClick={onHome} className="btn-xenith-primary mt-4">Back to Home</button>
      </div>
    </div>
  </div>
);

export default ScreenNotFound;
