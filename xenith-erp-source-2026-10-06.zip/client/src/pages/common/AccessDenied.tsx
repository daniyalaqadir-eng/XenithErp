import React from 'react';
import { ShieldX } from 'lucide-react';

export const AccessDenied: React.FC<{ screen: string; onHome: () => void }> = ({ screen, onHome }) => (
  <div className="nb-card">
    <div className="nb-card-body">
      <div className="max-w-md mx-auto text-center py-12">
        <div className="w-14 h-14 mx-auto rounded-full bg-red-50 text-red-500 flex items-center justify-center mb-3">
          <ShieldX className="w-7 h-7" />
        </div>
        <h2 className="card-title">You do not have access to this area</h2>
        <p className="text-xs text-gray-500 mt-1">
          Your role has no <span className="font-semibold">{screen}</span> view permission. Ask an administrator
          to tick it from Setup &rarr; User Roles, then sign in again.
        </p>
        <button type="button" onClick={onHome} className="btn-xenith-primary mt-4">Back to Home</button>
      </div>
    </div>
  </div>
);

export default AccessDenied;
