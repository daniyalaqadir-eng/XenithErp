import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ChevronLeft, ChevronRight, MessageCircle, FileCheck, Sparkles
} from 'lucide-react';

interface Props {
  onNavigate: (tab: string) => void;
}

const AUTOPLAY_MS = 6000;

interface Slide {
  key: string;
  eyebrow: string;
  title: string[];
  highlight?: string;
  body: string;
  cta: string;
  ctaAction: () => void;
  bg: string;
  accent: string;
  art: 'chat' | 'till' | 'landed' | 'paper';
}

// Every line here names something the software actually does, and every button lands on the
// screen it describes — a banner that opens a different screen than it promises is a dead
// control with a picture over it.
const Home: React.FC<Props> = ({ onNavigate }) => {
  const slides: Slide[] = [
    {
      key: 'whatsapp',
      eyebrow: 'XENITH BROADCAST',
      title: ['Send the Reminder', 'on WhatsApp'],
      body: 'Open the customer due list, pick a bill and write the message. It goes out through your own WhatsApp number, and the outbox keeps the ones that failed.',
      cta: 'Open Due List',
      ctaAction: () => onNavigate('report:customer-due-list-report'),
      bg: 'from-[#08301f] via-[#0c4a30] to-[#08301f]',
      accent: '#25d366',
      art: 'chat'
    },
    {
      key: 'pos',
      eyebrow: 'SHOP FLOOR',
      title: ['Bill the Counter', 'in Seconds'],
      body: "The POS terminal rings up a sale, takes the cash and prints the receipt on that counter's own printer. Counters, printers and receipt designs are set up beside it.",
      cta: 'Open POS Terminal',
      ctaAction: () => onNavigate('pos-terminal'),
      bg: 'from-[#0a3a86] via-[#0f4f96] to-[#2b7cc4]',
      accent: '#ffc94d',
      art: 'till'
    },
    {
      key: 'import',
      eyebrow: 'TRADE & IMPORT',
      title: ['Landed Cost', 'on One Paper'],
      body: 'An import invoice carries the vendor bill and the clearing expenses added to it, so the goods reach the shelf at the cost they really took.',
      cta: 'Open Import Invoices',
      ctaAction: () => onNavigate('doc:import-invoice'),
      bg: 'from-[#16223a] via-[#2c3d55] to-[#17615e]',
      accent: '#5bc0be',
      art: 'landed'
    },
    {
      key: 'vouchers',
      eyebrow: 'CASH & BANK',
      title: ['Every Rupee In', 'and Out'],
      highlight: 'on Paper',
      body: 'Cash and Bank vouchers for money going out, cash and receipt vouchers for money coming in — each one posts straight into the ledger it names.',
      cta: 'Open Cash Payment Vouchers',
      ctaAction: () => onNavigate('doc:cash-voucher'),
      bg: 'from-[#081c2e] via-[#10547c] to-[#28779f]',
      accent: '#ffd54f',
      art: 'paper'
    }
  ];

  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const timer = useRef<number | null>(null);

  const go = useCallback((n: number) => {
    setIndex(prev => (n + slides.length) % slides.length);
    setProgress(0);
  }, [slides.length]);

  useEffect(() => {
    if (paused) return;
    const started = Date.now();
    timer.current = window.setInterval(() => {
      const pct = Math.min(100, ((Date.now() - started) / AUTOPLAY_MS) * 100);
      setProgress(pct);
      if (pct >= 100) { setIndex(i => (i + 1) % slides.length); setProgress(0); }
    }, 60);
    return () => { if (timer.current) window.clearInterval(timer.current); };
  }, [paused, index, slides.length]);

  return (
    <div className="space-y-4">
      <div
        className="relative rounded-2xl overflow-hidden shadow-lg ring-1 ring-black/5"
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        <div
          className="flex transition-transform duration-700 ease-[cubic-bezier(.22,.61,.36,1)]"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {slides.map(s => <Panel key={s.key} slide={s} onNavigate={s.ctaAction} />)}
        </div>

        <button
          onClick={() => go(index - 1)}
          aria-label="Previous slide"
          className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/15 hover:bg-white/35 text-white backdrop-blur flex items-center justify-center transition-all duration-300 hover:scale-110"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={() => go(index + 1)}
          aria-label="Next slide"
          className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/15 hover:bg-white/35 text-white backdrop-blur flex items-center justify-center transition-all duration-300 hover:scale-110"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center gap-2">
          {slides.map((s, i) => (
            <button
              key={s.key}
              onClick={() => go(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`h-2 rounded-full transition-all duration-500 ${
                i === index ? 'w-8 bg-white' : 'w-2 bg-white/45 hover:bg-white/70'
              }`}
            />
          ))}
        </div>

        <div className="absolute bottom-0 left-0 h-0.5 bg-white/70 transition-[width] duration-100 ease-linear"
          style={{ width: `${paused ? 0 : progress}%` }} />
      </div>

    </div>
  );
};

const Panel: React.FC<{ slide: Slide; onNavigate: () => void }> = ({ slide, onNavigate }) => (
  <section className={`relative w-full shrink-0 bg-gradient-to-br ${slide.bg} text-white`}>
    <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full opacity-25 blur-3xl" style={{ background: slide.accent }} />
    <div className="absolute -bottom-28 left-1/3 w-72 h-72 rounded-full bg-white/10 blur-3xl" />
    <div className="relative grid lg:grid-cols-2 gap-6 items-center px-8 sm:px-12 py-14 min-h-[420px]">
      <div className="space-y-4">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-bold tracking-[.18em] bg-white/15 border border-white/25 rounded-full px-3 py-1 backdrop-blur">
          <Sparkles className="w-3 h-3" /> {slide.eyebrow}
        </span>
        <h1 className="text-3xl sm:text-5xl font-black leading-[1.05] tracking-tight">
          {slide.highlight && <span className="block text-white/90">{slide.highlight}</span>}
          {slide.title.map(t => <span key={t} className="block">{t}</span>)}
        </h1>
        <p className="text-sm text-white/90 max-w-md leading-relaxed">{slide.body}</p>
        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button onClick={onNavigate}
            className="px-5 py-2.5 rounded-lg bg-white text-gray-900 text-xs font-bold shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300">
            {slide.cta}
          </button>
          <span className="text-[11px] text-white/80">Opens the {slide.cta.replace(/^Open /, '').toLowerCase()} screen.</span>
        </div>
      </div>
      <Art kind={slide.art} accent={slide.accent} />
    </div>
  </section>
);

// The art is a shape, not a record: no document numbers and no amounts, because a made-up
// SI-000042 on the landing screen reads as a bill that exists.
const Art: React.FC<{ kind: Slide['art']; accent: string }> = ({ kind, accent }) => {
  if (kind === 'chat') {
    return (
      <div className="hidden lg:flex justify-center">
        <div className="relative w-72">
          <Bubble className="w-44 -rotate-3" tone="bg-white/95 text-gray-800">Invoice reminder sent</Bubble>
          <Bubble delay="120ms" className="w-52 ml-20 rotate-2" tone="bg-white/15 text-white backdrop-blur">Payment still open this week</Bubble>
          <Bubble delay="240ms" className="w-40 ml-4 -rotate-1" tone="bg-white/95 text-gray-800">Thank you — payment received</Bubble>
          <div className="absolute -right-4 -top-6 w-16 h-16 rounded-2xl flex items-center justify-center shadow-2xl" style={{ background: accent }}>
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
        </div>
      </div>
    );
  }
  if (kind === 'till') {
    return (
      <div className="hidden lg:flex justify-center gap-4 items-end">
        <TillMock scale="scale-90 opacity-80" />
        <TillMock />
      </div>
    );
  }
  if (kind === 'landed') {
    return (
      <div className="hidden lg:flex flex-col justify-center gap-3 w-72">
        {[['Vendor bill (goods)', 100], ['Clearing & freight', 62], ['Duties and handling', 40]].map(([label, w], i) => (
          <div key={String(label)} className="rounded-xl bg-white/10 border border-white/20 p-3 backdrop-blur">
            <div className="flex justify-between text-[11px] text-white/90">
              <span>{label}</span>
              {i === 0 && <span className="font-bold text-white">added to</span>}
            </div>
            <div className="mt-2 h-1.5 rounded-full bg-white/20 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${w}%`, background: accent }} />
            </div>
          </div>
        ))}
        <div className="flex items-center justify-between text-[11px] font-black text-white pt-1">
          <span className="uppercase tracking-[.14em]">Landed cost</span>
          <span className="h-2 w-16 rounded-full bg-white/35" />
        </div>
      </div>
    );
  }
  return (
    <div className="hidden lg:flex justify-center">
      <div className="relative w-64 rounded-xl bg-white text-gray-800 shadow-2xl p-4 rotate-2">
        <div className="flex items-center justify-between border-b border-gray-100 pb-2 mb-3">
          <span className="text-xs font-black tracking-wide">XENITH ERP</span>
          <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">APPROVED</span>
        </div>
        {[0, 1, 2].map(i => (
          <div key={i} className="flex justify-between items-center py-1.5 border-b border-dashed border-gray-100 text-[10px]">
            <span className="h-2 rounded bg-gray-200" style={{ width: `${70 - i * 12}px` }} />
            <span className="h-2 w-10 rounded bg-gray-200" />
          </div>
        ))}
        <div className="flex justify-between items-center pt-3 text-xs font-black">
          <span>TOTAL</span><span className="h-2.5 w-14 rounded bg-blue-200" />
        </div>
        <span className="absolute -bottom-3 -right-3 rotate-[-8deg] text-[10px] font-black text-emerald-600 border-2 border-emerald-500 rounded px-2 py-0.5 bg-white">PAID</span>
        <span className="absolute -top-3 -left-3 w-7 h-7 rounded-full bg-[#1e88e5] grid place-items-center shadow-lg">
          <FileCheck className="w-4 h-4" />
        </span>
      </div>
    </div>
  );
};

const Bubble: React.FC<{ className?: string; tone?: string; delay?: string; children: React.ReactNode }> = ({
  className = '', tone = 'bg-white/95 text-gray-800', delay = '0ms', children
}) => (
  <div className={`${className} ${tone} rounded-2xl rounded-bl-sm px-3.5 py-2.5 text-[11px] font-semibold shadow-xl mb-3 animate-[bubbleIn_.6s_ease-out_backwards]`}
    style={{ animationDelay: delay }}>
    {children}
  </div>
);

// The counter's own till: what a cashier rings, not a shopping app a customer opens.
const TillMock: React.FC<{ scale?: string }> = ({ scale = '' }) => (
  <div className={`w-40 rounded-[1.75rem] border-[6px] border-gray-900/80 bg-white shadow-2xl ${scale} transition-transform duration-500 hover:-translate-y-2`}>
    <div className="h-6 flex items-center justify-center"><span className="w-14 h-1.5 rounded-full bg-gray-900/80" /></div>
    <div className="px-2.5 pb-3 space-y-2">
      <div className="h-7 rounded-lg bg-gray-100 flex items-center px-2 text-[9px] text-gray-400">Scan or search a product…</div>
      {['Beverages', 'Biscuits', 'Rice', 'Oil & Ghee'].map(c => (
        <div key={c} className="flex items-center justify-between rounded-lg border border-gray-100 px-2 py-1.5">
          <span className="text-[9px] font-semibold text-gray-700">{c}</span>
          <span className="text-[9px] font-bold text-blue-600">Add</span>
        </div>
      ))}
      <div className="flex items-center justify-between rounded-lg bg-emerald-500 text-emerald-950 px-2 py-1.5">
        <span className="text-[9px] font-bold">Cart</span>
        <span className="h-2 w-10 rounded-full bg-emerald-900/30" />
      </div>
    </div>
  </div>
);

export const HomePage = Home;
export default Home;
