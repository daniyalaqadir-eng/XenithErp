import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Ruler, Trash2, X } from 'lucide-react';
import { useTenant } from '../../context/TenantContext';
import { Uom, UomBand, UOM_BANDS, UomBoard } from '../../types';
import { addUom, deleteUom, getUoms, updateUom } from '../../services/masters.service';
import { DeleteConfirm, ExportPair, IconAction, ListToolbar, Pick, StatStrip, StatusPills, Text } from '../Masters/masterUi';
import { SearchBox } from '../../components/common/SearchBox';
import { ExportColumn } from '../../utils/exportTable';
import { useScreenReload } from '../../utils/screenReload';

const columns: ExportColumn<Uom>[] = [
  { label: 'Code', value: (u) => u.code },
  { label: 'Name', value: (u) => u.name },
  { label: 'Band', value: (u) => u.band },
  { label: 'In Use', value: (u) => String(u.inUse) },
  { label: 'Status', value: (u) => (u.isActive ? 'On' : 'Off') },
];

// A unit that is on the board but switched off cannot be picked on a new product, so the
// card says which of the two states it is in rather than leaving a greyed box to guess at.
const Switch: React.FC<{ on: boolean; label: string; onFlip: () => void; busy?: boolean }> = ({ on, label, onFlip, busy }) => (
  <button
    type="button" role="switch" aria-checked={on} aria-label={`${on ? 'Switch off' : 'Switch on'} ${label}`}
    disabled={busy} onClick={onFlip}
    className={`flex items-center gap-1.5 shrink-0 disabled:opacity-50 ${busy ? 'cursor-wait' : ''}`}
  >
    <span className={`text-[10px] font-black tracking-wide ${on ? 'text-[#178a80]' : 'text-gray-400'}`}>
      {on ? 'ON' : 'OFF'}
    </span>
    <span className={`relative w-9 h-5 rounded-full transition-colors ${on ? 'bg-[#2ec4b6]' : 'bg-gray-300'}`}>
      <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} />
    </span>
  </button>
);

const UnitCard: React.FC<{
  u: Uom;
  editing: boolean;
  busy: boolean;
  error: string | null;
  onEdit: () => void;
  onCancelEdit: () => void;
  onSaveEdit: (body: { code: string; name: string; band: UomBand }) => void;
  onFlip: () => void;
  onDeleteConfirmed: () => void;
}> = ({ u, editing, busy, error, onEdit, onCancelEdit, onSaveEdit, onFlip, onDeleteConfirmed }) => {
  const [code, setCode] = useState(u.code);
  const [name, setName] = useState(u.name);
  const [band, setBand] = useState<UomBand>(u.band);
  const [armDelete, setArmDelete] = useState(false);

  useEffect(() => {
    if (editing) { setCode(u.code); setName(u.name); setBand(u.band); setArmDelete(false); }
  }, [editing, u.code, u.name, u.band]);

  return (
    <div className={`nb-card p-3 flex flex-col gap-2 ${u.isActive ? 'ring-1 ring-[#2ec4b6]/45' : 'opacity-75'}`}>
      {editing ? (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <input
              className="input-xenith w-24 uppercase nums"
              value={code}
              maxLength={8}
              onChange={e => setCode(e.target.value.toUpperCase())}
              placeholder="CODE"
              aria-label={`Code of ${u.code}`}
            />
            <input
              className="input-xenith flex-1 min-w-0"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Unit name"
              aria-label={`Name of ${u.code}`}
              autoFocus
            />
          </div>
          <Pick value={band} onChange={e => setBand(e.target.value as UomBand)} aria-label={`Band of ${u.code}`}>
            {UOM_BANDS.map(b => <option key={b} value={b}>{b}</option>)}
          </Pick>
          {error && <p className="text-[11px] font-semibold text-red-700 leading-snug">{error}</p>}
          <div className="flex items-center gap-2">
            <button
              type="button" disabled={busy || !name.trim()} onClick={() => onSaveEdit({ code: code.trim(), name: name.trim(), band })}
              className="btn-xenith-success disabled:opacity-50"
            >
              <Plus className="w-3.5 h-3.5" /> {busy ? 'Saving...' : 'Save'}
            </button>
            <button type="button" onClick={onCancelEdit} className="btn-xenith-outline"><X className="w-3.5 h-3.5" /> Cancel</button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-start gap-2">
            <span className="shrink-0 text-[11px] font-black tracking-wider text-[#178a80] bg-teal-50 border border-[#2ec4b6]/30 rounded px-1.5 py-0.5 nums">
              {u.code}
            </span>
            <span className="min-w-0 flex-1 text-xs font-bold text-gray-800 leading-snug">{u.name}</span>
            <Switch on={u.isActive} label={`${u.code} ${u.name}`} busy={busy} onFlip={onFlip} />
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {u.inUse > 0 && (
              <span
                title={u.usedBy.length ? `On: ${u.usedBy.join(', ')}` : undefined}
                className="text-[10px] font-bold text-gray-600 bg-gray-100 rounded-full px-2 py-0.5 tabular-nums"
              >
                In Use ({u.inUse})
              </span>
            )}
            {u.inUse === 0 && (
              <span className="text-[10px] font-semibold text-gray-400">Not used by any product or item</span>
            )}
            <span className="ml-auto flex items-center gap-0.5">
              {armDelete ? (
                <DeleteConfirm
                  confirmLabel="Delete"
                  keepLabel={`Keep ${u.code}`}
                  onConfirm={() => { setArmDelete(false); onDeleteConfirmed(); }}
                  onCancel={() => setArmDelete(false)}
                />
              ) : (
                <>
                  <IconAction title={`Edit ${u.code} ${u.name}`} tone="primary" onClick={onEdit}>
                    <Pencil className="w-4 h-4" />
                  </IconAction>
                  <IconAction
                    title={u.inUse > 0
                      ? `${u.code} is the unit on ${u.inUse} record${u.inUse > 1 ? 's' : ''} — move them to another unit to delete it`
                      : `Delete ${u.code} ${u.name}`}
                    tone={u.inUse > 0 ? 'muted' : 'danger'}
                    disabled={u.inUse > 0}
                    onClick={u.inUse > 0 ? undefined : () => setArmDelete(true)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </IconAction>
                </>
              )}
            </span>
          </div>
          {error && <p className="text-[11px] font-semibold text-red-700 leading-snug">{error}</p>}
        </>
      )}
    </div>
  );
};

export const UnitsOfMeasurement: React.FC = () => {
  const { tenantSlug, branchId } = useTenant();
  const [board, setBoard] = useState<UomBoard | null>(null);
  const [rows, setRows] = useState<Uom[]>([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchEpoch, setSearchEpoch] = useState(0);
  const [adding, setAdding] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newBand, setNewBand] = useState<UomBand>('Count & Units');
  const [editId, setEditId] = useState<number | null>(null);
  // One line of refusal at a time, named by the card it came from, so a rejected rename or
  // delete explains itself where the reader just clicked instead of vanishing into a toast.
  const [error, setError] = useState<{ at: 'add' | number; msg: string } | null>(null);
  const [busyId, setBusyId] = useState<number | 'add' | null>(null);

  // The whole board comes back on every read: the counts of records using each unit belong
  // to the server, so a switch, an add or a product edit cannot leave this page stale.
  const refresh = useCallback(() => {
    setLoading(true);
    getUoms(tenantSlug, branchId, search, status)
      .then(d => { setBoard(d); setRows(d.data); })
      .finally(() => setLoading(false));
  }, [tenantSlug, branchId, search, status]);

  useEffect(() => { refresh(); }, [refresh]);
  useScreenReload(refresh);

  const stats = board?.stats ?? { total: 0, active: 0, inactive: 0, inUse: 0 };
  const bands = board?.bands ?? [];

  const grouped = useMemo(() => {
    const order = new Map(bands.map((b, i) => [b.name, i]));
    const byBand = new Map<UomBand, Uom[]>();
    rows.forEach(r => {
      const list = byBand.get(r.band) ?? [];
      list.push(r);
      byBand.set(r.band, list);
    });
    return [...byBand.entries()]
      .sort((a, b) => (order.get(a[0]) ?? 99) - (order.get(b[0]) ?? 99))
      .map(([name, units]) => ({
        name,
        units: units.sort((x, y) => x.code.localeCompare(y.code)),
        counts: bands.find(b => b.name === name)
      }));
  }, [rows, bands]);

  const activeFilters = [
    search && `search “${search}”`,
    status && `switched ${status.toLowerCase()}`
  ].filter(Boolean) as string[];

  const clearAll = () => {
    setStatus('');
    if (search) { setSearch(''); setSearchEpoch(n => n + 1); }
  };

  const run = async (at: number | 'add', fn: () => Promise<unknown>) => {
    setBusyId(at);
    setError(null);
    try {
      await fn();
      refresh();
    } catch (e) {
      setError({ at, msg: (e as Error).message });
    } finally {
      setBusyId(null);
    }
  };

  const submitAdd = () => {
    const name = newName.trim();
    if (!name) return;
    run('add', async () => {
      await addUom(tenantSlug, branchId, { code: newCode.trim(), name, band: newBand });
      setAdding(false); setNewCode(''); setNewName('');
      if (status === 'Inactive') setStatus('');
    });
  };

  const shownCount = rows.length;

  return (
    <div className="space-y-4">
      <div className="nb-card p-0 overflow-hidden">
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-4 pt-3.5 pb-3.5">
          <div className="min-w-0">
            <h2 className="page-title">Units of Measurement (UOM) Switchboard</h2>
            <p className="text-xs text-gray-500 mt-1 max-w-3xl leading-snug">
              Turn individual units On or Off, add names, or delete units nothing references. Products and the Item Master
              pick their unit from the units switched on here, and “In Use” counts the records that already carry each one.
            </p>
            <div className="mt-2">
              <StatStrip stats={[
                { label: 'Total Units', value: loading ? '…' : stats.total },
                { label: 'Active Units', value: loading ? '…' : stats.active, tone: 'ok' },
                { label: 'Inactive Units', value: loading ? '…' : stats.inactive, tone: 'warn' },
                { label: 'Units In Use', value: loading ? '…' : stats.inUse, title: 'Units carried by at least one product or item' }
              ]} />
            </div>
          </div>
          <ListToolbar addLabel="ADD UNIT" onAdd={() => { setAdding(a => !a); setError(null); }} />
        </div>

        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-t border-gray-100">
          <SearchBox key={searchEpoch} className="w-64 max-w-full"
            placeholder="Search unit codes, names..." onSearch={setSearch} />
          <StatusPills value={status} onChange={setStatus} counts={[
            { value: '', label: 'All', count: stats.total },
            { value: 'Active', label: 'On', count: stats.active },
            { value: 'Inactive', label: 'Off', count: stats.inactive }
          ]} />
          <span className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <span className="text-[11px] text-gray-500 tabular-nums">
              {shownCount} of {stats.total} unit{stats.total === 1 ? '' : 's'} showing
            </span>
            <ExportPair title="Units of Measurement (UOM) Switchboard" filename="units-of-measurement"
              columns={columns} rows={rows} />
          </span>
        </div>

        {adding && (
          <div className="flex flex-wrap items-end gap-2 px-4 py-3 border-t border-gray-100 bg-gray-50/70">
            <div className="w-24">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Code</label>
              <Text value={newCode} maxLength={8}
                onChange={e => setNewCode(e.target.value.toUpperCase())}
                onKeyDown={e => { if (e.key === 'Enter') submitAdd(); }}
                placeholder="auto" className="nums uppercase" />
            </div>
            <div className="flex-1 min-w-40 max-w-xs">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Name <span className="text-red-500">*</span></label>
              <Text value={newName} autoFocus
                onChange={e => setNewName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') submitAdd(); }}
                placeholder="e.g. Trolley, Drum, 50 kg Bag" />
            </div>
            <div className="w-52 max-w-full">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Band</label>
              <Pick value={newBand} onChange={e => setNewBand(e.target.value as UomBand)}>
                {UOM_BANDS.map(b => <option key={b} value={b}>{b}</option>)}
              </Pick>
            </div>
            <button type="button" onClick={() => { setAdding(false); setNewCode(''); setNewName(''); setError(null); }}
              className="btn-xenith-outline"><X className="w-3.5 h-3.5" /> Cancel</button>
            <button type="button" disabled={busyId === 'add' || !newName.trim()} onClick={submitAdd}
              className="btn-xenith-success disabled:opacity-50">
              <Plus className="w-3.5 h-3.5" /> {busyId === 'add' ? 'Saving...' : 'Save'}
            </button>
            {error?.at === 'add' && (
              <p className="w-full text-[11px] font-semibold text-red-700">{error.msg}</p>
            )}
          </div>
        )}
      </div>

      {loading && !rows.length ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-2.5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="nb-card p-3"><div className="h-12 rounded bg-gray-100 animate-pulse" /></div>
          ))}
        </div>
      ) : !grouped.length ? (
        <div className="nb-card p-8 text-center">
          <p className="text-sm font-semibold text-gray-700">
            {activeFilters.length ? 'No units match these filters' : 'No units on the board yet'}
          </p>
          <p className="text-xs text-gray-500 mt-1 max-w-md mx-auto leading-snug">
            {activeFilters.length
              ? <>Nothing answers to {activeFilters.join(' and ')}. <button type="button" onClick={clearAll} className="font-bold text-[#1f8c82] hover:underline">Clear every filter</button> to see all {stats.total}.</>
              : 'Press ADD UNIT to put the first one on the board — products can only be counted in a unit that is listed here.'}
          </p>
        </div>
      ) : grouped.map(g => (
        <div key={g.name} className="nb-card p-0 overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 border-b border-gray-100 bg-gray-50/60">
            <Ruler className="w-3.5 h-3.5 text-[#2ec4b6]" />
            <h3 className="card-title">{g.name}</h3>
            <span className="text-[11px] font-bold text-gray-500 tabular-nums">
              {g.counts ? `${g.counts.active} / ${g.counts.total} Active` : `${g.units.length} shown`}
            </span>
            {search && <span className="text-[11px] text-gray-400 tabular-nums">· {g.units.length} matching</span>}
          </div>
          <div className="p-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-2.5">
            {g.units.map(u => (
              <UnitCard
                key={u.id}
                u={u}
                editing={editId === u.id}
                busy={busyId === u.id}
                error={error?.at === u.id ? error.msg : null}
                onEdit={() => { setEditId(u.id); setError(null); }}
                onCancelEdit={() => setEditId(null)}
                onSaveEdit={body => run(u.id, async () => {
                  await updateUom(tenantSlug, branchId, u.id, body);
                  setEditId(null);
                })}
                onFlip={() => run(u.id, () => updateUom(tenantSlug, branchId, u.id, { isActive: !u.isActive }))}
                onDeleteConfirmed={() => run(u.id, async () => {
                  await deleteUom(tenantSlug, branchId, u.id);
                  if (editId === u.id) setEditId(null);
                })}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
