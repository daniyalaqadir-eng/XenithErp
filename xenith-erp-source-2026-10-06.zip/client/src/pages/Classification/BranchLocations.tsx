import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { Branch } from '../../types';
import { MapPin, ExternalLink, Building2 } from 'lucide-react';

function osmEmbed(b: Branch): string {
  const lat = b.latitude ?? 0;
  const lng = b.longitude ?? 0;
  const d = 0.01;
  const bbox = `${lng - d},${lat - d},${lng + d},${lat + d}`;
  return `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat},${lng}`;
}

function gmapsLink(b: Branch): string {
  return `https://www.google.com/maps/search/?api=1&query=${b.latitude ?? 0},${b.longitude ?? 0}`;
}

export const BranchLocations: React.FC = () => {
  const { branches } = useTenant();
  const [selectedId, setSelectedId] = useState<number>(branches[0]?.id ?? 0);
  const selected = branches.find(b => b.id === selectedId) || branches[0];

  return (
    <div className="space-y-4">
      <div className="mb-1">
        <h1 className="page-title">Branch Locations</h1>
        <p className="text-xs text-gray-500 mt-0.5">
          Pick a branch on the left to see the address printed on its papers and the ground it sits on. A branch only
          maps once Setup → Branches holds its latitude and longitude.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Branch list */}
        <div className="nb-card p-0 overflow-hidden">
          <div className="px-4 py-2.5 border-b border-gray-100 flex items-center gap-2">
            <Building2 size={14} className="text-gray-400"/>
            <h2 className="card-title">Branches</h2>
            <span className="ml-auto text-[11px] text-gray-400 tabular-nums">{branches.length}</span>
          </div>
          {!branches.length ? (
            <p className="px-4 py-5 text-xs text-gray-500 leading-snug">
              This company has no branch on the book yet. Add one under Setup → Branches and it will show up here with
              its address and map.
            </p>
          ) : (
          <div className="divide-y divide-gray-100">
            {branches.map(b => (
              <button
                key={b.id}
                onClick={() => setSelectedId(b.id)}
                className={`w-full text-left px-4 py-2.5 hover:bg-gray-50 ${b.id === selectedId ? 'bg-blue-50' : ''}`}
              >
                <div className={`text-xs font-semibold ${b.id === selectedId ? 'text-blue-700' : 'text-gray-800'}`}>
                  {b.name} {b.isMain && <span className="ml-1 text-[9px] font-bold text-[#2ec4b6]">(MAIN)</span>}
                </div>
                <div className="text-[11px] text-gray-500">{b.code} · {b.city || 'No city set'}</div>
              </button>
            ))}
          </div>
          )}
        </div>

        {/* Map + details */}
        <div className="md:col-span-2 space-y-4">
          {selected ? (
            <>
              <div className="nb-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-bold text-gray-900">{selected.name}</h2>
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mt-1">
                      <MapPin size={12} className="text-[#2ec4b6]"/>
                      <span>{selected.address || 'No address on file'}{selected.city ? `, ${selected.city}` : ''}</span>
                    </div>
                    <div className="text-[11px] text-gray-400 mt-1">
                      Lat {selected.latitude?.toFixed(4) ?? '—'}, Lng {selected.longitude?.toFixed(4) ?? '—'}
                    </div>
                  </div>
                  {selected.latitude != null && selected.longitude != null ? (
                    <a
                      className="btn-xenith-outline"
                      href={gmapsLink(selected)}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink size={13}/>Open in Google Maps
                    </a>
                  ) : (
                    <span className="text-[11px] text-gray-400 max-w-40 text-right leading-snug">
                      Google Maps opens once this branch has coordinates.
                    </span>
                  )}
                </div>
              </div>

              <div className="nb-card p-0 overflow-hidden">
                {selected.latitude != null && selected.longitude != null ? (
                  <iframe
                    title={`Map of ${selected.name}`}
                    className="w-full h-80 border-0"
                    src={osmEmbed(selected)}
                  />
                ) : (
                  <div className="h-80 flex flex-col items-center justify-center gap-1 text-center px-6">
                    <MapPin size={20} className="text-gray-300"/>
                    <span className="text-sm font-semibold text-gray-600">
                      {selected.name} has no coordinates on file
                    </span>
                    <span className="text-xs text-gray-400 max-w-72 leading-snug">
                      Set its latitude and longitude under Setup → Branches and the map for this branch appears here.
                    </span>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="nb-card p-8 text-center">
              <p className="text-sm font-semibold text-gray-600">Nothing to map yet</p>
              <p className="text-xs text-gray-400 mt-1 max-w-md mx-auto leading-snug">
                A branch added under Setup → Branches shows its address and map here.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
