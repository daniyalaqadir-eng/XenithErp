/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        // One family for the whole interface, one for headings. `sans` replaces Tailwind's
        // default, so every existing font-sans and every inheriting element follows along.
        sans: ['Manrope', 'Segoe UI', 'system-ui', 'Arial', 'sans-serif'],
        display: ['Plus Jakarta Sans', 'Manrope', 'Segoe UI', 'system-ui', 'Arial', 'sans-serif']
      },

      /* Neither face in this pairing is drawn heavier than 800, so every `font-black` in
         the app was asking the browser for a 900 that does not exist — and getting one
         smeared out of 800 by the synthesiser, which reads as fuzzy rather than emphatic.
         Naming the heaviest cut the fonts actually have fixes all hundred of them at once. */
      fontWeight: {
        black: '800',
      },

      /* The whole product was written against `text-xs`, and against 10/11px literals, because
         the screen it copied was built for a projector. A ledger is read at arm's length on a
         laptop, so the ladder starts at 13 and every step is a point wider than the old one.
         Redefining the named sizes lifts every screen at once; index.css lifts the literals. */
      fontSize: {
        xs:   ['0.8125rem', { lineHeight: '1.25rem' }],   // 13px — body of a table, a form
        sm:   ['0.875rem',  { lineHeight: '1.375rem' }],  // 14px — page copy
        base: ['0.9375rem', { lineHeight: '1.5rem' }],    // 15px
        lg:   ['1.0625rem', { lineHeight: '1.5rem' }],    // 17px
        xl:   ['1.1875rem', { lineHeight: '1.6rem' }],    // 19px
        '2xl': ['1.375rem',  { lineHeight: '1.75rem' }],  // 22px
        '3xl': ['1.625rem',  { lineHeight: '2rem' }],     // 26px
        '4xl': ['2rem',      { lineHeight: '2.25rem' }],  // 32px
        '5xl': ['2.5rem',    { lineHeight: '1' }],
      },

      /* Corners carry most of the difference between a 2015 admin panel and a current one.
         Controls and cards sit a step apart so a card still visibly contains its buttons. */
      borderRadius: {
        none: '0',
        sm: '0.375rem',   // 6px — chips, ticks
        DEFAULT: '0.5rem',// 8px — bare `rounded`, the old 4px
        md: '0.625rem',   // 10px
        lg: '0.875rem',   // 14px
        xl: '1.125rem',   // 18px
        '2xl': '1.375rem',
        '3xl': '1.625rem',
      },

      // Elevation is a theme property, not a fixed grey: index.css gives the night surfaces
      // black shadows and a lit hairline, and every `shadow-*` in the app follows.
      boxShadow: {
        sm: 'var(--elev-1)',
        DEFAULT: 'var(--elev-2)',
        md: 'var(--elev-2)',
        lg: 'var(--elev-3)',
        xl: 'var(--elev-4)',
        pop: 'var(--elev-3)',
        card: 'var(--elev-card)',
      },

      /* Semantic surfaces, so a new page never has to guess a grey. The variables are the
         same ones the theme switcher writes, which is why `bg-surface` is already correct
         in all twelve themes while `bg-gray-100` needs the override layer to move. */
      colors: {
        xenith: {
          blue: '#1e88e5',
          navy: '#2d3748',
          teal: '#00bcd4',
          gray: '#f4f6f9',
          sidebar: '#f8fafc',
          border: '#e2e8f0',
          success: '#2ec4b6',
          warning: '#ff9f1c'
        },
        canvas: 'var(--bg)',
        surface: 'var(--surface)',
        'surface-2': 'var(--surface-2)',
        'surface-3': 'var(--surface-3)',
        line: 'var(--line)',
        'line-strong': 'var(--line-strong)',
        ink: 'var(--text)',
        'ink-muted': 'var(--muted)',
        'ink-faint': 'var(--faint)',
        accent: 'var(--accent)',
        'accent-ink': 'var(--accent-text)',
        'accent-wash': 'var(--accent-weak)',
      },
    },
  },
  plugins: [],
}
