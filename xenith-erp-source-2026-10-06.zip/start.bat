@echo off
title Xenith ERP Runner
echo ========================================================
echo Starting Xenith ERP (Server + Client)...
echo ========================================================
start cmd /k "cd /d %~dp0server && npm.cmd run dev"
timeout /t 3 /nobreak >nul
start cmd /k "cd /d %~dp0client && npm.cmd run dev"
echo.
echo Server running on: http://localhost:5000
echo Frontend running on: http://localhost:5173
echo.
echo Opening browser in 3 seconds...
timeout /t 3 /nobreak >nul
start http://localhost:5173
