# Xenith ERP & Cloud Accounting Software

**Xenith ERP** is a multi-tenant, multi-branch accounting suite with invoicing, purchase, banking
and accounting capabilities: one Express API that owns the books, and one React SPA that reads them.

## Architecture

- **Backend (`/server`)**: Node.js, Express, TypeScript, REST API matching the exact Xenith API URL structure (`/api/:tenantSlug/:branchId/...`).
- **Frontend (`/client`)**: Vite, React, TypeScript, TailwindCSS, Lucide/FontAwesome Icons, replicating the Nebular & Bootstrap UI design.

## Features Implemented from Chunks & Screenshots

1. **Dashboard**:
   - Financial Metrics: Total Inflow, Total Outflow, Net Profit, Cash & Bank Balances.
   - Accounts Receivable Aging (Current, 1-30, 31-60, 61-90, 90+ days).
   - Income vs Expense visualization.
   - Business Health Ratios (Gross Profit %, Net Profit %, Operating Expenses).
   - Top Customers & Top Products tables.
   - Real-time Cash & Bank Accounts balances.

2. **Customer / Detail B Groups (Chunk 2350)**:
   - Add/Edit form with 100 max length and validation.
   - Multi-branch assignment selector (`app-detail-selector`).
   - 3-Way Save actions: **Save & Close**, **Save Only**, **Save & New**.
   - Mark as Default status and Activity audit logs.

3. **Recurring Invoices / Sale Invoice Templates (Chunk 761)**:
   - Dynamic line-item pricing engine with fractional units.
   - Multi-discount types: Percentage, Fixed Amount, and Custom Price override.
   - Tax rate calculation and Net amount.
   - Number-to-Words in South Asian Lakhs/Crores.
   - Lifecycle: Draft, Pending, Approved, Copy, Revise.

4. **Customer Settlements & Tax Adjusted Entries (Chunk 761)**:
   - Linked payment adjustment ledger.
   - Tax Authority Invoice Number support (e.g. FBR Sales Tax compliance).
   - Delete settlement modal with automatic un-adjustment.

5. **Purchase Invoices / Vendor Bills (Chunk 883)**:
   - Real-time KPI banner: Total Bills, Approved, Pending, Void.
   - Full bill workflow: Approve, Void, Create Purchase Return.

6. **Product Packaging & Carton Breakup Modal (Chunk 883)**:
   - Auto packaging number generator (`DOC[1001]`, `DOC[1002]`).
   - Carton size, pack quantity, and running total pieces.
   - Live remaining quantity calculation with dynamic green/red alert indicator.

## How to Run

### Option 1 (`xenith.bat`) — the program, on any PC
Double click `xenith.bat`. One window, one address: **`http://localhost:5000`**. It runs the
compiled API, which hands out the built screens too, so there is no second server to keep
alive. It checks four things before starting and says which one failed: that Node is
installed, that this Node can open the book (`node:sqlite` needs **Node 22.5 or newer**, and
24 is what the workbench runs), that nothing else is already answering on that port — two
processes holding one book is not safe, so it refuses rather than starting — and that the
folders it needs are built, installing the three runtime packages or building either side from
source when they are not. `npm` is only asked for when something genuinely has to be made, so
a folder copied whole from this PC runs on a PC that has no npm at all.

Settings live in `xenith.env` beside the batch file. Copy `xenith.env.example` to start one; it
is where the vendor's sign-in key goes, and it is not versioned. **Without that file there is
no vendor door**, so a new company cannot be opened on that installation — the owner account
still works.

### Option 2 (`start.bat`) — the workbench, with hot reload
Double click `start.bat` for the two-window development setup: the API on 5000 and Vite on
5173 with `/api` proxied to it. Edit a screen and the browser redraws without a rebuild.
Open `http://localhost:5173`.

### Option 3 (Command Line):
1. **Start the backend** — the API listens on port 5000:
   ```powershell
   cd server
   npm.cmd run dev
   ```
2. **Start the frontend** — Vite serves on 5173 and proxies `/api` to the backend:
   ```powershell
   cd client
   npm.cmd run dev
   ```
3. Open `http://localhost:5173` in your browser.

All three work from wherever the folder happens to sit, so nothing has to be re-pathed when
the project is copied. `npm.cmd` is written out because PowerShell blocks the bare `npm` shim
on some machines; the root `package.json` offers the same two steps as `npm run server` and
`npm run client`. `npm run build` in `server` compiles `src` to `dist`, and `npm start` runs
that compiled copy — build again after editing, or the books will be kept by yesterday's code.
`xenith.bat` is the one that remembers to do this for you.

## Environment

| Variable | Side | What it does |
| --- | --- | --- |
| `PORT` | server | Port the API listens on (default `5000`) |
| `XENITH_HOST` | server | Interface to bind to; `127.0.0.1` keeps the port off the network |
| `XENITH_TRUST_PROXY` | server | How many proxies stand in front (`1` behind nginx). Unset, every customer arrives as `127.0.0.1` and shares one login budget |
| `XENITH_ORIGIN` | server | Extra browser origins allowed to call the API, comma-separated |
| `XENITH_DB` | server | SQLite file the books live in (default `server/data/xenith.db`) |
| `XENITH_DB_OFF=1` | server | Keep everything in memory only — nothing is written to disk |
| `XENITH_FRESH=1` | server | Start from the seed data instead of the stored snapshot |
| `XENITH_DEMO_DATA=0` | server | Never load the sample trading history — not at start-up and not on press |
| `XENITH_SIGNUPS=1` | server | Allow new companies to register themselves |
| `XENITH_STATIC` | server | Serve a built frontend from this folder instead of Vite |
| `XENITH_VENDOR_USER` | server | The vendor's sign-in name — a door, not a row in any company's book |
| `XENITH_VENDOR_PASSWORD` | server | His key. Eight characters or more, or the pair counts as no vendor at all |
| `XENITH_VENDOR_NAME` | server | The job title a buyer's screens show for him (default `Vendor`); his real name never appears |
| `VITE_API_PROXY` | client | Where the dev proxy sends `/api` (default `http://localhost:5000`) |

`server/data/` holds the live customer book. It is not versioned and it is not a test
database — back it up before running anything that writes to it.

**The book kept its name through the renaming.** This software used to be called something else,
and a shop that was already trading kept its records in a file named after that old name. The store
now opens `xenith.db`; if only the older file is there, it copies both books into
`_before-rename-<stamp>/` beside them and moves the trading one across before anything is opened. A
move that cannot finish stops the server rather than opening an empty book next to a full one, so a
half-done renaming never costs a day of trading.

**What a client sees on first opening.** A book that has never held a single record of its own
fills itself once, at start-up, with a sample trading history: 12 products on a category tree, 6
customers, 3 vendors, three months of goods-receiving onto purchase bills and payments out,
invoices with receipts and returns, counter bills, cash and bank vouchers, a journal entry, petty
cash, a stock adjustment and a stock audit — around 114 papers in all. Every one of them was raised
through the normal saving routes, so the ledgers tie, no stock card is negative and the reports
have something to answer with. Two conditions say a book is "never been opened": it holds no rows,
and this installation found nothing written for it on disk. A shop that has been trading — on an
empty book or a full one — is never filled, and filling one is never repeated.
**Settings → Company Settings → Sample Data** loads the set again or takes every one of those rows
back out; the clear deletes through the same routes a clerk uses, so anything a real record has come
to depend on refuses to go rather than break. `XENITH_DEMO_DATA=0` turns the whole thing off, and the
test suite runs with it off.

**Putting a whole price list on the shelf.** **Masters → Products → BULK UPLOAD** takes the client's
own spreadsheet: a `.xlsx` or a CSV (up to 6 MB, 5 000 rows) is read by what it holds rather than by
its name, so a heading under a three-line title block is still found, and money typed as `Rs. 480/-`,
`PKR 1,450.50` or `(980.25)` comes out as one figure. The modal's first step downloads a sample
workbook whose columns, units, categories and brands are this company's own. Nothing is written until
**Import**: the file is checked row by row first, and each row that fails says why — a unit off the
switchboard, a brand that is not on the list, a name already on the book. The rows that pass then go
through the very door the ADD PRODUCT form uses (`products:add` is the wall, and no role that cannot
add one product can add four hundred), so they arrive with a code, the master's own unit name and the
tax line the product card carries. Opening stock is deliberately not a column: the stock ledger holds
what is on the shelf, and a figure here would be overwritten the first time that ledger is read.

**Putting it on a domain** is a different job from running it on the workbench: it needs a VPS
(not shared hosting), a process systemd keeps alive, nginx with a certificate, and a nightly copy
of the book. `DEPLOY.md` is that runbook, and `deploy/` holds the three files it installs.

## Checking the arithmetic

`npm test` runs the suite in `server/test/`. It boots the real API on a spare port against a
fresh seed book in the OS temp folder — never `server/data` — and checks the money: half-up
rounding, journals that must balance to the paisa, the tax a product card carries, what a till
bill leaves in the drawer and on the shelf, document numbers that are never handed out twice, and
what a clerk may not do. Dates come from the server's own Karachi clock, so the suite passes in
any timezone.

```bash
npm test                            # the whole suite, about 15 seconds
npm --prefix server run test:watch  # re-run on change
npm --prefix server run typecheck   # src and test together
```

`bash _scratch/run-verify.sh _scratch/verify-phase5.mjs` boots the API against a throwaway
database on a spare port, runs one of the standalone scripts of money assertions against it, then
shuts the server down and deletes the database. `VERIFY_PORT` picks the port so two of them can
run side by side. Those scripts are what these tests grew out of: `_scratch/` is not versioned,
and `npm test` is the gate.
