@echo off
setlocal
title Xenith ERP

rem ── Xenith ERP launcher ────────────────────────────────────────────────────────
rem One window, one address: http://localhost:5000. This runs the built program, so the
rem folder can sit on any drive of any PC — every path below is read from where this file
rem itself is standing, never from a letter written into it.
set "ROOT=%~dp0"

echo ============================================================
echo  Xenith ERP
echo ============================================================

where node >nul 2>nul
if errorlevel 1 goto :no_node

rem The book is opened by node:sqlite, a module that comes with Node itself but only from
rem 22.5 on. Asking node is surer than reading a version number out of `node -v`.
node -e "require('node:sqlite')" >nul 2>nul
if errorlevel 1 goto :old_node

rem Settings are plain text beside this file: the vendor's own sign-in key, a different
rem port, a different database file. Nothing here is required to start.
if not exist "%ROOT%xenith.env" goto :no_env
echo Using the settings in xenith.env
for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%ROOT%xenith.env") do set "%%a=%%b"
:no_env

if "%PORT%"=="" set "PORT=5000"

rem ── what this copy is missing, and whether npm is needed to fill it in ───────
rem A folder copied whole from the workbench usually needs none of this: the packages and both
rem builds come along with it. npm is only asked for when something genuinely has to be made.
set "NEED="
if not exist "%ROOT%server\node_modules\express\" set "NEED=deps"
if not exist "%ROOT%server\dist\index.js" set "NEED=build"
if not exist "%ROOT%client\dist\index.html" set "NEED=build"
if not defined NEED goto :ready
where npm.cmd >nul 2>nul
if errorlevel 1 goto :no_npm
if not "%NEED%"=="deps" goto :no_deps
echo First run on this PC: installing what the API needs...
pushd "%ROOT%server" & call npm.cmd install --omit=dev & popd
:no_deps
if exist "%ROOT%server\dist\index.js" goto :no_server_build
echo Building the API...
pushd "%ROOT%server" & call npm.cmd install & call npm.cmd run build & popd
:no_server_build
if exist "%ROOT%client\dist\index.html" goto :no_client_build
echo Building the screens... this takes a minute the first time.
pushd "%ROOT%client" & call npm.cmd install & call npm.cmd run build & popd
:no_client_build
:ready

rem One process per book. If something already answers on this port it is most likely this
rem same program in another window, and two of them holding one database file is how a book
rem gets written by yesterday's memory. Refuse before opening anything.
netstat -ano | findstr /i ":%PORT% " | findstr /i "listening" >nul && goto :port_busy

rem XENITH_STATIC is what makes this one process answer both the pages and the API on one
rem address. NODE_ENV is deliberately left alone: on http://localhost a session cookie marked
rem Secure is never stored, and the login would look broken.
set "XENITH_STATIC=%ROOT%client\dist"

echo.
echo  Open this in a browser:   http://localhost:%PORT%
if defined XENITH_DB (echo  The book is:              %XENITH_DB%) else (echo  The book is:              %ROOT%server\data\xenith.db)
echo  Stop it with Ctrl+C, or by closing this window.
echo.
pushd "%ROOT%server"
start "" /b powershell -NoProfile -Command "Start-Sleep 3; Start-Process 'http://localhost:%PORT%'"
node dist\index.js
popd
echo.
echo The server stopped.
pause
exit /b 0

:no_node
echo.
echo  Node.js is not installed on this PC, or it is not on the command path.
echo  Install Node 24 from https://nodejs.org - the setup adds node and npm by itself.
echo  Then CLOSE this window, open xenith.bat again.
echo.
pause
exit /b 1

:no_npm
echo.
echo  Node is installed, but npm is not on the command path, and this copy still needs it
echo  to fill in what is missing: %NEED%.
echo  Usual reason: Node was installed without the npm option, or the folder was moved by
echo  hand from another PC that had a different Node.
echo.
echo  Two ways forward, either one is fine:
echo    1. Reinstall Node 24 from https://nodejs.org with its defaults, then run this again.
echo    2. Copy the WHOLE project folder again, including server\node_modules, server\dist,
echo       client\dist - then nothing has to be installed on this PC at all.
echo.
pause
exit /b 1

:old_node
echo.
echo  Node is installed, but this one cannot open the book: node:sqlite is missing.
echo  Found:
node -v
echo  Install Node 24 (anything from 22.5 up works) from https://nodejs.org and try again.
echo.
pause
exit /b 1

:port_busy
echo.
echo  Something already answers on port %PORT%, so this was not started.
echo  Most likely the program is already open in another window, or the development server
echo  is running. Two copies holding one book at the same time is not safe.
echo.
echo  Close that other window, or put a line saying PORT=5001 into xenith.env and try again.
echo.
pause
exit /b 1
