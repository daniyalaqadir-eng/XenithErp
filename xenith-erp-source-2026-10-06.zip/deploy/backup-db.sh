#!/usr/bin/env bash
# ─── deploy/backup-db.sh ──────────────────────────────────────────────────────
# A copy of the book, taken while the API is running.
#
#   ./deploy/backup-db.sh                 # -> deploy/backups/xenith-20261002-0140.db.gz
#   DEST=/var/backups/xenith ./deploy/backup-db.sh
#   KEEP_DAYS=30 ./deploy/backup-db.sh    # also forget copies older than a month
#
# Cron, nightly, before every deploy, and once a week to somewhere that is not this disk —
# a backup that dies with the server is not a backup:
#
#   17 3 * * *  CD/STAMP=1 DEST=/var/backups/xenith /opt/xenith-erp/deploy/backup-db.sh >> /var/log/xenith-backup.log 2>&1
#
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Where the database is: the environment wins, then deploy/.env, then the usual path.
DB="${XENITH_DB:-}"
if [ -z "$DB" ] && [ -f "$HERE/.env" ]; then
  DB="$(sed -n 's/^[[:space:]]*XENITH_DB=//p' "$HERE/.env" | tail -1 | tr -d '"')"
fi
DB="${DB:-/opt/xenith-erp/server/data/xenith.db}"

DEST="${DEST:-$HERE/backups}"
KEEP_DAYS="${KEEP_DAYS:-0}"

if [ ! -f "$DB" ]; then
  echo "backup-db: no database at $DB — check XENITH_DB in deploy/.env" >&2
  exit 1
fi

mkdir -p "$DEST"
STAMP="$(date +%Y%m%d-%H%M%S)"
NAME="$(basename "$DB")"
OUT="$DEST/${NAME%.db}-$STAMP.db"

# VACUUM INTO asks SQLite itself for a consistent snapshot, which is what makes this safe to
# run while the API is answering: it reads a committed view out into a new file and never
# touches the live database or its write-ahead log. The copy that comes out is one file, with
# no -wal beside it to replay.
# (No apostrophes inside these two snippets: bash holds them inside a single-quoted argument.)
node -e '
const { DatabaseSync } = require("node:sqlite");
const [src, dst] = process.argv.slice(1);
const q = String.fromCharCode(39);
const lit = (s) => q + String(s).split(q).join(q + q) + q;
const db = new DatabaseSync(src, { readOnly: true });
try { db.exec(`VACUUM INTO ${lit(dst)}`); } finally { db.close(); }
' "$DB" "$OUT" || {
  # Some builds refuse a read-only open; the same snapshot taken normally is just as good.
  node -e '
  const { DatabaseSync } = require("node:sqlite");
  const [src, dst] = process.argv.slice(1);
  const q = String.fromCharCode(39);
  const lit = (s) => q + String(s).split(q).join(q + q) + q;
  const db = new DatabaseSync(src);
  try { db.exec(`VACUUM INTO ${lit(dst)}`); } finally { db.close(); }
  ' "$DB" "$OUT"
}

gzip -f "$OUT"
SIZE="$(du -h "$OUT.gz" | cut -f1)"
echo "backup-db: wrote $OUT.gz ($SIZE)"

# Old copies are only touched when asked for, and only ones this script could have written:
# a filename that is not <name>-<timestamp>.db.gz is left alone, and so is everything else
# in the directory.
if [ "$KEEP_DAYS" -gt 0 ] 2>/dev/null; then
  find "$DEST" -maxdepth 1 -type f -name "${NAME%.db}-*.db.gz" -mtime +"$KEEP_DAYS" -print -delete
fi
