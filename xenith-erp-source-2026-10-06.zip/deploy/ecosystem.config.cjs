// PM2 keeps the API alive across a reboot and a crash. Start it from the repository root:
//
//   pm2 start deploy/ecosystem.config.cjs
//   pm2 save                      # so `pm2 startup`'s systemd unit brings it back on boot
//
// PM2 does not read .env files, and the machine's secrets have no business sitting in a file
// that is committed, so the values live in deploy/.env and this script hands them over.
const { existsSync, readFileSync } = require('fs');
const { join, resolve } = require('path');

const ROOT = resolve(__dirname, '..');

function fromEnvFile(path) {
  if (!existsSync(path)) return {};
  const out = {};
  for (const line of readFileSync(path, 'utf8').split(/\r?\n/)) {
    if (!line || line.trim().startsWith('#')) continue;
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  return out;
}

const env = {
  NODE_ENV: 'production',
  PORT: '5000',
  XENITH_HOST: '127.0.0.1',
  XENITH_DB: join(ROOT, 'server', 'data', 'xenith.db'),
  ...fromEnvFile(join(__dirname, '.env'))
};

module.exports = {
  apps: [{
    name: 'xenith-erp',
    cwd: join(ROOT, 'server'),
    script: 'dist/index.js',
    // One process, fork mode, always. A company's whole book lives in this process's memory
    // and reaches the disk a few hundred milliseconds after a save; two instances would each
    // hold their own copy of it and answer from whichever one happened to take the write.
    exec_mode: 'fork',
    instances: 1,
    // A killed process still gets its chance to flush: store.ts answers SIGINT/SIGTERM/SIGHUP
    // by emptying the write queue before it exits, so a restart loses nothing that was saved.
    kill_timeout: 5000,
    max_memory_restart: '1G',
    env,
    // Uncomment to pin the exact binary when several Node versions share the box
    // (nvm's `which node` is what PM2 inherits, which is not always the one you tested with):
    // interpreter: '/usr/bin/node',
    out_file: join(ROOT, 'logs', 'api-out.log'),
    error_file: join(ROOT, 'logs', 'api-error.log'),
    time: true,
    merge_logs: true
  }]
};
