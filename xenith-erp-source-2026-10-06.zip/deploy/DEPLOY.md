# Xenith ERP — deploy to your own domain

This is the **PM2** shape of the deployment. `DEPLOY.md` at the repository root walks the same
install with **systemd** (`deploy/xenith-erp.service`), which is the one this box uses. Both end
at the same place — nginx on 80/443, the API on `127.0.0.1:5000`, the book on that disk — but
they put the code in different directories (`/opt/xenith-erp` here, `/opt/xenith` there) and the
book in different files. Pick one guide and stay in it; mixing the two paths gives a server
that starts and an empty database.

Target: one Linux VPS, nginx in front, PM2 keeping the API alive, the SQLite book on that
server's disk. This is the shape the app was built for: after a production boot the API
answers on `127.0.0.1:5000` only, and nginx is the single public door for both the pages and
`/api`.

Roughly 45 minutes the first time, about 3 minutes for every update after that.

---

## 0. What the machine has to have

| | |
|---|---|
| OS | Ubuntu 22.04 / 24.04, Debian 12 (anything with a recent nginx) |
| RAM | 2 GB minimum. 1 GB works with the swap below. |
| **Node** | **24.x.** Not negotiable: the store uses the built-in `node:sqlite`, which only exists from Node **22.5**. Ubuntu's `apt install nodejs` gives you something older. |
| Disk | ~1 GB for the two `node_modules` plus whatever the book grows to (a few hundred MB today) |
| Ports open to the world | **80 and 443 only.** 5000 stays on loopback. |

Check the Node you end up with:

```bash
node -v          # must print v22.5 or newer; the app is developed and tested on v24
```

Swap, if the box is 1 GB — the client build (`vite`) is the only step that gets hungry:

```bash
sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

---

## 1. Node 24 and the tools

```bash
curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
sudo apt-get install -y nodejs nginx git rsync
sudo npm install -g pm2
node -v && pm2 -v
```

---

## 2. Put the code on the box

Create the deploy user (optional but tidy — everything below assumes it):

```bash
sudo adduser --disabled-password --gecos "" xenith
sudo usermod -aG sudo xenith
sudo mkdir -p /opt/xenith-erp && sudo chown xenith:xenith /opt/xenith-erp
```

**Do not copy `node_modules`, `server/dist` or `client/dist` from Windows.** The binaries in
`node_modules` are built for your laptop, and the two `dist` folders are cheap to rebuild on
the server. From your work machine, the folder that goes is `D:\MY SOFTWARE - Copy`:

```bash
# run this from your Windows Git Bash, not on the VPS
rsync -av --delete \
  --exclude node_modules --exclude dist --exclude .env --exclude data \
  --exclude scratch --exclude _removed --exclude '*.log' \
  "/d/MY SOFTWARE - Copy/" xenith@YOUR-SERVER:/opt/xenith-erp/
```

`--exclude data` matters: that is where the live book lives, and a first deploy should not
overwrite it with the one from your desk. When it *is* your desk's book you want on the
server — which is how this starts — copy it deliberately in step 5.

Then, on the VPS:

```bash
cd /opt/xenith-erp/server && npm ci
cd /opt/xenith-erp/client && npm ci
cd /opt/xenith-erp/server && npm run build      # src/*.ts -> dist/index.js
cd /opt/xenith-erp/client && npm run build      # src -> dist/index.html + dist/assets/*
```

Both builds must finish without errors. `npm ci` (not `npm install`) so the lockfiles on the
box match the ones this code was tested with.

---

## 3. Configure the environment

```bash
cd /opt/xenith-erp
cp deploy/.env.example deploy/.env
nano deploy/.env                    # set XENITH_DB to the absolute path, and your domain in XENITH_ORIGIN
chmod 600 deploy/.env
sudo mkdir -p /opt/xenith-erp/server/data /opt/xenith-erp/logs
sudo chown -R xenith:xenith /opt/xenith-erp/server/data /opt/xenith-erp/logs
```

The three values that actually matter:

- `NODE_ENV=production` — turns on the page serving, HSTS and `Secure` cookies.
- `XENITH_VENDOR_USER` / `XENITH_VENDOR_PASSWORD` — the seller's own sign-in. Once it is set, the
  Subscription screen and new companies leave the buyer's hands and are answered `403 … ask your
  vendor` for him. A production build without it refuses both doors, so fill them in.
- `XENITH_OWNER_NAME` / `_EMAIL` / `_USERNAME` / `_PASSWORD` — the first owner of a *brand new*
  book, so the copy you hand over carries the buyer's name and his own first password instead of
  the workbench's `demo@xenitherp.com` / `demo123`. An opened database keeps its own rows.
- `XENITH_HOST=127.0.0.1` — the API stops answering on the public interface.
- `XENITH_DB=/opt/xenith-erp/server/data/xenith.db` — absolute, or a restart from another
  working directory quietly starts on a different (empty) book.

---

## 4. Bring it up

```bash
cd /opt/xenith-erp
pm2 start deploy/ecosystem.config.cjs
pm2 logs xenith-erp --lines 40        # read it, then Ctrl-C
pm2 save
pm2 startup systemd -u xenith --hp /home/xenith   # follow the one command it prints
```

A healthy boot says, in this order:

```
[xenith:auth] re-hashed N stored password(s) with scrypt      (only on the first boot)
[xenith:web] pages served from /opt/xenith-erp/client/dist
[Xenith ERP API] Server listening on http://127.0.0.1:5000
[Xenith ERP API] today is Thursday (from <clock source>)
```

Confirm it is local-only — from the VPS this answers, from your laptop it must not:

```bash
curl -I http://127.0.0.1:5000/                       # 200
curl -I http://YOUR-SERVER-PUBLIC-IP:5000/           # connection refused — correct
ss -ltnp | grep 5000                                 # 127.0.0.1:5000, not 0.0.0.0:5000
```

The line about `today` waiting means the box has no outbound DNS yet; the app keeps running
on its fallback clock and retries.

One thing this test cannot do: with `NODE_ENV=production` the session cookie is marked
`Secure`, so a browser will not carry it over plain `http://` — the sign-in looks fine (the
token also travels as a header) and the screens it loads after that fall over. Open the site
through its https address instead. That is the flag working, not a bug: a key that travels in
the clear is no key.

---

## 5. Move the real book onto the server

Skip this if the VPS should start from the seed data.

The database is safe to copy while nothing is writing to it — which means stopping the API on
the desk machine first (close `start.bat` / the `tsx watch` window), because the write queue
holds the last few hundred milliseconds of saves:

1. Stop the local server.
2. Copy these three files if they exist — the log beside the database is part of it:
   `server/data/xenith.db`, `server/data/xenith.db-wal`, `server/data/xenith.db-shm`
3. Put them in `/opt/xenith-erp/server/data/` and fix ownership:
   ```bash
   sudo chown xenith:xenith /opt/xenith-erp/server/data/*
   ```
4. `pm2 restart xenith-erp`.

**Do not leave the scratch books up there.** `scratch-*.db` files are test books from
development; only `xenith.db` (or whatever `XENITH_DB` names) is real.

After the first login, check the boot actually rebuilt the same numbers you had: open the
dashboard and compare the receivable and the stock total with what you last saw.

---

## 6. nginx

```bash
sudo cp /opt/xenith-erp/deploy/nginx.xenitherp.conf /etc/nginx/sites-available/xenitherp.conf
sudo nano /etc/nginx/sites-available/xenitherp.conf    # your domain (twice) + the /opt paths if you used others
sudo ln -s /etc/nginx/sites-available/xenitherp.conf /etc/nginx/sites-enabled/
sudo mkdir -p /var/www/certbot
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

`nginx -t` will fail on the two `ssl_certificate` lines until the certificate exists. For the
first minute, comment those two lines out, pass the test, and let certbot write them in step 7.

---

## 7. HTTPS certificate

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d xenitherp.com -d www.xenitherp.com
sudo systemctl reload nginx
```

certbot edits the site file with the real certificate paths and an auto-renew hook. Check it:

```bash
sudo certbot renew --dry-run
```

**If Cloudflare proxies the record (the orange cloud),** set SSL/TLS mode to **Full (strict)**.
Cloudflare-to-origin traffic then also arrives over TLS, and the origin's own certificate has
to be valid — which Let's Encrypt gives it. With grey-cloud (DNS only) nothing changes.

---

## 8. DNS

At your registrar (or Cloudflare, if the zone lives there):

| Type | Name | Value |
|---|---|---|
| A | `@` | the VPS IPv4 |
| A | `www` | the VPS IPv4 |
| AAAA | `@`, `www` | the VPS IPv6, only if the box has one and nginx listens on it (it does) |

Wait for `dig +short xenitherp.com` to return the server's address before the next step, or
certbot will fail its http-01 challenge. If Cloudflare proxies, keep the record **grey cloud
only** until the certificate is issued, then turn the proxy back on.

---

## 9. Firewall

Last, once https works — locking the box down before the site answers makes a mistake hard to
notice:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo ufw default deny incoming && sudo ufw enable
sudo ufw status verbose
```

Port 5000 must not appear in that list. It is reachable from the server itself only, because
`XENITH_HOST` is `127.0.0.1` — the firewall is the second lock, not the only one.

---

## 10. Before you tell anyone the address

This is the part that is actually worth the ten minutes. Go through it in order.

1. **The owner account still has its seed password.** `muhammad` / `demo@xenitherp.com` /
   `demo123` — and `demo123` is printed in the source. Sign in as the owner, open
   **Company menu → Change Password**, and set something you have not used elsewhere. Also fix
   the email if `demo@xenitherp.com` is not an address you own.
2. **The demo staff accounts are real logins.** Ayesha, Bilal, Sana and Usman all answer to
   `demo123`. On **Settings → Users**, either set a password for each one you intend to keep
   (the same screen resets a password for you) or switch off the ones you do not. The API
   prints a warning naming every account still on that password at each boot — so
   `pm2 logs xenith-erp` tells you whether you missed one. Once this book is on
   **Settings → Users**, treat that warning as something to see *zero* of.
3. **Passwords are hashed, and the boot said so.** The first production boot re-hashes
   whatever plain text the old build left behind; `server/data/xenith.db` no longer contains a
   readable password for anyone. Verify with:
   ```bash
   strings /opt/xenith-erp/server/data/xenith.db | grep -c demo123     # 0
   ```
4. **Set up the email** in **Settings → Company Settings → Email**, with a real SMTP login
   (for Gmail-family accounts that means an app password, not your normal one). Until this is
   complete, *Forgot password* answers honestly that it cannot send, and an administrator
   resets passwords from the Users screen — that is by design, and the reset code is never
   shown in the browser any more.
5. **Test the lockout:** five wrong passwords on any account and the sixth attempt is refused
   for 15 minutes, even with the right one.
6. **Test that a stranger gets nothing:**
   ```bash
   curl -s -o /dev/null -w '%{http_code}\n' https://xenitherp.com/api/abc-company679/38039/saleInvoices
   # 401 — the registers no longer answer an anonymous caller
   ```
7. **Back the book up**, and put the copy somewhere that is not this server:
   ```bash
   DEST=/var/backups/xenith /opt/xenith-erp/deploy/backup-db.sh
   ```
   Then the cron line at the top of `deploy/backup-db.sh`, and once a week `rsync` the folder
   off-box.
8. **Read the logs once** — `pm2 logs xenith-erp --lines 200`. Anything you do not understand
   now is cheaper than understanding it during a fire.

---

## 11. Updating the software later

```bash
# from Windows Git Bash
rsync -av --delete \
  --exclude node_modules --exclude dist --exclude .env --exclude data \
  --exclude scratch --exclude _removed --exclude '*.log' \
  "/d/MY SOFTWARE - Copy/" xenith@YOUR-SERVER:/opt/xenith-erp/

# on the VPS
DEST=/var/backups/xenith KEEP_DAYS=30 /opt/xenith-erp/deploy/backup-db.sh   # always back up first
cd /opt/xenith-erp/server && npm ci && npm run build
cd /opt/xenith-erp/client && npm ci && npm run build
pm2 restart xenith-erp
```

A restart costs a couple of seconds, and nothing is lost: `SIGTERM` is answered by emptying
the write queue before the process exits. Open the site after every deploy and look at one
number you know.

**Rollback:** `pm2 stop xenith-erp`, replace `server/data/xenith.db` with the gzipped copy from
before (`gunzip -c backups/xenith-<stamp>.db > server/data/xenith.db`), move any
`xenith.db-wal`/`-shm` that is lying beside it into a dated folder so the old log is not
replayed onto the restored file, `chown xenith:xenith`, `pm2 start`.

---

## 12. What this deployment does *not* do yet

Honest list, so nobody is surprised later:

- **Several businesses, one box: the isolation is there now.** Each company's people, roles,
  loyalty ledger, adjustment types and valuations live in its own book, and a session is minted
  inside one of them — a token from firm A is answered with the same 404 that an unregistered
  name gets, so no address lets one customer read another's ledger. Sign-in searches every book
  for the name and lets the password decide; if two firms hold the same name *and* the same
  password, the server refuses to guess and asks for the company code instead. The vendor opens
  each new firm and names its first account with a real password (at least 8 characters when a
  vendor key is armed), so a sold copy never opens on the seeded one.
  What still keeps this one-tenant-per-box friendly: the API is a single process that holds every
  company it has opened in memory, so a hundred customers on one VPS want a hundred `XENITH_DB`
  files and one process each (see §13) — not one process reading one shared book.
- **No rate limit beyond sign-in and password reset.** Five bad passwords lock an identifier;
  an authenticated client can still hammer the report endpoints. nginx's `limit_req` on
  `/api/` is the place to add it when you care.
- **No 2FA**, no audit trail of failed logins to a file (`failedLogins` is in memory, so a
  restart clears a lockout in progress).
- **Sessions live in memory and are persisted with the rest of the book**, which is why a
  restart does not log anyone out — but it also means the API is one process, and `pm2
  cluster`/multiple instances would each hold their own copy of the ledger. Never scale this
  horizontally by adding instances; add a bigger box.
- **Deleting a company** from the software is not implemented; a company row can be switched
  off in the screens, but nothing here destroys its book (deliberately).
- **WhatsApp reminders** need your own Meta phone number id and a permanent token before
  anything leaves the server (**Settings → Company Settings**, WhatsApp tab).
- The `X-Frame-Options`/CSP posture is thin by design: printing works by writing a full
  document into a new window, and a Content-Security-Policy strict enough for that would be
  loose anyway. Do not add a blanket CSP without re-testing every PRINT button.

---

## 13. Selling to several businesses from one VPS

The isolation is per company now (§12), so one installation *can* hold several customers' books.
Two shapes work, and the difference is memory, not safety:

**One process, many books** — the vendor opens each firm from the company menu in the header
(ADD COMPANY: firm name, the owner's email, and the password he starts with), then sells it its
modules on the Subscription screen. Every firm's people, roles and ledgers are its own; a session
cannot step into another firm's address. This is the shape the screens are built for, and the one
to start with.

**One process per customer** — each firm gets its own `XENITH_DB` file and its own unit:

```bash
# /etc/systemd/system/xenith-firm-a.service  (copy of xenith-erp.service)
Environment=XENITH_DB=/var/lib/xenith/firm-a.db
Environment=XENITH_ORIGIN=https://firm-a.example.com
ExecStart=/usr/bin/node dist/index.js
```

and one nginx `server {}` block per hostname pointing at its own `XENITH_PORT`.

Choose this second shape when a customer's book is big enough that holding it in memory beside
the others starts to cost, or when he wants his file off the machine next to his neighbours'.
Do not run two processes against **one** database file: each holds its own copy of the ledger,
so they would write over each other.

Either way the vendor key is armed once in the environment (`XENITH_VENDOR_USER`,
`XENITH_VENDOR_PASSWORD`, `XENITH_VENDOR_NAME`) and is **not** a row in any customer's Users list —
see §9 of the root `DEPLOY.md`.
