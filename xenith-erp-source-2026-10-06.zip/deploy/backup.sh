#!/usr/bin/env bash
# One copy of the book per day, kept for a fortnight.
#
# `.backup` is the only safe way to copy a live WAL database: a plain `cp` of xenith.db can catch
# it between two writes and give a copy that opens and is wrong. The command writes a new, fully
# checkpointed file, so the customer's own process never pauses.
#
# Install as root:
#   sudo cp deploy/backup.sh /usr/local/bin/xenith-backup && sudo chmod 755 /usr/local/bin/xenith-backup
#   sudo crontab -e          # and add the line DEPLOY.md gives, once a night
set -euo pipefail

DB="${XENITH_DB:-/var/lib/xenith/xenith.db}"
DEST="${XENITH_BACKUP_DIR:-/var/backups/xenith}"
KEEP_DAYS="${XENITH_BACKUP_KEEP:-14}"

if [ ! -f "$DB" ]; then
  echo "xenith-backup: no book at $DB — nothing to do" >&2
  exit 1
fi

mkdir -p "$DEST"
STAMP="$(date +%F-%H%M)"
OUT="$DEST/xenith-$STAMP.db"

sqlite3 "$DB" ".backup '$OUT'"

# A copy that cannot be opened is not a backup. This reads the copied file, not the live one.
if ! sqlite3 "$OUT" "PRAGMA integrity_check;" | grep -q '^ok$'; then
  echo "xenith-backup: $OUT failed integrity_check — kept for looking at, not for restoring" >&2
  gzip -f "$OUT"
  exit 1
fi

sqlite3 "$OUT" "VACUUM;" && gzip -9 -f "$OUT"
chmod 640 "$OUT.gz"

find "$DEST" -name 'xenith-*.db.gz' -mtime "+$KEEP_DAYS" -delete
echo "xenith-backup: wrote $OUT.gz"
